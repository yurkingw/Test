import React, { createContext, useCallback, useContext, useMemo, useState } from 'react';

// Simple in-memory cache to persist review data between routes without forcing users to re-enter.
const ReviewCacheContext = createContext(null);

export const ReviewCacheProvider = ({ children }) => {
  const [cache, setCache] = useState({});

  const updateCache = useCallback((key, value) => {
    setCache((prev) => {
      if (prev[key] === value) return prev;
      return { ...prev, [key]: value };
    });
  }, []);

  const clearCache = useCallback((key) => {
    setCache((prev) => {
      if (!(key in prev)) return prev;
      const next = { ...prev };
      delete next[key];
      return next;
    });
  }, []);

  const clearAllCaches = useCallback(() => setCache({}), []);

  const contextValue = useMemo(
    () => ({
      cache,
      updateCache,
      clearCache,
      clearAllCaches,
    }),
    [cache]
  );

  return <ReviewCacheContext.Provider value={contextValue}>{children}</ReviewCacheContext.Provider>;
};

export const useReviewCache = (key) => {
  const ctx = useContext(ReviewCacheContext);
  if (!ctx) {
    throw new Error('useReviewCache must be used within a ReviewCacheProvider');
  }
  const { cache, updateCache, clearCache, clearAllCaches } = ctx;
  return {
    cachedValue: cache[key],
    saveCache: (value) => updateCache(key, value),
    clearCacheForKey: () => clearCache(key),
    clearAllCaches,
  };
};
