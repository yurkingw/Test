import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import apiClient from '../api';

const STORAGE_KEY = 'csad_user_role';
const UserContext = createContext(null);

const DEFAULT_USER = { name: '', role: '' };
const ROLES = ['Requestor', 'Reviewer', 'Peer Reviewer', 'Auditor'];
const PRESET_USERS = [
  { name: 'itso', role: 'Requestor', password: 'password' },
  { name: 'reviewera', role: 'Reviewer', password: 'password' },
  { name: 'reviewerb', role: 'Reviewer', password: 'password' },
  { name: 'auditor', role: 'Auditor', password: 'password' },
];

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(DEFAULT_USER);

  const updateUser = useCallback((next) => {
    setUser((prev) => {
      const merged = { ...prev, ...next };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
      } catch {
        // ignore
      }
      return merged;
    });
  }, []);

  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed?.role) {
          setUser(parsed);
        }
      }
    } catch {
      // ignore storage errors
    }
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    if (params.get('aad_login') !== '1') return;
    const aadUser = params.get('aad_user') || '';
    const aadRole = params.get('aad_role') || '';
    const aadDisplay = params.get('aad_display') || '';
    const aadEmail = params.get('aad_email') || '';
    if (aadUser && aadRole) {
      updateUser({
        name: aadUser,
        role: aadRole,
        displayName: aadDisplay,
        email: aadEmail,
        authType: 'sso',
      });
    }
    params.delete('aad_login');
    params.delete('aad_user');
    params.delete('aad_role');
    params.delete('aad_display');
    params.delete('aad_email');
    const next = `${window.location.pathname}${params.toString() ? `?${params.toString()}` : ''}`;
    window.history.replaceState({}, '', next);
  }, [updateUser]);

  const value = useMemo(
    () => ({
      user,
      setRole: (role) => updateUser({ role }),
      setName: (name) => updateUser({ name }),
      setUserByName: (name, password = 'password') => {
        const preset = PRESET_USERS.find((u) => u.name === name);
        if (preset) {
          if (preset.password && password !== preset.password) {
            throw new Error('Invalid password');
          }
          updateUser(preset);
        } else {
          updateUser({ name });
        }
        // After switching user, redirect to home to refresh context-sensitive pages.
        if (typeof window !== 'undefined') {
          window.location.assign('/');
        }
      },
      login: (username, password, authType = 'local') => {
        if (authType === 'local') {
          const preset = PRESET_USERS.find((u) => u.name === username);
          if (!preset) throw new Error('User not found');
          if (preset.password && password !== preset.password) throw new Error('Invalid password');
          updateUser({ name: preset.name, role: preset.role, authType: 'local' });
        } else {
          const base = apiClient.defaults.baseURL || 'http://localhost:8000/api/v1';
          const prefix = base.replace(/\/$/, '');
          window.location.assign(`${prefix}/auth/aad/login`);
          return;
        }
        if (typeof window !== 'undefined') {
          window.location.assign('/');
        }
      },
      logout: () => {
        updateUser(DEFAULT_USER);
        if (typeof window !== 'undefined') {
          window.location.assign('/');
        }
      },
      roles: ROLES,
      presetUsers: PRESET_USERS,
    }),
    [user, updateUser]
  );

  return <UserContext.Provider value={value}>{children}</UserContext.Provider>;
};

export const useUser = () => {
  const ctx = useContext(UserContext);
  if (!ctx) throw new Error('useUser must be used within UserProvider');
  return ctx;
};
