import apiClient from '../api';

export const listBlueprintTemplatesApi = async () => {
  const response = await apiClient.get('/blueprint-templates/');
  return response.data || {};
};
