import apiClient from '../api';

export const listJiraTicketsApi = async ({ query, page = 1, pageSize = 20 } = {}) => {
  const params = { page, page_size: pageSize };
  if (query) params.query = query;
  const response = await apiClient.get('/jira/tickets', { params });
  return response.data || { items: [], total: 0, page, page_size: pageSize, last_refreshed: null };
};

export const refreshJiraTicketsApi = async () => {
  const response = await apiClient.post('/jira/tickets/refresh');
  return response.data || {};
};
