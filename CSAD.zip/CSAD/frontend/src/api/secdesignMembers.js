import apiClient from '../api';

export const listSecDesignMembersApi = async () => {
  const response = await apiClient.get('/secdesign-members');
  return Array.isArray(response.data) ? response.data : [];
};
