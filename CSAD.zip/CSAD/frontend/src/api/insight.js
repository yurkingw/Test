import apiClient from '../api';

export const listSecurityDomainsApi = async () => {
  const response = await apiClient.get('/insight/domains');
  return response.data || { items: [], last_refreshed: null };
};

export const listSecurityZonesApi = async () => {
  const response = await apiClient.get('/insight/zones');
  return response.data || { items: [], last_refreshed: null };
};

export const listSecurityComponentsApi = async () => {
  const response = await apiClient.get('/insight/components');
  return response.data || { items: [], last_refreshed: null };
};

export const listSubnetBoundariesApi = async () => {
  const response = await apiClient.get('/insight/subnet-boundaries');
  return response.data || { items: [], last_refreshed: null };
};

export const listProtocolPortsApi = async () => {
  const response = await apiClient.get('/insight/protocol-ports');
  return response.data || { items: [], last_refreshed: null };
};

export const refreshSecurityDomainsZonesApi = async () => {
  const response = await apiClient.post('/insight/refresh');
  return response.data || {};
};
