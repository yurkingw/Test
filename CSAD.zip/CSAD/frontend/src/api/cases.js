import apiClient from '../api';

const normalizeCase = (item) => {
  if (!item) return null;
  return {
    id: item.id,
    name: item.name || item.id,
    description: item.description || '',
    status: item.status,
    reviewType: item.review_type || item.reviewType || 'control_exception',
    ticketId: item.ticket_id || item.ticketId || '',
    owner: item.owner_id || item.owner || '',
    designPayload: item.design_payload || item.designPayload || null,
    finalSnapshot: item.final_snapshot || item.finalSnapshot || null,
    findings: item.findings || [],
    evidence: item.evidence || {},
    reviewerComment: item.reviewerComment || item.reviewer_comment || '',
    reviewerCommentFiles: item.reviewerCommentFiles || item.reviewer_comment_files || [],
    reviewerExtraFindings: item.reviewerExtraFindings || item.reviewer_extra_findings || [],
    createdAt: item.created_at || item.createdAt,
    updatedAt: item.updated_at || item.updatedAt,
  };
};

export const listCasesApi = async (filters = {}) => {
  const params = {};
  if (filters.status) params.status = filters.status;
  if (filters.owner) params.owner_id = filters.owner;
  const res = await apiClient.get('/cases', { params });
  return Array.isArray(res.data) ? res.data.map(normalizeCase) : [];
};

export const getCaseApi = async (id) => {
  if (!id) return null;
  const safeId = encodeURIComponent(id);
  const res = await apiClient.get(`/cases/${safeId}`);
  return normalizeCase(res.data);
};

export const createCaseApi = async ({ owner, ticketId, reviewType = 'control_exception', id, name }) => {
  const payload = {
    id: id || `CASE-${Date.now()}`,
    name: name || `Case ${new Date().toISOString()}`,
    review_type: reviewType,
    ticket_id: ticketId || '',
    owner_id: owner || '',
    status: 'draft',
  };
  const res = await apiClient.post('/cases', payload);
  return normalizeCase(res.data);
};

export const saveCaseApi = async (id, partial) => {
  const safeId = encodeURIComponent(id);
  const res = await apiClient.patch(`/cases/${safeId}`, {
    ...partial,
    review_type: partial.reviewType,
    ticket_id: partial.ticketId,
    owner_id: partial.owner,
    design_payload: partial.designPayload,
    final_snapshot: partial.finalSnapshot,
    reviewer_comment: partial.reviewerComment,
    reviewer_comment_files: partial.reviewerCommentFiles,
    reviewer_extra_findings: partial.reviewerExtraFindings,
    evidence: partial.evidence,
  });
  return normalizeCase(res.data);
};

export const cancelCaseApi = async (id) => {
  const safeId = encodeURIComponent(id);
  await apiClient.post(`/cases/${safeId}/status`, { to_status: 'cancelled' });
  return getCaseApi(id);
};

export const confirmAndCancelCase = async (id) => {
  const ok = window.confirm('Cancel will delete this case. Proceed?');
  if (!ok) return null;
  try {
    return await cancelCaseApi(id);
  } catch (e) {
    throw e;
  }
};
