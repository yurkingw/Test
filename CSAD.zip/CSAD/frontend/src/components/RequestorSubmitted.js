import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const containerStyle = { margin: '40px auto', maxWidth: '720px', padding: '24px', backgroundColor: '#f8fbff', borderRadius: '10px', border: '1px solid #d7e3f4', boxShadow: '0 6px 16px rgba(0,0,0,0.06)', textAlign: 'left' };
const buttonStyle = { backgroundColor: '#1976D2', color: '#fff', border: 'none', padding: '12px 18px', borderRadius: '6px', cursor: 'pointer', fontSize: '16px', marginTop: '16px' };

const RequestorSubmitted = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const caseId = location.state?.caseId || 'Pending';

  return (
    <div style={containerStyle}>
      <h2>Review Submitted to SecDesign</h2>
      <p>The review has been submitted to SecDesign. Case ID: <strong>{caseId}</strong></p>
      <p>You can monitor your cases from the case status menu (top bar). You will be notified when SecDesign returns or closes this case.</p>
      <button type="button" style={buttonStyle} onClick={() => navigate('/')}>Return to Dashboard</button>
    </div>
  );
};

export default RequestorSubmitted;
