import React from 'react';
import { ensureFileMetaArray } from '../utils/fileUtils';
import { getAttachmentUrl } from '../utils/attachments';

const boxStyle = { border: '1px solid #e0e0e0', borderRadius: '8px', padding: '10px', background: '#fff' };
const label = (text) => <div style={{ fontWeight: 'bold', marginTop: '6px' }}>{text}</div>;

const formatImplementedControls = (controls) => {
  if (!controls || typeof controls !== 'object') return controls || '—';
  const lines = [];
  const entries = [
    { key: 'authn_authz', label: 'AuthN & AuthZ' },
    { key: 'access_control', label: 'Access Control' },
    { key: 'audit_logging', label: 'Audit & Logging' },
    { key: 'encryption', label: 'Encryption' },
    { key: 'privileged_access', label: 'Privileged Access' },
    { key: 'dlp', label: 'DLP' },
  ];
  entries.forEach(({ key, label: lbl }) => {
    const entry = controls[key] || {};
    if (!entry.value) return;
    const desc = entry.description ? `: ${entry.description}` : '';
    lines.push(`${lbl} = ${entry.value}${desc}`);
  });
  return lines.length ? lines.join('; ') : '—';
};

const FormReadonly = ({ checklist }) => {
  if (!checklist) return <p>No form data.</p>;
  const normalizedFiles = ensureFileMetaArray(checklist.architecture_files);

  const renderFile = (file, idx) => {
    if (!file) return null;
    const meta = typeof file === 'object' ? file : { name: file, type: '', dataUrl: null, path: '' };
    const href = meta.path ? getAttachmentUrl(meta.path) : (meta.dataUrl || '#');
    const isImage = meta.type?.startsWith?.('image') && !!href;
    return (
      <div key={idx} style={{ marginTop: '4px' }}>
        <a
          href={href}
          onClick={(e) => {
            if (!href || href === '#') {
              e.preventDefault();
            }
          }}
          download={meta.name || 'download'}
          style={{ color: '#1976D2' }}
        >
          {meta.name || 'attachment'}
        </a>
        {isImage ? (
          <div style={{ marginTop: '4px' }}>
            <img src={href} alt={meta.name} style={{ maxWidth: '240px', borderRadius: '6px', border: '1px solid #e0e0e0' }} />
          </div>
        ) : null}
      </div>
    );
  };

  return (
    <div style={{ background: '#fafbff', padding: '10px', borderRadius: '8px', border: '1px solid #dce3f7' }}>
      {label('Control Exception Basis')}
      <div style={boxStyle}>
        {['full_designs_unavailable', 'asset_risk_accepted', 'other_exception'].map((key) => (
          <div key={key}>{checklist.basis_options?.[key] ? '☑️' : '⬜️'} {key.replace(/_/g, ' ')}</div>
        ))}
      </div>

      {label('Scenario(s)')}
      <div style={boxStyle}>
        {['firewall_flowdb_flow', 'proxy_flow', 'privileged_access', 'enable_poc_testing', 'other_exception_context'].map((key) => (
          <div key={key}>{checklist.scenario_options?.[key] ? '☑️' : '⬜️'} {key.replace(/_/g, ' ')}</div>
        ))}
        {checklist.scenario_other_context ? <div style={{ marginTop: '4px' }}>Context: {checklist.scenario_other_context}</div> : null}
      </div>

      {label('Business Justification')}
      <div style={boxStyle}>{checklist.business_justification || '—'}</div>

      {label('Architecture Description')}
      <div style={boxStyle}>{checklist.architecture_description || '—'}</div>
      {normalizedFiles?.length ? (
        <div style={{ marginTop: '6px' }}>
          <div style={{ fontWeight: 'bold' }}>Architecture files:</div>
          {normalizedFiles.map(renderFile)}
        </div>
      ) : null}

      {label('Data Perimeter')}
      <div style={boxStyle}>
        <div>ARR 2.0: {checklist.data_perimeter?.arr20 || '—'}</div>
        <div>ISC: {checklist.data_perimeter?.isc || '—'}</div>
        <div>PII: {checklist.data_perimeter?.pii || '—'}</div>
        <div>MNPI: {checklist.data_perimeter?.mnpi || '—'}</div>
        <div>External transfer: {checklist.data_perimeter?.external_transfer || '—'}</div>
        <div>PROD data: {checklist.data_perimeter?.prod_data || '—'}</div>
        <div>COD MDEX: {checklist.data_perimeter?.prod_mdex || '—'}</div>
        <div>COD MSSIP: {checklist.data_perimeter?.prod_mssip || '—'}</div>
      </div>

      {label('Data Connection')}
      <div style={boxStyle}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', minWidth: '1200px', borderCollapse: 'collapse', fontSize: '0.9rem' }}>
            <thead>
              <tr style={{ background: '#eef2ff' }}>
                <th style={{ border: '1px solid #e0e0e0', padding: '6px' }}>#</th>
                <th style={{ border: '1px solid #e0e0e0', padding: '6px' }}>Control Exception Type</th>
                <th style={{ border: '1px solid #e0e0e0', padding: '6px' }}>Src Object</th>
                <th style={{ border: '1px solid #e0e0e0', padding: '6px' }}>Src Sec Domain</th>
                <th style={{ border: '1px solid #e0e0e0', padding: '6px' }}>Src Sec Zone</th>
                <th style={{ border: '1px solid #e0e0e0', padding: '6px' }}>Dst Object</th>
                <th style={{ border: '1px solid #e0e0e0', padding: '6px' }}>Dst Sec Domain</th>
                <th style={{ border: '1px solid #e0e0e0', padding: '6px' }}>Dst Sec Zone</th>
                <th style={{ border: '1px solid #e0e0e0', padding: '6px' }}>Accessed Protocol &amp; Port or Method</th>
                <th style={{ border: '1px solid #e0e0e0', padding: '6px' }}>Payload</th>
                <th style={{ border: '1px solid #e0e0e0', padding: '6px' }}>Implemented Controls</th>
                <th style={{ border: '1px solid #e0e0e0', padding: '6px' }}>Purpose</th>
              </tr>
            </thead>
            <tbody>
              {(checklist.data_connections || []).map((row, idx) => (
                <tr key={row.id || idx}>
                  <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{idx + 1}</td>
                  <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{(row.control_exception_types || []).join(', ')}</td>
                  <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.src_object}</td>
                  <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.src_domain || row.src_domain_zone}</td>
                  <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.src_zone}</td>
                  <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.dst_object}</td>
                  <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.dst_domain || row.dst_domain_zone}</td>
                  <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.dst_zone}</td>
                  <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.accessed_protocol}</td>
                  <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.payload_data}</td>
                  <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{formatImplementedControls(row.implemented_controls)}</td>
                  <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.purpose}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {checklist.firewall_details?.length ? (
        <>
          {label('Detailed Firewall Flow')}
          <div style={boxStyle}>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', minWidth: '1400px', borderCollapse: 'collapse', fontSize: '0.9rem' }}>
                <thead>
                  <tr style={{ background: '#eef2ff' }}>
                    {['#', 'Data Connection #', 'Src EONID', 'Src App', 'Src Component', 'Src Domain', 'Src Zone', 'Src Subnet', 'Dst EONID', 'Dst App', 'Dst Component', 'Dst Domain', 'Dst Zone', 'Dst Subnet', 'Protocol|Port', 'Expiry', 'Business Justification'].map((h) => (
                      <th key={h} style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {checklist.firewall_details.map((row, idx) => (
                    <tr key={row.id || idx}>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{idx + 1}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.connection_ref}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.source_eonid}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.source_application}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.source_component}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.source_domain}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.source_zone}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.source_subnet}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.destination_eonid}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.destination_application}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.destination_component}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.destination_domain}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.destination_zone}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.destination_subnet}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{(row.protocol_ports || []).join(', ')}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.expiry_date}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.business_justification}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : null}

      {checklist.proxy_details?.length ? (
        <>
          {label('Detailed Proxy Flow')}
          <div style={boxStyle}>
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', minWidth: '1100px', borderCollapse: 'collapse', fontSize: '0.9rem' }}>
                <thead>
                  <tr style={{ background: '#eef2ff' }}>
                    {['#', 'Data Connection #', 'Enable Offshore(Global) Proxy', 'Source Object Type', 'Target URLs', 'Proxy Type', 'Proxy Authentication', 'Proxy SSL Inspection', 'Proxy Anti-Virus', 'Expiry', 'Business Justification'].map((h) => (
                      <th key={h} style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {checklist.proxy_details.map((row, idx) => (
                    <tr key={row.id || idx}>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{idx + 1}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.connection_ref}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.enable_offshore_proxy}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.source_object_type}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{(row.target_urls || []).join(', ')}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.proxy_type}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.proxy_authentication}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.proxy_ssl_inspection}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.proxy_antivirus}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.expiry_date}</td>
                      <td style={{ border: '1px solid #e0e0e0', padding: '6px' }}>{row.business_justification}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : null}

      {label('Exception Expiry')}
      <div style={boxStyle}>{checklist.exception_expiry || checklist.expected_exception || '—'}</div>
    </div>
  );
};

export default FormReadonly;
