import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

// --- Styles (collapsed for brevity) --- //
const containerStyle = { margin: '20px auto', padding: '20px', maxWidth: '800px', backgroundColor: '#f9f9f9', borderRadius: '8px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)', textAlign: 'left' };
const buttonStyle = { backgroundColor: '#1976D2', color: '#FFFFFF', border: 'none', padding: '12px 20px', borderRadius: '5px', cursor: 'pointer', fontSize: '16px', margin: '10px' };
const findingItemStyle = { backgroundColor: '#fff', border: '1px solid #ddd', padding: '10px', borderRadius: '4px', marginBottom: '10px', display: 'flex', alignItems: 'center' };
const checkboxStyle = { marginRight: '15px', transform: 'scale(1.5)' };

const RiskRejection = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const findings = location.state?.findings || [];
    const getFindingTypeLabel = (finding) => {
        if (finding?.kind === 'ai' || (finding?.id || '').startsWith('AI-')) return 'AI Pre-Review';
        if (finding?.kind === 'manual' || finding?.riskDescription || finding?.issueContext) return 'Manual Review';
        return 'Rule-Based Pre-Review';
    };

    const [selectedFindings, setSelectedFindings] = useState([]);
    const [showConfirmation, setShowConfirmation] = useState(false);

    const handleCheckboxChange = (findingId) => {
        setSelectedFindings(prev => 
            prev.includes(findingId) 
                ? prev.filter(id => id !== findingId) 
                : [...prev, findingId]
        );
    };

    const handleSubmit = () => {
        if (selectedFindings.length === 0) {
            alert('Please select at least one risk to reject.');
            return;
        }
        setShowConfirmation(true);
    };

    const handleConfirmationAccept = () => {
        console.log("Rejected findings submitted for Risk Officer review:", selectedFindings);
        alert("The selected risks have been sent for further review.");
        // In a real app, this would navigate to a risk officer dashboard or a pending page
        navigate('/');
    };

    const handleConfirmationCancel = () => {
        // As per requirement, go back to the complete pre-review stage.
        // This is simplified to navigating back to the acknowledgement page.
        navigate('/review-acknowledgement', { state: { findings } });
    };

    if (showConfirmation) {
        return (
            <div style={containerStyle}>
                <h2>Confirm Risk Rejection</h2>
                <p>The risk items you have selected will be further reviewed by the risk officer. A risk acceptance may be required for the risks.</p>
                <div style={{textAlign: 'center'}}>
                    <button style={{...buttonStyle, backgroundColor: '#4CAF50'}} onClick={handleConfirmationAccept}>Accept</button>
                    <button style={{...buttonStyle, backgroundColor: '#757575'}} onClick={handleConfirmationCancel}>Not Ready to Further Review</button>
                </div>
            </div>
        );
    }

    return (
        <div style={containerStyle}>
            <h2>Risk Rejection</h2>
            <p>Select the risks you cannot remediate and wish to send for further review by a Risk Officer.</p>
            
            <div>
                {findings.map(finding => (
                    <div key={finding.id} style={findingItemStyle}>
                        <input 
                            type="checkbox"
                            style={checkboxStyle}
                            checked={selectedFindings.includes(finding.id)}
                            onChange={() => handleCheckboxChange(finding.id)}
                        />
                        <div>
                            <strong>ID:</strong> {finding.id || 'N/A'} <br />
                            <strong>Finding Type:</strong> {getFindingTypeLabel(finding)} <br />
                            <strong>Summary:</strong> {finding.details?.violation_summary || 'No summary provided.'}
                        </div>
                    </div>
                ))}
            </div>

            <button style={buttonStyle} onClick={handleSubmit} disabled={findings.length === 0}>
                Submit for Risk Officer Review
            </button>
        </div>
    );
};

export default RiskRejection;
