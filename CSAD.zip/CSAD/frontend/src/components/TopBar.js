import React, { useState } from 'react';
import { useUser } from '../context/UserContext';
import { useNavigate } from 'react-router-dom';

const barStyle = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  padding: '10px 20px',
  backgroundColor: '#e8f1ff',
  borderBottom: '1px solid #cfd8dc',
  color: '#0d47a1',
  fontFamily: '"Segoe UI", Arial, sans-serif',
};

const TopBar = () => {
  const { user, presetUsers, login, logout } = useUser();
  const navigate = useNavigate();
  const [showLogin, setShowLogin] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [authType, setAuthType] = useState('local');
  const [errorMsg, setErrorMsg] = useState('');

  return (
    <div style={barStyle}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        <button
          type="button"
          style={{ padding: '6px 12px', borderRadius: '6px', border: '1px solid #0d47a1', background: '#1976D2', color: '#fff', cursor: 'pointer' }}
          onClick={() => navigate('/')}
        >
          Home
        </button>
        <button
          type="button"
          style={{ padding: '6px 12px', borderRadius: '6px', border: '1px solid #90caf9', background: '#fff', cursor: 'pointer' }}
          onClick={() => navigate('/my-cases')}
        >
          My Cases
        </button>
        <button
          type="button"
          disabled={user.role !== 'Reviewer'}
          style={{
            padding: '6px 12px',
            borderRadius: '6px',
            border: '1px solid #90caf9',
            background: '#fff',
            opacity: user.role === 'Reviewer' ? 1 : 0.4,
            cursor: user.role === 'Reviewer' ? 'pointer' : 'not-allowed',
          }}
          onClick={() => {
            if (user.role !== 'Reviewer') {
              alert('Review List is available to Reviewer only.');
              return;
            }
            navigate('/review-list');
          }}
        >
          Review List
        </button>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        <div>
          <strong>User:</strong> {user.name || ''} &nbsp;|&nbsp; <strong>Role:</strong> {user.role || ''}
        </div>
        <button
          type="button"
          disabled={!!user?.name}
          style={{
            padding: '6px 12px',
            borderRadius: '6px',
            border: '1px solid #90caf9',
            background: '#fff',
            opacity: user?.name ? 0.4 : 1,
            cursor: user?.name ? 'not-allowed' : 'pointer',
          }}
          onClick={() => {
            if (user?.name) return;
            setShowLogin(true);
          }}
        >
          Login
        </button>
        {user?.name ? (
          <button
            type="button"
            style={{ padding: '6px 12px', borderRadius: '6px', border: '1px solid #b0bec5', background: '#f5f5f5' }}
            onClick={() => logout()}
          >
            Logout
          </button>
        ) : null}
      </div>
      {showLogin && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999,
        }}
        >
          <div style={{ background: '#fff', padding: '20px', borderRadius: '10px', minWidth: '330px', boxShadow: '0 4px 14px rgba(0,0,0,0.15)' }}>
            <h3 style={{ marginTop: 0 }}>Login</h3>
            <div style={{ marginBottom: '10px', textAlign: 'left' }}>
              <label style={{ fontWeight: 'bold' }}>Username</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter username"
                style={{ width: '90%', padding: '8px', borderRadius: '6px', border: '1px solid #cfd8dc' }}
              />
            </div>
            <div style={{ marginBottom: '10px',textAlign: 'left' }}>
              <label style={{ fontWeight: 'bold' }}>Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                style={{ width: '90%', padding: '8px', borderRadius: '6px', border: '1px solid #cfd8dc' }}
              />
            </div>
            <div style={{ marginBottom: '10px' ,textAlign: 'left' }}>
              <label style={{ fontWeight: 'bold' }}></label>
              <div style={{ display: 'flex', gap: '10px', marginTop: '6px' }}>
                <label>
                  <input type="radio" name="authType" value="local" checked={authType === 'local'} onChange={() => setAuthType('local')} />
                  {' '}Local
                </label>
                <label>
                  <input type="radio" name="authType" value="sso" checked={authType === 'sso'} onChange={() => setAuthType('sso')} />
                  {' '}SSO
                </label>
              </div>
            </div>
            {errorMsg ? (
              <p style={{ color: '#d32f2f', fontSize: '0.7rem', textAlign: 'left' }}>{errorMsg}</p>
            ) : (
              <p style={{ color: '#455a64', fontSize: '0.7rem', textAlign: 'left' }}>
                {authType === 'sso' ? 'SSO (AAD) will be used when integration is available.' : ''}
              </p>
            )}
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
              <button type="button" style={{ padding: '8px 12px', borderRadius: '6px', border: '1px solid #90caf9', background: '#fff' }} onClick={() => setShowLogin(false)}>Cancel</button>
              <button
                type="button"
                style={{ padding: '8px 12px', borderRadius: '6px', border: 'none', background: '#1976D2', color: '#fff' }}
                onClick={() => {
                  try {
                    setErrorMsg('');
                    login(username.trim(), password, authType);
                    setShowLogin(false);
                    setUsername('');
                    setPassword('');
                  } catch (err) {
                    setErrorMsg(err.message || 'Login failed');
                  }
                }}
              >
                Login
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TopBar;
