import React, { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import ReactMarkdown from 'react-markdown';
import { REVIEW_TYPES } from '../constants/reviewTypes';
import { getAttachmentUrl } from '../utils/attachments';
import { buildCalmReport, stripAttachmentData } from '../utils/calmUtils';
import { useBlueprintTemplates } from '../hooks/useBlueprintTemplates';

const containerStyle = { margin: '20px auto', padding: '20px', maxWidth: '1100px', backgroundColor: '#f9fbff', borderRadius: '12px', boxShadow: '0 6px 16px rgba(0,0,0,0.08)' };
const sectionStyle = { backgroundColor: '#fff', border: '1px solid #dce3f5', borderRadius: '10px', padding: '18px', marginBottom: '20px' };
const sectionTitleStyle = { margin: '0 0 12px 0', color: '#1a237e' };
const buttonRowStyle = { display: 'flex', gap: '12px', flexWrap: 'wrap', justifyContent: 'flex-end' };
const buttonPrimaryStyle = { backgroundColor: '#1976D2', color: '#FFFFFF', border: 'none', padding: '12px 20px', borderRadius: '5px', cursor: 'pointer', fontSize: '16px' };
const buttonSecondaryStyle = { ...buttonPrimaryStyle, backgroundColor: '#607d8b' };
const fieldListStyle = { listStyle: 'none', padding: 0, margin: 0 };
const fieldItemStyle = { marginBottom: '6px', color: '#37474f' };

const PreReviewSummary = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const state = location.state;

  const [imagePreviews, setImagePreviews] = useState([]);
  const { templates } = useBlueprintTemplates();

  useEffect(() => {
    if (!state) return undefined;
    const previews = [];

    const appendPreview = (item, label) => {
      if (!item) return;
      if (item.path) {
        previews.push({ name: item.name, type: item.type, url: getAttachmentUrl(item.path), label });
        return;
      }
      if (item instanceof File) {
        try {
          const url = URL.createObjectURL(item);
          previews.push({ name: item.name, type: item.type, url, label });
        } catch (error) {
          console.warn('Failed to create preview URL', error);
        }
      }
    };

    if (state.payload?.architectureFiles) {
      state.payload.architectureFiles.forEach((file) => appendPreview(file, 'Architecture Diagram'));
    }
    if (state.payload?.attachments) {
      state.payload.attachments.forEach((item) => appendPreview(item.attachment || item.file || item, item.label));
    }

    setImagePreviews(previews);

    return () => {
      previews.forEach((preview) => {
        if (preview.url?.startsWith?.('blob:')) {
          URL.revokeObjectURL(preview.url);
        }
      });
    };
  }, [state]);

  useEffect(() => {
    if (!state) {
      navigate('/');
    }
  }, [state, navigate]);

  const { mode, reviewType, payload, findings } = state || {};
  const manualFindings = state?.reviewerExtraFindings || [];
  const calmSummary = useMemo(
    () => buildCalmReport({
      payload: payload || {},
      findings: findings || [],
      manualFindings,
      templates,
    }),
    [payload, findings, manualFindings, templates]
  );

  const renderJSON = (data) => (
    <pre style={{ whiteSpace: 'pre-wrap', backgroundColor: '#f1f4ff', padding: '12px', borderRadius: '6px', fontSize: '0.92rem', textAlign: 'left' }}>
      {JSON.stringify(data, null, 2)}
    </pre>
  );

  const getFindingTypeLabel = (finding) => {
    if (finding?.kind === 'ai' || (finding?.id || '').startsWith('AI-')) return 'AI Pre-Review';
    if (finding?.kind === 'manual') return 'Manual Review';
    return 'Rule-Based Pre-Review';
  };

  const renderAISection = () => (
    <>
      <div style={sectionStyle}>
        <h3 style={sectionTitleStyle}>Conversation Transcript</h3>
        <ul style={fieldListStyle}>
          {payload?.messages?.map((message, index) => (
            <li key={`${message.sender}-${index}`} style={fieldItemStyle}>
              <strong>{message.sender.toUpperCase()}:</strong> {message.text}
            </li>
          ))}
        </ul>
      </div>
      {payload?.analysisMarkdown && (
        <div style={sectionStyle}>
          <h3 style={sectionTitleStyle}>Latest AI Analysis</h3>
          <ReactMarkdown>{payload.analysisMarkdown}</ReactMarkdown>
        </div>
      )}
    </>
  );

  const renderSecurityDesignSection = () => (
    <div style={sectionStyle}>
      <h3 style={sectionTitleStyle}>User Design (Security Design Review)</h3>
      {renderJSON(payload?.userDesign)}
    </div>
  );

  const renderControlExceptionSection = () => (
    <div style={sectionStyle}>
      <h3 style={sectionTitleStyle}>Design (CALM)</h3>
      {renderJSON(stripAttachmentData(calmSummary))}
    </div>
  );

  const renderAttachments = () => {
    if (!imagePreviews.length) {
      return null;
    }
    return (
      <div style={sectionStyle}>
        <h3 style={sectionTitleStyle}>Uploaded Images</h3>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px' }}>
          {imagePreviews.map((preview) => (
            <div key={preview.url} style={{ width: '220px' }}>
              <div style={{ fontSize: '0.85rem', marginBottom: '6px' }}>
                {preview.label ? `${preview.label}: ` : ''}{preview.name}
              </div>
              {preview.type?.startsWith('image/') ? (
                <img src={preview.url} alt={preview.name} style={{ width: '100%', borderRadius: '8px', boxShadow: '0 2px 6px rgba(0,0,0,0.15)' }} />
              ) : (
                <div style={{ fontSize: '0.85rem', color: '#455a64' }}>Preview not available (non-image file)</div>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  };

  const handleConfirm = () => {
    navigate('/review-acknowledgement', { state: { findings, reviewType, mode, payload } });
  };

  const handleBack = () => {
    navigate(-1);
  };

  const summaryHeader = useMemo(() => {
    const reviewLabel = REVIEW_TYPES[reviewType]?.label || reviewType;
    return `${mode === 'ai' ? 'AI' : 'Self'} Pre-Review Summary — ${reviewLabel}`;
  }, [mode, reviewType]);

  return (
    <div style={containerStyle}>
      <h2 style={{ color: '#0d47a1', marginBottom: '20px' }}>{summaryHeader}</h2>

      {mode === 'ai' && renderAISection()}
      {mode === 'self' && reviewType === 'security_design' && renderSecurityDesignSection()}
      {mode === 'self' && reviewType === 'control_exception' && renderControlExceptionSection()}

      {renderAttachments()}

      <div style={sectionStyle}>
        <h3 style={sectionTitleStyle}>Generated Findings</h3>
        {Array.isArray(findings) && findings.length ? (
          <div>
            {findings.map((finding, idx) => (
              <div key={finding?.id || idx} style={{ padding: '10px 0', borderBottom: '1px solid #e0e0e0' }}>
                <div><strong>Finding Type:</strong> {getFindingTypeLabel(finding)}</div>
                {finding?.details?.violation_summary ? (
                  <div><strong>Risk Description:</strong> {finding.details.violation_summary}</div>
                ) : null}
                {finding?.details?.risk ? (
                  <div><strong>Risk:</strong> {finding.details.risk}</div>
                ) : null}
                {finding?.details?.classification || finding?.classification ? (
                  <div><strong>Classification:</strong> {finding.details?.classification || finding.classification}</div>
                ) : null}
              </div>
            ))}
          </div>
        ) : (
          renderJSON(findings)
        )}
      </div>

      <div style={buttonRowStyle}>
        <button type="button" style={buttonSecondaryStyle} onClick={handleBack}>Go Back to Edit</button>
        <button type="button" style={buttonPrimaryStyle} onClick={handleConfirm}>Confirm &amp; Continue</button>
      </div>
    </div>
  );
};

export default PreReviewSummary;
