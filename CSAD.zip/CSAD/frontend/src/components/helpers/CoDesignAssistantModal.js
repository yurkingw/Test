import React, { useRef, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import apiClient from '../../api';
import { uploadFiles, getAttachmentUrl } from '../../utils/attachments';

const overlayStyle = { position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.18)', zIndex: 9999 };
const modalBaseStyle = { position: 'absolute', background: '#fff', padding: '16px', borderRadius: '10px', maxWidth: '90vw', boxShadow: '0 10px 28px rgba(0,0,0,0.22)', textAlign: 'left', cursor: 'default', minWidth: '520px', minHeight: '420px' };
const bodyStyle = { cursor: 'default', height: '100%', display: 'flex', flexDirection: 'column' };
const textareaStyle = { width: '100%', minHeight: '120px', borderRadius: '6px', border: '1px solid #cfd8dc', padding: '10px', boxSizing: 'border-box' };
const buttonRow = { display: 'flex', justifyContent: 'space-between', gap: '10px', marginTop: '12px', alignItems: 'center' };
const buttonStyle = { padding: '10px 16px', borderRadius: '6px', border: 'none', cursor: 'pointer' };
const chatBoxStyle = { border: '1px solid #e0e0e0', borderRadius: '8px', flex: 1, overflowY: 'auto', padding: '10px', background: '#f9fbff', marginTop: '10px' };
const resizeHandleStyle = { position: 'absolute', width: '14px', height: '14px', right: '4px', bottom: '4px', cursor: 'se-resize', background: '#90caf9', borderRadius: '4px' };

const CoDesignAssistantModal = ({ open, onClose, messages = [], setMessages }) => {
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [files, setFiles] = useState([]);
  const dragRef = useRef({ dragging: false, offsetX: 0, offsetY: 0, top: 40, left: 40, resizing: false });
  const modalRef = useRef(null);
  const [modalSize, setModalSize] = useState({ width: 820, height: 520 });

  if (!open) return null;

  const onMouseDown = (event) => {
    if (event.target.dataset?.resize === 'true') {
      dragRef.current = { ...dragRef.current, resizing: true, startX: event.clientX, startY: event.clientY, startW: modalSize.width, startH: modalSize.height };
      return;
    }
    if (!event.target.dataset?.draghandle) return;
    const rect = modalRef.current?.getBoundingClientRect();
    dragRef.current = {
      dragging: true,
      offsetX: event.clientX - (rect?.left || 0),
      offsetY: event.clientY - (rect?.top || 0),
      top: rect?.top || 40,
      left: rect?.left || 40,
    };
  };

  const onMouseMove = (event) => {
    if (dragRef.current.resizing) {
      const nextWidth = Math.max(520, dragRef.current.startW + (event.clientX - dragRef.current.startX));
      const nextHeight = Math.max(420, dragRef.current.startH + (event.clientY - dragRef.current.startY));
      setModalSize({ width: nextWidth, height: nextHeight });
      return;
    }
    if (!dragRef.current.dragging) return;
    dragRef.current.top = event.clientY - dragRef.current.offsetY;
    dragRef.current.left = event.clientX - dragRef.current.offsetX;
    if (modalRef.current) {
      modalRef.current.style.top = `${dragRef.current.top}px`;
      modalRef.current.style.left = `${dragRef.current.left}px`;
    }
  };

  const onMouseUp = () => {
    dragRef.current.dragging = false;
    dragRef.current.resizing = false;
  };

  const handleAsk = async () => {
    if (!prompt.trim() && files.length === 0) {
      setMessages((prev) => [...prev, { sender: 'system', text: 'Please enter text or add attachments.' }]);
      return;
    }
    const totalSize = files.reduce((sum, f) => sum + (f.size || 0), 0);
    const maxBytes = 1024 * 1024; // 1 MB server limit
    if (totalSize > maxBytes) {
      setMessages((prev) => [...prev, { sender: 'system', text: 'Attachments exceed 1 MB total. Please upload smaller files.' }]);
      return;
    }
    let attachmentsMeta = [];
    try {
      attachmentsMeta = await uploadFiles(files);
    } catch (error) {
      console.error('Assistant upload failed', error);
      setMessages((prev) => [...prev, { sender: 'system', text: 'Failed to upload attachments. Please try again.' }]);
      return;
    }
    const userEntry = { sender: 'user', text: prompt.trim() || '(attachments only)', attachments: attachmentsMeta };
    setMessages((prev) => [...prev, userEntry]);
    setIsLoading(true);
    try {
      const formData = new FormData();
      formData.append('conversation', JSON.stringify([...messages, userEntry]));
      formData.append('message', userEntry.text);
      formData.append('review_type', 'control_exception');
      files.forEach((file) => formData.append('files', file));
      const res = await apiClient.post('/ai/chat', formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      const reply = res.data?.reply || 'No response';
      setMessages((prev) => [...prev, { sender: 'ai', text: reply }]);
    } catch (error) {
      console.error('Assistant error', error);
      setMessages((prev) => [...prev, { sender: 'system', text: 'Failed to contact assistant. Please try again.' }]);
    } finally {
      setIsLoading(false);
      setPrompt('');
      setFiles([]);
    }
  };

  const dataUrlToUint8 = (dataUrl) => {
    if (!dataUrl) return new Uint8Array();
    const base64 = dataUrl.split(',')[1];
    const binary = atob(base64);
    const buffer = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) {
      buffer[i] = binary.charCodeAt(i);
    }
    return buffer;
  };

  const downloadMarkdown = async () => {
    const lines = messages.map((m) => {
      const header = `**${m.sender.toUpperCase()}**:`;
      const attach = m.attachments?.length ? `\nAttachments: ${m.attachments.map((a) => a.name).join(', ')}` : '';
      return `${header}\n${m.text}${attach}`;
    });
    const mdContent = lines.join('\n\n');
    try {
      const JSZip = (await import('jszip')).default;
      const zip = new JSZip();
      zip.file('co-design-assistant-chat.md', mdContent);
      for (const msg of messages) {
        for (const att of msg.attachments || []) {
          if (att.dataUrl) {
            const data = dataUrlToUint8(att.dataUrl);
            zip.file(att.name || 'attachment', data);
            continue;
          }
          if (att.path) {
            const url = getAttachmentUrl(att.path);
            const res = await fetch(url);
            if (res.ok) {
              const buffer = await res.arrayBuffer();
              zip.file(att.name || 'attachment', buffer);
            }
          }
        }
      }
      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'co-design-assistant-chat.zip';
      a.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Zip error', error);
      const blob = new Blob([mdContent], { type: 'text/markdown;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'co-design-assistant-chat.md';
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div style={overlayStyle} onMouseMove={onMouseMove} onMouseUp={onMouseUp}>
      <div
        ref={modalRef}
        style={{ ...modalBaseStyle, top: dragRef.current.top, left: dragRef.current.left, width: modalSize.width, height: modalSize.height }}
        onMouseDown={onMouseDown}
      >
        <div style={bodyStyle}>
          <div
            style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'move' }}
            data-draghandle="true"
          >
            <h3 style={{ margin: 0 }}>Security Co-Design Assistant</h3>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button type="button" style={{ ...buttonStyle, background: '#e0e0e0' }} onClick={downloadMarkdown} disabled={isLoading || messages.length === 0}>Download Chat (.md)</button>
              <button type="button" style={{ ...buttonStyle, background: '#ccc' }} onClick={onClose} disabled={isLoading}>Close</button>
            </div>
          </div>
          <p style={{ color: '#455a64', marginTop: '8px' }}>
            Ask for guidance on how to describe your design, risks, and controls. Chat is saved with the case.
          </p>

          <div style={chatBoxStyle}>
            {messages.length === 0 ? <div style={{ color: '#78909c' }}>No messages yet.</div> : messages.map((msg, idx) => (
              <div key={idx} style={{ marginBottom: '12px', padding: '8px', borderRadius: '6px', background: msg.sender === 'ai' ? '#e8f4ff' : '#fff' }}>
                <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>{msg.sender.toUpperCase()}</div>
                <div style={{ userSelect: 'text' }}>
                  <ReactMarkdown>{msg.text}</ReactMarkdown>
                </div>
                {msg.attachments?.length ? (
                  <div style={{ fontSize: '0.9rem', color: '#546e7a', marginTop: '4px' }}>
                    {msg.attachments.map((att, i) => (
                      <div key={i} style={{ marginTop: '4px' }}>
                        {att.type?.startsWith('image') && (att.path || att.dataUrl) ? (
                          <img src={att.path ? getAttachmentUrl(att.path) : att.dataUrl} alt={att.name} style={{ maxWidth: '220px', maxHeight: '220px', borderRadius: '6px', border: '1px solid #cfd8dc' }} />
                        ) : (
                          <span role="img" aria-label="file">📎</span>
                        )}{' '}
                        {att.path ? (
                          <a href={getAttachmentUrl(att.path)} style={{ color: '#1976D2' }} download={att.name}>{att.name}</a>
                        ) : att.name}
                      </div>
                    ))}
                  </div>
                ) : null}
              </div>
            ))}
          </div>

          <textarea
            style={textareaStyle}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe your design or ask for suggestions..."
            disabled={isLoading}
          />
          <div style={buttonRow}>
            <div>
              <input
                type="file"
                multiple
                onChange={(e) => {
                  const incoming = Array.from(e.target.files || []);
                  setFiles((prev) => [...prev, ...incoming]);
                }}
                disabled={isLoading}
              />
              {files.length > 0 && (
                <div style={{ fontSize: '0.85rem', color: '#546e7a' }}>
                  Selected: {files.map((f) => f.name).join(', ')}
                  <button
                    type="button"
                    style={{ marginLeft: '8px', padding: '2px 8px', borderRadius: '4px', border: '1px solid #ccc', background: '#fff', cursor: 'pointer' }}
                    onClick={() => setFiles([])}
                    disabled={isLoading}
                  >
                    Clear
                  </button>
                </div>
              )}
            </div>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button type="button" style={{ ...buttonStyle, background: '#1976D2', color: '#fff' }} onClick={handleAsk} disabled={isLoading}>
                {isLoading ? 'Thinking...' : 'Ask Assistant'}
              </button>
            </div>
          </div>
        </div>
        <div style={resizeHandleStyle} data-resize="true" onMouseDown={onMouseDown} />
      </div>
    </div>
  );
};

export default CoDesignAssistantModal;
