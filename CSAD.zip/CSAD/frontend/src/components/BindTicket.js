import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../context/UserContext';
import { listJiraTicketsApi, refreshJiraTicketsApi } from '../api/jira';

const containerStyle = { margin: '20px auto', maxWidth: '640px', padding: '20px', backgroundColor: '#f7faff', border: '1px solid #dce3f5', borderRadius: '10px', boxShadow: '0 6px 16px rgba(0,0,0,0.08)', textAlign: 'left' };
const labelStyle = { display: 'block', marginBottom: '6px', fontWeight: 'bold' };
const selectStyle = { width: '100%', padding: '10px', borderRadius: '6px', border: '1px solid #cfd8dc', marginBottom: '12px' };
const buttonStyle = { padding: '12px 18px', backgroundColor: '#1976D2', color: '#fff', border: 'none', borderRadius: '6px', cursor: 'pointer' };
const secondaryButtonStyle = { ...buttonStyle, backgroundColor: '#607d8b' };
const fieldRowStyle = { display: 'flex', gap: '10px', alignItems: 'center', marginBottom: '12px', flexWrap: 'wrap' };

const dummyTickets = [
  { id: 'Example JSM-1001', summary: 'Prod firewall exception' },
  { id: 'Example JSM-1002', summary: 'Proxy whitelist for service A' },
  { id: 'Example JSM-1003', summary: 'Privileged access change' },
];

const BindTicket = () => {
  const [ticket, setTicket] = useState('');
  const [reviewType, setReviewType] = useState('control_exception');
  const [jiraTickets, setJiraTickets] = useState([]);
  const [jiraError, setJiraError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [total, setTotal] = useState(0);
  const [lastRefreshed, setLastRefreshed] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { user } = useUser();

  useEffect(() => {
    let mounted = true;
    (async () => {
      setLoading(true);
      try {
        const data = await listJiraTicketsApi({ query: searchQuery, page, pageSize });
        if (mounted) {
          setJiraTickets(data.items || []);
          setTotal(data.total || 0);
          setLastRefreshed(data.last_refreshed || '');
          setJiraError('');
        }
      } catch (error) {
        console.error('Failed to load Jira tickets', error);
        if (mounted) setJiraError('Jira tickets unavailable.');
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, [searchQuery, page, pageSize]);

  const ticketOptions = useMemo(() => {
    const map = new Map();
    dummyTickets.forEach((t) => map.set(t.id, t));
    jiraTickets.forEach((t) => {
      if (t?.id) map.set(t.id, t);
    });
    return Array.from(map.values());
  }, [jiraTickets]);
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  const handleRefreshTickets = async () => {
    setLoading(true);
    try {
      const refreshed = await refreshJiraTicketsApi();
      if (refreshed?.cooldown_remaining) {
        alert(`Refresh is rate-limited. Please retry after ${refreshed.cooldown_remaining} seconds.`);
      }
      setPage(1);
      const data = await listJiraTicketsApi({ query: searchQuery, page: 1, pageSize });
      setJiraTickets(data.items || []);
      setTotal(data.total || 0);
      setLastRefreshed(data.last_refreshed || '');
      setJiraError('');
    } catch (error) {
      console.error('Failed to refresh Jira tickets', error);
      setJiraError('Jira tickets unavailable.');
    } finally {
      setLoading(false);
    }
  };

  const handleStart = async () => {
    if (!ticket) {
      alert('A preliminary SecDesign Review Ticket (ITSM) is required before submit CSAD case.\nPlease select an existing one to bind.');
      return;
    }
    try {
      navigate(`/self-pre-review?type=${reviewType}&ticketId=${encodeURIComponent(ticket)}`);
    } catch (e) {
      console.error('Failed to create case', e);
      alert('Failed to start design. Please try again.');
    }
  };

  return (
    <div style={containerStyle}>
      <h2>Bind ITSM Ticket</h2>
      <p style={{ color: '#546e7a' }}>A preliminary SecDesign Review Ticket (ITSM) is required before submit CSAD case. Please select an existing one to bind.</p>
      <label style={labelStyle}>Review Type</label>
      <select value={reviewType} onChange={(e) => setReviewType(e.target.value)} style={selectStyle}>
        <option value="control_exception">Control Exception Review</option>
        <option value="security_design" disabled>SecDesign Review (coming soon)</option>
        <option value="security_design" disabled>CloudSec Review (coming soon)</option>
        <option value="security_design" disabled>TPSA Review (coming soon)</option>
        <option value="security_design" disabled>NAC Review (coming soon)</option>
      </select>
      <label style={labelStyle}>ITSM Ticket</label>
      <div style={fieldRowStyle}>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
            setPage(1);
          }}
          placeholder="Search ITSM ticket number (e.g., 00001)"
          style={{ ...selectStyle, marginBottom: 0, flex: 1 }}
        />
        <button type="button" style={secondaryButtonStyle} onClick={handleRefreshTickets} disabled={loading}>
          Refresh JSM Ticket
        </button>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px', fontSize: '0.85rem', color: '#546e7a' }}>
        <span>{loading ? 'Loading tickets...' : `Total: ${total}`}</span>
        <span>{lastRefreshed ? `Last refreshed: ${lastRefreshed}` : ''}</span>
      </div>
      <div style={{ display: 'flex', gap: '8px', marginBottom: '12px' }}>
        <button
          type="button"
          style={secondaryButtonStyle}
          onClick={() => setPage((prev) => Math.max(1, prev - 1))}
          disabled={page <= 1 || loading}
        >
          Prev
        </button>
        <button
          type="button"
          style={secondaryButtonStyle}
          onClick={() => setPage((prev) => Math.min(totalPages, prev + 1))}
          disabled={page >= totalPages || loading}
        >
          Next
        </button>
        <span style={{ alignSelf: 'center', color: '#546e7a', fontSize: '0.85rem' }}>Page {page} / {totalPages}</span>
      </div>
      <select value={ticket} onChange={(e) => setTicket(e.target.value)} style={selectStyle}>
        <option value="">Select a Ticket from ITSM ...</option>
        {ticketOptions.map((t) => (
          <option key={t.id} value={t.id}>
            {t.id} — {t.summary}
          </option>
        ))}
      </select>
      {jiraError ? <div style={{ color: '#d32f2f', marginBottom: '10px' }}>{jiraError}</div> : null}
      <button type="button" style={buttonStyle} onClick={handleStart}>Start Design</button>
    </div>
  );
};

export default BindTicket;
