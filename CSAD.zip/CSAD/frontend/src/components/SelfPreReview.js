import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import apiClient from '../api';
import { REVIEW_TYPES, DEFAULT_REVIEW_TYPE } from '../constants/reviewTypes';

import SystemForm from './SelfPreReviewForms/SystemForm';
import ApplicationForm from './SelfPreReviewForms/ApplicationForm';
import ServiceForm from './SelfPreReviewForms/ServiceForm';
import ServiceInstanceForm from './SelfPreReviewForms/ServiceInstanceForm';
import ConnectionForm from './SelfPreReviewForms/ConnectionForm';
import Summary from './SelfPreReviewForms/Summary';
import SelfPreReviewControlException from './SelfPreReviewControlException';

const containerNoteStyle = { margin: '20px auto', maxWidth: '900px', padding: '10px', textAlign: 'left', color: '#444' };

const SelfPreReview = () => {
  const [searchParams] = useSearchParams();
  const reviewType = searchParams.get('type') || 'control_exception';

  if (reviewType === 'control_exception') {
    return <SelfPreReviewControlException reviewType={reviewType} />;
  }

  return <SecurityDesignWizard reviewType={reviewType} />;
};

const SecurityDesignWizard = ({ reviewType }) => {
  const reviewMeta = REVIEW_TYPES[reviewType] ?? REVIEW_TYPES[DEFAULT_REVIEW_TYPE];
  const [userDesign, setUserDesign] = useState({
    systems: [],
    applications: [],
    services: [],
    service_instances: [],
    connections: [],
  });
  const [currentStep, setCurrentStep] = useState(1);
  const [findings, setFindings] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const [systemForm, setSystemForm] = useState({
    cmdb_sysid: '',
    sysname: '',
    description: '',
    information_sensetivity_classification: 'Public',
    asset_risk_ranking: 'P1',
  });

  const [applicationForm, setApplicationForm] = useState({
    appid: '',
    appname: '',
    deployment_model_id: '',
  });

  const [serviceForm, setServiceForm] = useState({
    svcid: '',
    svcname: '',
    application_ids: [],
  });

  const [serviceInstanceForm, setServiceInstanceForm] = useState({
    svcid: '',
    svcint_id: '',
    svcintname: '',
  });

  const [connectionForm, setConnectionForm] = useState({
    conid: '',
    source_cmpid: '',
    destination_cmpid: '',
    connection_type_id: '',
  });

  const handleSystemChange = (event) => {
    const { name, value } = event.target;
    setSystemForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSystemSubmit = (event) => {
    event.preventDefault();
    setUserDesign((prev) => ({ ...prev, systems: [systemForm] }));
    setCurrentStep(2);
  };

  const handleApplicationChange = (event) => {
    const { name, value } = event.target;
    setApplicationForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleApplicationSubmit = (event) => {
    event.preventDefault();
    setUserDesign((prev) => ({
      ...prev,
      applications: [...prev.applications, applicationForm],
    }));
    setApplicationForm({
      appid: '',
      appname: '',
      deployment_model_id: '',
    });
  };

  const handleServiceChange = (event) => {
    const { name, value, type } = event.target;
    if (type === 'checkbox') {
      setServiceForm((prev) => {
        const alreadySelected = prev.application_ids.includes(name);
        const nextIds = alreadySelected
          ? prev.application_ids.filter((id) => id !== name)
          : [...prev.application_ids, name];
        return { ...prev, application_ids: nextIds };
      });
    } else {
      setServiceForm((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleServiceSubmit = (event) => {
    event.preventDefault();
    setUserDesign((prev) => ({
      ...prev,
      services: [...prev.services, serviceForm],
    }));
    setServiceForm({
      svcid: '',
      svcname: '',
      application_ids: [],
    });
  };

  const handleServiceInstanceChange = (event) => {
    const { name, value } = event.target;
    setServiceInstanceForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleServiceInstanceSubmit = (event) => {
    event.preventDefault();
    setUserDesign((prev) => ({
      ...prev,
      service_instances: [...prev.service_instances, serviceInstanceForm],
    }));
    setServiceInstanceForm({
      svcid: '',
      svcint_id: '',
      svcintname: '',
    });
  };

  const handleConnectionChange = (event) => {
    const { name, value } = event.target;
    setConnectionForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleConnectionSubmit = (event) => {
    event.preventDefault();
    setUserDesign((prev) => ({
      ...prev,
      connections: [...prev.connections, connectionForm],
    }));
    setConnectionForm({
      conid: '',
      source_cmpid: '',
      destination_cmpid: '',
      connection_type_id: '',
    });
  };

  const handleAuditSubmit = async () => {
    setIsLoading(true);
    setFindings([]);
    try {
      const response = await apiClient.post('/audits/', {
        review_type: reviewType,
        user_design: userDesign,
      });
      setFindings(response.data);
      navigate('/pre-review-summary', {
        state: {
          mode: 'self',
          reviewType,
          findings: response.data,
          payload: { userDesign },
        },
      });
    } catch (error) {
      console.error('Error submitting audit:', error);
      alert('Failed to submit audit. Check the console for details.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <div style={containerNoteStyle}>
        <h2>Self Pre-Review — {reviewMeta.label}</h2>
        <p>{reviewMeta.description}</p>
      </div>
      {currentStep === 1 && (
        <SystemForm
          system={systemForm}
          onSystemChange={handleSystemChange}
          onSystemSubmit={handleSystemSubmit}
        />
      )}
      {currentStep === 2 && (
        <ApplicationForm
          application={applicationForm}
          onApplicationChange={handleApplicationChange}
          onApplicationSubmit={handleApplicationSubmit}
          userDesign={userDesign}
          setCurrentStep={setCurrentStep}
        />
      )}
      {currentStep === 3 && (
        <ServiceForm
          service={serviceForm}
          onServiceChange={handleServiceChange}
          onServiceSubmit={handleServiceSubmit}
          userDesign={userDesign}
          setCurrentStep={setCurrentStep}
        />
      )}
      {currentStep === 4 && (
        <ServiceInstanceForm
          serviceInstance={serviceInstanceForm}
          onServiceInstanceChange={handleServiceInstanceChange}
          onServiceInstanceSubmit={handleServiceInstanceSubmit}
          userDesign={userDesign}
          setCurrentStep={setCurrentStep}
        />
      )}
      {currentStep === 5 && (
        <ConnectionForm
          connection={connectionForm}
          onConnectionChange={handleConnectionChange}
          onConnectionSubmit={handleConnectionSubmit}
          userDesign={userDesign}
          setCurrentStep={setCurrentStep}
        />
      )}
      {currentStep === 6 && (
        <Summary
          userDesign={userDesign}
          onAuditSubmit={handleAuditSubmit}
          isLoading={isLoading}
          findings={findings}
        />
      )}
    </div>
  );
};

export default SelfPreReview;
