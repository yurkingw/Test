import React, { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { getCaseApi } from '../api/cases';
import FormReadonly from './FormReadonly';
import { downloadCaseBundle } from '../utils/bundleDownloader';
import { buildCalmReport, stripAttachmentData } from '../utils/calmUtils';
import { getAttachmentUrl } from '../utils/attachments';
import { useBlueprintTemplates } from '../hooks/useBlueprintTemplates';

const containerStyle = { margin: '20px auto', maxWidth: '1100px', padding: '20px', backgroundColor: '#f7faff', borderRadius: '10px', border: '1px solid #dce3f5', textAlign: 'left' };

const renderJSON = (data) => (
  <pre style={{ whiteSpace: 'pre-wrap', background: '#f1f4ff', padding: '10px', borderRadius: '6px', border: '1px solid #dce3f7' }}>
    {JSON.stringify(data, null, 2)}
  </pre>
);

const SecDesignFinalSnapshot = () => {
  const [searchParams] = useSearchParams();
  const caseId = useMemo(() => searchParams.get('caseId'), [searchParams]);
  const [caseData, setCaseData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { templates } = useBlueprintTemplates();

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const data = await getCaseApi(caseId);
        if (mounted) setCaseData(data);
      } catch (e) {
        console.error('Failed to load case', e);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, [caseId]);

  if (!caseId) {
    return <div style={containerStyle}><h2>SecDesign Final</h2><p>Missing caseId.</p></div>;
  }

  if (loading) {
    return <div style={containerStyle}><h2>SecDesign Final</h2><p>Loading...</p></div>;
  }

  if (!caseData) {
    return <div style={containerStyle}><h2>SecDesign Final</h2><p>Case not found.</p></div>;
  }

  const payload = caseData.designPayload;
  const finalSnapshot = stripAttachmentData(caseData.finalSnapshot || {});
  const calmSummary = stripAttachmentData(
    buildCalmReport({
      payload: payload || {},
      findings: caseData?.findings || [],
      manualFindings: caseData?.reviewerExtraFindings || [],
      templates,
    })
  );
  const evidence = caseData.evidence || {};
  const reviewerExtras = caseData.reviewerExtraFindings || [];
  const baseFindings = (caseData.findings || []).filter((f) => {
    const details = f.details || {};
    return Boolean(f.summary || details.violation_summary);
  });

  const resolveEvidence = (finding, idx) => {
    const fid = finding.id || `finding-${idx}`;
    return evidence[fid] || evidence[idx] || null;
  };

  const renderEvidence = (ev) => {
    if (!ev) return <p>No evidence provided.</p>;
    return (
      <div style={{ marginTop: '6px' }}>
        <div><strong>Decision:</strong> {ev.decision || 'accept'}</div>
        <div><strong>Description:</strong> {ev.description || '—'}</div>
        {ev.files?.length ? (
          <div>
            <strong>Attachments:</strong>
            <ul>
              {ev.files.map((file, idx) => {
                const url = file.path ? getAttachmentUrl(file.path) : '';
                const isImage = (file.type || '').startsWith('image/');
                return (
                  <li key={`${file.name || 'file'}-${idx}`}>
                    {url ? (
                      <a href={url} target="_blank" rel="noreferrer">{file.name || 'file'}</a>
                    ) : (
                      file.name || 'file'
                    )}
                    {isImage && url ? (
                      <div style={{ marginTop: '6px' }}>
                        <img src={url} alt={file.name || 'attachment'} style={{ maxWidth: '100%', borderRadius: '6px', border: '1px solid #e0e0e0' }} />
                      </div>
                    ) : null}
                  </li>
                );
              })}
            </ul>
          </div>
        ) : null}
      </div>
    );
  };
  const isSuppressed = (finding) => Boolean(finding?.suppressed || finding?.details?.suppressed);
  const getFindingTypeLabel = (finding) => {
    if (finding?.kind === 'ai' || (finding?.id || '').startsWith('AI-')) return 'AI Pre-Review';
    if (finding?.kind === 'manual') return 'Manual Review';
    return 'Rule-Based Pre-Review';
  };

  return (
    <div style={containerStyle}>
      <h2>SecDesign Final</h2>
      <p>Case: {caseId} — Status: {caseData.status}</p>
      <button
        type="button"
        onClick={() => downloadCaseBundle(caseData, `${caseId}_bundle`, { htmlSnapshot: document.documentElement.outerHTML, templates })}
        style={{ marginBottom: '12px', background: '#2e7d32', color: '#fff', border: 'none', padding: '8px 14px', borderRadius: '6px', cursor: 'pointer' }}
      >
        Download Final Bundle
      </button>

      <h4>Design (Form)</h4>
      <FormReadonly checklist={payload?.metadata?.checklist} />

      <h4>Design (CALM)</h4>
      {renderJSON(calmSummary)}

      <h4>Findings</h4>
      {renderJSON(caseData.findings || [])}

      <h4>Review Report</h4>
      {baseFindings.length || reviewerExtras.length ? (
        <div style={{ background: '#fff', border: '1px dashed #90caf9', padding: '12px', borderRadius: '8px' }}>
          {baseFindings.map((f, idx) => {
            const details = f.details || {};
            const summary = f.summary || details.violation_summary || '—';
            const requirement = f.requirement || details.requirement || details.control_requirement || '';
            const reqText = Array.isArray(requirement)
              ? requirement.map((item) => (typeof item === 'string' ? item : item?.description || '')).filter(Boolean).join('; ')
              : (typeof requirement === 'object' ? requirement?.description : requirement);
            const riskLevel = f.risk_level || details.risk || '—';
            const classification = f.classification || details.classification || '—';
            const suppressed = isSuppressed(f);
            const ev = resolveEvidence(f, idx);
            const findingType = getFindingTypeLabel(f);
            return (
              <div key={f.id || idx} style={{ padding: '10px 0', borderBottom: '1px solid #e0e0e0' }}>
                <div><strong>Risk Description:</strong> {summary}</div>
                <div><strong>Finding Type:</strong> {findingType}</div>
                <div><strong>Classification:</strong> {classification}</div>
                <div><strong>Risk Level:</strong> {riskLevel}</div>
                <div><strong>Suppressed:</strong> {suppressed ? 'Yes' : 'No'}</div>
                {reqText ? <div><strong>Requirement:</strong> {reqText}</div> : null}
                {renderEvidence(ev)}
              </div>
            );
          })}
          {reviewerExtras.map((f, idx) => {
            const ev = resolveEvidence({ id: f.id || `EX-${idx}` }, idx + baseFindings.length);
            const findingType = 'Manual Review';
            return (
              <div key={f.id || `EX-${idx}`} style={{ padding: '10px 0', borderBottom: '1px solid #e0e0e0' }}>
                <div><strong>Issue Context:</strong> {f.issueContext || '—'}</div>
                <div><strong>Finding Type:</strong> {findingType}</div>
                <div><strong>Risk Description:</strong> {f.riskDescription || '—'}</div>
                <div><strong>Classification:</strong> {f.classification || '—'}</div>
                <div><strong>Risk Level:</strong> {f.riskLevel || '—'}</div>
                {f.requirement ? <div><strong>Requirement:</strong> {f.requirement}</div> : null}
                {renderEvidence(ev)}
              </div>
            );
          })}
        </div>
      ) : (
        <p>No findings recorded.</p>
      )}

      <h4>Final Snapshot</h4>
      {renderJSON(finalSnapshot)}
    </div>
  );
};

export default SecDesignFinalSnapshot;
