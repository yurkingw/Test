import React from 'react';

// --- Styles --- //
const formContainerStyle = { margin: '20px auto', padding: '20px', maxWidth: '800px', backgroundColor: '#f9f9f9', borderRadius: '8px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)', textAlign: 'left' };
const buttonStyle = { backgroundColor: '#1976D2', color: '#FFFFFF', border: 'none', padding: '12px 20px', borderRadius: '5px', cursor: 'pointer', fontSize: '16px', width: '100%', marginTop: '10px' };
const listStyle = { listStyleType: 'none', padding: 0 };
const listItemStyle = { backgroundColor: '#fff', border: '1px solid #ddd', padding: '10px', borderRadius: '4px', marginBottom: '10px' };
const findingItemStyle = { ...listItemStyle, borderLeft: '5px solid #D32F2F' };

const Summary = ({ userDesign, onAuditSubmit, isLoading, findings }) => {
    return (
        <div style={formContainerStyle}>
            <h2>Step 6: Summary & Submit for Audit</h2>
            <div style={{backgroundColor: '#eee', padding: '15px', borderRadius: '4px'}}>
                <h4>Current Design Overview:</h4>
                <pre style={{ textAlign: 'left', whiteSpace: 'pre-wrap' }}>{JSON.stringify(userDesign, null, 2)}</pre>
            </div>
            <button style={buttonStyle} onClick={onAuditSubmit} disabled={isLoading}>
                {isLoading ? 'Auditing...' : 'Submit for Audit'}
            </button>

            {findings.length > 0 && (
                <div style={{marginTop: '20px'}}>
                    <h3>Audit Findings:</h3>
                    <ul style={listStyle}>
                        {findings.map((finding, index) => (
                            <li key={index} style={findingItemStyle}>
                                <div>
                                    <strong>ID:</strong> {finding.id} <br />
                                    <strong>Summary:</strong> {finding.details.violation_summary}
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default Summary;
