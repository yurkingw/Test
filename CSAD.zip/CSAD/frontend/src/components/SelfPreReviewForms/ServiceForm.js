import React from 'react';

// --- Styles --- //
const formContainerStyle = { margin: '20px auto', padding: '20px', maxWidth: '800px', backgroundColor: '#f9f9f9', borderRadius: '8px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)', textAlign: 'left' };
const formGroupStyle = { marginBottom: '15px' };
const labelStyle = { display: 'block', marginBottom: '5px', color: '#333', fontWeight: 'bold' };
const inputStyle = { width: '100%', padding: '10px', border: '1px solid #ccc', borderRadius: '4px', boxSizing: 'border-box' };
const buttonStyle = { backgroundColor: '#1976D2', color: '#FFFFFF', border: 'none', padding: '12px 20px', borderRadius: '5px', cursor: 'pointer', fontSize: '16px', width: '100%', marginTop: '10px' };
const listStyle = { listStyleType: 'none', padding: 0 };
const listItemStyle = { backgroundColor: '#fff', border: '1px solid #ddd', padding: '10px', borderRadius: '4px', marginBottom: '10px' };
const checkboxLabelStyle = { marginLeft: '10px' };

const ServiceForm = ({ service, onServiceChange, onServiceSubmit, userDesign, setCurrentStep }) => {
    return (
        <div style={formContainerStyle}>
            <h2>Step 3: Add Services</h2>
            <h4>Added Services:</h4>
            {userDesign.services.length === 0 ? <p>No services added yet.</p> : (
                <ul style={listStyle}>
                    {userDesign.services.map((svc, i) => <li key={i} style={listItemStyle}>{svc.svcname}</li>)}
                </ul>
            )}
            <hr style={{margin: '20px 0'}} />
            <h4>Add New Service:</h4>
            <form onSubmit={onServiceSubmit}>
                <div style={formGroupStyle}>
                    <label style={labelStyle}>Service ID</label>
                    <input style={inputStyle} type="text" name="svcid" value={service.svcid} onChange={onServiceChange} required />
                </div>
                <div style={formGroupStyle}>
                    <label style={labelStyle}>Service Name</label>
                    <input style={inputStyle} type="text" name="svcname" value={service.svcname} onChange={onServiceChange} required />
                </div>
                <div style={formGroupStyle}>
                    <label style={labelStyle}>Belongs to Applications:</label>
                    {userDesign.applications.map(app => (
                        <div key={app.appid}>
                            <input 
                                type="checkbox" 
                                id={`app-${app.appid}`} 
                                name={app.appid} 
                                checked={service.application_ids.includes(app.appid)}
                                onChange={onServiceChange} 
                            />
                            <label style={checkboxLabelStyle} htmlFor={`app-${app.appid}`}>{app.appname}</label>
                        </div>
                    ))}
                </div>
                <button style={buttonStyle} type="submit">Add Service</button>
            </form>
            <button style={{...buttonStyle, backgroundColor: '#4CAF50'}} onClick={() => setCurrentStep(4)}>Next: Add Service Instances</button>
        </div>
    );
};

export default ServiceForm;
