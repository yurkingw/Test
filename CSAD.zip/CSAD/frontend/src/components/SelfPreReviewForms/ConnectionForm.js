import React from 'react';

// --- Styles --- //
const formContainerStyle = { margin: '20px auto', padding: '20px', maxWidth: '800px', backgroundColor: '#f9f9f9', borderRadius: '8px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)', textAlign: 'left' };
const formGroupStyle = { marginBottom: '15px' };
const labelStyle = { display: 'block', marginBottom: '5px', color: '#333', fontWeight: 'bold' };
const inputStyle = { width: '100%', padding: '10px', border: '1px solid #ccc', borderRadius: '4px', boxSizing: 'border-box' };
const buttonStyle = { backgroundColor: '#1976D2', color: '#FFFFFF', border: 'none', padding: '12px 20px', borderRadius: '5px', cursor: 'pointer', fontSize: '16px', width: '100%', marginTop: '10px' };
const listStyle = { listStyleType: 'none', padding: 0 };
const listItemStyle = { backgroundColor: '#fff', border: '1px solid #ddd', padding: '10px', borderRadius: '4px', marginBottom: '10px' };

const ConnectionForm = ({ connection, onConnectionChange, onConnectionSubmit, userDesign, setCurrentStep }) => {
    return (
        <div style={formContainerStyle}>
            <h2>Step 5: Add Connections</h2>
            <h4>Added Connections:</h4>
            {userDesign.connections.length === 0 ? <p>No connections added yet.</p> : (
                <ul style={listStyle}>
                    {userDesign.connections.map((conn, i) => <li key={i} style={listItemStyle}>{conn.conid}: {conn.source_cmpid} → {conn.destination_cmpid}</li>)}
                </ul>
            )}
            <hr style={{margin: '20px 0'}} />
            <h4>Add New Connection:</h4>
            <form onSubmit={onConnectionSubmit}>
                <div style={formGroupStyle}>
                    <label style={labelStyle}>Connection ID</label>
                    <input style={inputStyle} type="text" name="conid" value={connection.conid} onChange={onConnectionChange} required />
                </div>
                <div style={formGroupStyle}>
                    <label style={labelStyle}>Source Component (Service Instance)</label>
                    <select style={inputStyle} name="source_cmpid" value={connection.source_cmpid} onChange={onConnectionChange} required>
                        <option value="" disabled>Select a source</option>
                        {userDesign.service_instances.map(i => <option key={i.svcint_id} value={i.svcint_id}>{i.svcintname}</option>)}
                    </select>
                </div>
                <div style={formGroupStyle}>
                    <label style={labelStyle}>Destination Component (Service Instance)</label>
                    <select style={inputStyle} name="destination_cmpid" value={connection.destination_cmpid} onChange={onConnectionChange} required>
                        <option value="" disabled>Select a destination</option>
                        {userDesign.service_instances.map(i => <option key={i.svcint_id} value={i.svcint_id}>{i.svcintname}</option>)}
                    </select>
                </div>
                <div style={formGroupStyle}>
                    <label style={labelStyle}>Connection Type ID</label>
                    <input style={inputStyle} type="text" name="connection_type_id" value={connection.connection_type_id} onChange={onConnectionChange} required />
                </div>
                <button style={buttonStyle} type="submit">Add Connection</button>
            </form>
            <button style={{...buttonStyle, backgroundColor: '#4CAF50'}} onClick={() => setCurrentStep(6)}>Next: Summary & Submit</button>
        </div>
    );
};

export default ConnectionForm;
