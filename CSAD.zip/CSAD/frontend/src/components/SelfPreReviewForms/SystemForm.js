import React from 'react';

// --- Styles --- //
const formContainerStyle = { margin: '20px auto', padding: '20px', maxWidth: '800px', backgroundColor: '#f9f9f9', borderRadius: '8px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)', textAlign: 'left' };
const formGroupStyle = { marginBottom: '15px' };
const labelStyle = { display: 'block', marginBottom: '5px', color: '#333', fontWeight: 'bold' };
const inputStyle = { width: '100%', padding: '10px', border: '1px solid #ccc', borderRadius: '4px', boxSizing: 'border-box' };
const buttonStyle = { backgroundColor: '#1976D2', color: '#FFFFFF', border: 'none', padding: '12px 20px', borderRadius: '5px', cursor: 'pointer', fontSize: '16px', width: '100%', marginTop: '10px' };

const SystemForm = ({ system, onSystemChange, onSystemSubmit }) => {
    return (
        <div style={formContainerStyle}>
            <h2>Step 1: Define Your System</h2>
            <form onSubmit={onSystemSubmit}>
                <div style={formGroupStyle}>
                    <label style={labelStyle} htmlFor="cmdb_sysid">System ID (CMDB SYSID)</label>
                    <input style={inputStyle} type="text" id="cmdb_sysid" name="cmdb_sysid" value={system.cmdb_sysid} onChange={onSystemChange} required />
                </div>
                <div style={formGroupStyle}>
                    <label style={labelStyle} htmlFor="sysname">System Name</label>
                    <input style={inputStyle} type="text" id="sysname" name="sysname" value={system.sysname} onChange={onSystemChange} required />
                </div>
                <div style={formGroupStyle}>
                    <label style={labelStyle} htmlFor="description">Description</label>
                    <textarea style={{...inputStyle, height: '100px'}} id="description" name="description" value={system.description} onChange={onSystemChange}></textarea>
                </div>
                <div style={formGroupStyle}>
                    <label style={labelStyle} htmlFor="information_sensetivity_classification">Information Sensitivity Classification</label>
                    <select style={inputStyle} id="information_sensetivity_classification" name="information_sensetivity_classification" value={system.information_sensetivity_classification} onChange={onSystemChange}>
                        <option value="Public">Public</option>
                        <option value="Confidential">Confidential</option>
                        <option value="Highly Restricted">Highly Restricted</option>
                    </select>
                </div>
                <div style={formGroupStyle}>
                    <label style={labelStyle} htmlFor="asset_risk_ranking">Asset Risk Ranking</label>
                    <select style={inputStyle} id="asset_risk_ranking" name="asset_risk_ranking" value={system.asset_risk_ranking} onChange={onSystemChange}>
                        <option value="P1">P1</option>
                        <option value="P2">P2</option>
                        <option value="P3">P3</option>
                        <option value="P4">P4</option>
                    </select>
                </div>
                <button style={buttonStyle} type="submit">Next: Add Applications</button>
            </form>
        </div>
    );
};

export default SystemForm;
