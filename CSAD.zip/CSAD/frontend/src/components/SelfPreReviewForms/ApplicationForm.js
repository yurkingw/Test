import React from 'react';

// --- Styles --- //
const formContainerStyle = { margin: '20px auto', padding: '20px', maxWidth: '800px', backgroundColor: '#f9f9f9', borderRadius: '8px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)', textAlign: 'left' };
const formGroupStyle = { marginBottom: '15px' };
const labelStyle = { display: 'block', marginBottom: '5px', color: '#333', fontWeight: 'bold' };
const inputStyle = { width: '100%', padding: '10px', border: '1px solid #ccc', borderRadius: '4px', boxSizing: 'border-box' };
const buttonStyle = { backgroundColor: '#1976D2', color: '#FFFFFF', border: 'none', padding: '12px 20px', borderRadius: '5px', cursor: 'pointer', fontSize: '16px', width: '100%', marginTop: '10px' };
const listStyle = { listStyleType: 'none', padding: 0 };
const listItemStyle = { backgroundColor: '#fff', border: '1px solid #ddd', padding: '10px', borderRadius: '4px', marginBottom: '10px' };

const ApplicationForm = ({ application, onApplicationChange, onApplicationSubmit, userDesign, setCurrentStep }) => {
    return (
        <div style={formContainerStyle}>
            <h2>Step 2: Add Applications to System '{userDesign.systems[0]?.sysname}'</h2>
            <h4>Added Applications:</h4>
            {userDesign.applications.length === 0 ? (
                <p>No applications added yet.</p>
            ) : (
                <ul style={listStyle}>
                    {userDesign.applications.map((app, index) => (
                        <li key={index} style={listItemStyle}>{app.appname} ({app.appid})</li>
                    ))}
                </ul>
            )}

            <hr style={{margin: '20px 0'}} />

            <h4>Add New Application:</h4>
            <form onSubmit={onApplicationSubmit}>
                <div style={formGroupStyle}>
                    <label style={labelStyle} htmlFor="appid">Application ID</label>
                    <input style={inputStyle} type="text" id="appid" name="appid" value={application.appid} onChange={onApplicationChange} required />
                </div>
                <div style={formGroupStyle}>
                    <label style={labelStyle} htmlFor="appname">Application Name</label>
                    <input style={inputStyle} type="text" id="appname" name="appname" value={application.appname} onChange={onApplicationChange} required />
                </div>
                 <div style={formGroupStyle}>
                    <label style={labelStyle} htmlFor="deployment_model_id">Deployment Model ID</label>
                    <input style={inputStyle} type="text" id="deployment_model_id" name="deployment_model_id" value={application.deployment_model_id} onChange={onApplicationChange} required />
                </div>
                {/* Add other application fields as dropdowns */}
                <button style={buttonStyle} type="submit">Add Application</button>
            </form>

            <button style={{...buttonStyle, backgroundColor: '#4CAF50', marginTop: '20px'}} onClick={() => setCurrentStep(3)}>
                Next: Add Services
            </button>
        </div>
    );
};

export default ApplicationForm;
