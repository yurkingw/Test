import React from 'react';

// --- Styles --- //
const formContainerStyle = { margin: '20px auto', padding: '20px', maxWidth: '800px', backgroundColor: '#f9f9f9', borderRadius: '8px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)', textAlign: 'left' };
const formGroupStyle = { marginBottom: '15px' };
const labelStyle = { display: 'block', marginBottom: '5px', color: '#333', fontWeight: 'bold' };
const inputStyle = { width: '100%', padding: '10px', border: '1px solid #ccc', borderRadius: '4px', boxSizing: 'border-box' };
const buttonStyle = { backgroundColor: '#1976D2', color: '#FFFFFF', border: 'none', padding: '12px 20px', borderRadius: '5px', cursor: 'pointer', fontSize: '16px', width: '100%', marginTop: '10px' };
const listStyle = { listStyleType: 'none', padding: 0 };
const listItemStyle = { backgroundColor: '#fff', border: '1px solid #ddd', padding: '10px', borderRadius: '4px', marginBottom: '10px' };

const ServiceInstanceForm = ({ serviceInstance, onServiceInstanceChange, onServiceInstanceSubmit, userDesign, setCurrentStep }) => {
    return (
        <div style={formContainerStyle}>
            <h2>Step 4: Add Service Instances</h2>
            <h4>Added Instances:</h4>
            {userDesign.service_instances.length === 0 ? <p>No instances added yet.</p> : (
                <ul style={listStyle}>
                    {userDesign.service_instances.map((inst, i) => <li key={i} style={listItemStyle}>{inst.svcintname}</li>)}
                </ul>
            )}
            <hr style={{margin: '20px 0'}} />
            <h4>Add New Service Instance:</h4>
            <form onSubmit={onServiceInstanceSubmit}>
                <div style={formGroupStyle}>
                    <label style={labelStyle}>Parent Service</label>
                    <select style={inputStyle} name="svcid" value={serviceInstance.svcid} onChange={onServiceInstanceChange} required>
                        <option value="" disabled>Select a service</option>
                        {userDesign.services.map(s => <option key={s.svcid} value={s.svcid}>{s.svcname}</option>)}
                    </select>
                </div>
                <div style={formGroupStyle}>
                    <label style={labelStyle}>Service Instance ID</label>
                    <input style={inputStyle} type="text" name="svcint_id" value={serviceInstance.svcint_id} onChange={onServiceInstanceChange} required />
                </div>
                <div style={formGroupStyle}>
                    <label style={labelStyle}>Service Instance Name</label>
                    <input style={inputStyle} type="text" name="svcintname" value={serviceInstance.svcintname} onChange={onServiceInstanceChange} required />
                </div>
                {/* Other service instance fields can be added here */}
                <button style={buttonStyle} type="submit">Add Service Instance</button>
            </form>
            <button style={{...buttonStyle, backgroundColor: '#4CAF50'}} onClick={() => setCurrentStep(5)}>Next: Add Connections</button>
        </div>
    );
};

export default ServiceInstanceForm;
