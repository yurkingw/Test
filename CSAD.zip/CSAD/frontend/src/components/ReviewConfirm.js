import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { getCaseApi } from '../api/cases';
import FormReadonly from './FormReadonly';
import { appendCaseIdParam } from '../utils/caseId';
import { buildCalmReport, stripAttachmentData } from '../utils/calmUtils';
import { useBlueprintTemplates } from '../hooks/useBlueprintTemplates';

const containerStyle = { margin: '20px auto', maxWidth: '1100px', padding: '20px', backgroundColor: '#f7faff', borderRadius: '10px', border: '1px solid #dce3f5', textAlign: 'left' };
const buttonPrimaryStyle = { backgroundColor: '#1976D2', color: '#FFFFFF', border: 'none', padding: '10px 16px', borderRadius: '6px', cursor: 'pointer', fontSize: '15px' };
const sectionCardStyle = { backgroundColor: '#fff', border: '1px dashed #90caf9', padding: '12px', borderRadius: '10px', marginBottom: '16px' };

const renderJSON = (data) => (
  <pre style={{ whiteSpace: 'pre-wrap', background: '#f1f4ff', padding: '10px', borderRadius: '6px', border: '1px solid #dce3f7' }}>
    {JSON.stringify(data, null, 2)}
  </pre>
);

const ReviewConfirm = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const caseId = useMemo(() => searchParams.get('caseId'), [searchParams]);
  const [caseData, setCaseData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { templates } = useBlueprintTemplates();

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const data = await getCaseApi(caseId);
        if (mounted) setCaseData(data);
      } catch (e) {
        console.error('Failed to load case', e);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, [caseId]);

  const payload = caseData?.designPayload;
  const reviewerExtras = useMemo(() => {
    if (!caseData) return [];
    const direct = caseData.reviewerExtraFindings || caseData.reviewer_extra_findings || [];
    if (Array.isArray(direct) && direct.length) return direct;
    const snapshot = caseData.finalSnapshot || {};
    const fallback = snapshot.addedFindings || snapshot.reviewerExtraFindings || snapshot.reviewer_extra_findings || [];
    return Array.isArray(fallback) ? fallback : [];
  }, [caseData]);
  const calmSummary = useMemo(
    () => buildCalmReport({
      payload: payload || {},
      findings: caseData?.findings || [],
      manualFindings: reviewerExtras,
      templates,
    }),
    [payload, caseData?.findings, reviewerExtras, templates]
  );
  const getFindingTypeLabel = (finding) => {
    if (finding?.kind === 'ai' || (finding?.id || '').startsWith('AI-')) return 'AI Pre-Review';
    if (finding?.kind === 'manual' || finding?.riskDescription || finding?.issueContext) return 'Manual Review';
    return 'Rule-Based Pre-Review';
  };

  if (loading) {
    return (
      <div style={containerStyle}>
        <h2>Review Confirm</h2>
        <p>Loading...</p>
        <button type="button" style={buttonPrimaryStyle} onClick={() => navigate('/my-cases')}>Back to My Cases</button>
      </div>
    );
  }

  if (!caseData) {
    return (
      <div style={containerStyle}>
        <h2>Review Confirm</h2>
        <p>Case not found. Return to My Cases.</p>
        <button type="button" style={buttonPrimaryStyle} onClick={() => navigate('/my-cases')}>Back to My Cases</button>
      </div>
    );
  }

  if (caseData.status !== 'returned') {
    return (
      <div style={containerStyle}>
        <h2>Review Confirm</h2>
        <p>This case is not in returned status. Please reopen from My Cases when it is returned.</p>
        <button type="button" style={buttonPrimaryStyle} onClick={() => navigate('/my-cases')}>Back to My Cases</button>
      </div>
    );
  }

  return (
    <div style={containerStyle}>
      <h2>Review Confirm</h2>
      <p>Review your case details and upload evidence before resubmitting.</p>

      <div style={sectionCardStyle}>
        <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', alignItems: 'center' }}>
          <button
            type="button"
            style={buttonPrimaryStyle}
            onClick={() =>
              navigate(appendCaseIdParam('/evidence-collection', caseData.id), {
                state: { findings: caseData.findings || [], evidence: caseData.evidence || {}, payload, caseId: caseData.id },
              })
            }
          >
            Control Confirm &amp; Evidence Collection
          </button>
        </div>

        <div style={{ marginTop: '10px' }}>
          <h4>Design (Form)</h4>
          <FormReadonly checklist={payload?.metadata?.checklist} />
        </div>
        <div style={{ marginTop: '10px' }}>
          <h4>Design (CALM)</h4>
          {renderJSON(stripAttachmentData(calmSummary))}
        </div>
        <div style={{ marginTop: '10px' }}>
          <h4>Review Findings (CALM)</h4>
          {caseData.findings?.length ? (
            <div>
              {caseData.findings
                .filter((finding) =>
                  Boolean(
                    (finding?.details?.violation_summary || '').trim()
                    || (finding?.riskDescription || '').trim()
                    || (finding?.issueContext || '').trim()
                  )
                )
                .map((finding, idx) => (
                <div key={finding.id || idx} style={{ padding: '10px 0', borderBottom: '1px solid #e0e0e0' }}>
                  <div><strong>Finding Type:</strong> {getFindingTypeLabel(finding)}</div>
                  <div><strong>Risk Description:</strong> {finding.details?.violation_summary || finding.riskDescription || '—'}</div>
                  <div><strong>Classification:</strong> {finding.details?.classification || finding.classification || '—'}</div>
                  <div><strong>Risk:</strong> {finding.details?.risk || finding.riskLevel || '—'}</div>
                </div>
              ))}
            </div>
          ) : <p>No findings.</p>}
        </div>
      </div>
    </div>
  );
};

export default ReviewConfirm;
