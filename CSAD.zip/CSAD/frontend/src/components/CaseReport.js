import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import ReactMarkdown from 'react-markdown';
import apiClient from '../api';

const CaseReport = () => {
    const { caseId } = useParams();
    const [reportContent, setReportContent] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchReport = async () => {
            try {
                const response = await apiClient.get(`/cases/${caseId}/report`, {
                    responseType: 'text',
                });
                setReportContent(response.data);
            } catch (e) {
                setError(e.message);
            } finally {
                setLoading(false);
            }
        };

        fetchReport();
    }, [caseId]);

    const reportBoxStyle = {
        border: '1px solid #ccc',
        padding: '20px',
        marginTop: '20px',
        backgroundColor: '#f9f9f9',
        textAlign: 'left' // Align markdown content to the left
    };

    return (
        <div>
            <h1>Security Design Report for Case: {caseId}</h1>
            <div style={reportBoxStyle}>
                {loading && <p>Loading report...</p>}
                {error && <p>Error fetching report: {error}</p>}
                {!loading && !error && (
                    <ReactMarkdown>{reportContent}</ReactMarkdown>
                )}
            </div>
        </div>
    );
};

export default CaseReport;
