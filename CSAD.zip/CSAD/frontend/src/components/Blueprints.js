/**
 * ------------------------------------------------------------------------
 * Blueprints Component
 * ------------------------------------------------------------------------
 * This component fetches and displays a list of security blueprints from the API.
 * For each blueprint, it also renders the associated review findings.
 */

import React, { useState, useEffect } from 'react';
import apiClient from '../api';
import ReviewFindings from './ReviewFindings';

/**
 * Renders a list of security blueprints and their findings.
 * @returns {JSX.Element} The rendered Blueprints component.
 */
function Blueprints() {
  // State to hold the list of blueprints.
  const [blueprints, setBlueprints] = useState([]);

  // useEffect hook to fetch data when the component mounts.
  useEffect(() => {
    // Fetch blueprints from the backend API.
    apiClient.get('/blueprints/')
      .then(response => {
        // On success, update the state with the fetched data.
        setBlueprints(response.data);
      })
      .catch(error => {
        // Log any errors to the console.
        console.error('Error fetching blueprints:', error);
      });
  }, []); // The empty dependency array ensures this effect runs only once.

  return (
    <div>
      <h2>Existing Security Blueprints</h2>
      {blueprints.length === 0 ? (
        <p>No blueprints found in the database.</p>
      ) : (
        <ul>
          {/* Map over the blueprints and render a list item for each one. */}
          {blueprints.map(bp => (
            <li key={bp.id}>
              <strong>ID {bp.id}:</strong> {bp.component_type}
              {/* Display the blueprint details in a formatted JSON block. */}
              <pre style={{ textAlign: 'left', whiteSpace: 'pre-wrap' }}>{JSON.stringify(bp.details, null, 2)}</pre>
              
              {/* Render the ReviewFindings component for the current blueprint. */}
              <ReviewFindings blueprintId={bp.id} />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default Blueprints;
