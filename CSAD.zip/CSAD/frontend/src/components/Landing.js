import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useUser } from '../context/UserContext';

const pageStyle = {
  backgroundColor: '#FFFFFF',
  color: '#000000',
  minHeight: '100vh',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  fontFamily: 'sans-serif',
};

const containerStyle = {
  textAlign: 'center',
  border: '1px solid #CCCCCC',
  padding: '40px',
  borderRadius: '12px',
  boxShadow: '0 6px 14px rgba(0,0,0,0.12)',
  maxWidth: '600px',
  width: '90%',
};

const titleStyle = {
  color: '#0D47A1',
  marginBottom: '30px',
};

const buttonStyle = {
  backgroundColor: '#1976D2',
  color: '#FFFFFF',
  border: 'none',
  padding: '15px 30px',
  margin: '10px',
  borderRadius: '5px',
  cursor: 'pointer',
  fontSize: '16px',
};

const selectStyle = {
  padding: '10px',
  fontSize: '16px',
  borderRadius: '4px',
  border: '1px solid #ccc',
  width: '100%',
  maxWidth: '320px',
  margin: '0 auto 10px auto',
};

const descriptionStyle = {
  fontSize: '15px',
  color: '#444',
  marginBottom: '25px',
  lineHeight: 1.5,
};

const Landing = () => {
  const navigate = useNavigate();
  const { user } = useUser();

  const handleSubmit = () => {
    if (!user?.name || !user?.role) {
      alert('Please login before submitting a case.');
      return;
    }
    navigate('/bind-ticket');
  };

  return (
    <div style={pageStyle}>
      <div style={containerStyle}>
        <h1 style={titleStyle}>COD Security Design Review Platform</h1>

        <p style={descriptionStyle}>
          Start from security review guidances - <a href="https://www.baidu.com" target="_blank" rel="noopener noreferrer">https://www.baidu.com</a>
        </p>
        <p style={descriptionStyle}>
          Find the case you submitted under "My Cases" in the upper left corner of the page.
        </p>
        <button type="button" style={buttonStyle} onClick={handleSubmit}>
          Submit Case
        </button>
        <button type="button" style={buttonStyle} onClick={() => { window.open('https://www.baidu.com', '_blank', 'noopener,noreferrer'); }}>
          Get Help
        </button>
      </div>
    </div>
  );
};

export default Landing;
