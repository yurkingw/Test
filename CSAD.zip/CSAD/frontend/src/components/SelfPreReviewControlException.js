import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import apiClient from '../api';
import { REVIEW_TYPES } from '../constants/reviewTypes';
import { useReviewCache } from '../context/ReviewCacheContext';
import CoDesignAssistantModal from './helpers/CoDesignAssistantModal';
import { createCaseApi, getCaseApi, saveCaseApi, confirmAndCancelCase, listCasesApi } from '../api/cases';
import { listSecurityDomainsApi, listSecurityZonesApi, listSecurityComponentsApi, listSubnetBoundariesApi, listProtocolPortsApi } from '../api/insight';
import FormReadonly from './FormReadonly';
import { ensureFileMetaArray } from '../utils/fileUtils';
import { uploadFiles } from '../utils/attachments';
import { useUser } from '../context/UserContext';
import { buildCalmReport } from '../utils/calmUtils';
import { useBlueprintTemplates } from '../hooks/useBlueprintTemplates';

const containerStyle = { margin: '20px auto', padding: '20px', maxWidth: '1240px', backgroundColor: '#f5f7ff', borderRadius: '10px', boxShadow: '0 4px 14px rgba(0,0,0,0.08)', textAlign: 'left' };
const sectionCardStyle = { backgroundColor: '#fff', border: '1px solid #dde3f7', padding: '18px', borderRadius: '10px', marginBottom: '20px' };
const disclaimerCardStyle = { border: '1px solid #c5cae9', backgroundColor: '#eef2ff' };
const formGroupStyle = { marginBottom: '15px' };
const labelStyle = { display: 'block', marginBottom: '6px', color: '#1a237e', fontWeight: 'bold' };
const requiredStar = <span style={{ color: '#d32f2f', marginLeft: '4px' }}>*</span>;
const inputStyle = { width: '100%', padding: '10px', border: '1px solid #b0bec5', borderRadius: '4px', boxSizing: 'border-box', backgroundColor: '#fafafa' };
const textareaStyle = { ...inputStyle, minHeight: '100px', resize: 'vertical' };
const buttonPrimaryStyle = { backgroundColor: '#1976D2', color: '#FFFFFF', border: 'none', padding: '12px 20px', borderRadius: '5px', cursor: 'pointer', fontSize: '16px', marginTop: '12px' };
const buttonSecondaryStyle = { ...buttonPrimaryStyle, backgroundColor: '#607d8b' };
const summaryCardStyle = { backgroundColor: '#fff', border: '1px solid #d0d8eb', padding: '15px', borderRadius: '8px', marginBottom: '15px' };
const tableStyle = { width: '100%', borderCollapse: 'collapse', fontSize: '0.92rem' };
const scrollTableWrapperStyle = { overflowX: 'auto' };
const dataConnectionTableStyle = { ...tableStyle, minWidth: '1500px' };
const firewallTableStyle = { ...tableStyle, minWidth: '1900px' };
const proxyTableStyle = { ...tableStyle, minWidth: '1200px' };
const thStyle = { padding: '8px', border: '1px solid #c5cae9', backgroundColor: '#e8eaf6', textAlign: 'left' };
const tdStyle = { padding: '6px', border: '1px solid #cfd8dc', verticalAlign: 'top' };
const wideColumnStyle = { minWidth: '120px' };
const mediumColumnStyle = { minWidth: '140px' };
const checklistListStyle = { listStyle: 'none', padding: 0, margin: 0 };
const checklistItemStyle = { display: 'flex', alignItems: 'flex-start', gap: '10px', marginBottom: '10px', color: '#333' };

const CONTROL_EXCEPTION_TYPE_OPTIONS = [
  { value: 'firewall_flow', label: 'Firewall Flow' },
  { value: 'proxy_flow', label: 'Proxy Flow' },
  { value: 'privileged_access', label: 'Privileged Access' },
  { value: 'enable_poc_testing', label: 'Enable PoC Test' },
  { value: 'other', label: 'Other' },
];
const CONTROL_EXCEPTION_TYPE_LABELS = CONTROL_EXCEPTION_TYPE_OPTIONS.reduce((acc, item) => {
  acc[item.value] = item.label;
  return acc;
}, {});

const DATA_PERIMETER_SELECTS = [
  { key: 'arr20', label: 'ARR 2.0', options: ['P1', 'P2', 'P3', 'P4'] },
  { key: 'isc', label: 'ISC', options: ['Public', 'Confidential', 'Highly Restricted'] },
  { key: 'pii', label: 'PII', options: ['No', 'Public', 'Confidential', 'Highly Restricted'] },
  { key: 'mnpi', label: 'MNPI', options: ['Yes', 'No'] },
];
const YES_NO_OPTIONS = ['Yes', 'No'];

const PROXY_TYPE_OPTIONS = [
  { value: 'HTTP Proxy', label: 'HTTP Proxy' },
  { value: 'SOCKS Proxy', label: 'SOCKS Proxy' },
];
const PROXY_AUTH_OPTIONS = [
  'None',
  'HTTP-Auth-Proxy-8888',
  'HTTP-NonAuth-Proxy-8080',
  'HTTP-NonAuth-WinHTTP-Proxy-7777',
  'SOCKS-Auth-Proxy-1088',
  'SOCKS-NonAuth-Proxy-1080',
];
const FEATURE_TOGGLE_OPTIONS = ['Enabled', 'Disabled'];
const DATA_CONNECTION_FIELD_LABELS = {
  src_object: 'Source Object',
  src_domain: 'Source Sec Domain',
  src_zone: 'Source Sec Zone',
  dst_object: 'Destination Object',
  dst_domain: 'Destination Sec Domain',
  dst_zone: 'Destination Sec Zone',
  accessed_protocol: 'Accessed Protocol & Port or Method',
  payload_data: 'Payload Data',
  implemented_controls: 'Implemented Controls',
  purpose: 'Purpose',
};
const IMPLEMENTED_CONTROL_FIELDS = [
  { key: 'authn_authz', label: 'AuthN & AuthZ', options: ['Yes', 'No'] },
  { key: 'access_control', label: 'Access Control', options: ['Yes', 'No'] },
  { key: 'audit_logging', label: 'Audit & Logging', options: ['Yes', 'No'] },
  { key: 'encryption', label: 'Encryption', options: ['Yes', 'No'] },
  { key: 'privileged_access', label: 'Privileged Access', options: ['IAM PA Onboarding', 'No', 'Other'] },
  { key: 'dlp', label: 'DLP', options: ['Yes', 'No'] },
];
const FIREWALL_FIELD_LABELS = {
  source_eonid: 'Source EONID / AssetID',
  source_component: 'Source Component',
  source_domain: 'Source Security Plant Domain',
  source_zone: 'Source Security Zone',
  source_subnet: 'Source Subnet Boundary',
  destination_eonid: 'Destination EONID / AssetID',
  destination_component: 'Destination Component',
  destination_domain: 'Destination Security Plant Domain',
  destination_zone: 'Destination Security Zone',
  destination_subnet: 'Destination Subnet Boundary',
};
const BINARY_QUESTION_LABELS = {
  external_transfer: 'Question 2 (External data transfer)',
  prod_data: 'Question 3 (PROD data)',
  prod_mdex: 'Question 4 (COD MDEX connection)',
  prod_mssip: 'Question 5 (COD MSSIP connection)',
};

const createDataConnectionRow = () => ({
  id: `${Date.now()}-${Math.random()}`,
  control_exception_types: [],
  src_object: '',
  src_domain: '',
  src_zone: '',
  dst_object: '',
  dst_domain: '',
  dst_zone: '',
  accessed_protocol: '',
  payload_data: '',
  implemented_controls: {
    authn_authz: { value: '', description: '' },
    access_control: { value: '', description: '' },
    audit_logging: { value: '', description: '' },
    encryption: { value: '', description: '' },
    privileged_access: { value: '', description: '' },
    dlp: { value: '', description: '' },
  },
  purpose: '',
});

const normalizeDataConnectionRow = (row = {}) => ({
  id: row.id || `${Date.now()}-${Math.random()}`,
  control_exception_types: row.control_exception_types || [],
  src_object: row.src_object || '',
  src_domain: row.src_domain || row.src_domain_zone || '',
  src_zone: row.src_zone || '',
  dst_object: row.dst_object || '',
  dst_domain: row.dst_domain || row.dst_domain_zone || '',
  dst_zone: row.dst_zone || '',
  accessed_protocol: row.accessed_protocol || '',
  payload_data: row.payload_data || '',
  implemented_controls: typeof row.implemented_controls === 'object' && row.implemented_controls
    ? row.implemented_controls
    : {
        authn_authz: { value: '', description: '' },
        access_control: { value: '', description: '' },
        audit_logging: { value: '', description: '' },
        encryption: { value: '', description: '' },
        privileged_access: { value: '', description: '' },
        dlp: { value: '', description: '' },
      },
  purpose: row.purpose || '',
});

const createFirewallDetailRow = () => ({
  id: `${Date.now()}-${Math.random()}`,
  connection_ref: '',
  source_eonid: '',
  source_application: '',
  source_component: '',
  source_domain: '',
  source_zone: '',
  source_subnet: '',
  destination_eonid: '',
  destination_application: '',
  destination_component: '',
  destination_domain: '',
  destination_zone: '',
  destination_subnet: '',
  protocol_ports: [],
  expiry_date: '',
  business_justification: '',
});

const normalizeFirewallDetailRow = (row = {}) => ({
  id: row.id || `${Date.now()}-${Math.random()}`,
  connection_ref: row.connection_ref || '',
  source_eonid: row.source_eonid || '',
  source_application: row.source_application || '',
  source_component: row.source_component || '',
  source_domain: row.source_domain || '',
  source_zone: row.source_zone || '',
  source_subnet: row.source_subnet || '',
  destination_eonid: row.destination_eonid || '',
  destination_application: row.destination_application || '',
  destination_component: row.destination_component || '',
  destination_domain: row.destination_domain || '',
  destination_zone: row.destination_zone || '',
  destination_subnet: row.destination_subnet || '',
  protocol_ports: Array.isArray(row.protocol_ports)
    ? row.protocol_ports
    : row.protocol_port
      ? [row.protocol_port]
      : [],
  expiry_date: row.expiry_date || '',
  business_justification: row.business_justification || '',
});

const createProxyDetailRow = () => ({
  id: `${Date.now()}-${Math.random()}`,
  connection_ref: '',
  enable_offshore_proxy: 'No',
  source_object_type: 'Individual',
  target_urls: [],
  proxy_type: 'HTTP Proxy',
  proxy_authentication: 'None',
  proxy_ssl_inspection: 'Enabled',
  proxy_antivirus: 'Enabled',
  expiry_date: '',
  business_justification: '',
});

const normalizeProxyDetailRow = (row = {}) => ({
  id: row.id || `${Date.now()}-${Math.random()}`,
  connection_ref: row.connection_ref || '',
  enable_offshore_proxy: row.enable_offshore_proxy || 'No',
  source_object_type: row.source_object_type || 'Individual',
  target_urls: Array.isArray(row.target_urls) ? row.target_urls : [],
  proxy_type: row.proxy_type || 'HTTP Proxy',
  proxy_authentication: row.proxy_authentication || 'None',
  proxy_ssl_inspection: row.proxy_ssl_inspection || 'Enabled',
  proxy_antivirus: row.proxy_antivirus || 'Enabled',
  expiry_date: row.expiry_date || '',
  business_justification: row.business_justification || '',
});

const SelfPreReviewControlException = ({ reviewType }) => {
  const reviewMeta = useMemo(() => REVIEW_TYPES[reviewType] ?? REVIEW_TYPES.security_design, [reviewType]);
  const navigate = useNavigate();
  const cacheKey = `self_control_exception_${reviewType}`;
  const { cachedValue, saveCache, clearCacheForKey } = useReviewCache(cacheKey);
  const hydrated = useRef(false);
  const lastSavedRef = useRef(null);

  const shallowEqual = (a, b) => {
    if (a === b) return true;
    if (!a || !b) return false;
    const keysA = Object.keys(a);
    const keysB = Object.keys(b);
    if (keysA.length !== keysB.length) return false;
    for (const key of keysA) {
      if (a[key] !== b[key]) return false;
    }
    return true;
  };

  const [controlScenarioType, setControlScenarioType] = useState('');
  const [scenarioChecks, setScenarioChecks] = useState({
    firewall_flowdb_flow: false,
    proxy_flow: false,
    privileged_access: false,
    enable_poc_testing: false,
  });
  const [otherScenarioText, setOtherScenarioText] = useState('');
  const [businessJustification, setBusinessJustification] = useState('');
  const [architectureDescription, setArchitectureDescription] = useState('');
  const [architectureFiles, setArchitectureFiles] = useState([]);
  const [dataPerimeter, setDataPerimeter] = useState({
    arr20: '',
    isc: '',
    pii: '',
    mnpi: '',
    external_transfer: '',
    prod_data: '',
    prod_mdex: '',
    prod_mssip: '',
  });
  const [dataConnections, setDataConnections] = useState([createDataConnectionRow()]);
  const [firewallDetails, setFirewallDetails] = useState([createFirewallDetailRow()]);
  const [proxyDetails, setProxyDetails] = useState([createProxyDetailRow()]);
  const [proxyUrlInputs, setProxyUrlInputs] = useState({});
  const [protocolPortInputs, setProtocolPortInputs] = useState({});
  const [exceptionExpiry, setExceptionExpiry] = useState('');
  const [integratorReviewer, setIntegratorReviewer] = useState('');
  const [securityDomains, setSecurityDomains] = useState([]);
  const [securityZones, setSecurityZones] = useState([]);
  const [securityComponents, setSecurityComponents] = useState([]);
  const [subnetBoundaries, setSubnetBoundaries] = useState([]);
  const [protocolPortOptions, setProtocolPortOptions] = useState([]);
  const [reviewerUsers, setReviewerUsers] = useState([]);
  const [insightError, setInsightError] = useState('');

  const [isLoading, setIsLoading] = useState(false);
  const [validationNote, setValidationNote] = useState('');
  const architectureProvided = architectureFiles.length > 0;
  const minimumExpiryDate = useMemo(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  }, []);
  const maxExceptionExpiryDate = useMemo(() => {
    const maxDate = new Date();
    maxDate.setDate(maxDate.getDate() + 365);
    return maxDate.toISOString().split('T')[0];
  }, []);

  const [searchParams] = useSearchParams();
  const caseId = useMemo(() => searchParams.get('caseId'), [searchParams]);
  const ticketIdParam = useMemo(() => searchParams.get('ticketId') || '', [searchParams]);
  const [caseData, setCaseData] = useState(null);
  const [loadingCase, setLoadingCase] = useState(false);
  const { user, presetUsers } = useUser();
  const { templates } = useBlueprintTemplates();
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [assistantMessages, setAssistantMessages] = useState([]);
  const [showSavedFeedback, setShowSavedFeedback] = useState(false);
  const [showSavedForm, setShowSavedForm] = useState(false);
  const [showSavedCalm, setShowSavedCalm] = useState(false);
  const [showSavedFindings, setShowSavedFindings] = useState(false);

  const hasFirewallType = useMemo(
    () => dataConnections.some((row) => row.control_exception_types.includes('firewall_flow')),
    [dataConnections]
  );
  const hasProxyType = useMemo(
    () => dataConnections.some((row) => row.control_exception_types.includes('proxy_flow')),
    [dataConnections]
  );

  const hasManualSaveRef = useRef(false);
  const hasContent = useMemo(() => {
    if (controlScenarioType) return true;
    if (otherScenarioText.trim() || businessJustification.trim() || architectureDescription.trim()) return true;
    if (architectureFiles.length) return true;
    if (exceptionExpiry || integratorReviewer) return true;
    if (Object.values(dataPerimeter).some((value) => value)) return true;
    const hasDataConnections = dataConnections.some((row) =>
      row.control_exception_types.length ||
      row.src_object ||
      row.src_domain ||
      row.src_zone ||
      row.dst_object ||
      row.dst_domain ||
      row.dst_zone ||
      row.accessed_protocol ||
      row.payload_data ||
      row.purpose
    );
    if (hasDataConnections) return true;
    const hasFirewallDetails = firewallDetails.some((row) =>
      row.connection_ref ||
      row.source_eonid ||
      row.source_application ||
      row.source_component ||
      row.source_domain ||
      row.source_zone ||
      row.source_subnet ||
      row.destination_eonid ||
      row.destination_application ||
      row.destination_component ||
      row.destination_domain ||
      row.destination_zone ||
      row.destination_subnet ||
      row.protocol_ports.length ||
      row.business_justification
    );
    if (hasFirewallDetails) return true;
    const hasProxyDetails = proxyDetails.some((row) =>
      row.connection_ref ||
      row.target_urls.length ||
      row.business_justification
    );
    return hasProxyDetails;
  }, [
    controlScenarioType,
    otherScenarioText,
    businessJustification,
    architectureDescription,
    architectureFiles,
    exceptionExpiry,
    integratorReviewer,
    dataPerimeter,
    dataConnections,
    firewallDetails,
    proxyDetails,
  ]);

  const renderJSON = (data) => (
    <pre style={{ whiteSpace: 'pre-wrap', backgroundColor: '#f1f4ff', padding: '12px', borderRadius: '6px', fontSize: '0.92rem', textAlign: 'left' }}>
      {JSON.stringify(data, null, 2)}
    </pre>
  );

  useEffect(() => {
    if (hydrated.current) return;
    if (cachedValue) {
      const cachedBasis = cachedValue.basisOptions;
      const cachedScenario = cachedValue.scenarioOptions;
      if (cachedValue.controlScenarioType) {
        setControlScenarioType(cachedValue.controlScenarioType);
      } else if (cachedBasis) {
        if (cachedBasis.full_designs_unavailable) {
          setControlScenarioType('full_design_not_ready');
        } else if (cachedBasis.asset_risk_accepted) {
          setControlScenarioType('risk_accepted');
        } else if (cachedBasis.other_exception) {
          setControlScenarioType('other');
        }
      }
      if (cachedValue.scenarioChecks) {
        setScenarioChecks(cachedValue.scenarioChecks);
      } else if (cachedScenario) {
        setScenarioChecks({
          firewall_flowdb_flow: !!cachedScenario.firewall_flowdb_flow,
          proxy_flow: !!cachedScenario.proxy_flow,
          privileged_access: !!cachedScenario.privileged_access,
          enable_poc_testing: !!cachedScenario.enable_poc_testing,
        });
      }
      setOtherScenarioText(cachedValue.otherScenarioText ?? cachedValue.scenarioOtherContext ?? '');
      setBusinessJustification(cachedValue.businessJustification ?? '');
      setArchitectureDescription(cachedValue.architectureDescription ?? '');
      setArchitectureFiles(ensureFileMetaArray(cachedValue.architectureFiles));
      setDataPerimeter(
        cachedValue.dataPerimeter ?? {
          arr20: '',
          isc: '',
          pii: '',
          mnpi: '',
          external_transfer: '',
          prod_data: '',
          prod_mdex: '',
          prod_mssip: '',
        }
      );
      setDataConnections(
        cachedValue.dataConnections?.length
          ? cachedValue.dataConnections.map((row) => normalizeDataConnectionRow(row))
          : [createDataConnectionRow()]
      );
      setFirewallDetails(
        cachedValue.firewallDetails?.length
          ? cachedValue.firewallDetails.map((row) => normalizeFirewallDetailRow(row))
          : [createFirewallDetailRow()]
      );
      setProxyDetails(
        cachedValue.proxyDetails?.length
          ? cachedValue.proxyDetails.map((row) => normalizeProxyDetailRow(row))
          : [createProxyDetailRow()]
      );
      setProxyUrlInputs(cachedValue.proxyUrlInputs ?? {});
      setProtocolPortInputs(cachedValue.protocolPortInputs ?? {});
      setExceptionExpiry(cachedValue.exceptionExpiry ?? cachedValue.expectedException ?? '');
      setIntegratorReviewer(cachedValue.integratorReviewer ?? '');
      setAssistantMessages(cachedValue.assistantMessages ?? []);
    }
  }, [cachedValue]);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const [domainsResp, zonesResp, componentsResp, subnetsResp, portsResp] = await Promise.all([
          listSecurityDomainsApi(),
          listSecurityZonesApi(),
          listSecurityComponentsApi(),
          listSubnetBoundariesApi(),
          listProtocolPortsApi(),
        ]);
        if (!mounted) return;
        setSecurityDomains(domainsResp.items || []);
        setSecurityZones(zonesResp.items || []);
        setSecurityComponents(componentsResp.items || []);
        setSubnetBoundaries(subnetsResp.items || []);
        setProtocolPortOptions(portsResp.items || []);
        setReviewerUsers((presetUsers || []).filter((entry) => entry.role === 'Reviewer'));
        setInsightError('');
      } catch (error) {
        console.error('Failed to load security options', error);
        if (mounted) setInsightError('Failed to load Security options.');
      }
    })();
    return () => { mounted = false; };
  }, [presetUsers]);

  useEffect(() => {
    let mounted = true;
    if (!caseId) {
      hydrated.current = true;
      return;
    }
    setLoadingCase(true);
    (async () => {
      try {
        const stored = await getCaseApi(caseId);
        if (!mounted) return;
        setCaseData(stored);
        hasManualSaveRef.current = true;
        if (stored?.designPayload) {
          const payload = stored.designPayload;
          const checklist = payload.metadata?.checklist || {};
          setAssistantMessages(payload.assistant_chat || []);
          const basis = checklist.basis_options || { full_designs_unavailable: false, asset_risk_accepted: false, other_exception: false };
          if (basis.full_designs_unavailable) {
            setControlScenarioType('full_design_not_ready');
          } else if (basis.asset_risk_accepted) {
            setControlScenarioType('risk_accepted');
          } else if (basis.other_exception) {
            setControlScenarioType('other');
          } else {
            setControlScenarioType('');
          }
          const scenarios = checklist.scenario_options || {};
          setScenarioChecks({
            firewall_flowdb_flow: !!scenarios.firewall_flowdb_flow,
            proxy_flow: !!scenarios.proxy_flow,
            privileged_access: !!scenarios.privileged_access,
            enable_poc_testing: !!scenarios.enable_poc_testing,
          });
          setOtherScenarioText(checklist.scenario_other_context || '');
          setBusinessJustification(checklist.business_justification || '');
          setArchitectureDescription(checklist.architecture_description || '');
          setArchitectureFiles(ensureFileMetaArray(checklist.architecture_files));
          setDataPerimeter(checklist.data_perimeter || {
            arr20: '',
            isc: '',
            pii: '',
            mnpi: '',
            external_transfer: '',
            prod_data: '',
            prod_mdex: '',
            prod_mssip: '',
          });
          setDataConnections(
            (checklist.data_connections || [createDataConnectionRow()]).map((row) => normalizeDataConnectionRow(row))
          );
          setExceptionExpiry(checklist.exception_expiry || checklist.expected_exception || '');
          setIntegratorReviewer(checklist.integrator_reviewer || '');
          setFirewallDetails(
            checklist.firewall_details && checklist.firewall_details.length
              ? checklist.firewall_details.map((row) => normalizeFirewallDetailRow(row))
              : [createFirewallDetailRow()]
          );
          setProxyDetails(
            checklist.proxy_details && checklist.proxy_details.length
              ? checklist.proxy_details.map((row) => normalizeProxyDetailRow(row))
              : [createProxyDetailRow()]
          );
        }
      } catch (e) {
        console.error('Failed to load case', e);
      } finally {
        hydrated.current = true;
        if (mounted) setLoadingCase(false);
      }
    })();
    return () => { mounted = false; };
  }, [caseId]);

  useEffect(() => {
    const handleBeforeUnload = (event) => {
      if (caseId || hasManualSaveRef.current || !hasContent) {
        return undefined;
      }
      event.preventDefault();
      event.returnValue = 'Page will be lost. Do you want to save?';
      return event.returnValue;
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [caseId, hasContent]);

  const buildCaseLabel = async (ticketId) => {
    if (!ticketId) {
      return `CASE-${Date.now()}`;
    }
    const allCases = await listCasesApi({});
    const countableStatuses = new Set(['submitted', 'returned', 'resubmitted', 'closed_approve', 'closed_deny']);
    const sameTicketCount = allCases.filter(
      (c) => (c.ticketId || '') === ticketId && countableStatuses.has(c.status)
    ).length;
    const seq = sameTicketCount + 1;
    return `${ticketId} (CSAD-${seq})`;
  };

  const findActiveCaseForTicket = async (ticketId, owner) => {
    if (!ticketId) return null;
    const allCases = await listCasesApi({});
    const activeCases = allCases.filter((c) =>
      (c.ticketId || '') === ticketId &&
      !['cancelled', 'closed_approve', 'closed_deny'].includes(c.status)
    );
    const candidates = owner
      ? activeCases.filter((c) => c.owner === owner)
      : activeCases;
    const pool = candidates.length ? candidates : activeCases;
    if (!pool.length) return null;
    const getUpdatedAt = (item) => {
      const raw = item.updatedAt || item.updated_at || '';
      const normalized = raw && !raw.endsWith('Z') ? `${raw}Z` : raw;
      const parsed = normalized ? new Date(normalized) : new Date(0);
      const ts = Number.isNaN(parsed.getTime()) ? 0 : parsed.getTime();
      return ts;
    };
    return pool.reduce((latest, item) =>
      getUpdatedAt(item) >= getUpdatedAt(latest) ? item : latest
    );
  };

  useEffect(() => {
      const snapshot = {
        controlScenarioType,
        scenarioChecks,
        otherScenarioText,
        businessJustification,
        architectureDescription,
        architectureFiles,
        dataPerimeter,
        dataConnections,
        firewallDetails,
        proxyDetails,
        proxyUrlInputs,
        protocolPortInputs,
        exceptionExpiry,
        integratorReviewer,
        assistantMessages,
      };
    if (shallowEqual(lastSavedRef.current, snapshot)) return;
    lastSavedRef.current = snapshot;
    saveCache(snapshot);
  }, [
    controlScenarioType,
    scenarioChecks,
    otherScenarioText,
    businessJustification,
    architectureDescription,
    architectureFiles,
    dataPerimeter,
    dataConnections,
    firewallDetails,
    proxyDetails,
    proxyUrlInputs,
    protocolPortInputs,
    exceptionExpiry,
    integratorReviewer,
    assistantMessages,
    saveCache,
  ]);

  const updateScenarioCheck = (key, value) => {
    setScenarioChecks((prev) => ({ ...prev, [key]: value }));
  };

  const handleArchitectureFiles = async (event) => {
    const files = Array.from(event.target.files || []);
    if (!files.length) return;
    try {
      const uploaded = await uploadFiles(files);
      setArchitectureFiles((prev) => [...prev, ...uploaded]);
    } catch (error) {
      console.error('Failed to upload architecture files', error);
      alert('Failed to upload architecture files.');
    }
  };

  const handleDataPerimeterSelect = (key, value) => {
    setDataPerimeter((prev) => ({ ...prev, [key]: value }));
  };

  const handleDataPerimeterBinary = (key, value) => {
    setDataPerimeter((prev) => ({ ...prev, [key]: value }));
  };

  const updateDataConnection = (index, field, value) => {
    setDataConnections((prev) =>
      prev.map((row, rowIndex) => (rowIndex === index ? { ...row, [field]: value } : row))
    );
  };

  const updateImplementedControl = (index, key, patch) => {
    setDataConnections((prev) =>
      prev.map((row, rowIndex) => {
        if (rowIndex !== index) return row;
        const controls = row.implemented_controls || {};
        const current = controls[key] || { value: '', description: '' };
        return {
          ...row,
          implemented_controls: {
            ...controls,
            [key]: { ...current, ...patch },
          },
        };
      })
    );
  };

  const addDataConnectionRow = () => {
    setDataConnections((prev) => [...prev, createDataConnectionRow()]);
  };

  const removeDataConnectionRow = (index) => {
    setDataConnections((prev) => {
      if (prev.length === 1) {
        return prev;
      }
      return prev.filter((_, rowIndex) => rowIndex !== index);
    });
  };

  const updateFirewallDetail = (index, field, value) => {
    setFirewallDetails((prev) =>
      prev.map((row, rowIndex) => (rowIndex === index ? { ...row, [field]: value } : row))
    );
  };

  const addFirewallDetailRow = () => {
    setFirewallDetails((prev) => [...prev, createFirewallDetailRow()]);
  };

  const removeFirewallDetailRow = (index) => {
    setFirewallDetails((prev) => {
      if (prev.length === 1) return prev;
      return prev.filter((_, rowIndex) => rowIndex !== index);
    });
  };

  const updateProxyDetail = (index, field, value) => {
    setProxyDetails((prev) =>
      prev.map((row, rowIndex) => (rowIndex === index ? { ...row, [field]: value } : row))
    );
  };

  const addProxyDetailRow = () => {
    setProxyDetails((prev) => [...prev, createProxyDetailRow()]);
  };

  const removeProxyDetailRow = (index) => {
    setProxyDetails((prev) => {
      if (prev.length === 1) return prev;
      return prev.filter((_, rowIndex) => rowIndex !== index);
    });
  };

  const handleProxyUrlInputChange = (rowId, value) => {
    setProxyUrlInputs((prev) => ({ ...prev, [rowId]: value }));
  };

  const handleAddProxyUrl = (rowId, value) => {
    const trimmed = (value || '').trim();
    if (!trimmed) return;
    if (!trimmed.includes('://')) {
      window.alert('URI Scheme Missed');
      return;
    }
    setProxyDetails((prev) =>
      prev.map((row) => {
        if (row.id !== rowId) return row;
        if (row.target_urls.includes(trimmed)) return row;
        return { ...row, target_urls: [...row.target_urls, trimmed] };
      })
    );
    setProxyUrlInputs((prev) => ({ ...prev, [rowId]: '' }));
  };

  const handleRemoveProxyUrl = (rowId, url) => {
    setProxyDetails((prev) =>
      prev.map((row) =>
        row.id === rowId ? { ...row, target_urls: row.target_urls.filter((item) => item !== url) } : row
      )
    );
  };

  const validateProtocolPort = (value) => {
    const trimmed = value.trim();
    const match = trimmed.match(/^(TCP|UDP)\s+(\d{1,5})$/i);
    if (!match) {
      return null;
    }
    const port = Number(match[2]);
    if (port < 0 || port > 65535) {
      return null;
    }
    return `${match[1].toUpperCase()} ${port}`;
  };

  const handleProtocolPortInputChange = (rowId, value) => {
    setProtocolPortInputs((prev) => ({ ...prev, [rowId]: value }));
  };

  const handleAddProtocolPortFromOption = (rowId, value) => {
    const trimmed = value.trim();
    if (!trimmed) return;
    setFirewallDetails((prev) =>
      prev.map((row) => {
        if (row.id !== rowId) return row;
        if (row.protocol_ports.includes(trimmed)) return row;
        return { ...row, protocol_ports: [...row.protocol_ports, trimmed] };
      })
    );
  };

  const handleAddProtocolPortFromInput = (rowId, value) => {
    const normalized = validateProtocolPort(value);
    if (!normalized) {
      window.alert('Protocol | Port format must be "TCP <0-65535>" or "UDP <0-65535>".');
      return;
    }
    setFirewallDetails((prev) =>
      prev.map((row) => {
        if (row.id !== rowId) return row;
        if (row.protocol_ports.includes(normalized)) return row;
        return { ...row, protocol_ports: [...row.protocol_ports, normalized] };
      })
    );
    setProtocolPortInputs((prev) => ({ ...prev, [rowId]: '' }));
  };

  const handleRemoveProtocolPort = (rowId, value) => {
    setFirewallDetails((prev) =>
      prev.map((row) =>
        row.id === rowId ? { ...row, protocol_ports: row.protocol_ports.filter((item) => item !== value) } : row
      )
    );
  };

  const handleAddControlType = (index, value) => {
    if (!value) return;
    setDataConnections((prev) =>
      prev.map((row, rowIndex) => {
        if (rowIndex !== index) return row;
        if (row.control_exception_types.includes(value)) return row;
        return { ...row, control_exception_types: [...row.control_exception_types, value] };
      })
    );
  };

  const handleRemoveControlType = (index, value) => {
    setDataConnections((prev) =>
      prev.map((row, rowIndex) =>
        rowIndex === index
          ? { ...row, control_exception_types: row.control_exception_types.filter((item) => item !== value) }
          : row
      )
    );
  };

  const isFutureDate = (value) => {
    if (!value) return false;
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) {
      return false;
    }
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return parsed.getTime() > today.getTime();
  };

  const collectValidationErrors = () => {
    const errors = [];
    if (!controlScenarioType) {
      errors.push('Select a Control Exception Scenario.');
    }
    if (controlScenarioType && controlScenarioType !== 'other' && !Object.values(scenarioChecks).some(Boolean)) {
      errors.push('Select at least one scenario item.');
    }
    if (!businessJustification.trim()) {
      errors.push('Business Justification is required.');
    }
    if (!architectureDescription.trim()) {
      errors.push('Architecture Description is required.');
    }
    if (!architectureProvided) {
      errors.push('Upload at least one Architecture Diagram.');
    }
    DATA_PERIMETER_SELECTS.forEach((field) => {
      const value = dataPerimeter[field.key];
      if (!value) {
        errors.push(`Select ${field.label}.`);
      } else if (!field.options.includes(value)) {
        errors.push(`Invalid value for ${field.label}.`);
      }
    });
    ['external_transfer', 'prod_data', 'prod_mdex', 'prod_mssip'].forEach((key) => {
      if (!YES_NO_OPTIONS.includes(dataPerimeter[key])) {
        errors.push(`${BINARY_QUESTION_LABELS[key]} requires a Yes or No selection.`);
      }
    });
    if (controlScenarioType === 'other' && !otherScenarioText.trim()) {
      errors.push('Describe the Other Scenario.');
    }
    dataConnections.forEach((row, index) => {
      const label = `Data Connection row ${index + 1}`;
      if (!row.control_exception_types.length) {
        errors.push(`${label}: select at least one Control Exception Type.`);
      }
      Object.entries(DATA_CONNECTION_FIELD_LABELS).forEach(([field, friendly]) => {
        if (field === 'implemented_controls') {
          return;
        }
        if (!row[field].trim()) {
          errors.push(`${label}: ${friendly} is required.`);
        }
      });
      const controls = row.implemented_controls || {};
      IMPLEMENTED_CONTROL_FIELDS.forEach((item) => {
        const entry = controls[item.key] || {};
        const value = (entry.value || '').trim();
        if (!value) {
          errors.push(`${label}: ${item.label} selection is required.`);
          return;
        }
        const needsDescription = value === 'Yes' || value === 'Other';
        if (needsDescription && !(entry.description || '').trim()) {
          errors.push(`${label}: ${item.label} description is required.`);
        }
      });
    });
    if (!exceptionExpiry.trim()) {
      errors.push('Exception Expiry date is required.');
    } else if (!isFutureDate(exceptionExpiry)) {
      errors.push('Exception Expiry must be a future date.');
    } else if (exceptionExpiry > maxExceptionExpiryDate) {
      errors.push('Exception Expiry cannot exceed 365 days from today.');
    }
    if (!integratorReviewer) {
      errors.push('Integrator Reviewer is required.');
    }
    const connectionCount = dataConnections.length;
    const validateConnectionReference = (value) => {
      const numeric = Number(value);
      return Number.isInteger(numeric) && numeric >= 1 && numeric <= connectionCount;
    };
    if (hasFirewallType) {
      firewallDetails.forEach((row, index) => {
        const label = `Firewall Flow row ${index + 1}`;
        if (!validateConnectionReference(row.connection_ref)) {
          errors.push(`${label}: select a valid Data Connection row number.`);
        }
        Object.entries(FIREWALL_FIELD_LABELS).forEach(([field, friendly]) => {
          if (!row[field].trim()) {
            errors.push(`${label}: ${friendly} is required.`);
          }
        });
        if (!row.protocol_ports || !row.protocol_ports.length) {
          errors.push(`${label}: Protocol | Port is required.`);
        }
        if (!row.business_justification.trim()) {
          errors.push(`${label}: Business Justification is required.`);
        }
        if (!isFutureDate(row.expiry_date)) {
          errors.push(`${label}: choose a future Expiry Date.`);
        }
      });
    }
    if (hasProxyType) {
      proxyDetails.forEach((row, index) => {
        const label = `Proxy Flow row ${index + 1}`;
        if (!validateConnectionReference(row.connection_ref)) {
          errors.push(`${label}: select a valid Data Connection row number.`);
        }
        if (!row.target_urls.length) {
          errors.push(`${label}: add at least one Target URL.`);
        }
        if (!row.enable_offshore_proxy) {
          errors.push(`${label}: select Enable Offshore(Global) Proxy.`);
        }
        if (!row.source_object_type) {
          errors.push(`${label}: select Source Object Type.`);
        }
        if (!row.proxy_type) {
          errors.push(`${label}: select a Proxy Type.`);
        }
        if (!row.proxy_authentication) {
          errors.push(`${label}: select a Proxy Authentication option.`);
        }
        if (!row.proxy_ssl_inspection) {
          errors.push(`${label}: select Proxy SSL Inspection status.`);
        }
        if (!row.proxy_antivirus) {
          errors.push(`${label}: select Proxy Anti-Virus status.`);
        }
        if (!isFutureDate(row.expiry_date)) {
          errors.push(`${label}: choose a future Expiry Date.`);
        }
        if (!row.business_justification.trim()) {
          errors.push(`${label}: Business Justification is required.`);
        }
      });
    }
    return errors;
  };

  const validationErrors = collectValidationErrors();
  const canContinueFromChecklist = validationErrors.length === 0;

  const buildCasePayload = () => {
    const metadataPayload = {
      checklist: {
        basis_options: {
          full_designs_unavailable: controlScenarioType === 'full_design_not_ready',
          asset_risk_accepted: controlScenarioType === 'risk_accepted',
          other_exception: controlScenarioType === 'other',
        },
        scenario_options: {
          firewall_flowdb_flow: controlScenarioType !== 'other' && scenarioChecks.firewall_flowdb_flow,
          proxy_flow: controlScenarioType !== 'other' && scenarioChecks.proxy_flow,
          privileged_access: controlScenarioType !== 'other' && scenarioChecks.privileged_access,
          enable_poc_testing: controlScenarioType !== 'other' && scenarioChecks.enable_poc_testing,
          other_exception_context: controlScenarioType === 'other',
        },
        scenario_other_context: controlScenarioType === 'other' ? otherScenarioText : '',
        business_justification: businessJustification,
        architecture_description: architectureDescription,
        architecture_files: architectureFiles,
        data_perimeter: dataPerimeter,
        data_connections: dataConnections,
        exception_expiry: exceptionExpiry,
        integrator_reviewer: integratorReviewer,
        firewall_details: hasFirewallType ? firewallDetails : [],
        proxy_details: hasProxyType ? proxyDetails : [],
      },
    };
    const calmSummary = buildCalmReport({
      payload: {
        review_type: reviewType,
        metadata: metadataPayload,
      },
      findings: [],
      manualFindings: [],
      templates,
    });
    return {
      review_type: reviewType,
      metadata: metadataPayload,
      calmSummary,
      assistant_chat: assistantMessages,
    };
  };

  const handleSaveDraft = async () => {
    const casePayload = buildCasePayload();
    const owner = caseData?.owner || user?.name || '';
    if (!owner) {
      window.alert('Please login before saving this case.');
      return;
    }
    const ticketId = caseData?.ticketId || ticketIdParam || '';
    if (caseId) {
      await saveCaseApi(caseId, { designPayload: casePayload, status: 'draft', owner, ticketId });
    } else {
      const existing = await findActiveCaseForTicket(ticketId, owner);
      if (existing?.id) {
        await saveCaseApi(existing.id, { designPayload: casePayload, status: 'draft', owner, ticketId });
      } else {
        const caseLabel = await buildCaseLabel(ticketId);
        const allCases = await listCasesApi({});
        const existingById = allCases.find((c) => c.id === caseLabel);
        if (existingById?.id) {
          await saveCaseApi(existingById.id, { designPayload: casePayload, status: 'draft', owner, ticketId });
        } else {
          const created = await createCaseApi({ owner, ticketId, reviewType, id: caseLabel, name: caseLabel });
          await saveCaseApi(created.id, { designPayload: casePayload, status: 'draft', owner, ticketId });
        }
      }
    }
    hasManualSaveRef.current = true;
    window.alert('Draft saved (status: draft).');
  };

  const handleAuditSubmit = async () => {
    const errors = collectValidationErrors();
    if (errors.length > 0) {
      setValidationNote(errors[0]);
      window.alert(`Cannot submit:\n- ${errors.join('\n- ')}`);
      return;
    }
    setIsLoading(true);
    try {
      const casePayload = buildCasePayload();
      const owner = caseData?.owner || user?.name || '';
      if (!owner) {
        window.alert('Please login before submitting this case.');
        return;
      }
      const ticketId = caseData?.ticketId || ticketIdParam || '';

      let updated = null;
      if (caseId) {
        updated = await saveCaseApi(caseId, {
          designPayload: casePayload,
          status: 'submitted',
          owner,
          ticketId,
        });
      } else {
        const existing = await findActiveCaseForTicket(ticketId, owner);
        if (existing?.id) {
          updated = await saveCaseApi(existing.id, {
            designPayload: casePayload,
            status: 'submitted',
            owner,
            ticketId,
          });
        } else {
          const caseLabel = await buildCaseLabel(ticketId);
          const allCases = await listCasesApi({});
          const existingById = allCases.find((c) => c.id === caseLabel);
          if (existingById?.id) {
            updated = await saveCaseApi(existingById.id, {
              designPayload: casePayload,
              status: 'submitted',
              owner,
              ticketId,
            });
          } else {
            updated = await createCaseApi({
              owner,
              ticketId,
              reviewType,
              id: caseLabel,
              name: caseLabel,
            });
            await saveCaseApi(updated.id, {
              designPayload: casePayload,
              status: 'submitted',
              owner,
              ticketId,
            });
          }
        }
      }
      hasManualSaveRef.current = true;
      navigate('/my-cases');
    } catch (error) {
      console.error('Error submitting design:', error);
      alert('Failed to submit design. Check console for details.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={containerStyle}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '12px' }}>
        <div>
          <h2 style={{ marginBottom: '4px' }}>Design Submission — {reviewMeta.label}</h2>
          <p style={{ color: '#455a64', marginBottom: '12px' }}>Submit your control exception design. </p>
        </div>
        <button type="button" style={buttonSecondaryStyle} onClick={() => setAssistantOpen(true)}>
          Security Co-Design Assistant
        </button>
      </div>

      {/* Buttons removed per request to avoid inline display on edit page */}

      <div>
          <div style={{ ...sectionCardStyle, ...disclaimerCardStyle }}>
            <p>
              Please note that the COD SecDesign – <strong>Control Exception Case Review</strong> process is a limited scope review looking at a production related control exception such as a firewall rule, proxy whitelist, privileged access etc.
            </p>
            <p>
              This review process supports Agile iterative development model, unblocking engineering work without closing/recreating another standard design review.
            </p>
            <p>
              Anything approved by Control Exception Case Review can only be <strong>TEMPORARY valid for at most one year.</strong>
            </p>
            <p>
              Any permanent requirement must be reviewed and recorded by a dedicated COD SecDesign – SecDesign/CloudSec/TPSA Case Review.
            </p>
          </div>

            <div style={sectionCardStyle}>
            <h3 style={{ marginTop: 0, color: '#1a237e' }}>Review Check List</h3>
            <div>
              <div style={{ ...labelStyle, marginBottom: '10px' }}>Control Exception Scenario {requiredStar}</div>
              <select
                value={controlScenarioType}
                onChange={(event) => {
                  const value = event.target.value;
                  setControlScenarioType(value);
                  if (value === 'other') {
                    setScenarioChecks({
                      firewall_flowdb_flow: false,
                      proxy_flow: false,
                      privileged_access: false,
                      enable_poc_testing: false,
                    });
                  } else {
                    setOtherScenarioText('');
                  }
                }}
                style={{ ...inputStyle, maxWidth: '360px' }}
                required
              >
                <option value="">Select a scenario...</option>
                <option value="full_design_not_ready">System Full Design Not Ready</option>
                <option value="risk_accepted">System Risk-Accepted</option>
                <option value="other">Other Scenario</option>
              </select>
              {controlScenarioType && controlScenarioType !== 'other' && (
                <ul style={{ ...checklistListStyle, marginTop: '10px' }}>
                  {[
                    { key: 'firewall_flowdb_flow', label: 'Firewall Flow' },
                    { key: 'proxy_flow', label: 'Proxy Flow' },
                    { key: 'privileged_access', label: 'Privileged Access' },
                    { key: 'enable_poc_testing', label: 'Enable PoC Test' },
                  ].map((item) => (
                    <li key={item.key} style={checklistItemStyle}>
                      <input
                        id={`scenario_${item.key}`}
                        type="checkbox"
                        checked={scenarioChecks[item.key]}
                        onChange={(e) => updateScenarioCheck(item.key, e.target.checked)}
                        style={{ marginTop: '3px' }}
                      />
                      <label htmlFor={`scenario_${item.key}`} style={{ cursor: 'pointer' }}>{item.label}</label>
                    </li>
                  ))}
                </ul>
              )}
              {controlScenarioType === 'other' && (
                <input
                  style={{ ...inputStyle, marginTop: '10px', maxWidth: '520px' }}
                  value={otherScenarioText}
                  onChange={(event) => setOtherScenarioText(event.target.value)}
                  placeholder="Describe the other scenario"
                  required
                />
              )}
            </div>

            <div style={{ marginTop: '14px' }} />

            <div style={formGroupStyle}>
              <label style={labelStyle}>Business Justification {requiredStar}</label>
              <textarea
                style={textareaStyle}
                value={businessJustification}
                onChange={(event) => setBusinessJustification(event.target.value)}
                placeholder="Explain why the exception is required, ownership, timeline, and risk acceptance."
                required
              />
            </div>

            <div style={formGroupStyle}>
              <label style={labelStyle}>Architecture Diagram &amp; Description {requiredStar}</label>
              <textarea
                style={textareaStyle}
                value={architectureDescription}
                onChange={(event) => setArchitectureDescription(event.target.value)}
                placeholder="Summarize architecture components, data flows, and controls impacted by this exception."
                required
              />
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={handleArchitectureFiles}
                style={{ marginTop: '10px' }}
                required={architectureFiles.length === 0}
              />
              {architectureFiles.length > 0 && (
                <ul style={{ marginTop: '8px', marginBottom: 0 }}>
                  {architectureFiles.map((file) => (
                    <li key={file.name} style={{ fontSize: '0.9rem' }}>{file.name}</li>
                  ))}
                </ul>
              )}
              {!architectureProvided && <div style={{ color: '#d32f2f', fontSize: '0.85rem', marginTop: '6px' }}>At least one architecture image is required.</div>}
            </div>

            <div style={{ marginBottom: '16px' }}>
              <h4 style={{ color: '#1a237e' }}>Data Perimeter {requiredStar}</h4>
              <p style={{ marginTop: 0, marginBottom: '8px' }}><strong>1. Asset Risk Attributes from ChinaQ/CMDB?</strong></p>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '12px', marginBottom: '12px' }}>
                {DATA_PERIMETER_SELECTS.map((field) => (
                  <div key={field.key}>
                    <label style={{ ...labelStyle, fontSize: '0.9rem' }}>{field.label} {requiredStar}</label>
                    <select
                      value={dataPerimeter[field.key]}
                      onChange={(event) => handleDataPerimeterSelect(field.key, event.target.value)}
                      style={inputStyle}
                      required
                    >
                      <option value="">Select...</option>
                      {field.options.map((option) => (
                        <option key={option} value={option}>{option}</option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>

              {[
                { key: 'external_transfer', question: <>2. Any data involving update, upgrade, upload or download accessed through <strong>External</strong>?</> },
                { key: 'prod_data', question: <>3. Any <strong>PROD</strong> Data involved?</> },
                { key: 'prod_mdex', question: <>4. Any connection through [Prod] COD <strong>MDEX</strong> domains?</> },
                { key: 'prod_mssip', question: <>5. Any connection through [Prod] COD <strong>MSSIP</strong> domains?</> },
              ].map((item) => (
                <div key={item.key} style={{ marginBottom: '12px' }}>
                  <div style={{ fontWeight: '600', marginBottom: '6px' }}>{item.question}</div>
                  <div style={{ display: 'flex', gap: '16px' }}>
                    {YES_NO_OPTIONS.map((option, optionIndex) => (
                      <label key={option} style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <input
                          type="radio"
                          name={`data_perimeter_${item.key}`}
                          value={option}
                          checked={dataPerimeter[item.key] === option}
                          onChange={() => handleDataPerimeterBinary(item.key, option)}
                          required={optionIndex === 0}
                        />
                        {option}
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div style={formGroupStyle}>
              <label style={labelStyle}>Data Connection {requiredStar}</label>
              <div style={{ fontSize: '0.9rem', color: '#455a64', marginBottom: '8px' }}>
                Record each data connection or flow that relies on this exception. Add or remove rows as needed.
              </div>
              {insightError && (
                <div style={{ color: '#d32f2f', fontSize: '0.85rem', marginBottom: '8px' }}>
                  {insightError}
                </div>
              )}
              <div style={scrollTableWrapperStyle}>
                <table style={dataConnectionTableStyle}>
                <thead>
                  <tr>
                    <th style={thStyle}>No.</th>
                    <th style={thStyle}>Control Exception Type</th>
                    <th style={thStyle}>Src Object</th>
                    <th style={{ ...thStyle, ...wideColumnStyle }}>Src Sec Domain</th>
                    <th style={{ ...thStyle, ...wideColumnStyle }}>Src Sec Zone</th>
                    <th style={thStyle}>Dst Object</th>
                    <th style={{ ...thStyle, ...wideColumnStyle }}>Dst Sec Domain</th>
                    <th style={{ ...thStyle, ...wideColumnStyle }}>Dst Sec Zone</th>
                    <th style={thStyle}>NetProtocol(TargetPort) or AccessMethod</th>
                    <th style={thStyle}>What Data in Payload</th>
                    <th style={thStyle}>Implemented Min Control(s)</th>
                    <th style={thStyle}>Purpose</th>
                  </tr>
                </thead>
                <tbody>
                  {dataConnections.map((row, index) => (
                    <tr key={row.id}>
                      <td style={{ ...tdStyle, textAlign: 'center' }}>{index + 1}</td>
                      <td style={tdStyle}>
                        <select
                          value=""
                          onChange={(event) => handleAddControlType(index, event.target.value)}
                          style={{ ...inputStyle, marginBottom: '8px' }}
                        >
                          <option value="">Select type...</option>
                          {CONTROL_EXCEPTION_TYPE_OPTIONS.map((option) => (
                            <option key={option.value} value={option.value}>{option.label}</option>
                          ))}
                        </select>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                          {row.control_exception_types.map((type) => (
                            <span
                              key={type}
                              style={{ display: 'inline-flex', alignItems: 'center', backgroundColor: '#e3f2fd', color: '#0d47a1', borderRadius: '16px', padding: '4px 8px', fontSize: '0.85rem' }}
                            >
                              {CONTROL_EXCEPTION_TYPE_LABELS[type] || type}
                              <button
                                type="button"
                                onClick={() => handleRemoveControlType(index, type)}
                                style={{ marginLeft: '6px', border: 'none', background: 'transparent', color: '#0d47a1', cursor: 'pointer', fontSize: '0.9rem' }}
                                aria-label={`Remove ${CONTROL_EXCEPTION_TYPE_LABELS[type] || type}`}
                              >
                                ×
                              </button>
                            </span>
                          ))}
                        </div>
                        {row.control_exception_types.length === 0 && (
                          <div style={{ color: '#d32f2f', fontSize: '0.8rem', marginTop: '4px' }}>Select at least one control exception type.</div>
                        )}
                      </td>
                      <td style={tdStyle}>
                        <input
                          style={inputStyle}
                          value={row.src_object}
                          onChange={(event) => updateDataConnection(index, 'src_object', event.target.value)}
                          required
                        />
                      </td>
                      <td style={{ ...tdStyle, ...wideColumnStyle }}>
                        <select
                          style={inputStyle}
                          value={row.src_domain}
                          onChange={(event) => updateDataConnection(index, 'src_domain', event.target.value)}
                          required
                        >
                          <option value="">Select...</option>
                          {securityDomains.map((name) => (
                            <option key={name} value={name}>{name}</option>
                          ))}
                        </select>
                      </td>
                      <td style={{ ...tdStyle, ...wideColumnStyle }}>
                        <select
                          style={inputStyle}
                          value={row.src_zone}
                          onChange={(event) => updateDataConnection(index, 'src_zone', event.target.value)}
                          required
                        >
                          <option value="">Select...</option>
                          {securityZones.map((name) => (
                            <option key={name} value={name}>{name}</option>
                          ))}
                        </select>
                      </td>
                      <td style={tdStyle}>
                        <input
                          style={inputStyle}
                          value={row.dst_object}
                          onChange={(event) => updateDataConnection(index, 'dst_object', event.target.value)}
                          required
                        />
                      </td>
                      <td style={{ ...tdStyle, ...wideColumnStyle }}>
                        <select
                          style={inputStyle}
                          value={row.dst_domain}
                          onChange={(event) => updateDataConnection(index, 'dst_domain', event.target.value)}
                          required
                        >
                          <option value="">Select...</option>
                          {securityDomains.map((name) => (
                            <option key={name} value={name}>{name}</option>
                          ))}
                        </select>
                      </td>
                      <td style={{ ...tdStyle, ...wideColumnStyle }}>
                        <select
                          style={inputStyle}
                          value={row.dst_zone}
                          onChange={(event) => updateDataConnection(index, 'dst_zone', event.target.value)}
                          required
                        >
                          <option value="">Select...</option>
                          {securityZones.map((name) => (
                            <option key={name} value={name}>{name}</option>
                          ))}
                        </select>
                      </td>
                      <td style={tdStyle}>
                        <textarea
                          style={{ ...textareaStyle, minHeight: '60px' }}
                          value={row.accessed_protocol}
                          onChange={(event) => updateDataConnection(index, 'accessed_protocol', event.target.value)}
                          required
                        />
                      </td>
                      <td style={tdStyle}>
                        <textarea
                          style={{ ...textareaStyle, minHeight: '60px' }}
                          value={row.payload_data}
                          onChange={(event) => updateDataConnection(index, 'payload_data', event.target.value)}
                          required
                        />
                      </td>
                      <td style={tdStyle}>
                        <div style={{ display: 'grid', gap: '10px' }}>
                          {IMPLEMENTED_CONTROL_FIELDS.map((item) => {
                            const entry = row.implemented_controls?.[item.key] || { value: '', description: '' };
                            const showDesc = entry.value === 'Yes' || entry.value === 'Other';
                            return (
                              <div key={item.key}>
                                <label style={{ fontWeight: 600, fontSize: '0.85rem', display: 'block', marginBottom: '4px' }}>{item.label}</label>
                                <select
                                  style={inputStyle}
                                  value={entry.value}
                                  onChange={(event) => updateImplementedControl(index, item.key, { value: event.target.value })}
                                  required
                                >
                                  <option value="">Select...</option>
                                  {item.options.map((option) => (
                                    <option key={option} value={option}>{option}</option>
                                  ))}
                                </select>
                                {showDesc && (
                                  <input
                                    style={{ ...inputStyle, marginTop: '6px' }}
                                    value={entry.description || ''}
                                    onChange={(event) => updateImplementedControl(index, item.key, { description: event.target.value })}
                                    placeholder="Description"
                                    required
                                  />
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </td>
                      <td style={tdStyle}>
                        <textarea
                          style={{ ...textareaStyle, minHeight: '60px' }}
                          value={row.purpose}
                          onChange={(event) => updateDataConnection(index, 'purpose', event.target.value)}
                          required
                        />
                        {dataConnections.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeDataConnectionRow(index)}
                            style={{ ...buttonSecondaryStyle, padding: '6px 10px', fontSize: '14px', marginTop: '8px' }}
                          >
                            Remove Row
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
                </table>
              </div>
              <button type="button" onClick={addDataConnectionRow} style={{ ...buttonPrimaryStyle, marginTop: '12px' }}>
                Add Data Connection
              </button>
            </div>

            {(scenarioChecks.firewall_flowdb_flow || hasFirewallType) && (
              <FirewallDetailsSection
                rows={firewallDetails}
                dataConnectionsLength={dataConnections.length}
                onFieldChange={updateFirewallDetail}
                onAddRow={addFirewallDetailRow}
                onRemoveRow={removeFirewallDetailRow}
                minDate={minimumExpiryDate}
                securityComponents={securityComponents}
                securityDomains={securityDomains}
                securityZones={securityZones}
                subnetBoundaries={subnetBoundaries}
                protocolPortOptions={protocolPortOptions}
                protocolPortInputs={protocolPortInputs}
                onProtocolPortInputChange={handleProtocolPortInputChange}
                onAddProtocolPortFromOption={handleAddProtocolPortFromOption}
                onAddProtocolPortFromInput={handleAddProtocolPortFromInput}
                onRemoveProtocolPort={handleRemoveProtocolPort}
              />
            )}

            {(scenarioChecks.proxy_flow || hasProxyType) && (
              <ProxyDetailsSection
                rows={proxyDetails}
                dataConnectionsLength={dataConnections.length}
                onFieldChange={updateProxyDetail}
                onAddRow={addProxyDetailRow}
                onRemoveRow={removeProxyDetailRow}
                proxyUrlInputs={proxyUrlInputs}
                onUrlInputChange={handleProxyUrlInputChange}
                onAddUrl={handleAddProxyUrl}
                onRemoveUrl={handleRemoveProxyUrl}
                minDate={minimumExpiryDate}
              />
            )}

            <div style={formGroupStyle}>
              <label style={labelStyle}>Exception Expiry {requiredStar}</label>
              <input
                type="date"
                style={{ ...inputStyle, maxWidth: '220px' }}
                value={exceptionExpiry}
                onChange={(event) => setExceptionExpiry(event.target.value)}
                max={maxExceptionExpiryDate}
                required
              />
              <div style={{ color: '#90a4ae', fontSize: '0.85rem', marginTop: '6px' }}>Up to ONE year.</div>
            </div>
            <div style={formGroupStyle}>
              <label style={labelStyle}>Reviewer {requiredStar}</label>
              <select
                style={{ ...inputStyle, maxWidth: '360px' }}
                value={integratorReviewer}
                onChange={(event) => setIntegratorReviewer(event.target.value)}
                required
              >
                <option value="">Select reviewer...</option>
                {reviewerUsers.map((member) => (
                  <option key={member.name} value={member.name}>
                    {member.name}
                  </option>
                ))}
              </select>
            </div>

            {validationNote && (
              <div style={{ color: '#d32f2f', fontSize: '0.85rem', marginBottom: '8px' }}>{validationNote}</div>
            )}

            <button
              type="button"
              style={{ ...buttonSecondaryStyle, marginRight: '10px' }}
              onClick={handleSaveDraft}
              disabled={isLoading}
            >
              Save
            </button>
            <button type="button" style={buttonPrimaryStyle} onClick={handleAuditSubmit} disabled={isLoading}>
              {isLoading ? 'Submitting...' : 'Submit for Review'}
            </button>
            <button
              type="button"
              style={{ ...buttonSecondaryStyle, marginLeft: '10px' }}
              onClick={async () => {
                if (!caseId && !hasManualSaveRef.current && hasContent) {
                  const shouldSave = window.confirm('Page will be lost. Do you want to save?');
                  if (shouldSave) {
                    await handleSaveDraft();
                  }
                } else if (caseId) {
                  try {
                    await confirmAndCancelCase(caseId);
                  } catch (e) {
                    console.error('Cancel failed', e);
                  }
                }
                clearCacheForKey(cacheKey);
                navigate('/my-cases');
              }}
            >
              Cancel
            </button>
          </div>
      </div>

      <CoDesignAssistantModal
        open={assistantOpen}
        onClose={() => setAssistantOpen(false)}
        messages={assistantMessages}
        setMessages={setAssistantMessages}
      />
    </div>
  );
};

const FirewallDetailsSection = ({
  rows,
  dataConnectionsLength,
  onFieldChange,
  onAddRow,
  onRemoveRow,
  minDate,
  securityComponents,
  securityDomains,
  securityZones,
  subnetBoundaries,
  protocolPortOptions,
  protocolPortInputs,
  onProtocolPortInputChange,
  onAddProtocolPortFromOption,
  onAddProtocolPortFromInput,
  onRemoveProtocolPort,
}) => {
  const connectionOptions = Array.from({ length: dataConnectionsLength }, (_, index) => index + 1);
  return (
    <div style={sectionCardStyle}>
      <h4 style={{ color: '#1a237e' }}>Detailed Firewall Flow</h4>
      <div style={scrollTableWrapperStyle}>
        <table style={firewallTableStyle}>
          <thead>
            <tr>
              <th style={thStyle}>No.</th>
              <th style={thStyle}>Data Connection Row #</th>
              <th style={thStyle}>Source EONID / AssetID</th>
              <th style={thStyle}>Source Application</th>
              <th style={{ ...thStyle, ...mediumColumnStyle }}>Source Component</th>
              <th style={{ ...thStyle, ...wideColumnStyle }}>Source Security Plant Domain</th>
              <th style={{ ...thStyle, ...wideColumnStyle }}>Source Security Zone</th>
              <th style={thStyle}>Source Subnet Boundary</th>
              <th style={thStyle}>Destination EONID / AssetID</th>
              <th style={thStyle}>Destination Application</th>
              <th style={{ ...thStyle, ...mediumColumnStyle }}>Destination Component</th>
              <th style={{ ...thStyle, ...wideColumnStyle }}>Destination Security Plant Domain</th>
              <th style={{ ...thStyle, ...wideColumnStyle }}>Destination Security Zone</th>
              <th style={thStyle}>Destination Subnet Boundary</th>
              <th style={thStyle}>Protocol | Port</th>
              <th style={thStyle}>Expiry</th>
              <th style={thStyle}>Business Justification</th>
              <th style={thStyle}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, index) => (
              <tr key={row.id}>
                <td style={{ ...tdStyle, textAlign: 'center' }}>{index + 1}</td>
                <td style={tdStyle}>
                  <select
                    style={inputStyle}
                    value={row.connection_ref}
                    onChange={(event) => onFieldChange(index, 'connection_ref', event.target.value)}
                  >
                    <option value="">Select row</option>
                    {connectionOptions.map((option) => (
                      <option key={option} value={option}>{option}</option>
                    ))}
                  </select>
                </td>
                <td style={tdStyle}>
                  <input
                    style={inputStyle}
                    value={row.source_eonid}
                    onChange={(event) => onFieldChange(index, 'source_eonid', event.target.value)}
                    required
                  />
                </td>
                <td style={tdStyle}>
                  <input
                    style={inputStyle}
                    value={row.source_application}
                    onChange={(event) => onFieldChange(index, 'source_application', event.target.value)}
                    required
                  />
                </td>
                <td style={{ ...tdStyle, ...mediumColumnStyle }}>
                  <select
                    style={inputStyle}
                    value={row.source_component}
                    onChange={(event) => onFieldChange(index, 'source_component', event.target.value)}
                    required
                  >
                    <option value="">Select...</option>
                    {securityComponents.map((name) => (
                      <option key={name} value={name}>{name}</option>
                    ))}
                  </select>
                </td>
                <td style={{ ...tdStyle, ...wideColumnStyle }}>
                  <select
                    style={inputStyle}
                    value={row.source_domain}
                    onChange={(event) => onFieldChange(index, 'source_domain', event.target.value)}
                    required
                  >
                    <option value="">Select...</option>
                    {securityDomains.map((name) => (
                      <option key={name} value={name}>{name}</option>
                    ))}
                  </select>
                </td>
                <td style={{ ...tdStyle, ...wideColumnStyle }}>
                  <select
                    style={inputStyle}
                    value={row.source_zone}
                    onChange={(event) => onFieldChange(index, 'source_zone', event.target.value)}
                    required
                  >
                    <option value="">Select...</option>
                    {securityZones.map((name) => (
                      <option key={name} value={name}>{name}</option>
                    ))}
                  </select>
                </td>
                <td style={tdStyle}>
                  <select
                    style={inputStyle}
                    value={row.source_subnet}
                    onChange={(event) => onFieldChange(index, 'source_subnet', event.target.value)}
                    required
                  >
                    <option value="">Select...</option>
                    {subnetBoundaries.map((value) => (
                      <option key={value} value={value}>{value}</option>
                    ))}
                  </select>
                </td>
                <td style={tdStyle}>
                  <input
                    style={inputStyle}
                    value={row.destination_eonid}
                    onChange={(event) => onFieldChange(index, 'destination_eonid', event.target.value)}
                    required
                  />
                </td>
                <td style={tdStyle}>
                  <input
                    style={inputStyle}
                    value={row.destination_application}
                    onChange={(event) => onFieldChange(index, 'destination_application', event.target.value)}
                    required
                  />
                </td>
                <td style={{ ...tdStyle, ...mediumColumnStyle }}>
                  <select
                    style={inputStyle}
                    value={row.destination_component}
                    onChange={(event) => onFieldChange(index, 'destination_component', event.target.value)}
                    required
                  >
                    <option value="">Select...</option>
                    {securityComponents.map((name) => (
                      <option key={name} value={name}>{name}</option>
                    ))}
                  </select>
                </td>
                <td style={{ ...tdStyle, ...wideColumnStyle }}>
                  <select
                    style={inputStyle}
                    value={row.destination_domain}
                    onChange={(event) => onFieldChange(index, 'destination_domain', event.target.value)}
                    required
                  >
                    <option value="">Select...</option>
                    {securityDomains.map((name) => (
                      <option key={name} value={name}>{name}</option>
                    ))}
                  </select>
                </td>
                <td style={{ ...tdStyle, ...wideColumnStyle }}>
                  <select
                    style={inputStyle}
                    value={row.destination_zone}
                    onChange={(event) => onFieldChange(index, 'destination_zone', event.target.value)}
                    required
                  >
                    <option value="">Select...</option>
                    {securityZones.map((name) => (
                      <option key={name} value={name}>{name}</option>
                    ))}
                  </select>
                </td>
                <td style={tdStyle}>
                  <select
                    style={inputStyle}
                    value={row.destination_subnet}
                    onChange={(event) => onFieldChange(index, 'destination_subnet', event.target.value)}
                    required
                  >
                    <option value="">Select...</option>
                    {subnetBoundaries.map((value) => (
                      <option key={value} value={value}>{value}</option>
                    ))}
                  </select>
                </td>
                <td style={tdStyle}>
                  <div style={{ display: 'grid', gap: '6px' }}>
                    <select
                      style={inputStyle}
                      value=""
                      onChange={(event) => {
                        if (event.target.value) {
                          onAddProtocolPortFromOption(row.id, event.target.value);
                        }
                      }}
                    >
                      <option value="">Select...</option>
                      {protocolPortOptions.map((option) => (
                        <option key={option} value={option}>{option}</option>
                      ))}
                    </select>
                    <div style={{ display: 'flex', gap: '6px' }}>
                      <input
                        style={{ ...inputStyle, flex: 1, minWidth: '220px' }}
                        value={protocolPortInputs[row.id] || ''}
                        onChange={(event) => onProtocolPortInputChange(row.id, event.target.value)}
                        placeholder="TCP 443"
                        onBlur={(event) => {
                          if (event.target.value.trim()) {
                            onAddProtocolPortFromInput(row.id, event.target.value);
                          }
                        }}
                      />
                    </div>
                    {row.protocol_ports.length > 0 && (
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                        {row.protocol_ports.map((item) => (
                          <span
                            key={item}
                            style={{
                              backgroundColor: '#e3f2fd',
                              color: '#0d47a1',
                              padding: '4px 8px',
                              borderRadius: '12px',
                              fontSize: '0.8rem',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '6px',
                            }}
                          >
                            {item}
                            <button
                              type="button"
                              onClick={() => onRemoveProtocolPort(row.id, item)}
                              style={{
                                border: 'none',
                                background: 'transparent',
                                color: '#0d47a1',
                                cursor: 'pointer',
                                fontWeight: 700,
                              }}
                            >
                              ×
                            </button>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </td>
                <td style={tdStyle}>
                  <input
                    type="date"
                    style={inputStyle}
                    min={minDate}
                    value={row.expiry_date}
                    onChange={(event) => onFieldChange(index, 'expiry_date', event.target.value)}
                    required
                  />
                </td>
                <td style={tdStyle}>
                  <textarea
                    style={{ ...textareaStyle, minHeight: '80px' }}
                    value={row.business_justification}
                    onChange={(event) => onFieldChange(index, 'business_justification', event.target.value)}
                    required
                  />
                </td>
                <td style={{ ...tdStyle, textAlign: 'center' }}>
                  {rows.length > 1 && (
                    <button
                      type="button"
                      style={{ ...buttonSecondaryStyle, padding: '6px 10px', fontSize: '14px', marginTop: '8px' }}
                      onClick={() => onRemoveRow(index)}
                    >
                      Remove
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <button type="button" onClick={onAddRow} style={{ ...buttonPrimaryStyle, marginTop: '12px' }}>
        Add Firewall Flow
      </button>
    </div>
  );
};

const ProxyDetailsSection = ({
  rows,
  dataConnectionsLength,
  onFieldChange,
  onAddRow,
  onRemoveRow,
  proxyUrlInputs,
  onUrlInputChange,
  onAddUrl,
  onRemoveUrl,
  minDate,
}) => {
  const connectionOptions = Array.from({ length: dataConnectionsLength }, (_, index) => index + 1);
  return (
    <div style={sectionCardStyle}>
      <h4 style={{ color: '#1a237e' }}>Detailed Proxy Flow</h4>
      <div style={scrollTableWrapperStyle}>
        <table style={proxyTableStyle}>
          <thead>
            <tr>
              <th style={thStyle}>No.</th>
              <th style={thStyle}>Data Connection Row #</th>
              <th style={thStyle}>Enable Offshore(Global) Proxy</th>
              <th style={thStyle}>Source Object Type</th>
              <th style={thStyle}>Target URLs</th>
              <th style={thStyle}>Proxy Type</th>
              <th style={thStyle}>Proxy Authentication</th>
              <th style={thStyle}>Proxy SSL Inspection</th>
              <th style={thStyle}>Proxy Anti-Virus</th>
              <th style={thStyle}>Expiry</th>
              <th style={thStyle}>Business Justification</th>
              <th style={thStyle}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row, index) => (
              <tr key={row.id}>
                <td style={{ ...tdStyle, textAlign: 'center' }}>{index + 1}</td>
                <td style={tdStyle}>
                  <select
                    style={inputStyle}
                    value={row.connection_ref}
                    onChange={(event) => onFieldChange(index, 'connection_ref', event.target.value)}
                  >
                    <option value="">Select row</option>
                    {connectionOptions.map((option) => (
                      <option key={option} value={option}>{option}</option>
                    ))}
                  </select>
                </td>
                <td style={tdStyle}>
                  <select
                    style={inputStyle}
                    value={row.enable_offshore_proxy}
                    onChange={(event) => onFieldChange(index, 'enable_offshore_proxy', event.target.value)}
                  >
                    <option value="No">No</option>
                    <option value="Yes">Yes</option>
                  </select>
                </td>
                <td style={tdStyle}>
                  <select
                    style={inputStyle}
                    value={row.source_object_type}
                    onChange={(event) => onFieldChange(index, 'source_object_type', event.target.value)}
                  >
                    <option value="Individual">Individual</option>
                    <option value="System">System</option>
                  </select>
                </td>
                <td style={tdStyle}>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '8px' }}>
                    {row.target_urls.map((url) => (
                      <span
                        key={url}
                        style={{ display: 'inline-flex', alignItems: 'center', backgroundColor: '#e3f2fd', color: '#0d47a1', borderRadius: '16px', padding: '4px 8px', fontSize: '0.85rem' }}
                      >
                        {url}
                        <button
                          type="button"
                          onClick={() => onRemoveUrl(row.id, url)}
                          style={{ marginLeft: '6px', border: 'none', background: 'transparent', color: '#0d47a1', cursor: 'pointer' }}
                          aria-label={`Remove ${url}`}
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                  <input
                    style={inputStyle}
                    value={proxyUrlInputs[row.id] || ''}
                    onChange={(event) => onUrlInputChange(row.id, event.target.value)}
                    onBlur={(event) => {
                      if (event.target.value.trim()) {
                        onAddUrl(row.id, event.target.value);
                      }
                    }}
                    placeholder="Enter URL (include scheme, e.g. https://)"
                  />
                </td>
                <td style={tdStyle}>
                  <select
                    style={inputStyle}
                    value={row.proxy_type}
                    onChange={(event) => onFieldChange(index, 'proxy_type', event.target.value)}
                  >
                    {PROXY_TYPE_OPTIONS.map((option) => (
                      <option key={option.value} value={option.value}>{option.label}</option>
                    ))}
                  </select>
                </td>
                <td style={tdStyle}>
                  <select
                    style={inputStyle}
                    value={row.proxy_authentication}
                    onChange={(event) => onFieldChange(index, 'proxy_authentication', event.target.value)}
                  >
                    {PROXY_AUTH_OPTIONS.map((option) => (
                      <option key={option} value={option}>{option}</option>
                    ))}
                  </select>
                </td>
                <td style={tdStyle}>
                  <select
                    style={inputStyle}
                    value={row.proxy_ssl_inspection}
                    onChange={(event) => onFieldChange(index, 'proxy_ssl_inspection', event.target.value)}
                  >
                    {FEATURE_TOGGLE_OPTIONS.map((option) => (
                      <option key={option} value={option}>{option}</option>
                    ))}
                  </select>
                </td>
                <td style={tdStyle}>
                  <select
                    style={inputStyle}
                    value={row.proxy_antivirus}
                    onChange={(event) => onFieldChange(index, 'proxy_antivirus', event.target.value)}
                  >
                    {FEATURE_TOGGLE_OPTIONS.map((option) => (
                      <option key={option} value={option}>{option}</option>
                    ))}
                  </select>
                </td>
                <td style={tdStyle}>
                  <input
                    type="date"
                    style={inputStyle}
                    min={minDate}
                    value={row.expiry_date}
                    onChange={(event) => onFieldChange(index, 'expiry_date', event.target.value)}
                    required
                  />
                </td>
                <td style={tdStyle}>
                  <textarea
                    style={{ ...textareaStyle, minHeight: '80px' }}
                    value={row.business_justification}
                    onChange={(event) => onFieldChange(index, 'business_justification', event.target.value)}
                    required
                  />
                </td>
                <td style={{ ...tdStyle, textAlign: 'center' }}>
                  {rows.length > 1 && (
                    <button
                      type="button"
                      style={{ ...buttonSecondaryStyle, padding: '6px 10px', fontSize: '14px', marginTop: '8px' }}
                      onClick={() => onRemoveRow(index)}
                    >
                      Remove
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <button type="button" onClick={onAddRow} style={{ ...buttonPrimaryStyle, marginTop: '12px' }}>
        Add Proxy Flow
      </button>
    </div>
  );
};

export default SelfPreReviewControlException;
