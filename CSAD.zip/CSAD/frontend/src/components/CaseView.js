import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { getCaseApi } from '../api/cases';
import FormReadonly from './FormReadonly';
import { buildCalmReport, stripAttachmentData } from '../utils/calmUtils';
import { appendCaseIdParam } from '../utils/caseId';
import { useBlueprintTemplates } from '../hooks/useBlueprintTemplates';

const containerStyle = { margin: '20px auto', maxWidth: '1100px', padding: '20px', backgroundColor: '#f7faff', borderRadius: '10px', border: '1px solid #dce3f5', textAlign: 'left' };
const buttonPrimaryStyle = { backgroundColor: '#1976D2', color: '#FFFFFF', border: 'none', padding: '10px 16px', borderRadius: '6px', cursor: 'pointer', fontSize: '15px' };
const sectionCardStyle = { backgroundColor: '#fff', border: '1px dashed #90caf9', padding: '12px', borderRadius: '10px', marginBottom: '16px' };

const renderJSON = (data) => (
  <pre style={{ whiteSpace: 'pre-wrap', background: '#f1f4ff', padding: '10px', borderRadius: '6px', border: '1px solid #dce3f7' }}>
    {JSON.stringify(data, null, 2)}
  </pre>
);

const CaseView = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const caseId = useMemo(() => searchParams.get('caseId'), [searchParams]);
  const [caseData, setCaseData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [showCalm, setShowCalm] = useState(false);
  const [showFindings, setShowFindings] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);
  const { templates } = useBlueprintTemplates();

  const payload = caseData?.designPayload;
  const reviewerExtras = caseData?.reviewerExtraFindings || caseData?.reviewer_extra_findings || [];
  const calmSummary = useMemo(
    () =>
      buildCalmReport({
        payload: payload || {},
        findings: caseData?.findings || [],
        manualFindings: reviewerExtras,
        templates,
      }),
    [payload, caseData?.findings, reviewerExtras, templates]
  );

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const data = await getCaseApi(caseId);
        if (mounted) setCaseData(data);
      } catch (e) {
        console.error('Failed to load case', e);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, [caseId]);

  if (loading) {
    return (
      <div style={containerStyle}>
        <h2>Case View</h2>
        <p>Loading...</p>
        <button type="button" style={buttonPrimaryStyle} onClick={() => navigate('/my-cases')}>Back to My Cases</button>
      </div>
    );
  }

  if (!caseData) {
    return (
      <div style={containerStyle}>
        <h2>Case View</h2>
        <p>Case not found. Return to My Cases.</p>
        <button type="button" style={buttonPrimaryStyle} onClick={() => navigate('/my-cases')}>Back to My Cases</button>
      </div>
    );
  }

  const getFindingTypeLabel = (finding) => {
    if (finding?.kind === 'ai' || (finding?.id || '').startsWith('AI-')) return 'AI Pre-Review';
    if (finding?.kind === 'manual') return 'Manual Review';
    return 'Rule-Based Pre-Review';
  };

  const goToFinalReport = () => {
    navigate(appendCaseIdParam('/secdesign-final', caseData.id));
  };

  return (
    <div style={containerStyle}>
      <h2>Case View</h2>
      <p>Review the submitted design and feedback.</p>
      <p>This page is read-only. You can download the case report bundle once it is completed.</p>

      <div style={sectionCardStyle}>
        <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', alignItems: 'center' }}>
          <button type="button" style={buttonPrimaryStyle} onClick={() => setShowForm((v) => !v)}>
            {showForm ? 'Hide' : 'Show'} Design (Form)
          </button>
          <button type="button" style={buttonPrimaryStyle} onClick={() => setShowCalm((v) => !v)}>
            {showCalm ? 'Hide' : 'Show'} Design (CALM)
          </button>
          <button type="button" style={buttonPrimaryStyle} onClick={() => setShowFindings((v) => !v)}>
            {showFindings ? 'Hide' : 'Show'} Findings (CALM)
          </button>
          <button type="button" style={buttonPrimaryStyle} onClick={() => setShowFeedback((v) => !v)}>
            {showFeedback ? 'Hide' : 'Show'} Reviewer Feedback
          </button>
          <button
            type="button"
            style={{ ...buttonPrimaryStyle, backgroundColor: '#2e7d32' }}
            onClick={goToFinalReport}
          >
            SecDesign Final Report
          </button>
        </div>

        {showForm && (
          <div style={{ marginTop: '10px' }}>
            <h4>Design (Form)</h4>
            <FormReadonly checklist={payload?.metadata?.checklist} />
          </div>
        )}
        {showCalm && (
          <div style={{ marginTop: '10px' }}>
            <h4>Design (CALM)</h4>
            {renderJSON(stripAttachmentData(calmSummary))}
          </div>
        )}
        {showFindings && (
          <div style={{ marginTop: '10px' }}>
            <h4>Review Findings (CALM)</h4>
            {caseData.findings?.length
              ? renderJSON({ ReviewFinding: caseData.findings })
              : <p>No findings.</p>}
          </div>
        )}
        {showFeedback && (
          <div style={{ marginTop: '10px' }}>
            <h4>Reviewer Feedback &amp; Pre-Review Results</h4>
            {caseData.reviewerComment && <p><strong>Comment:</strong> {caseData.reviewerComment}</p>}
            {caseData.findings?.length ? (
              <div style={{ marginBottom: '10px' }}>
                <h5>Pre-Review Findings</h5>
                <ul>
                  {caseData.findings.map((f, idx) => (
                    <li key={f.id || idx}>
                      <div><strong>Finding Type:</strong> {getFindingTypeLabel(f)}</div>
                      <div><strong>Summary:</strong> {f.details?.violation_summary || '—'}</div>
                      <div><strong>Classification:</strong> {f.details?.classification || f.classification || '—'}</div>
                      <div><strong>Risk:</strong> {f.details?.risk || '—'}</div>
                      <div><strong>Suppressed:</strong> {f.details?.suppressed || f.suppressed ? 'Yes' : 'No'}</div>
                      {f.details?.requirement?.length ? (
                        <div>
                          <strong>Requirements:</strong>
                          <ul>
                            {f.details.requirement.map((req, i) => (
                              <li key={i}>{req.description || req}</li>
                            ))}
                          </ul>
                        </div>
                      ) : null}
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
            {caseData.reviewerExtraFindings?.length ? (
              <div>
                <h5>Reviewer Added Findings</h5>
                <ul>
                  {caseData.reviewerExtraFindings.map((f, idx) => (
                    <li key={idx}>
                      <div><strong>Finding Type:</strong> Manual Review</div>
                      <div><strong>Issue Context:</strong> {f.issueContext || '—'}</div>
                      <div><strong>Risk Description:</strong> {f.riskDescription || '—'}</div>
                      <div><strong>Classification:</strong> {f.classification || '—'}</div>
                      <div><strong>Risk Level:</strong> {f.riskLevel || '—'}</div>
                      {f.requirement ? <div><strong>Requirement:</strong> {f.requirement}</div> : null}
                      {f.attachments?.length ? <div><strong>Attachments:</strong> {f.attachments.map((a) => a.name || 'file').join(', ')}</div> : null}
                    </li>
                  ))}
                </ul>
              </div>
            ) : <p>No reviewer-added findings.</p>}
          </div>
        )}
      </div>
    </div>
  );
};

export default CaseView;
