import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

// --- Styles (collapsed for brevity) --- //
const containerStyle = { margin: '20px auto', padding: '20px', maxWidth: '800px', backgroundColor: '#f9f9f9', borderRadius: '8px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)', textAlign: 'left' };
const buttonStyle = { backgroundColor: '#1976D2', color: '#FFFFFF', border: 'none', padding: '12px 20px', borderRadius: '5px', cursor: 'pointer', fontSize: '16px', margin: '10px' };
const findingItemStyle = { backgroundColor: '#fff', border: '1px solid #ddd', padding: '10px', borderRadius: '4px', marginBottom: '10px', borderLeft: '5px solid #D32F2F' };

const ReviewAcknowledgement = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const findings = location.state?.findings || [];
    const payload = location.state?.payload;
    const reviewType = location.state?.reviewType;
    const mode = location.state?.mode;
    const getFindingTypeLabel = (finding) => {
        if (finding?.kind === 'ai' || (finding?.id || '').startsWith('AI-')) return 'AI Pre-Review';
        if (finding?.kind === 'manual' || finding?.riskDescription || finding?.issueContext) return 'Manual Review';
        return 'Rule-Based Pre-Review';
    };

    useEffect(() => {
        if (!location.state) {
            window.alert('Review session is missing. Please start again from the landing page.');
            navigate('/', { replace: true });
        }
    }, [location.state, navigate]);

    const handleAccept = () => {
        navigate('/evidence-collection', { state: { findings, payload, reviewType, mode } });
    };

    const handleReject = () => {
        navigate('/risk-rejection', { state: { findings, payload, reviewType, mode } });
    };

    return (
        <div style={containerStyle}>
            <h2>Pre-Review Completed</h2>
            <p>The following security findings were identified. Please review them and acknowledge the remediation path.</p>
            
            <div style={{marginTop: '20px'}}>
                <h3>Audit Findings:</h3>
                {findings.length === 0 ? (
                    <p>No findings were generated.</p>
                ) : (
                    <ul>
                        {findings.map((finding, index) => (
                            <li key={index} style={findingItemStyle}>
                                <strong>ID:</strong> {finding.id || 'N/A'} <br />
                                <strong>Finding Type:</strong> {getFindingTypeLabel(finding)} <br />
                                <strong>Summary:</strong> {finding.details?.violation_summary || 'No summary provided.'}
                            </li>
                        ))}
                    </ul>
                )}
            </div>

            <hr style={{margin: '20px 0'}} />

            <h3>Do you acknowledge the risk remediation?</h3>
            <div style={{textAlign: 'center'}}>
                <button style={{...buttonStyle, backgroundColor: '#4CAF50'}} onClick={handleAccept}>
                    Accept Findings & Provide Evidence
                </button>
                <button style={{...buttonStyle, backgroundColor: '#f44336'}} onClick={handleReject}>
                    Reject Findings
                </button>
            </div>
        </div>
    );
};

export default ReviewAcknowledgement;
