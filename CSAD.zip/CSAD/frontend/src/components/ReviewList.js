import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { listCasesApi, confirmAndCancelCase } from '../api/cases';
import { useUser } from '../context/UserContext';
import { appendCaseIdParam } from '../utils/caseId';

const containerStyle = { margin: '20px auto', maxWidth: '1500px', padding: '20px', backgroundColor: '#f7faff', borderRadius: '10px', border: '1px solid #dce3f5' };

const ReviewList = () => {
  const navigate = useNavigate();
  const { user } = useUser();
  const [cases, setCases] = useState([]);
  const [filters, setFilters] = useState({
    id: '',
    ticket: '',
    requestor: '',
    reviewer: '',
    status: '',
    updated: '',
  });
  const [sortConfig, setSortConfig] = useState({ key: 'updatedAt', direction: 'desc' });
  const formatDate = (ts) => {
    if (!ts) return '';
    const normalized = ts.endsWith('Z') ? ts : `${ts}Z`;
    const d = new Date(normalized);
    if (Number.isNaN(d.getTime())) {
      const fallback = new Date(ts);
      if (Number.isNaN(fallback.getTime())) return ts;
      return fallback.toLocaleString();
    }
    return d.toLocaleString();
  };

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const data = await listCasesApi();
        if (mounted) {
          setCases(data);
        }
      } catch (e) {
        console.error('Failed to load cases', e);
      }
    })();
    return () => { mounted = false; };
  }, []);

  const getUpdatedAt = (item) => {
    const raw = item.updatedAt || item.updated_at || '';
    const normalized = raw && !raw.endsWith('Z') ? `${raw}Z` : raw;
    const parsed = normalized ? new Date(normalized) : new Date(0);
    const ts = Number.isNaN(parsed.getTime()) ? 0 : parsed.getTime();
    return ts;
  };

  const displayedCases = useMemo(() => {
    const normalizedFilter = (value) => (value || '').toString().toLowerCase();
    const active = cases.filter((item) => {
      const idMatch = normalizedFilter(item.id).includes(normalizedFilter(filters.id));
      const ticketMatch = normalizedFilter(item.ticketId).includes(normalizedFilter(filters.ticket));
      const requestorMatch = normalizedFilter(item.owner).includes(normalizedFilter(filters.requestor));
      const reviewerValue = item.finalSnapshot?.reviewerName || item.finalSnapshot?.reviewer || item.designPayload?.metadata?.checklist?.integrator_reviewer || '';
      const reviewerMatch = normalizedFilter(reviewerValue).includes(normalizedFilter(filters.reviewer));
      const statusMatch = normalizedFilter(item.status).includes(normalizedFilter(filters.status));
      const updatedMatch = normalizedFilter(formatDate(item.updatedAt || item.updated_at)).includes(normalizedFilter(filters.updated));
      return idMatch && ticketMatch && requestorMatch && reviewerMatch && statusMatch && updatedMatch;
    });
    const sorted = [...active].sort((a, b) => {
      const { key, direction } = sortConfig;
      let aVal = '';
      let bVal = '';
      if (key === 'updatedAt') {
        aVal = getUpdatedAt(a);
        bVal = getUpdatedAt(b);
      } else if (key === 'reviewer') {
        aVal = a.finalSnapshot?.reviewerName || a.finalSnapshot?.reviewer || a.designPayload?.metadata?.checklist?.integrator_reviewer || '';
        bVal = b.finalSnapshot?.reviewerName || b.finalSnapshot?.reviewer || b.designPayload?.metadata?.checklist?.integrator_reviewer || '';
      } else if (key === 'ticketId') {
        aVal = a.ticketId || '';
        bVal = b.ticketId || '';
      } else if (key === 'owner') {
        aVal = a.owner || '';
        bVal = b.owner || '';
      } else if (key === 'status') {
        aVal = a.status || '';
        bVal = b.status || '';
      } else {
        aVal = a[key] || '';
        bVal = b[key] || '';
      }
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return direction === 'asc' ? aVal - bVal : bVal - aVal;
      }
      return direction === 'asc'
        ? String(aVal).localeCompare(String(bVal))
        : String(bVal).localeCompare(String(aVal));
    });
    return sorted;
  }, [cases, filters, sortConfig, formatDate]);

  if (user.role === 'Requestor' || user.role === 'Auditor') {
    return (
      <div style={containerStyle}>
        <h2>Review List</h2>
        <p>Access denied. Reviewer only.</p>
      </div>
    );
  }

  return (
    <div style={containerStyle}>
      <h2>Pending Review Cases</h2>
      {displayedCases.length === 0 ? <p>No cases available.</p> : (
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: '#e8eaf6' }}>
              <th style={{ padding: '8px', textAlign: 'left', cursor: 'pointer' }} onClick={() => setSortConfig({ key: 'id', direction: sortConfig.key === 'id' && sortConfig.direction === 'asc' ? 'desc' : 'asc' })}>Case</th>
              <th style={{ padding: '8px', textAlign: 'left', cursor: 'pointer' }} onClick={() => setSortConfig({ key: 'owner', direction: sortConfig.key === 'owner' && sortConfig.direction === 'asc' ? 'desc' : 'asc' })}>Owner</th>
              <th style={{ padding: '8px', textAlign: 'left', cursor: 'pointer' }} onClick={() => setSortConfig({ key: 'ticketId', direction: sortConfig.key === 'ticketId' && sortConfig.direction === 'asc' ? 'desc' : 'asc' })}>Ticket</th>
              <th style={{ padding: '8px', textAlign: 'left', cursor: 'pointer' }} onClick={() => setSortConfig({ key: 'owner', direction: sortConfig.key === 'owner' && sortConfig.direction === 'asc' ? 'desc' : 'asc' })}>Requestor</th>
              <th style={{ padding: '8px', textAlign: 'left', cursor: 'pointer' }} onClick={() => setSortConfig({ key: 'reviewer', direction: sortConfig.key === 'reviewer' && sortConfig.direction === 'asc' ? 'desc' : 'asc' })}>Reviewer</th>
              <th style={{ padding: '8px', textAlign: 'left', cursor: 'pointer' }} onClick={() => setSortConfig({ key: 'status', direction: sortConfig.key === 'status' && sortConfig.direction === 'asc' ? 'desc' : 'asc' })}>Status</th>
              <th style={{ padding: '8px', textAlign: 'left', cursor: 'pointer' }} onClick={() => setSortConfig({ key: 'updatedAt', direction: sortConfig.key === 'updatedAt' && sortConfig.direction === 'asc' ? 'desc' : 'asc' })}>Updated</th>
              <th style={{ padding: '8px' }} />
            </tr>
            <tr style={{ background: '#f3f5fb' }}>
              <th style={{ padding: '6px' }}>
                <input value={filters.id} onChange={(e) => setFilters({ ...filters, id: e.target.value })} placeholder="Filter" style={{ width: '90%' }} />
              </th>
              <th style={{ padding: '6px' }}>
                <input value={filters.requestor} onChange={(e) => setFilters({ ...filters, requestor: e.target.value })} placeholder="Filter" style={{ width: '90%' }} />
              </th>
              <th style={{ padding: '6px' }}>
                <input value={filters.ticket} onChange={(e) => setFilters({ ...filters, ticket: e.target.value })} placeholder="Filter" style={{ width: '90%' }} />
              </th>
              <th style={{ padding: '6px' }}>
                <input value={filters.requestor} onChange={(e) => setFilters({ ...filters, requestor: e.target.value })} placeholder="Filter" style={{ width: '90%' }} />
              </th>
              <th style={{ padding: '6px' }}>
                <input value={filters.reviewer} onChange={(e) => setFilters({ ...filters, reviewer: e.target.value })} placeholder="Filter" style={{ width: '90%' }} />
              </th>
              <th style={{ padding: '6px' }}>
                <input value={filters.status} onChange={(e) => setFilters({ ...filters, status: e.target.value })} placeholder="Filter" style={{ width: '90%' }} />
              </th>
              <th style={{ padding: '6px' }}>
                <input value={filters.updated} onChange={(e) => setFilters({ ...filters, updated: e.target.value })} placeholder="Filter" style={{ width: '90%' }} />
              </th>
              <th />
            </tr>
          </thead>
          <tbody>
            {displayedCases.map((item) => (
              <tr key={item.id} style={{ borderBottom: '1px solid #e0e0e0' }}>
                <td style={{ padding: '8px' }}>{item.id}</td>
                <td style={{ padding: '8px' }}>{item.owner}</td>
                <td style={{ padding: '8px' }}>{item.ticketId}</td>
                <td style={{ padding: '8px' }}>{item.owner}</td>
                <td style={{ padding: '8px' }}>
                  {item.finalSnapshot?.reviewerName || item.finalSnapshot?.reviewer || item.designPayload?.metadata?.checklist?.integrator_reviewer || ''}
                </td>
                <td style={{ padding: '8px' }}>{item.status}</td>
                <td style={{ padding: '8px' }}>{formatDate(item.updatedAt || item.updated_at)}</td>
                <td style={{ padding: '8px' }}>
                  <button
                    type="button"
                    disabled={['closed_approve', 'closed_deny', 'cancelled'].includes(item.status)}
                    onClick={() => navigate(appendCaseIdParam('/secdesign-review', item.id), { state: { caseId: item.id } })}
                    style={{
                      padding: '6px 10px',
                      borderRadius: '6px',
                      border: '1px solid #1976D2',
                      background: '#fff',
                      cursor: ['closed_approve', 'closed_deny', 'cancelled'].includes(item.status) ? 'not-allowed' : 'pointer',
                      opacity: ['closed_approve', 'closed_deny', 'cancelled'].includes(item.status) ? 0.5 : 1,
                    }}
                  >
                    Review
                  </button>
                  <button
                    type="button"
                    disabled={['closed_approve', 'closed_deny', 'cancelled'].includes(item.status)}
                    onClick={async () => {
                      if (['closed_approve', 'closed_deny', 'cancelled'].includes(item.status)) return;
                      const ok = window.confirm('Cancel this case? This action cannot be undone.');
                      if (!ok) return;
                      try {
                        await confirmAndCancelCase(item.id);
                        const data = await listCasesApi();
                        setCases(data);
                      } catch (e) {
                        console.error('Cancel failed', e);
                      }
                    }}
                    style={{
                      padding: '6px 10px',
                      marginLeft: '8px',
                      borderRadius: '6px',
                      border: '1px solid #c62828',
                      background: '#fff',
                      cursor: ['closed_approve', 'closed_deny', 'cancelled'].includes(item.status) ? 'not-allowed' : 'pointer',
                      color: '#c62828',
                      opacity: ['closed_approve', 'closed_deny', 'cancelled'].includes(item.status) ? 0.5 : 1,
                    }}
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    disabled={!['closed_approve', 'closed_deny'].includes(item.status)}
                    onClick={() => navigate(appendCaseIdParam('/secdesign-final', item.id), { state: { caseId: item.id } })}
                    style={{
                      padding: '6px 10px',
                      marginLeft: '8px',
                      borderRadius: '6px',
                      border: '1px solid #2e7d32',
                      background: '#fff',
                      cursor: ['closed_approve', 'closed_deny'].includes(item.status) ? 'pointer' : 'not-allowed',
                      color: '#2e7d32',
                      opacity: ['closed_approve', 'closed_deny'].includes(item.status) ? 1 : 0.5,
                    }}
                  >
                    Report
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default ReviewList;
