/**
 * ------------------------------------------------------------------------
 * ReviewFindings Component
 * ------------------------------------------------------------------------
 * This component fetches and displays a list of review findings for a given
 * security blueprint ID.
 */

import React, { useState, useEffect } from 'react';
import apiClient from '../api';

/**
 * Renders the review findings for a specific blueprint.
 * @param {{blueprintId: number}} props - The props object.
 * @param {number} props.blueprintId - The ID of the blueprint to fetch findings for.
 * @returns {JSX.Element} The rendered ReviewFindings component.
 */
function ReviewFindings({ blueprintId }) {
  // State to hold the list of findings.
  const [findings, setFindings] = useState([]);
  // State to manage the loading status.
  const [isLoading, setIsLoading] = useState(false);
  // State to hold any potential errors during the API call.
  const [error, setError] = useState(null);

  // useEffect hook to fetch findings when the blueprintId prop changes.
  useEffect(() => {
    // Do not run if blueprintId is not yet available.
    if (!blueprintId) return;

    // Set initial state for the fetch operation.
    setIsLoading(true);
    setError(null);

    // Fetch findings for the specific blueprint ID.
    apiClient.get(`/findings/by-blueprint/${blueprintId}`)
      .then(response => {
        // On success, update the findings state.
        setFindings(response.data);
      })
      .catch(error => {
        // On failure, log the error and update the error state.
        console.error(`Error fetching findings for blueprint ${blueprintId}:`, error);
        setError(error);
      })
      .finally(() => {
        // In any case, set loading to false once the request is complete.
        setIsLoading(false);
      });
  }, [blueprintId]); // The effect re-runs whenever blueprintId changes.

  // Conditional rendering based on the current state.
  if (isLoading) return <p>Loading findings...</p>;
  if (error) return <p>Error loading findings.</p>;

  return (
    <div style={{ marginLeft: '20px', borderLeft: '2px solid #ccc', paddingLeft: '10px' }}>
      <h4>Review Findings</h4>
      {findings.length === 0 ? (
        <p>No findings for this blueprint.</p>
      ) : (
        <ul>
          {/* Map over the findings and render a list item for each one. */}
          {findings.map(finding => (
            <li key={finding.id}>
              <strong>Finding ID {finding.id}:</strong>
              {/* Display finding details in a formatted JSON block. */}
              <pre style={{ textAlign: 'left', whiteSpace: 'pre-wrap' }}>{JSON.stringify(finding.details, null, 2)}</pre>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default ReviewFindings;
