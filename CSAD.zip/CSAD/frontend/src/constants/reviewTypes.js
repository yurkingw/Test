export const REVIEW_TYPES = {
  security_design: {
    label: 'Security Design Review',
    description:
      'Analyze full system architecture, data flows, and control coverage for new or changed designs.',
    aiHelperText:
      'Provide architecture context—systems, applications, services, data flows, and known controls. Attach design diagrams or documents for the most accurate analysis.',
    aiMarkdownHint:
      'Focus on architecture risks, missing controls, and blueprint alignment.',
  },
  control_exception: {
    label: 'Control Exception Review',
    description:
      'Assess exception requests, compensating controls, residual risk, and approval evidence.',
    aiHelperText:
      'Include exception justification, compensating controls, risk owner, timelines, and evidence attachments.',
    aiMarkdownHint:
      'Highlight residual risk, outstanding approvals, and required monitoring actions.',
  },
};

export const REVIEW_TYPE_OPTIONS = Object.entries(REVIEW_TYPES).map(([value, meta]) => ({
  value,
  label: meta.label,
}));

export const DEFAULT_REVIEW_TYPE = 'control_exception';
