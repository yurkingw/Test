const QUESTION_LABELS = {
  arr20: 'ARR 2.0',
  isc: 'ISC',
  pii: 'PII',
  mnpi: 'MNPI',
  external_transfer: 'Any data involving update, upgrade, upload or download accessed through External?',
  prod_data: 'Any PROD Data involved?',
  prod_mdex: 'Any connection through [Prod] COD MDEX domains?',
  prod_mssip: 'Any connection through [Prod] COD MSSIP domains?',
};

const toArray = (value) => (Array.isArray(value) ? value : []);

const buildDataPerimeter = (dataPerimeter = {}) => ({
  arr20: { question: QUESTION_LABELS.arr20, value: dataPerimeter.arr20 || '' },
  isc: { question: QUESTION_LABELS.isc, value: dataPerimeter.isc || '' },
  pii: { question: QUESTION_LABELS.pii, value: dataPerimeter.pii || '' },
  mnpi: { question: QUESTION_LABELS.mnpi, value: dataPerimeter.mnpi || '' },
  external_transfer: { question: QUESTION_LABELS.external_transfer, value: dataPerimeter.external_transfer || '' },
  prod_data: { question: QUESTION_LABELS.prod_data, value: dataPerimeter.prod_data || '' },
  prod_mdex: { question: QUESTION_LABELS.prod_mdex, value: dataPerimeter.prod_mdex || '' },
  prod_mssip: { question: QUESTION_LABELS.prod_mssip, value: dataPerimeter.prod_mssip || '' },
});

const formatNumericId = (prefix, raw, width = 5) => {
  if (!raw && raw !== 0) return '';
  const rawStr = String(raw);
  if (rawStr.startsWith(`${prefix}-`)) return rawStr;
  const digits = rawStr.replace(/\D/g, '');
  if (digits) {
    return `${prefix}-${digits.padStart(width, '0')}`;
  }
  return `${prefix}-${rawStr}`;
};

const formatPatternId = (raw, width = 5) => {
  if (!raw && raw !== 0) return '';
  const rawStr = String(raw);
  if (/^\d+$/.test(rawStr)) return rawStr.padStart(width, '0');
  const digits = rawStr.replace(/\D/g, '');
  if (digits) return digits.padStart(width, '0');
  return rawStr;
};

const formatRuleId = (raw, width = 5) => formatPatternId(raw, width);
const formatFragmentId = (raw, width = 5) => formatNumericId('FRG', raw, width);

const formatConnectionId = (index) => {
  if (!index) return '';
  const number = Number(index);
  if (!Number.isFinite(number)) return '';
  return `CON-${String(number).padStart(2, '0')}`;
};

const buildFindingType = (finding = {}) => {
  if (finding?.kind === 'ai' || (finding?.id || '').startsWith('AI-')) return 'AI Pre-Review';
  if (finding?.kind === 'manual') return 'Manual Review';
  return 'Rule-Based Pre-Review';
};

const normalizeRequirement = (value) => {
  if (!value) return [];
  if (Array.isArray(value)) {
    return value.map((item) => (typeof item === 'string' ? { description: item } : item)).filter(Boolean);
  }
  if (typeof value === 'object') return [value];
  return [{ description: value }];
};

const normalizeRecommendation = (risk, requirement) => {
  const isLow = typeof risk === 'string' && risk.toLowerCase().includes('low');
  return isLow ? normalizeRequirement(requirement) : [];
};

const resolveFindingText = (finding = {}) => {
  const details = finding.details || {};
  return {
    violationSummary: details.violation_summary || finding.riskDescription || details.riskDescription || '—',
    risk: details.risk || finding.riskLevel || '—',
    classification: details.classification || finding.classification || '—',
    requirement: details.requirement || finding.requirement || details.control_requirement || '',
    issueContext: details.issue_context || details.issueContext || finding.issueContext || '',
  };
};

const resolvePatternId = (finding = {}) => {
  const details = finding.details || {};
  const raw = details.triggered_blueprint_id || finding.pattern_id || finding.blueprint_id || '';
  return formatPatternId(raw);
};

const resolveTcepId = (finding = {}) => {
  const details = finding.details || {};
  return (
    details.tcep_cr_id ||
    details.violating_condition_snapshot?.tcep_cr_id ||
    finding.tcep_cr_id ||
    ''
  );
};

const buildReviewFindings = (findings = []) =>
  (findings || []).map((finding, idx) => {
    const details = finding.details || {};
    const { violationSummary, risk, classification, requirement, issueContext } = resolveFindingText(finding);
    const status = details.status || finding.status || 'open';
    const snapshot = { ...(details.violating_condition_snapshot || {}) };
    if ('connection_properties' in snapshot) {
      delete snapshot.connection_properties;
    }
    if (issueContext) snapshot.issue_context = issueContext;
    const normalizedRequirement = normalizeRequirement(requirement);
    const recommendation = normalizeRecommendation(risk, requirement);
    const connectionIndex = snapshot.connection_index;
    const violatingEntityId = connectionIndex
      ? formatConnectionId(connectionIndex)
      : details.violating_entity_id || finding.violating_entity_id || '';
    const violatingEntityType = connectionIndex
      ? 'Connection'
      : details.violating_entity_type || finding.violating_entity_type || 'System';
    return {
      finding_id: `FIN-${String(idx + 1).padStart(2, '0')}`,
      pattern_id: resolvePatternId(finding),
      tcep_cr_id: resolveTcepId(finding),
      violating_entity_type: violatingEntityType,
      violating_entity_id: violatingEntityId,
      violating_condition_snapshot: snapshot,
      violation_summary: violationSummary,
      risk,
      requirement: normalizedRequirement,
      recommendation,
      status,
      properties: {
        from_review_process: {
          finding_type: buildFindingType(finding),
          classification,
          suppress: Boolean(finding.suppressed || details.suppressed),
        },
      },
    };
  });

const buildSecurityBlueprints = (templates = {}) => {
  const fragments = [];
  const fragmentRegistry = new Map();

  toArray(templates.security_fragments).forEach((fragment) => {
    const rawId = fragment.fragment_id || fragment.pattern_id || fragment.id || '';
    const fragmentId = formatFragmentId(rawId);
    if (fragmentRegistry.has(fragmentId)) return;
    const payload = {
      fragment_id: fragmentId,
      fragment_name: fragment.fragment_name || fragment.name || '',
      target_entity: fragment.target_entity || '',
      condition: fragment.condition || fragment.when || {},
    };
    fragmentRegistry.set(fragmentId, payload);
    fragments.push(payload);
  });

  const blueprints = toArray(templates.security_blueprints).map((blueprint) => {
    const rawPattern = blueprint.pattern_id || blueprint.blueprint_id || blueprint.id || '';
    const patternId = formatPatternId(rawPattern);
    const reviewTemplate = blueprint.review_finding_template || {};
    const fragmentRef = formatFragmentId(
      blueprint.fragment_id || blueprint.security_fragment_ref || rawPattern
    );
    if (!fragmentRegistry.has(fragmentRef)) {
      const fallbackFragment = {
        fragment_id: fragmentRef,
        fragment_name: blueprint.blueprint_name || blueprint.name || '',
        target_entity: blueprint.target_entity || '',
        condition: blueprint.condition || blueprint.when || {},
      };
      fragmentRegistry.set(fragmentRef, fallbackFragment);
      fragments.push(fallbackFragment);
    }
    const rules = toArray(blueprint.rules).map((rule) => ({
      ...rule,
      rule_id: formatRuleId(rule.rule_id || rawPattern),
      definitions: toArray(rule.definitions).map((definition) => ({
        ...definition,
        condition: {
          ...definition.condition,
          security_fragment_ref: formatFragmentId(
            definition.condition?.security_fragment_ref || fragmentRef
          ),
        },
      })),
    }));
    return {
      pattern_id: patternId,
      blueprint_name: blueprint.blueprint_name || blueprint.name || '',
      rules: rules.length
        ? rules
        : [
            {
              rule_id: formatRuleId(rawPattern),
              target_entity: blueprint.target_entity || '',
              definitions: [
                {
                  tcep_cr_id: reviewTemplate.tcep_cr_id || '',
                  condition: {
                    security_fragment_ref: formatFragmentId(fragmentRef),
                  },
                  outcome: {
                    violation_summary: reviewTemplate.violation_summary || '',
                    risk: reviewTemplate.risk || '',
                    requirement: reviewTemplate.requirement || [],
                  },
                },
              ],
            },
          ],
    };
  });

  return { fragments, blueprints };
};

const buildControlExceptionCalm = ({ payload = {}, findings = [], manualFindings = [], templates = {} }) => {
  const checklist = payload?.metadata?.checklist || {};
  const dataConnections = toArray(checklist.data_connections);
  const firewallDetails = toArray(checklist.firewall_details);
  const proxyDetails = toArray(checklist.proxy_details);
  const exceptionExpiry = checklist.exception_expiry || checklist.expected_exception || '';

  const system = [
    {
      cmdb_sysid: '',
      sysname: '',
      description: '',
      properties: {
        from_control_exception_form: {
          basis_options: checklist.basis_options || {},
          scenario_options: checklist.scenario_options || {},
            scenario_other_context: checklist.scenario_other_context || '',
            business_justification: checklist.business_justification || '',
            architecture_description: checklist.architecture_description || '',
            architecture_files: checklist.architecture_files || [],
            data_perimeter: buildDataPerimeter(checklist.data_perimeter || {}),
            exception_expiry: exceptionExpiry,
            integrator_reviewer: checklist.integrator_reviewer || '',
          },
        },
      },
    ];

  const application = [
    { appid: 'APP-01', appname: '', cmdb_sysid: '' },
  ];
  const service = [
    { svcid: 'SVC-01', svcname: '', appid: 'APP-01' },
  ];

  const serviceInstances = [];
  const components = [];
  const connectionTypes = [];
  const connections = [];
  const couponTypes = [];
  const coupons = [];

  let svcintCounter = 1;
  let componentCounter = 1;
  let connectionTypeCounter = 1;
  let connectionCounter = 1;
  let couponTypeCounter = 1;
  let couponCounter = 1;

  const connectionIdByRow = {};
  const connectionTypeByRow = {};
  const componentIdsByRow = {};

  dataConnections.forEach((row, index) => {
    const sourceSvcId = `SVCINT-${String(svcintCounter).padStart(2, '0')}`;
    svcintCounter += 1;
    const destSvcId = `SVCINT-${String(svcintCounter).padStart(2, '0')}`;
    svcintCounter += 1;

    serviceInstances.push(
      {
        svcint_id: sourceSvcId,
        svcintname: '',
        svcid: 'SVC-01',
        properties: {
          from_control_exception_form: {
            src_object: row.src_object || '',
            src_domain: row.src_domain || '',
            src_zone: row.src_zone || '',
          },
        },
      },
      {
        svcint_id: destSvcId,
        svcintname: '',
        svcid: 'SVC-01',
        properties: {
          from_control_exception_form: {
            dst_object: row.dst_object || '',
            dst_domain: row.dst_domain || '',
            dst_zone: row.dst_zone || '',
          },
        },
      }
    );

    const sourceComponentId = `CMP-${String(componentCounter).padStart(2, '0')}`;
    componentCounter += 1;
    const destComponentId = `CMP-${String(componentCounter).padStart(2, '0')}`;
    componentCounter += 1;

    const sourceInstance = serviceInstances[serviceInstances.length - 2];
    const destInstance = serviceInstances[serviceInstances.length - 1];
    components.push(
      {
        cmpid: sourceComponentId,
        cmpname: '',
        svcint_id: sourceSvcId,
        properties: {
          from_system: system[0]?.properties || {},
          from_application: application[0]?.properties || {},
          from_service: service[0]?.properties || {},
          from_serviceinstance: sourceInstance?.properties || {},
        },
      },
      {
        cmpid: destComponentId,
        cmpname: '',
        svcint_id: destSvcId,
        properties: {
          from_system: system[0]?.properties || {},
          from_application: application[0]?.properties || {},
          from_service: service[0]?.properties || {},
          from_serviceinstance: destInstance?.properties || {},
        },
      }
    );

    const connectionTypeId = `CONTYP-${String(connectionTypeCounter).padStart(2, '0')}`;
    connectionTypeCounter += 1;
    connectionTypeByRow[index + 1] = connectionTypeId;

    const rowIndex = index + 1;
    connectionTypes.push({
      connection_type_id: connectionTypeId,
      connection_type_name: '',
      properties: {
        from_control_exception_form: {
          id: `#${rowIndex}`,
          original_id: row.id || '',
          row_index: rowIndex,
          control_exception_types: row.control_exception_types || [],
          accessed_protocol: row.accessed_protocol || '',
          payload_data: row.payload_data || '',
          implemented_controls: row.implemented_controls || {},
          purpose: row.purpose || '',
        },
      },
    });

    const connectionId = `CON-${String(connectionCounter).padStart(2, '0')}`;
    connectionCounter += 1;
    connectionIdByRow[index + 1] = connectionId;
    componentIdsByRow[index + 1] = { source: sourceComponentId, destination: destComponentId };

    const sourceComponent = components[components.length - 2];
    const destComponent = components[components.length - 1];
    connections.push({
      conid: connectionId,
      source: {
        component_id: sourceComponentId,
        properties: {
          from_component: sourceComponent?.properties || {},
        },
      },
      destination: {
        component_id: destComponentId,
        properties: {
          from_component: destComponent?.properties || {},
        },
      },
      connection_type_id: connectionTypeId,
      properties: {
        from_connection_type: connectionTypes[connectionTypes.length - 1]?.properties || {},
      },
    });
  });

  const buildCouponType = (detail, typeName) => {
    const couponTypeId = `COPTYP-${String(couponTypeCounter).padStart(2, '0')}`;
    couponTypeCounter += 1;
    const payload = {
      coupon_type_id: couponTypeId,
      coupon_type_name: typeName,
      properties: {
        from_control_exception_form: { ...detail },
      },
    };
    couponTypes.push(payload);
    return payload;
  };

  const buildCoupon = (detail, typeName, connectionRef) => {
    const couponType = buildCouponType(detail, typeName);
    const couponId = `COP-${String(couponCounter).padStart(2, '0')}`;
    couponCounter += 1;
    const connId = connectionIdByRow[connectionRef] || '';
    coupons.push({
      coupon_id: couponId,
      coupon_type_id: couponType.coupon_type_id,
      triggering_connection_id: connId,
      expiry: detail.expiry_date || '',
      justification: detail.business_justification || '',
      properties: {
        from_connection: connections.find((conn) => conn.conid === connId)?.properties || {},
        from_coupon_type: couponType?.properties || {},
      },
    });
  };

  firewallDetails.forEach((detail) => buildCoupon(detail, 'FIREWALL_FLOW', Number(detail.connection_ref)));
  proxyDetails.forEach((detail) => buildCoupon(detail, 'PROXY_FLOW', Number(detail.connection_ref)));

  const architectureModel = [
    {
      architecture_model_id: 'ARCHM-01',
      architecture_model: '',
      properties: {
        from_control_exception_form: {
          architecture_description: checklist.architecture_description || '',
          architecture_files: checklist.architecture_files || [],
        },
      },
    },
  ];

  const deploymentModel = [
    { deployment_model_id: 'DEPM-01', deployment_model_name: '' },
  ];

  const { fragments, blueprints } = buildSecurityBlueprints(templates);

  return {
    System: system,
    Application: application,
    Service: service,
    ServiceInstance: serviceInstances,
    Component: components,
    Connection: connections,
    ConnectionType: connectionTypes,
    CouponType: couponTypes,
    Coupon: coupons,
    ArchitectureModel: architectureModel,
    DeploymentModel: deploymentModel,
    SecurityFragment: fragments,
    SecurityBlueprint: blueprints,
    ReviewFinding: buildReviewFindings([
      ...(findings || []),
      ...(manualFindings || []).map((item) => ({
        ...item,
        kind: 'manual',
        details: {
          violation_summary: item.riskDescription || '',
          risk: item.riskLevel || '',
          classification: item.classification || '',
          requirement: item.requirement || '',
          issue_context: item.issueContext || '',
          suppressed: item.suppressed || false,
        },
      })),
    ]),
  };
};

// Build CALM report for UI/bundle rendering.
export const buildCalmReport = ({ payload = {}, findings = [], manualFindings = [], templates = {} }) => {
  const reviewType = payload?.review_type || payload?.reviewType || '';
  const inferredType = reviewType || (payload?.metadata?.checklist ? 'control_exception' : '');
  if (inferredType !== 'control_exception') {
    return payload?.calmSummary || {};
  }
  return buildControlExceptionCalm({ payload, findings, manualFindings, templates });
};

// Normalize CALM summary objects to keep only CALM entity fields and strip attachments.
export const normalizeCalmSummary = (calm = {}) => {
  if (!calm || typeof calm !== 'object') return {};
  if (calm.System || calm.Component || calm.Connection) return calm;
  const components = Array.isArray(calm.calmComponents) ? calm.calmComponents : [];
  const connections = Array.isArray(calm.calmConnections) ? calm.calmConnections : [];
  const coupons = Array.isArray(calm.calmCoupons) ? calm.calmCoupons : [];
  const reviewMetadata = { ...(calm.reviewMetadata || {}) };
  delete reviewMetadata.architecture_files;
  delete reviewMetadata.attachments;
  return {
    calmComponents: components,
    calmConnections: connections,
    calmCoupons: coupons,
    reviewMetadata,
  };
};

export const stripAttachmentData = (value) => {
  if (Array.isArray(value)) {
    return value.map(stripAttachmentData);
  }
  if (value && typeof value === 'object') {
    const cleaned = {};
    Object.entries(value).forEach(([key, val]) => {
      if (key === 'dataUrl') return;
      if (key === 'attachments' || key === 'files') {
        if (Array.isArray(val)) {
          cleaned[key] = val.map((item) => ({
            name: item?.name,
            type: item?.type,
            size: item?.size,
          }));
          return;
        }
      }
      cleaned[key] = stripAttachmentData(val);
    });
    return cleaned;
  }
  return value;
};
