export const resolveCaseId = (stateCaseId, searchParams, fallbackId) => {
  const queryId = searchParams?.get ? searchParams.get('caseId') : null;
  return stateCaseId || queryId || fallbackId || null;
};

export const appendCaseIdParam = (path, caseId) => {
  if (!caseId) return path;
  return path.includes('?') ? `${path}&caseId=${caseId}` : `${path}?caseId=${caseId}`;
};
