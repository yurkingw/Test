import apiClient from '../api';

export const uploadFiles = async (files = []) => {
  if (!files || files.length === 0) return [];
  const formData = new FormData();
  files.forEach((file) => formData.append('files', file));
  const res = await apiClient.post('/attachments/', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return Array.isArray(res.data) ? res.data : [];
};

const resolveAttachmentBase = () => {
  const base = apiClient.defaults.baseURL || '';
  if (typeof window === 'undefined') {
    return base;
  }
  if (!base || base.startsWith('/')) {
    return `${window.location.origin}${base}`;
  }
  try {
    const parsed = new URL(base);
    if (parsed.hostname === window.location.hostname) {
      return `${window.location.origin}${parsed.pathname.replace(/\/$/, '')}`;
    }
  } catch (error) {
    // Fall back to base if URL parsing fails.
  }
  return base;
};

export const getAttachmentUrl = (path) => {
  if (!path) return '';
  const prefix = resolveAttachmentBase().replace(/\/$/, '');
  return `${prefix}/attachments/${encodeURI(path)}`;
};
