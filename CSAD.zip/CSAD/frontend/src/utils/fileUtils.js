// Utilities for normalizing file metadata stored in JSONB.
export const filesToDataUrls = async (fileList) => {
  const files = Array.from(fileList || []);
  const readers = files.map(
    (file) =>
      new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = () => {
          resolve({
            name: file.name,
            type: file.type || 'application/octet-stream',
            dataUrl: reader.result,
          });
        };
        reader.onerror = () => {
          resolve({
            name: file.name,
            type: file.type || 'application/octet-stream',
            dataUrl: null,
          });
        };
        reader.readAsDataURL(file);
      })
  );
  return Promise.all(readers);
};

export const ensureFileMetaArray = (items) => {
  if (!items || !items.length) return [];
  return items.map((item) => {
    if (typeof item === 'string') {
      return { name: item, type: '', size: 0, path: '', dataUrl: null };
    }
    if (item instanceof File) {
      return { name: item.name, type: item.type || 'application/octet-stream', size: item.size || 0, path: '', dataUrl: null };
    }
    return {
      name: item.name || 'attachment',
      type: item.type || '',
      size: item.size || 0,
      path: item.path || '',
      dataUrl: item.dataUrl || null,
    };
  });
};
