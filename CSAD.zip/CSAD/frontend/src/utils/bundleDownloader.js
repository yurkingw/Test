import JSZip from 'jszip';
import { buildCalmReport, stripAttachmentData } from './calmUtils';
import { getAttachmentUrl } from './attachments';
import { listBlueprintTemplatesApi } from '../api/blueprints';

const dataUrlToBlob = (dataUrl) => {
  if (!dataUrl) return null;
  const parts = dataUrl.split(',');
  if (parts.length < 2) return null;
  const mimeMatch = parts[0].match(/:(.*?);/);
  const mime = mimeMatch ? mimeMatch[1] : 'application/octet-stream';
  const binary = atob(parts[1]);
  const len = binary.length;
  const buffer = new Uint8Array(len);
  for (let i = 0; i < len; i += 1) buffer[i] = binary.charCodeAt(i);
  return new Blob([buffer], { type: mime });
};

const collectAttachments = (caseData = {}) => {
  const files = [];
  const checklist = caseData.designPayload?.metadata?.checklist || {};
  (checklist.architecture_files || []).forEach((f) => files.push({ path: `architecture/${f.name || 'file'}`, dataUrl: f.dataUrl, sourcePath: f.path, type: f.type, name: f.name }));
  (caseData.reviewerExtraFindings || []).forEach((f, idx) => {
    (f.attachments || []).forEach((a, i) => files.push({ path: `reviewer_findings/${idx + 1}_${i + 1}_${a.name || 'file'}`, dataUrl: a.dataUrl, sourcePath: a.path, type: a.type, name: a.name }));
  });
  Object.entries(caseData.evidence || {}).forEach(([fid, ev]) => {
    (ev.files || []).forEach((a, i) => files.push({ path: `evidence/${fid}_${i + 1}_${a.name || 'file'}`, dataUrl: a.dataUrl, sourcePath: a.path, type: a.type, name: a.name }));
  });
  (caseData.reviewerCommentFiles || []).forEach((a, i) => {
    files.push({ path: `reviewer_comment/${i + 1}_${a.name || 'file'}`, dataUrl: a.dataUrl, sourcePath: a.path, type: a.type, name: a.name });
  });
  (caseData.chat || caseData.chat_messages || []).forEach((msg, idx) => {
    (msg.attachments || []).forEach((a, i) => files.push({ path: `chat/${idx + 1}_${i + 1}_${a.name || 'file'}`, dataUrl: a.dataUrl, sourcePath: a.path, type: a.type, name: a.name }));
  });
  return files;
};

const buildMarkdown = (caseData = {}, calmReport = {}) => {
  const payload = caseData.designPayload || {};
  const lines = [];
  lines.push(`# Case Report ${caseData.id || ''}`);
  lines.push('');
  lines.push(`- Ticket: ${caseData.ticketId || '-'}`);
  lines.push(`- Owner: ${caseData.owner || '-'}`);
  lines.push(`- Status: ${caseData.status || '-'}`);
  lines.push(`- Review Type: ${payload.review_type || '-'}`);
  lines.push(`- Created: ${caseData.createdAt || caseData.created_at || '-'}`);
  lines.push(`- Updated: ${caseData.updatedAt || caseData.updated_at || '-'}`);
  lines.push('');
  lines.push('## Design (Form Snapshot)');
  lines.push('```json');
  lines.push(JSON.stringify(payload.metadata?.checklist || {}, null, 2));
  lines.push('```');
  lines.push('');
  lines.push('## CALM Summary');
  lines.push('```json');
  lines.push(JSON.stringify(calmReport || {}, null, 2));
  lines.push('```');
  lines.push('');
  lines.push('## Findings');
  lines.push('```json');
  lines.push(JSON.stringify(caseData.findings || [], null, 2));
  lines.push('```');
  lines.push('');
  lines.push('## Reviewer Added Findings');
  lines.push('```json');
  lines.push(JSON.stringify(caseData.reviewerExtraFindings || [], null, 2));
  lines.push('```');
  lines.push('');
  lines.push('## Evidence');
  lines.push('```json');
  lines.push(JSON.stringify(caseData.evidence || {}, null, 2));
  lines.push('```');
  lines.push('');
  lines.push('## Final Snapshot');
  lines.push('```json');
  lines.push(JSON.stringify(caseData.finalSnapshot || {}, null, 2));
  lines.push('```');
  return lines.join('\n');
};

const csvEscape = (value) => {
  if (value === null || value === undefined) return '';
  const raw = String(value);
  const escaped = raw.replace(/"/g, '""');
  return `"${escaped}"`;
};

const toCsv = (rows = [], headers = []) => {
  if (!rows.length || !headers.length) return '';
  const head = headers.map(csvEscape).join(',');
  const lines = rows.map((row) =>
    headers.map((key) => {
      const value = row?.[key];
      if (Array.isArray(value)) return csvEscape(value.join('; '));
      if (typeof value === 'object' && value !== null) return csvEscape(JSON.stringify(value));
      return csvEscape(value);
    }).join(',')
  );
  return [head, ...lines].join('\n');
};

const escapeHtml = (value) => {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
};

const buildFinalHtml = (caseData = {}, calmReport = {}) => {
  const payload = caseData.designPayload || {};
  const checklist = payload.metadata?.checklist || {};
  const calm = calmReport || {};
  const findings = caseData.findings || [];
  const reviewerExtras = caseData.reviewerExtraFindings || [];
  const evidence = caseData.evidence || {};
  const reviewerName = caseData.finalSnapshot?.reviewerName || caseData.finalSnapshot?.reviewer || '';

  const evidenceToHtml = (ev) => {
    if (!ev) return '<p>No evidence provided.</p>';
    const files = (ev.files || []).map((f) => `<li>${escapeHtml(f.name || 'file')}</li>`).join('');
    return `
      <div><strong>Decision:</strong> ${escapeHtml(ev.decision || 'accept')}</div>
      <div><strong>Description:</strong> ${escapeHtml(ev.description || '—')}</div>
      <div><strong>Attachments:</strong><ul>${files || '<li>None</li>'}</ul></div>
    `;
  };

  const renderFinding = (f, idx) => {
    const details = f.details || {};
    const summary = f.summary || details.violation_summary || f.riskDescription || '—';
    const riskLevel = f.risk_level || details.risk || f.riskLevel || '—';
    const classification = f.classification || details.classification || f.classification || '—';
    const requirement = f.requirement || details.requirement || details.control_requirement || '';
    const reqText = Array.isArray(requirement)
      ? requirement.map((item) => (typeof item === 'string' ? item : item?.description || '')).filter(Boolean).join('; ')
      : (typeof requirement === 'object' ? requirement?.description : requirement);
    const suppressed = Boolean(f.suppressed || details.suppressed);
    const fid = f.id || `finding-${idx}`;
    const ev = evidence[fid] || evidence[idx] || null;
    return `
      <div class="finding">
        <div><strong>Risk Description:</strong> ${escapeHtml(summary)}</div>
        <div><strong>Classification:</strong> ${escapeHtml(classification)}</div>
        <div><strong>Risk Level:</strong> ${escapeHtml(riskLevel)}</div>
        <div><strong>Suppressed:</strong> ${suppressed ? 'Yes' : 'No'}</div>
        ${reqText ? `<div><strong>Requirement:</strong> ${escapeHtml(reqText)}</div>` : ''}
        ${evidenceToHtml(ev)}
      </div>
    `;
  };

  const allFindingsHtml = [
    ...findings.map(renderFinding),
    ...reviewerExtras.map((f, idx) => renderFinding({ ...f, id: f.id || `EX-${idx}` }, idx + findings.length)),
  ].join('');

  return `<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>SecDesign Final Snapshot - ${escapeHtml(caseData.id || '')}</title>
  <style>
    body { font-family: "Segoe UI", Arial, sans-serif; margin: 24px; color: #1a1a1a; }
    h1 { margin-bottom: 6px; }
    .meta { margin-bottom: 20px; color: #455a64; }
    .section { border: 1px solid #dce3f5; border-radius: 8px; padding: 16px; margin-bottom: 16px; background: #f9fbff; }
    .finding { border: 1px dashed #90caf9; padding: 10px; border-radius: 8px; margin-bottom: 10px; background: #fff; }
    pre { background: #f1f4ff; padding: 10px; border-radius: 6px; border: 1px solid #dce3f7; overflow: auto; }
  </style>
</head>
<body>
  <h1>SecDesign Final</h1>
  <div class="meta">
    <div><strong>Case:</strong> ${escapeHtml(caseData.id || '')}</div>
    <div><strong>Status:</strong> ${escapeHtml(caseData.status || '')}</div>
    <div><strong>Reviewer:</strong> ${escapeHtml(reviewerName)}</div>
  </div>

  <div class="section">
    <h2>Design (Form)</h2>
    <pre>${escapeHtml(JSON.stringify(checklist, null, 2))}</pre>
  </div>

  <div class="section">
    <h2>Design (CALM)</h2>
    <pre>${escapeHtml(JSON.stringify(calm, null, 2))}</pre>
  </div>

  <div class="section">
    <h2>Findings & Evidence</h2>
    ${allFindingsHtml || '<p>No findings.</p>'}
  </div>
</body>
</html>`;
};

const resolveCalmReport = async (caseData = {}, options = {}) => {
  if (options.calmReport) return options.calmReport;
  let templates = options.templates;
  if (!templates) {
    try {
      templates = await listBlueprintTemplatesApi();
    } catch (error) {
      templates = {};
    }
  }
  return buildCalmReport({
    payload: caseData.designPayload || {},
    findings: caseData.findings || [],
    manualFindings: caseData.reviewerExtraFindings || [],
    templates: templates || {},
  });
};

export const downloadCaseBundle = async (caseData, filenamePrefix = 'case_bundle', options = {}) => {
  const zip = new JSZip();
  const calm = stripAttachmentData(await resolveCalmReport(caseData, options));
  const findings = caseData.findings || [];
  const checklist = caseData.designPayload?.metadata?.checklist || {};

  zip.file('report.md', buildMarkdown(caseData, calm));
  const htmlSnapshot = options.htmlSnapshot || (typeof window !== 'undefined' && window.location?.pathname === '/secdesign-final'
    ? document.documentElement.outerHTML
    : buildFinalHtml(caseData, calm));
  zip.file('secdesign_final_snapshot.html', htmlSnapshot);
  const designPayload = { ...(caseData.designPayload || {}), calmSummary: calm };
  zip.file('design_payload.json', JSON.stringify(designPayload, null, 2));
  const calmDir = 'calm/';
  zip.file(`${calmDir}calm_components.json`, JSON.stringify(calm.Component || [], null, 2));
  zip.file(`${calmDir}calm_connections.json`, JSON.stringify(calm.Connection || [], null, 2));
  zip.file(`${calmDir}calm_coupons.json`, JSON.stringify(calm.Coupon || [], null, 2));
  zip.file(`${calmDir}calm_review_findings.json`, JSON.stringify(calm.ReviewFinding || findings, null, 2));
  zip.file(`${calmDir}calm_system.json`, JSON.stringify(calm.System || [], null, 2));
  zip.file(`${calmDir}calm_applications.json`, JSON.stringify(calm.Application || [], null, 2));
  zip.file(`${calmDir}calm_services.json`, JSON.stringify(calm.Service || [], null, 2));
  zip.file(`${calmDir}calm_service_instances.json`, JSON.stringify(calm.ServiceInstance || [], null, 2));
  zip.file(`${calmDir}calm_connection_types.json`, JSON.stringify(calm.ConnectionType || [], null, 2));
  zip.file(`${calmDir}calm_coupon_types.json`, JSON.stringify(calm.CouponType || [], null, 2));
  zip.file(`${calmDir}calm_architecture_models.json`, JSON.stringify(calm.ArchitectureModel || [], null, 2));
  zip.file(`${calmDir}calm_deployment_models.json`, JSON.stringify(calm.DeploymentModel || [], null, 2));
  zip.file(`${calmDir}calm_security_fragments.json`, JSON.stringify(calm.SecurityFragment || [], null, 2));
  zip.file(`${calmDir}calm_security_blueprints.json`, JSON.stringify(calm.SecurityBlueprint || [], null, 2));
  zip.file('final_snapshot.json', JSON.stringify(caseData.finalSnapshot || {}, null, 2));
  zip.file('chat_messages.json', JSON.stringify(caseData.chat || caseData.chat_messages || [], null, 2));

  const reviewerName = caseData.finalSnapshot?.reviewerName || caseData.finalSnapshot?.reviewer || caseData.reviewer || '';
  const ticketLabel = caseData.ticketId || caseData.name || caseData.id || '';
  const firewallHeaders = [
    'FlowProcessType',
    'AssignedSecDesignReviewer(Integrator)',
    'SecDesignTicket/CaseId',
    'SourceEonId',
    'SourceComponent',
    'SourceApplicationName',
    'SourcePlantDomain',
    'SourceSecurityZone',
    'SourceSubnetBoundary',
    'DestinationEonId',
    'DestinationComponent',
    'DestinationApplicationName',
    'DestinationPlantDomain',
    'DestinationSecurityZone',
    'DestinationSubnetBoundary',
    'Service(Protocol|Port)',
    'ExpiryDate',
    'BusinessJustification',
  ];
  const proxyHeaders = [
    'connection_ref',
    'enable_offshore_proxy',
    'source_object_type',
    'target_urls',
    'proxy_type',
    'proxy_authentication',
    'proxy_ssl_inspection',
    'proxy_antivirus',
    'expiry_date',
    'business_justification',
  ];
  const formatProtocolPorts = (value) => {
    if (Array.isArray(value)) return value.join(', ');
    return value || '';
  };
  const firewallRows = (checklist.firewall_details || []).map((row) => ({
    FlowProcessType: 'Standard',
    'AssignedSecDesignReviewer(Integrator)': reviewerName,
    'SecDesignTicket/CaseId': ticketLabel,
    SourceEonId: row.source_eonid || '',
    SourceComponent: row.source_component || '',
    SourceApplicationName: row.source_application || '',
    SourcePlantDomain: row.source_domain || '',
    SourceSecurityZone: row.source_zone || '',
    SourceSubnetBoundary: row.source_subnet || '',
    DestinationEonId: row.destination_eonid || '',
    DestinationComponent: row.destination_component || '',
    DestinationApplicationName: row.destination_application || '',
    DestinationPlantDomain: row.destination_domain || '',
    DestinationSecurityZone: row.destination_zone || '',
    DestinationSubnetBoundary: row.destination_subnet || '',
    'Service(Protocol|Port)': formatProtocolPorts(row.protocol_ports),
    ExpiryDate: row.expiry_date || '',
    BusinessJustification: row.business_justification || '',
  }));
  const firewallCsv = toCsv(firewallRows, firewallHeaders);
  const proxyCsv = toCsv(checklist.proxy_details || [], proxyHeaders);
  if (firewallCsv) zip.file('detailed_firewall_flow.csv', firewallCsv);
  if (proxyCsv) zip.file('detailed_proxy_flow.csv', proxyCsv);

  const attachments = collectAttachments(caseData);
  for (const file of attachments) {
    const blob = dataUrlToBlob(file.dataUrl);
    if (blob) {
      zip.file(file.path || file.name || 'attachment', blob, { binary: true });
      continue;
    }
    if (file.sourcePath) {
      try {
        const url = getAttachmentUrl(file.sourcePath);
        const res = await fetch(url);
        if (res.ok) {
          const buffer = await res.arrayBuffer();
          zip.file(file.path || file.name || 'attachment', buffer, { binary: true });
          continue;
        }
      } catch (error) {
        // fall through to placeholder
      }
    }
    zip.file(`${file.path || file.name || 'attachment'}.txt`, 'Missing file data (no dataUrl or download failed)');
  }

  const content = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${filenamePrefix}.zip`;
  a.click();
  URL.revokeObjectURL(url);
};
