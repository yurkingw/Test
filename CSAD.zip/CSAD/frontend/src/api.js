/**
 * ------------------------------------------------------------------------
 * API Client Configuration (api.js)
 * ------------------------------------------------------------------------
 * This file configures and exports a centralized Axios instance for making
 * HTTP requests to the backend API.
 */

import axios from 'axios';

const resolveBaseURL = () => {
  const envValue = process.env.REACT_APP_API_BASE_URL;
  if (envValue && envValue.trim().length > 0) {
    const trimmed = envValue.trim();
    if (typeof window !== 'undefined') {
      try {
        const parsed = new URL(trimmed, window.location.origin);
        if (parsed.hostname === window.location.hostname) {
          return `${window.location.protocol}//${parsed.host}${parsed.pathname.replace(/\/$/, '')}`;
        }
      } catch (error) {
        // Fall back to the provided env value.
      }
    }
    return trimmed;
  }

  if (typeof window !== 'undefined') {
    const { protocol, hostname } = window.location;
    if (hostname === 'localhost' || hostname === '127.0.0.1') {
      return `${protocol}//${hostname}:8000/api/v1`;
    }
    return '/api/v1';
  }

  return 'http://localhost:8000/api/v1';
};

const apiClient = axios.create({
  baseURL: resolveBaseURL(),
  headers: {
    'Content-Type': 'application/json',
  },
});

export default apiClient;
