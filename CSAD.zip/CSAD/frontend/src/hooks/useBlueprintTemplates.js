import { useEffect, useState } from 'react';
import { listBlueprintTemplatesApi } from '../api/blueprints';

export const useBlueprintTemplates = () => {
  const [templates, setTemplates] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    listBlueprintTemplatesApi()
      .then((data) => {
        if (mounted) setTemplates(data || {});
      })
      .catch((err) => {
        if (mounted) setError(err);
      })
      .finally(() => {
        if (mounted) setLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, []);

  return { templates, loading, error };
};
