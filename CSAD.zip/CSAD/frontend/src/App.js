import React from 'react';
import { Routes, Route } from 'react-router-dom';

import Landing from './components/Landing';
import AiPreReview from './components/AiPreReview';
import SelfPreReview from './components/SelfPreReview';
import ReviewAcknowledgement from './components/ReviewAcknowledgement';
import EvidenceCollection from './components/EvidenceCollection';
import RiskRejection from './components/RiskRejection';
import SecDesignReview from './components/SecDesignReview';
import SecDesignFinalSnapshot from './components/SecDesignFinalSnapshot';
import ValidatorDashboard from './components/ValidatorDashboard';
import CaseReport from './components/CaseReport';
import Blueprints from './components/Blueprints';
import PreReviewSummary from './components/PreReviewSummary';
import RequestorSubmitted from './components/RequestorSubmitted';
import TopBar from './components/TopBar';
import BindTicket from './components/BindTicket';
import MyCases from './components/MyCases';
import ReviewList from './components/ReviewList';
import CaseView from './components/CaseView';
import ReviewConfirm from './components/ReviewConfirm';

function App() {
  const appStyle = { textAlign: 'center', fontFamily: '"Segoe UI", Arial, sans-serif' };
  const headerStyle = { backgroundColor: '#0D47A1', padding: '20px', color: 'white', marginBottom: '20px', fontFamily: '"Segoe UI", Arial, sans-serif' };

  return (
    <div style={appStyle} className="App">
      <header style={headerStyle} className="App-header">
        <h1>CALM Security Architecture Designer (CSAD)</h1>
      </header>
      <TopBar />
      <main>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/bind-ticket" element={<BindTicket />} />
          <Route path="/my-cases" element={<MyCases />} />
          <Route path="/review-list" element={<ReviewList />} />
          <Route path="/case-view" element={<CaseView />} />
          <Route path="/review-confirm" element={<ReviewConfirm />} />
          <Route path="/ai-pre-review" element={<AiPreReview />} />
          <Route path="/self-pre-review" element={<SelfPreReview />} />
          <Route path="/pre-review-summary" element={<PreReviewSummary />} />
          <Route path="/review-acknowledgement" element={<ReviewAcknowledgement />} />
          <Route path="/evidence-collection" element={<EvidenceCollection />} />
          <Route path="/risk-rejection" element={<RiskRejection />} />
          <Route path="/secdesign-review" element={<SecDesignReview />} />
          <Route path="/secdesign-final" element={<SecDesignFinalSnapshot />} />
          <Route path="/requestor-finish" element={<RequestorSubmitted />} />
          <Route path="/validator-dashboard" element={<ValidatorDashboard />} />
          <Route path="/case/:caseId/report" element={<CaseReport />} />
          <Route path="/blueprints" element={<Blueprints />} />
        </Routes>
      </main>
    </div>
  );
}

export default App;
