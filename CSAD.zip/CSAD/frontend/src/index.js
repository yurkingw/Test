/**
 * ------------------------------------------------------------------------
 * Application Entry Point
 * ------------------------------------------------------------------------
 * This file is the main entry point for the React application.
 * It uses ReactDOM to render the root <App /> component into the DOM.
 */

import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { ReviewCacheProvider } from './context/ReviewCacheContext';
import { UserProvider } from './context/UserContext';

// Get the root DOM element where the React app will be mounted.
const rootElement = document.getElementById('root');

// Create a new React root for concurrent rendering.
const root = ReactDOM.createRoot(rootElement);

// Render the main App component into the root.
// React.StrictMode is a wrapper that checks for potential problems in the app
// during development (it does not affect the production build).
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <UserProvider>
        <ReviewCacheProvider>
          <App />
        </ReviewCacheProvider>
      </UserProvider>
    </BrowserRouter>
  </React.StrictMode>
);
