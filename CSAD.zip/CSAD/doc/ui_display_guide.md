# UI Display Guide
本指南列出主要页面的文字显示及对应的前端文件位置，便于后续人工调整文案与样式。

- App 头部标题  
  - `frontend/src/App.js`：`<header>` 中的 “CSAD - Security Design Review”。

- 顶部导航（Home/My Cases/Review List、User/Role、Login/Logout、登录弹窗文案）  
  - `frontend/src/components/TopBar.js`。

- 首页（Landing）主按钮/介绍文案  
  - `frontend/src/components/Landing.js`（含 Submit Case 登录校验提示）。

- 绑定工单页面（Bind Ticket）表单标签/提示与按 Ticket 生成 Case 编号逻辑  
  - `frontend/src/components/BindTicket.js`（含 Jira 异常提示 “Jira tickets unavailable.”、搜索框占位 “Search ITSM ticket number (e.g., 00001)”、按钮 “Refresh JSM Ticket”、分页 “Prev/Next”、加载提示与 “Total/Last refreshed”）。
  - 隐藏演示工单（未来上线时）：在 `frontend/src/components/BindTicket.js` 的 `ticketOptions` 生成逻辑里移除 `dummyTickets` 合并（或将 `dummyTickets` 置空）。当前为测试保留，暂不修改。

- 我的案例列表（My Cases）表头/按钮  
  - `frontend/src/components/MyCases.js`（Auditor 显示 “All Cases (Auditor)” 标题，表头支持点击排序，表头下方有 Filter 输入行；Edit 按钮禁用条件、Cancel 统一确认）。

- 审核列表（Review List）表头/按钮/状态提示  
  - `frontend/src/components/ReviewList.js`（表头支持点击排序，表头下方有 Filter 输入行）。

- 设计提交（Self Pre-Review - Control Exception）表单标签/校验提示/按钮文案  
  - `frontend/src/components/SelfPreReviewControlException.js`（含 “Control Exception Scenario” 下拉选项、Scenario 勾选项与 Other Scenario 文本框、Data Connection 下拉选项、Implemented Control(s) 多级选择、Exception Expiry 日期、Reviewer 下拉（本地用户角色）、Firewall Protocol | Port 下拉/输入生成标签、Proxy Flow 新增 Enable Offshore(Global) Proxy、Source Object Type 与 Business Justification）。

- AI 预审、Pre-Review Summary、Review Acknowledgement、Risk Rejection  
  - `frontend/src/components/AiPreReview.js`  
  - `frontend/src/components/PreReviewSummary.js`（Generated Findings 包含 Finding Type / Classification）  
  - `frontend/src/components/ReviewAcknowledgement.js`（Audit Findings 包含 Finding Type）  
  - `frontend/src/components/RiskRejection.js`（列表项包含 Finding Type）。

- 证据收集页面（Evidence Collection）表单标签/按钮/校验提示  
  - `frontend/src/components/EvidenceCollection.js`（含 Finding Type、Classification、Existing Evidence 附件展示区块）。

- SecDesign 审核页面（SecDesign Review）文案与按钮  
  - `frontend/src/components/SecDesignReview.js`（Show Design/Form/CALM 与 Show Findings (CALM) 按钮、Review Findings (CALM) 标题；Existing Findings 区块包含 “Issue Context / Finding Type / Risk Description / Requirement / Risk / Classification / Decision” 标签；AI Pre Review 完成弹窗文案）。

- 审核完成页（SecDesign Final）区块标题/按钮  
  - `frontend/src/components/SecDesignFinalSnapshot.js`（Review Report 展示包含 Finding Type 与 “Suppressed: Yes/No” 文案）。

- Case 只读视图与确认视图  
  - `frontend/src/components/CaseView.js`（只读查看，含 Show Findings (CALM) 按钮与 Review Findings (CALM) 标题，Finding Type / Classification 展示与跳转到 SecDesign Final 报告的按钮与 “Suppressed: Yes/No” 文案）  
  - `frontend/src/components/ReviewConfirm.js`（确认/复核，Review Findings 展示包含 Finding Type、Classification）。

- 其他辅助视图  
  - `frontend/src/components/ValidatorDashboard.js`、`CaseReport.js`、`Blueprints.js`。

如需修改具体文字，请直接编辑对应文件中的文本字符串；样式多为组件内联样式，可在同文件中调整。全局字体在 `frontend/src/App.js` 的 `appStyle`/`headerStyle` 中设置。***
