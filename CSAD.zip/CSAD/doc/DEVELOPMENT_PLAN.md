# CSAD Development Plan

This document outlines the phased development plan for the CSAD project. It is a living document, updated continuously to reflect the current status and next steps.

---

## Completed Phases

### **Phase 1-6: Frontend UI Skeleton**
*   **Description**: This foundational phase focused on building the complete visual workflow for the application, creating all necessary pages and placeholder components for the user journey from start to finish.
*   **Key Deliverables**:
    *   Initial landing page (`Landing.js`).
    *   Self-Pre-Review multi-step form (`SystemForm.js`, `ApplicationForm.js`, etc.).
    *   Placeholders for AI-Pre-Review, Dashboards, and other workflow steps (`AiPreReview.js`, `SecDesignDashboard.js`, `ValidatorDashboard.js`, etc.).
    *   Routing for the entire validator workflow.
*   **Status**: ✅ Completed

### **Phase 7: Final Report Generation (Backend)**
*   **Description**: Implement the backend logic to generate a final, comprehensive security design report for a given case.
*   **Plan**:
    1.  Create a new API endpoint: `/api/v1/cases/{case_id}/report`.
    2.  Aggregate all relevant case data from the database.
    3.  Format the data into a Markdown report.
*   **Actual Progress & Notes**:
    *   Discovered and fixed a missing database relationship between `CaseReview` and `ReviewFinding`.
    *   Conducted major debugging and repair of the Alembic migration environment, including a full database reset.
    *   Implemented a new data access function (`get_full_details`) for efficient data aggregation.
    *   Successfully implemented the API endpoint to generate a dynamic Markdown report from real database data.
*   **Status**: ✅ Completed

### **Phase 8: Frontend Report Display**
*   **Description**: Connect the frontend to the new report generation backend API and display the report to the user.
*   **Plan**:
    1.  Add a "Generate Report" button to the validator's case review page.
    2.  Create a new `CaseReport.js` component to host the report view.
    3.  Implement the frontend API call to `/api/v1/cases/{caseId}/report`.
    4.  Use a library (e.g., `react-markdown`) to render the fetched Markdown report within the `CaseReport.js` component.
*   **Status**: ✅ Completed

---

## Upcoming Phases

### **Phase 9: "Coupon" Generation (Backend)**
*   **Description**: Implement the backend logic for the `/api/v1/cases/{case_id}/coupon` endpoint, replacing the current placeholder. This involves parsing an approved design and generating a structured JSON "coupon" for relevant firewall/proxy flows.
*   **Status**: 📋 Planned

### **Phase 10: Frontend Data Integration**
*   **Description**: Replace mock data currently used in various frontend components (e.g., dashboards) with live data from backend API calls.
*   **Status**: 📋 Planned

### **Phase 11: AI-Pre-Review Implementation**
*   **Description**: Build out the core functionality for the AI-Pre-Review workflow, including the interactive chat interface and backend integration for AI-driven analysis.
*   **Status**: 📋 Planned

---

## Feature Implementation Status Snapshot

| Feature Request | Scope Highlights | Current Status | Notes |
| :--- | :--- | :--- | :--- |
| Entry selection UI | Landing page offering AI vs. Self Pre-Review | ✅ Complete | Routes render with review type gateway and mode selection. |
| Review type selection | Toggle between Security Design and Control Exception flows | 🚧 In Progress | Landing page now captures review type; Control Exception workflow includes disclaimer, checklist, template scaffolding, and conditional detail sections. |
| AI-Pre-Review workspace | File & Security Design uploads, AI prompt orchestration, markdown download, iterative chat | 🚧 In Progress | Chat now supports review-type prompts, file/template uploads, OpenAI responses, and Markdown export; remaining tasks include richer prompt engineering and CALM finding synthesis. |
| Self-Pre-Review wizard | CALM-aligned form steps, typed inputs, validation, audit submission | 🚧 In Progress | Security design wizard retained; Control Exception template now captures Data Perimeter assessments, a renamed Data Connection grid, and purpose-built Firewall/Proxy detail tables (with coupon-ready metadata) plus a consolidated review step, left-aligned CALM previews, and blocking validation with explicit error popups (expiry must now be a future date). |
| Control Exception CALM pipeline | Map CE form input to CALM + coupon, evaluate blueprint heuristics | 🚧 In Progress | Backend `control_exception_calm.py` now materializes CALM entities using official keys (`cmdb_sysid`, `appid`, `svcid`, etc.), stores perimeter + connection structures, and emits coupons from the detailed firewall/proxy tables while evaluating YAML-driven rules; expiry checks auto-skip until structured data is reintroduced. DB persistence + full CALM materialization still pending. |
| Security Blueprint authoring pipeline | NLP/LLM extraction → config → CALM entities | 🚧 In Progress | Documented 3-layer approach并实现了初版转换器：`backend/app/config/security_blueprint_pattern.yaml` + `security_blueprint_pattern.py` 可将中间配置生成 CALM `SecurityFragment/SecurityBlueprint` 预览（通过 `/api/v1/blueprint-templates`). 后续需要接入正式蓝图存储与校验。 |
| Pre-review confirmation summary | Unified summary view before acknowledgement | ✅ Complete | Added summary route covering AI and Self flows, showing user inputs, findings, and uploaded media for confirmation. |
| Post pre-review acknowledgement | Accept vs. reject pathways, modal UX with close icon | 🚧 In Progress | Acknowledgement screen exists; requires modal implementation with dismiss, state persistence, and navigation guards. |
| Evidence collection | Per-finding evidence capture with uploads & storage | 🚧 In Progress | UI stub present; backend endpoints, file storage, and CALM linkage outstanding. |
| Risk rejection routing | Multi-select risks, risk officer queue, email notification | ⚠️ Not Started | Need risk officer case view, notification integration, and status tracking. |
| SecDesign review console | Case pool, comments, add/remove findings, return-to-requestor | ⚠️ Not Started | Placeholder list only; requires full CRUD, workflow transitions, and evidence visibility. |
| Approval/denial gating rules | Evidence completeness check, mandatory Action Plan fields | ⚠️ Not Started | Implement rule engine to enforce evidence presence and collect openpage/action plan numbers before advance. |
| Validator confirmation | Final review, return vs. complete actions | ⚠️ Not Started | Validator UI needs parity with SecDesign data plus transition hooks. |
| Final report & coupon | Consolidated CALM report, compliant coupon JSON generation | 🚧 In Progress | Report endpoint exists but needs full data aggregation; coupon logic still mocked. |
| Email & notification integration | Trigger emails to risk officer / stakeholders | ⚠️ Not Started | Define mail service abstraction and queue strategy. |
| Modal close UX | Dismiss icons on every wizard/dialog | ⚠️ Not Started | Audit all dialogs once modal system lands. |
