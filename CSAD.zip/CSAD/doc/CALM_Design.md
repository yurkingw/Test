# CALM Design For COD

## 1. CALM 核心模型概览

### 1.1. 核心理念

- 层级化组合：`System → Application → Service → ServiceInstance`。
- 动态属性聚合：`Component/Connection.properties` 由上下文与类型动态聚合，并以 `from_*` 命名空间保留来源。
- 扁平化继承：物化实体直接从所有相关上下文拉取属性，便于审计与回溯。
- 类型驱动：`Connection` 属性结构由 `ConnectionType` 定义；`Coupon` 快照由 `CouponType` 定义。
- 视图抽象：`Node` 为非持久化 DTO，仅聚合 `Application` 的组件清单（不继承应用属性）。
- 单一事实来源：字段与取值域以第4章为准。

---

### 1.2. 实体定义与边界

- 字典实体（定义类型）：`DeploymentModel/ArchitectureModel/ConnectionType/CouponType`。
- 上下文实体（定义上下文）：`System/Application/Service/ServiceInstance`，字段为该实体"自有"。
- 物化实体（聚合结果，继承上下文与字典）：`Component`（映射 `ServiceInstance`）、`Connection`（由 `ConnectionType` 决定聚合规则）、`Coupon` (快照，由`CouponType` 决定聚合规则)。
- 审计实体（规则与结果）：`SecurityFragment/SecurityBlueprint/ReviewFinding`。
- 视图模型（仅 UI）：`Node` 为运行时构造的 DTO，展现应用对象，不入库，不出现在 ER 图与模式章中。

---

### 1.3. 模型优势（要点）

- 可审计与可追溯：属性保留来源命名空间，支持细粒度追踪与问责。
- 自动验证与治理：类型驱动 + 模式校验，结合蓝图实现自动审计与工单化输出。
- 关注点分离：字典/上下文/物化/视图职责清晰，设计-实现-审计边界明确。
- UI 友好：`Node` 聚合接口隔离底层规范化结构，降低前端复杂度。

---

## 2. CALM 实体关系图

```mermaid
erDiagram
    System {
        string cmdb_sysid PK
        string sysname
        string description
        json properties
    }
    Application {
        string appid PK
        string appname
        string cmdb_sysid FK
        string deployment_model_id FK
        json properties
    }
    Service {
        string svcid PK
        string svcname
        string appid FK
        string architecture_model_id FK
        json properties
    }
    ServiceInstance {
        string svcint_id PK
        string svcintname
        string svcid FK
        json properties
    }
    Component {
        string cmpid PK
        string cmpname
        string svcint_id FK
        json properties
    }
    Connection {
        string conid PK
        string source_cmpid FK
        string destination_cmpid FK
        string connection_type_id FK
        json properties
    }
    DeploymentModel {
        string deployment_model_id PK
        string deployment_model_name
        json properties
    }
    ArchitectureModel {
        string architecture_model_id PK
        string architecture_model_category
        string architecture_model
        json properties
    }
    ConnectionType {
        string connection_type_id PK
        string connection_type_name
    }
    CouponType {
        string coupon_type_id PK
        string coupon_type_name
    }
    Coupon {
        string coupon_id PK
        string triggering_connection_id FK
        string coupon_type_id FK
        string expiry
        string justification
        json properties
    }
    SecurityFragment {
        string fragment_id PK
        string fragment_name
        string target_entity
        object condition
    }
    SecurityBlueprint {
        string blueprint_id PK
        string blueprint_name
        array rules
    }
    ReviewFinding {
        string finding_id PK
        string triggered_blueprint_id FK
        string triggered_rule_id
        string triggered_definition_id
        string violating_entity_type
        string violating_entity_id
        object violating_condition_snapshot
        string violation_summary
        string risk
        array requirement
        array recommendation
        string status
    }
    System ||--o{ Application : "hosts"
    Application ||--o{ Service : "contains"
    Service ||--o{ ServiceInstance : "realized by"
    ServiceInstance ||--|| Component : "maps to"
    Connection }|--|| Component : "has source"
    Connection }|--|| Component : "has target"
    Connection }o--|| ConnectionType : "is of type"
    Application }o--|| DeploymentModel : "deployed on"
    Service }o--|| ArchitectureModel : "uses"
    SecurityBlueprint }o..o{ SecurityFragment : "references"
    SecurityBlueprint ||--o{ ReviewFinding : "triggers"
    Connection ||--o{ Coupon : "triggers"
    CouponType ||--o{ Coupon : "is of type"
```

---

## 3. 用户案例: Corebanking System

本章根据用户提供的"Corebanking System Security Architecture"设计案例，生成一套完整的CALM实体对象。所有实体的`properties`字段均已根据第四章的模式定义进行了全面填充，未在设计案例中提及的属性值被明确置空。

### 3.1. 字典实体定义

#### DeploymentModel

```yaml
DeploymentModel:
  - deployment_model_id: DTP-001
    deployment_model:
      deployment_model_name: Virtual Machine
      hypervisor_os: ESXi 7.0
      guest_os: Windows Server 2019
      vm_escape_protection: Enabled
      sec_baseline_golden_image: Enabled
      trusted_platform_module_status: Enabled
      secure_boot_status: Enabled
  - deployment_model_id: DTP-002
    deployment_model:
      deployment_model_name: Desktop
      os: Windows 10
      host_firewall: Windows Firewall
      endpoint_antivirus: Windows Defender
      endpoint_detection_response: Cortex XDR
      endpoint_data_leakage_protection: Disabled
      Windows_gpo_policy: Enabled
      trusted_platform_module_status: Enabled
      secure_boot_status: Enabled
  - deployment_model_id: DTP-003
    deployment_model:
      deployment_model_name: External Service
      external_service_resource: ["https://report.smartensemble.com:5020"]
      trusted_platform_module_status: N/A
      secure_boot_status: N/A
```

#### ArchitectureModel

```yaml
ArchitectureModel:
  - architecture_model_id: AML-001
    architecture_model_category: AccessLayer
    architecture_model: Client
    tool_licensing_model:
    tool:
      tool_name: Core Banking Thick Client
      software_runas: Normal Account
  - architecture_model_id: AML-002
    architecture_model_category: ApplicationLayer
    architecture_model: Application Service
    tool_licensing_model:
    tool:
      tool_name: Core Banking
      console_access_control: Enabled
```

#### ConnectionType

```yaml
ConnectionType:
  - connection_type_id: CTP-001
    connection_type:
      connection_type_name: Network Communication
      source_security_domain: Connection.source_cmpid.inherited_properties.from_Application.security_domain
      source_security_zone: Connection.source_cmpid.inherited_properties.from_Application.security_zone
      destination_security_domain: Connection.destination_cmpid.inherited_properties.from_Application.security_domain
      destination_security_zone: Connection.destination_cmpid.inherited_properties.from_Application.security_zone
      destination_protocol: Connection.destination_cmpid.inherited_properties.from_Service.listening_protocol
      destination_port: Connection.destination_cmpid.inherited_properties.from_Service.listening_port
      destination_authentication_methods: Connection.destination_cmpid.inherited_properties.from_Service.authentication_methods
      destination_authorization_methods: Connection.destination_cmpid.inherited_properties.from_Service.authorization_methods
      destination_encryption_in_transit_algorithms: Connection.destination_cmpid.inherited_properties.from_Service.encryption_in_transit_algorithms
  - connection_type_id: CTP-002
    connection_type:
      connection_type_name: Inter-Process Communication
      destination_ipc_authentication_methods: Connection.destination_cmpid.inherited_properties.from_ServiceInstance.ipc_authentication_methods
      destination_ipc_authorization_methods: Connection.destination_cmpid.inherited_properties.from_ServiceInstance.ipc_authorization_methods
      destination_race_condition_sync: Connection.destination_cmpid.inherited_properties.from_ServiceInstance.race_condition_sync
```

#### CouponType

```yaml
CouponType:
  - coupon_type_id: CPT-001
    coupon_type:
      coupon_type_name: Firewall Flow
      source_security_domain: Connection.source_cmpid.inherited_properties.from_Application.security_domain
      source_security_zone: Connection.source_cmpid.inherited_properties.from_Application.security_zone
      destination_security_domain: Connection.destination_cmpid.inherited_properties.from_Application.security_domain
      destination_security_zone: Connection.destination_cmpid.inherited_properties.from_Application.security_zone
      destination_protocol: Connection.destination_cmpid.inherited_properties.from_Service.listening_protocol
      destination_port: Connection.destination_cmpid.inherited_properties.from_Service.listening_port
  - coupon_type_id: CPT-002
    coupon_type:
      coupon_type_name: Proxy Flow
      source_security_domain: Connection.source_cmpid.inherited_properties.from_Application.security_domain
      source_security_zone: Connection.source_cmpid.inherited_properties.from_Application.security_zone
      destination_security_domain: Connection.destination_cmpid.inherited_properties.from_Application.security_domain
      destination_security_zone: Connection.destination_cmpid.inherited_properties.from_Application.security_zone
      destination_external_service_resource: Connection.destination_cmpid.inherited_properties.from_DeploymentModel.deployment_model.external_service_resource
      proxy_type: SOCKS
      proxy_ssli: Disabled
      proxy_auth: Non-Auth
```

### 3.2. 上下文实体定义

#### System

```yaml
System:
  - cmdb_sysid: SYS-001
    sysname: Corebanking System
    description: Corebanking system with thick clients deployed in branches and data centers.
    information_sensetivity_classification: Highly Restricted
    asset_risk_ranking: P1
```

#### Application

```yaml
Application:
  - appid: APP-001
    appname: Corebanking Client (Vanilla)
    cmdb_sysid: SYS-001
    deployment_model_id: DTP-002
    location: Onprem_DC_SH
    security_environment: Prod
    security_domain: MSBIC_MDEX
    security_zone: vanilla-dmz
  - appid: APP-002
    appname: Corebanking Client (MS-DMZ)
    cmdb_sysid: SYS-001
    deployment_model_id: DTP-001
    location: Onprem_DC_SH
    security_environment: Prod
    security_domain: MSBIC_MDEX
    security_zone: ms-dmz
  - appid: APP-003
    appname: Corebanking Service
    cmdb_sysid: SYS-001
    deployment_model_id: DTP-003
    location: Cloud_Other
    security_environment: Prod
    security_domain: MSBIC_MDEX
    security_zone: external
  - appid: APP-004
    appname: MSBIC Branch OA Desktop
    cmdb_sysid: SYS-001
    deployment_model_id: DTP-002
    location: Onprem_DC_SH
    security_environment: Prod
    security_domain: MSBIC_OA
    security_zone: int-broa
  - appid: APP-005
    appname: MSMS Branch OA Desktop
    cmdb_sysid: SYS-001
    deployment_model_id: DTP-002
    location: Onprem_DC_SH
    security_environment: Prod
    security_domain: COD_MSMS
    security_zone: branch-oa
```

#### Service

```yaml
Service:
  - svcid: SVC-001
    svcname: Corebanking Client Service
    appid: ["APP-001", "APP-002"]
    architecture_model_id: AML-001
    authentication_methods: Corebanking Client Account
    authorization_methods: RBAC
    encryption_in_transit_algorithms: N/A
    encryption_in_transit_key_strength: N/A
    encryption_at_rest_algorithms: N/A
    encryption_at_rest_key_strength: N/A
    logging_retention_days: N/A
    logging_cyber_detection_feed: N/A
    listening_port: N/A
    listening_protocol: N/A
  - svcid: SVC-002
    svcname: Remote Desktop Service
    appid: ["APP-002"]
    architecture_model_id: AML-001
    authentication_methods: Local Account
    authorization_methods: Local Group
    encryption_in_transit_algorithms: ["TLS 1.2", "RSA", "AES", "SHA-2"]
    encryption_in_transit_key_strength: ["RSA2048", "AES_256_GCM", "SHA256"]
    encryption_at_rest_algorithms: N/A
    encryption_at_rest_key_strength: N/A
    logging_retention_days: N/A
    logging_cyber_detection_feed: SIEM
    listening_port: 3389
    listening_protocol: TCP
  - svcid: SVC-003
    svcname: Corebanking Backend Service
    appid: APP-003
    architecture_model_id: AML-002
    authentication_methods: Corebanking Client Account
    authorization_methods: RBAC
    encryption_in_transit_algorithms: N/A
    encryption_in_transit_key_strength: N/A
    encryption_at_rest_algorithms: N/A
    encryption_at_rest_key_strength: N/A
    logging_retention_days: N/A
    logging_cyber_detection_feed: N/A
    listening_port: [7012, 3022, 5022, 8099, 9112, 9004, 7032]
    listening_protocol: TCP
  - svcid: SVC-004
    svcname: Desktop RDP Client
    appid: ["APP-004", "APP-005"]
    architecture_model_id: AML-001
    authentication_methods: N/A
    authorization_methods: N/A
    encryption_in_transit_algorithms: N/A
    encryption_in_transit_key_strength: N/A
    encryption_at_rest_algorithms: N/A
    encryption_at_rest_key_strength: N/A
    logging_retention_days: N/A
    logging_cyber_detection_feed: N/A
    listening_port: N/A
    listening_protocol: N/A
```

#### ServiceInstance

```yaml
ServiceInstance:
  - svcint_id: SIN-001
    svcintname: Corebanking Client Service Instance
    svcid: SVC-001
    ipc_authentication_methods: N/A
    ipc_authorization_methods: N/A
    sast_status: N/A
    dast_status: N/A
    parameterized_queries_status: N/A
    input_validation_methods: N/A
    output_encoding_contexts: N/A
    csrf_protection_mechanism: N/A
    race_condition_sync: N/A
  - svcint_id: SIN-002
    svcintname: Remote Desktop Service Instance
    svcid: SVC-002
    ipc_authentication_methods: N/A
    ipc_authorization_methods: N/A
    sast_status: Passed
    dast_status: Passed
    parameterized_queries_status: N/A
    input_validation_methods: TypeChecking
    output_encoding_contexts: N/A
    csrf_protection_mechanism: N/A
    race_condition_sync: N/A
  - svcint_id: SIN-003
    svcintname: Corebanking Backend Service Instance - Core
    svcid: SVC-003
    ipc_authentication_methods: N/A
    ipc_authorization_methods: N/A
    sast_status: N/A
    dast_status: N/A
    parameterized_queries_status: N/A
    input_validation_methods: N/A
    output_encoding_contexts: N/A
    csrf_protection_mechanism: N/A
    race_condition_sync: N/A
  - svcint_id: SIN-004
    svcintname: Corebanking Backend Service Instance - Counter
    svcid: SVC-003
    ipc_authentication_methods: N/A
    ipc_authorization_methods: N/A
    sast_status: N/A
    dast_status: N/A
    parameterized_queries_status: N/A
    input_validation_methods: N/A
    output_encoding_contexts: N/A
    csrf_protection_mechanism: N/A
    race_condition_sync: N/A
  - svcint_id: SIN-005
    svcintname: Corebanking Backend Service Instance - Reporter
    svcid: SVC-003
    ipc_authentication_methods: N/A
    ipc_authorization_methods: N/A
    sast_status: N/A
    dast_status: N/A
    parameterized_queries_status: N/A
    input_validation_methods: N/A
    output_encoding_contexts: N/A
    csrf_protection_mechanism: N/A
    race_condition_sync: N/A
  - svcint_id: SIN-006
    svcintname: Corebanking Backend Service Instance - Operation Management
    svcid: SVC-003
    ipc_authentication_methods: N/A
    ipc_authorization_methods: N/A
    sast_status: N/A
    dast_status: N/A
    parameterized_queries_status: N/A
    input_validation_methods: N/A
    output_encoding_contexts: N/A
    csrf_protection_mechanism: N/A
    race_condition_sync: N/A
  - svcint_id: SIN-007
    svcintname: Corebanking Backend Service Instance - Endpoint Authorization
    svcid: SVC-003
    ipc_authentication_methods: N/A
    ipc_authorization_methods: N/A
    sast_status: N/A
    dast_status: N/A
    parameterized_queries_status: N/A
    input_validation_methods: N/A
    output_encoding_contexts: N/A
    csrf_protection_mechanism: N/A
    race_condition_sync: N/A
  - svcint_id: SIN-008
    svcintname: Corebanking Backend Service Instance - Judicial control
    svcid: SVC-003
    ipc_authentication_methods: N/A
    ipc_authorization_methods: N/A
    sast_status: N/A
    dast_status: N/A
    parameterized_queries_status: N/A
    input_validation_methods: N/A
    output_encoding_contexts: N/A
    csrf_protection_mechanism: N/A
    race_condition_sync: N/A
  - svcint_id: SIN-009
    svcintname: Corebanking Backend Service Instance - AntiMoney Landering
    svcid: SVC-003
    ipc_authentication_methods: N/A
    ipc_authorization_methods: N/A
    sast_status: N/A
    dast_status: N/A
    parameterized_queries_status: N/A
    input_validation_methods: N/A
    output_encoding_contexts: N/A
    csrf_protection_mechanism: N/A
    race_condition_sync: N/A
  - svcint_id: SIN-010
    svcintname: Remote Desktop Client Instance
    svcid: SVC-004
    ipc_authentication_methods: N/A
    ipc_authorization_methods: N/A
    sast_status: Passed
    dast_status: Passed
    parameterized_queries_status: N/A
    input_validation_methods: TypeChecking
    output_encoding_contexts: N/A
    csrf_protection_mechanism: N/A
    race_condition_sync: N/A
```

### 3.3. 物化实体定义

#### Component

```yaml
Component:
  - cmpid: CMP-001
    cmpname: Corebanking Client Service Instance in Corebanking Client (Vanilla)
    svcint_id: SIN-001
    inherited_properties:
      from_ServiceInstance:
        svcint_id: SIN-001
        svcintname: Corebanking Client Service Instance
        svcid: SVC-001
        ipc_authentication_methods: N/A
        ipc_authorization_methods: N/A
        sast_status: N/A
        dast_status: N/A
        parameterized_queries_status: N/A
        input_validation_methods: N/A
        output_encoding_contexts: N/A
        csrf_protection_mechanism: N/A
        race_condition_sync: N/A
      from_Service:
        svcid: SVC-001
        svcname: Corebanking Client Service
        appid: ["APP-001", "APP-002"]
        architecture_model_id: AML-001
        authentication_methods: Corebanking Client Account
        authorization_methods: RBAC
        encryption_in_transit_algorithms: N/A
        encryption_in_transit_key_strength: N/A
        encryption_at_rest_algorithms: N/A
        encryption_at_rest_key_strength: N/A
        logging_retention_days: N/A
        logging_cyber_detection_feed: N/A
        listening_port: N/A
        listening_protocol: N/A
      from_Application:
        appid: APP-001
        appname: Corebanking Client (Vanilla)
        cmdb_sysid: SYS-001
        deployment_model_id: DTP-002
        location: Onprem_DC_SH
        security_environment: Prod
        security_domain: MSBIC_MDEX
        security_zone: vanilla-dmz
      from_System:
        cmdb_sysid: SYS-001
        sysname: Corebanking System
        description: Corebanking system with thick clients deployed in branches and data centers.
        information_sensetivity_classification: Highly Restricted
        asset_risk_ranking: P1
      from_DeploymentModel:
        deployment_model_id: DTP-002
        deployment_model:
          deployment_model_name: Desktop
          os: Windows 10
          host_firewall: Windows Firewall
          endpoint_antivirus: Windows Defender
          endpoint_detection_response: Cortex XDR
          endpoint_data_leakage_protection: Disabled
          Windows_gpo_policy: Enabled
          trusted_platform_module_status: Enabled
          secure_boot_status: Enabled
      from_ArchitectureModel:
        architecture_model_id: AML-001
        architecture_model_category: AccessLayer
        architecture_model: Client
        tool_licensing_model:
        tool:
          tool_name: Core Banking Thick Client
          software_runas: Normal Account
  - cmpid: CMP-002
    cmpname: Corebanking Client Service Instance in Corebanking Client (MS-DMZ)
    svcint_id: SIN-001
    inherited_properties:
      from_ServiceInstance:
        svcint_id: SIN-001
        svcintname: Corebanking Client Service Instance
        svcid: SVC-001
        ipc_authentication_methods: N/A
        ipc_authorization_methods: N/A
        sast_status: N/A
        dast_status: N/A
        parameterized_queries_status: N/A
        input_validation_methods: N/A
        output_encoding_contexts: N/A
        csrf_protection_mechanism: N/A
        race_condition_sync: N/A
      from_Service:
        svcid: SVC-001
        svcname: Corebanking Client Service
        appid: ["APP-001", "APP-002"]
        architecture_model_id: AML-001
        authentication_methods: Corebanking Client Account
        authorization_methods: RBAC
        encryption_in_transit_algorithms: N/A
        encryption_in_transit_key_strength: N/A
        encryption_at_rest_algorithms: N/A
        encryption_at_rest_key_strength: N/A
        logging_retention_days: N/A
        logging_cyber_detection_feed: N/A
        listening_port: N/A
        listening_protocol: N/A
      from_Application:
        appid: APP-002
        appname: Corebanking Client (MS-DMZ)
        cmdb_sysid: SYS-001
        deployment_model_id: DTP-001
        location: Onprem_DC_SH
        security_environment: Prod
        security_domain: MSBIC_MDEX
        security_zone: ms-dmz
      from_System:
        cmdb_sysid: SYS-001
        sysname: Corebanking System
        description: Corebanking system with thick clients deployed in branches and data centers.
        information_sensetivity_classification: Highly Restricted
        asset_risk_ranking: P1
      from_DeploymentModel:
        deployment_model_id: DTP-001
        deployment_model:
          deployment_model_name: Virtual Machine
          hypervisor_os: ESXi 7.0
          guest_os: Windows Server 2019
          vm_escape_protection: Enabled
          sec_baseline_golden_image: Enabled
          trusted_platform_module_status: Enabled
          secure_boot_status: Enabled
      from_ArchitectureModel:
        architecture_model_id: AML-001
        architecture_model_category: AccessLayer
        architecture_model: Client
        tool_licensing_model:
        tool:
          tool_name: Core Banking Thick Client
          software_runas: Normal Account
  - cmpid: CMP-003
    cmpname: Corebanking Backend Service Instance - Core in Corebanking Service
    svcint_id: SIN-003
    inherited_properties:
      from_ServiceInstance:
        svcint_id: SIN-003
        svcintname: Corebanking Backend Service Instance - Core
        svcid: SVC-003
        ipc_authentication_methods: N/A
        ipc_authorization_methods: N/A
        sast_status: N/A
        dast_status: N/A
        parameterized_queries_status: N/A
        input_validation_methods: N/A
        output_encoding_contexts: N/A
        csrf_protection_mechanism: N/A
        race_condition_sync: N/A
      from_Service:
        svcid: SVC-003
        svcname: Corebanking Backend Service
        appid: APP-003
        architecture_model_id: AML-002
        authentication_methods: Corebanking Client Account
        authorization_methods: RBAC
        encryption_in_transit_algorithms: N/A
        encryption_in_transit_key_strength: N/A
        encryption_at_rest_algorithms: N/A
        encryption_at_rest_key_strength: N/A
        logging_retention_days: N/A
        logging_cyber_detection_feed: N/A
        listening_port: [7012, 3022, 5022, 8099, 9112, 9004, 7032]
        listening_protocol: TCP
      from_Application:
        appid: APP-003
        appname: Corebanking Service
        cmdb_sysid: SYS-001
        deployment_model_id: DTP-003
        location: Cloud_Other
        security_environment: Prod
        security_domain: MSBIC_MDEX
        security_zone: external
      from_System:
        cmdb_sysid: SYS-001
        sysname: Corebanking System
        description: Corebanking system with thick clients deployed in branches and data centers.
        information_sensetivity_classification: Highly Restricted
        asset_risk_ranking: P1
      from_DeploymentModel:
        deployment_model_id: DTP-003
        deployment_model:
          deployment_model_name: External Service
          external_service_resource: ["https://report.smartensemble.com:5020"]
          trusted_platform_module_status: N/A
          secure_boot_status: N/A
      from_ArchitectureModel:
        architecture_model_id: AML-002
        architecture_model_category: ApplicationLayer
        architecture_model: Application Service
        tool_licensing_model:
        tool:
          tool_name: Core Banking
          console_access_control: Enabled
  - cmpid: CMP-004
    cmpname: Remote Desktop Client Instance in MSBIC Branch OA Desktop
    svcint_id: SIN-010
    inherited_properties:
      from_ServiceInstance:
        svcint_id: SIN-010
        svcintname: Remote Desktop Client Instance
        svcid: SVC-004
        ipc_authentication_methods: N/A
        ipc_authorization_methods: N/A
        sast_status: Passed
        dast_status: Passed
        parameterized_queries_status: N/A
        input_validation_methods: TypeChecking
        output_encoding_contexts: N/A
        csrf_protection_mechanism: N/A
        race_condition_sync: N/A
      from_Service:
        svcid: SVC-004
        svcname: Desktop RDP Client
        appid: ["APP-004", "APP-005"]
        architecture_model_id: AML-001
        authentication_methods: N/A
        authorization_methods: N/A
        encryption_in_transit_algorithms: N/A
        encryption_in_transit_key_strength: N/A
        encryption_at_rest_algorithms: N/A
        encryption_at_rest_key_strength: N/A
        logging_retention_days: N/A
        logging_cyber_detection_feed: N/A
        listening_port: N/A
        listening_protocol: N/A
      from_Application:
        appid: APP-004
        appname: MSBIC Branch OA Desktop
        cmdb_sysid: SYS-001
        deployment_model_id: DTP-002
        location: Onprem_DC_SH
        security_environment: Prod
        security_domain: MSBIC_OA
        security_zone: int-broa
      from_System:
        cmdb_sysid: SYS-001
        sysname: Corebanking System
        description: Corebanking system with thick clients deployed in branches and data centers.
        information_sensetivity_classification: Highly Restricted
        asset_risk_ranking: P1
      from_DeploymentModel:
        deployment_model_id: DTP-002
        deployment_model:
          deployment_model_name: Desktop
          os: Windows 10
          host_firewall: Windows Firewall
          endpoint_antivirus: Windows Defender
          endpoint_detection_response: Cortex XDR
          endpoint_data_leakage_protection: Disabled
          Windows_gpo_policy: Enabled
          trusted_platform_module_status: Enabled
          secure_boot_status: Enabled
      from_ArchitectureModel:
        architecture_model_id: AML-001
        architecture_model_category: AccessLayer
        architecture_model: Client
        tool_licensing_model:
        tool:
          tool_name: Core Banking Thick Client
          software_runas: Normal Account
  - cmpid: CMP-005
    cmpname: Remote Desktop Client Instance in MSMS Branch OA Desktop
    svcint_id: SIN-010
    inherited_properties:
      from_ServiceInstance:
        svcint_id: SIN-010
        svcintname: Remote Desktop Client Instance
        svcid: SVC-004
        ipc_authentication_methods: N/A
        ipc_authorization_methods: N/A
        sast_status: Passed
        dast_status: Passed
        parameterized_queries_status: N/A
        input_validation_methods: TypeChecking
        output_encoding_contexts: N/A
        csrf_protection_mechanism: N/A
        race_condition_sync: N/A
      from_Service:
        svcid: SVC-004
        svcname: Desktop RDP Client
        appid: ["APP-004", "APP-005"]
        architecture_model_id: AML-001
        authentication_methods: N/A
        authorization_methods: N/A
        encryption_in_transit_algorithms: N/A
        encryption_in_transit_key_strength: N/A
        encryption_at_rest_algorithms: N/A
        encryption_at_rest_key_strength: N/A
        logging_retention_days: N/A
        logging_cyber_detection_feed: N/A
        listening_port: N/A
        listening_protocol: N/A
      from_Application:
        appid: APP-005
        appname: MSMS Branch OA Desktop
        cmdb_sysid: SYS-001
        deployment_model_id: DTP-002
        location: Onprem_DC_SH
        security_environment: Prod
        security_domain: COD_MSMS
        security_zone: branch-oa
      from_System:
        cmdb_sysid: SYS-001
        sysname: Corebanking System
        description: Corebanking system with thick clients deployed in branches and data centers.
        information_sensetivity_classification: Highly Restricted
        asset_risk_ranking: P1
      from_DeploymentModel:
        deployment_model_id: DTP-002
        deployment_model:
          deployment_model_name: Desktop
          os: Windows 10
          host_firewall: Windows Firewall
          endpoint_antivirus: Windows Defender
          endpoint_detection_response: Cortex XDR
          endpoint_data_leakage_protection: Disabled
          Windows_gpo_policy: Enabled
          trusted_platform_module_status: Enabled
          secure_boot_status: Enabled
      from_ArchitectureModel:
        architecture_model_id: AML-001
        architecture_model_category: AccessLayer
        architecture_model: Client
        tool_licensing_model:
        tool:
          tool_name: Core Banking Thick Client
          software_runas: Normal Account
  - cmpid: CMP-006
    cmpname: Remote Desktop Service Instance in Corebanking Client (MS-DMZ)
    svcint_id: SIN-002
    inherited_properties:
      from_ServiceInstance:
        svcint_id: SIN-002
        svcintname: Remote Desktop Service Instance
        svcid: SVC-002
        ipc_authentication_methods: N/A
        ipc_authorization_methods: N/A
        sast_status: Passed
        dast_status: Passed
        parameterized_queries_status: N/A
        input_validation_methods: TypeChecking
        output_encoding_contexts: N/A
        csrf_protection_mechanism: N/A
        race_condition_sync: N/A
      from_Service:
        svcid: SVC-002
        svcname: Remote Desktop Service
        appid: ["APP-001", "APP-002"]
        architecture_model_id: AML-001
        authentication_methods: Local Account
        authorization_methods: Local Group
        encryption_in_transit_algorithms: ["TLS 1.2", "RSA", "AES", "SHA-2"]
        encryption_in_transit_key_strength: ["RSA2048", "AES_256_GCM", "SHA256"]
        encryption_at_rest_algorithms: N/A
        encryption_at_rest_key_strength: N/A
        logging_retention_days: N/A
        logging_cyber_detection_feed: SIEM
        listening_port: 3389
        listening_protocol: TCP
      from_Application:
        appid: APP-002
        appname: Corebanking Client (MS-DMZ)
        cmdb_sysid: SYS-001
        deployment_model_id: DTP-001
        location: Onprem_DC_SH
        security_environment: Prod
        security_domain: MSBIC_MDEX
        security_zone: ms-dmz
      from_System:
        cmdb_sysid: SYS-001
        sysname: Corebanking System
        description: Corebanking system with thick clients deployed in branches and data centers.
        information_sensetivity_classification: Highly Restricted
        asset_risk_ranking: P1
      from_DeploymentModel:
        deployment_model_id: DTP-001
        deployment_model:
          deployment_model_name: Virtual Machine
          hypervisor_os: ESXi 7.0
          guest_os: Windows Server 2019
          vm_escape_protection: Enabled
          sec_baseline_golden_image: Enabled
          trusted_platform_module_status: Enabled
          secure_boot_status: Enabled
      from_ArchitectureModel:
        architecture_model_id: AML-001
        architecture_model_category: AccessLayer
        architecture_model: Client
        tool_licensing_model:
        tool:
          tool_name: Core Banking Thick Client
          software_runas: Normal Account
  - cmpid: CMP-007
    cmpname: Corebanking Backend Service Instance - Counter in Corebanking Service
    svcint_id: SIN-004
    inherited_properties:
      from_ServiceInstance:
        svcint_id: SIN-004
        svcintname: Corebanking Backend Service Instance - Counter
        svcid: SVC-003
        ipc_authentication_methods: N/A
        ipc_authorization_methods: N/A
        sast_status: N/A
        dast_status: N/A
        parameterized_queries_status: N/A
        input_validation_methods: N/A
        output_encoding_contexts: N/A
        csrf_protection_mechanism: N/A
        race_condition_sync: N/A
      from_Service:
        svcid: SVC-003
        svcname: Corebanking Backend Service
        appid: APP-003
        architecture_model_id: AML-002
        authentication_methods: Corebanking Client Account
        authorization_methods: RBAC
        encryption_in_transit_algorithms: N/A
        encryption_in_transit_key_strength: N/A
        encryption_at_rest_algorithms: N/A
        encryption_at_rest_key_strength: N/A
        logging_retention_days: N/A
        logging_cyber_detection_feed: N/A
        listening_port: [7012, 3022, 5022, 8099, 9112, 9004, 7032]
        listening_protocol: TCP
      from_Application:
        appid: APP-003
        appname: Corebanking Service
        cmdb_sysid: SYS-001
        deployment_model_id: DTP-003
        location: Cloud_Other
        security_environment: Prod
        security_domain: MSBIC_MDEX
        security_zone: external
      from_System:
        cmdb_sysid: SYS-001
        sysname: Corebanking System
        description: Corebanking system with thick clients deployed in branches and data centers.
        information_sensetivity_classification: Highly Restricted
        asset_risk_ranking: P1
      from_DeploymentModel:
        deployment_model_id: DTP-003
        deployment_model:
          deployment_model_name: External Service
          external_service_resource: ["https://report.smartensemble.com:5020"]
          trusted_platform_module_status: N/A
          secure_boot_status: N/A
      from_ArchitectureModel:
        architecture_model_id: AML-002
        architecture_model_category: ApplicationLayer
        architecture_model: Application Service
        tool_licensing_model:
        tool:
          tool_name: Core Banking
          console_access_control: Enabled
  - cmpid: CMP-008
    cmpname: Corebanking Backend Service Instance - Reporter in Corebanking Service
    svcint_id: SIN-005
    inherited_properties:
      from_ServiceInstance:
        svcint_id: SIN-005
        svcintname: Corebanking Backend Service Instance - Reporter
        svcid: SVC-003
        ipc_authentication_methods: N/A
        ipc_authorization_methods: N/A
        sast_status: N/A
        dast_status: N/A
        parameterized_queries_status: N/A
        input_validation_methods: N/A
        output_encoding_contexts: N/A
        csrf_protection_mechanism: N/A
        race_condition_sync: N/A
      from_Service:
        svcid: SVC-003
        svcname: Corebanking Backend Service
        appid: APP-003
        architecture_model_id: AML-002
        authentication_methods: Corebanking Client Account
        authorization_methods: RBAC
        encryption_in_transit_algorithms: N/A
        encryption_in_transit_key_strength: N/A
        encryption_at_rest_algorithms: N/A
        encryption_at_rest_key_strength: N/A
        logging_retention_days: N/A
        logging_cyber_detection_feed: N/A
        listening_port: [7012, 3022, 5022, 8099, 9112, 9004, 7032]
        listening_protocol: TCP
      from_Application:
        appid: APP-003
        appname: Corebanking Service
        cmdb_sysid: SYS-001
        deployment_model_id: DTP-003
        location: Cloud_Other
        security_environment: Prod
        security_domain: MSBIC_MDEX
        security_zone: external
      from_System:
        cmdb_sysid: SYS-001
        sysname: Corebanking System
        description: Corebanking system with thick clients deployed in branches and data centers.
        information_sensetivity_classification: Highly Restricted
        asset_risk_ranking: P1
      from_DeploymentModel:
        deployment_model_id: DTP-003
        deployment_model:
          deployment_model_name: External Service
          external_service_resource: ["https://report.smartensemble.com:5020"]
          trusted_platform_module_status: N/A
          secure_boot_status: N/A
      from_ArchitectureModel:
        architecture_model_id: AML-002
        architecture_model_category: ApplicationLayer
        architecture_model: Application Service
        tool_licensing_model:
        tool:
          tool_name: Core Banking
          console_access_control: Enabled
  - cmpid: CMP-009
    cmpname: Corebanking Backend Service Instance - Operation Management in Corebanking Service
    svcint_id: SIN-006
    inherited_properties:
      from_ServiceInstance:
        svcint_id: SIN-006
        svcintname: Corebanking Backend Service Instance - Operation Management
        svcid: SVC-003
        ipc_authentication_methods: N/A
        ipc_authorization_methods: N/A
        sast_status: N/A
        dast_status: N/A
        parameterized_queries_status: N/A
        input_validation_methods: N/A
        output_encoding_contexts: N/A
        csrf_protection_mechanism: N/A
        race_condition_sync: N/A
      from_Service:
        svcid: SVC-003
        svcname: Corebanking Backend Service
        appid: APP-003
        architecture_model_id: AML-002
        authentication_methods: Corebanking Client Account
        authorization_methods: RBAC
        encryption_in_transit_algorithms: N/A
        encryption_in_transit_key_strength: N/A
        encryption_at_rest_algorithms: N/A
        encryption_at_rest_key_strength: N/A
        logging_retention_days: N/A
        logging_cyber_detection_feed: N/A
        listening_port: [7012, 3022, 5022, 8099, 9112, 9004, 7032]
        listening_protocol: TCP
      from_Application:
        appid: APP-003
        appname: Corebanking Service
        cmdb_sysid: SYS-001
        deployment_model_id: DTP-003
        location: Cloud_Other
        security_environment: Prod
        security_domain: MSBIC_MDEX
        security_zone: external
      from_System:
        cmdb_sysid: SYS-001
        sysname: Corebanking System
        description: Corebanking system with thick clients deployed in branches and data centers.
        information_sensetivity_classification: Highly Restricted
        asset_risk_ranking: P1
      from_DeploymentModel:
        deployment_model_id: DTP-003
        deployment_model:
          deployment_model_name: External Service
          external_service_resource: ["https://report.smartensemble.com:5020"]
          trusted_platform_module_status: N/A
          secure_boot_status: N/A
      from_ArchitectureModel:
        architecture_model_id: AML-002
        architecture_model_category: ApplicationLayer
        architecture_model: Application Service
        tool_licensing_model:
        tool:
          tool_name: Core Banking
          console_access_control: Enabled
  - cmpid: CMP-010
    cmpname: Corebanking Backend Service Instance - Endpoint Authorization in Corebanking Service
    svcint_id: SIN-007
    inherited_properties:
      from_ServiceInstance:
        svcint_id: SIN-007
        svcintname: Corebanking Backend Service Instance - Endpoint Authorization
        svcid: SVC-003
        ipc_authentication_methods: N/A
        ipc_authorization_methods: N/A
        sast_status: N/A
        dast_status: N/A
        parameterized_queries_status: N/A
        input_validation_methods: N/A
        output_encoding_contexts: N/A
        csrf_protection_mechanism: N/A
        race_condition_sync: N/A
      from_Service:
        svcid: SVC-003
        svcname: Corebanking Backend Service
        appid: APP-003
        architecture_model_id: AML-002
        authentication_methods: Corebanking Client Account
        authorization_methods: RBAC
        encryption_in_transit_algorithms: N/A
        encryption_in_transit_key_strength: N/A
        encryption_at_rest_algorithms: N/A
        encryption_at_rest_key_strength: N/A
        logging_retention_days: N/A
        logging_cyber_detection_feed: N/A
        listening_port: [7012, 3022, 5022, 8099, 9112, 9004, 7032]
        listening_protocol: TCP
      from_Application:
        appid: APP-003
        appname: Corebanking Service
        cmdb_sysid: SYS-001
        deployment_model_id: DTP-003
        location: Cloud_Other
        security_environment: Prod
        security_domain: MSBIC_MDEX
        security_zone: external
      from_System:
        cmdb_sysid: SYS-001
        sysname: Corebanking System
        description: Corebanking system with thick clients deployed in branches and data centers.
        information_sensetivity_classification: Highly Restricted
        asset_risk_ranking: P1
      from_DeploymentModel:
        deployment_model_id: DTP-003
        deployment_model:
          deployment_model_name: External Service
          external_service_resource: ["https://report.smartensemble.com:5020"]
          trusted_platform_module_status: N/A
          secure_boot_status: N/A
      from_ArchitectureModel:
        architecture_model_id: AML-002
        architecture_model_category: ApplicationLayer
        architecture_model: Application Service
        tool_licensing_model:
        tool:
          tool_name: Core Banking
          console_access_control: Enabled
  - cmpid: CMP-011
    cmpname: Corebanking Backend Service Instance - Judicial control in Corebanking Service
    svcint_id: SIN-008
    inherited_properties:
      from_ServiceInstance:
        svcint_id: SIN-008
        svcintname: Corebanking Backend Service Instance - Judicial control
        svcid: SVC-003
        ipc_authentication_methods: N/A
        ipc_authorization_methods: N/A
        sast_status: N/A
        dast_status: N/A
        parameterized_queries_status: N/A
        input_validation_methods: N/A
        output_encoding_contexts: N/A
        csrf_protection_mechanism: N/A
        race_condition_sync: N/A
      from_Service:
        svcid: SVC-003
        svcname: Corebanking Backend Service
        appid: APP-003
        architecture_model_id: AML-002
        authentication_methods: Corebanking Client Account
        authorization_methods: RBAC
        encryption_in_transit_algorithms: N/A
        encryption_in_transit_key_strength: N/A
        encryption_at_rest_algorithms: N/A
        encryption_at_rest_key_strength: N/A
        logging_retention_days: N/A
        logging_cyber_detection_feed: N/A
        listening_port: [7012, 3022, 5022, 8099, 9112, 9004, 7032]
        listening_protocol: TCP
      from_Application:
        appid: APP-003
        appname: Corebanking Service
        cmdb_sysid: SYS-001
        deployment_model_id: DTP-003
        location: Cloud_Other
        security_environment: Prod
        security_domain: MSBIC_MDEX
        security_zone: external
      from_System:
        cmdb_sysid: SYS-001
        sysname: Corebanking System
        description: Corebanking system with thick clients deployed in branches and data centers.
        information_sensetivity_classification: Highly Restricted
        asset_risk_ranking: P1
      from_DeploymentModel:
        deployment_model_id: DTP-003
        deployment_model:
          deployment_model_name: External Service
          external_service_resource: ["https://report.smartensemble.com:5020"]
          trusted_platform_module_status: N/A
          secure_boot_status: N/A
      from_ArchitectureModel:
        architecture_model_id: AML-002
        architecture_model_category: ApplicationLayer
        architecture_model: Application Service
        tool_licensing_model:
        tool:
          tool_name: Core Banking
          console_access_control: Enabled
  - cmpid: CMP-012
    cmpname: Corebanking Backend Service Instance - AntiMoney Landering in Corebanking Service
    svcint_id: SIN-009
    inherited_properties:
      from_ServiceInstance:
        svcint_id: SIN-009
        svcintname: Corebanking Backend Service Instance - AntiMoney Landering
        svcid: SVC-003
        ipc_authentication_methods: N/A
        ipc_authorization_methods: N/A
        sast_status: N/A
        dast_status: N/A
        parameterized_queries_status: N/A
        input_validation_methods: N/A
        output_encoding_contexts: N/A
        csrf_protection_mechanism: N/A
        race_condition_sync: N/A
      from_Service:
        svcid: SVC-003
        svcname: Corebanking Backend Service
        appid: APP-003
        architecture_model_id: AML-002
        authentication_methods: Corebanking Client Account
        authorization_methods: RBAC
        encryption_in_transit_algorithms: N/A
        encryption_in_transit_key_strength: N/A
        encryption_at_rest_algorithms: N/A
        encryption_at_rest_key_strength: N/A
        logging_retention_days: N/A
        logging_cyber_detection_feed: N/A
        listening_port: [7012, 3022, 5022, 8099, 9112, 9004, 7032]
        listening_protocol: TCP
      from_Application:
        appid: APP-003
        appname: Corebanking Service
        cmdb_sysid: SYS-001
        deployment_model_id: DTP-003
        location: Cloud_Other
        security_environment: Prod
        security_domain: MSBIC_MDEX
        security_zone: external
      from_System:
        cmdb_sysid: SYS-001
        sysname: Corebanking System
        description: Corebanking system with thick clients deployed in branches and data centers.
        information_sensetivity_classification: Highly Restricted
        asset_risk_ranking: P1
      from_DeploymentModel:
        deployment_model_id: DTP-003
        deployment_model:
          deployment_model_name: External Service
          external_service_resource: ["https://report.smartensemble.com:5020"]
          trusted_platform_module_status: N/A
          secure_boot_status: N/A
      from_ArchitectureModel:
        architecture_model_id: AML-002
        architecture_model_category: ApplicationLayer
        architecture_model: Application Service
        tool_licensing_model:
        tool:
          tool_name: Core Banking
          console_access_control: Enabled
```

#### Connection

```yaml
Connection:
  - conid: CON-001
    source_cmpid: CMP-001
    destination_cmpid: CMP-003
    connection_type_id: CTP-001
    inherited_properties:
      source_security_domain: MSBIC_MDEX
      source_security_zone: vanilla-dmz
      destination_security_domain: MSBIC_MDEX
      destination_security_zone: external
      destination_protocol: TCP
      destination_port: [7012, 3022, 5022, 8099, 9112, 9004, 7032]
      destination_authentication_methods: Corebanking Client Account
      destination_authorization_methods: RBAC
      destination_encryption_in_transit_algorithms: N/A
  - conid: CON-002
    source_cmpid: CMP-002
    destination_cmpid: CMP-003
    connection_type_id: CTP-001
    inherited_properties:
      source_security_domain: MSBIC_MDEX
      source_security_zone: ms-dmz
      destination_security_domain: MSBIC_MDEX
      destination_security_zone: external
      destination_protocol: TCP
      destination_port: [7012, 3022, 5022, 8099, 9112, 9004, 7032]
      destination_authentication_methods: Corebanking Client Account
      destination_authorization_methods: RBAC
      destination_encryption_in_transit_algorithms: N/A
  - conid: CON-003
    source_cmpid: CMP-004
    destination_cmpid: CMP-006
    connection_type_id: CTP-001
    inherited_properties:
      source_security_domain: MSBIC_OA
      source_security_zone: int-broa
      destination_security_domain: MSBIC_MDEX
      destination_security_zone: ms-dmz
      destination_protocol: TCP
      destination_port: 3389
      destination_authentication_methods: Local Account
      destination_authorization_methods: Local Group
      destination_encryption_in_transit_algorithms: ["TLS 1.2", "RSA", "AES", "SHA-2"]
  - conid: CON-004
    source_cmpid: CMP-005
    destination_cmpid: CMP-006
    connection_type_id: CTP-001
    inherited_properties:
      source_security_domain: COD_MSMS
      source_security_zone: branch-oa
      destination_security_domain: MSBIC_MDEX
      destination_security_zone: ms-dmz
      destination_protocol: TCP
      destination_port: 3389
      destination_authentication_methods: Local Account
      destination_authorization_methods: Local Group
      destination_encryption_in_transit_algorithms: ["TLS 1.2", "RSA", "AES", "SHA-2"]
  - conid: CON-005
    source_cmpid: CMP-012
    destination_cmpid: CMP-011
    connection_type_id: CTP-002
    inherited_properties:
      destination_ipc_authentication_methods: N/A
      destination_ipc_authorization_methods: N/A
      destination_race_condition_sync: N/A
  - conid: CON-006
    source_cmpid: CMP-010
    destination_cmpid: CMP-009
    connection_type_id: CTP-002
    inherited_properties:
      destination_ipc_authentication_methods: N/A
      destination_ipc_authorization_methods: N/A
      destination_race_condition_sync: N/A
  - conid: CON-007
    source_cmpid: CMP-012
    destination_cmpid: CMP-008
    connection_type_id: CTP-002
    inherited_properties:
      destination_ipc_authentication_methods: N/A
      destination_ipc_authorization_methods: N/A
      destination_race_condition_sync: N/A
```

#### Coupon

```yaml
Coupon:
  - coupon_id: CPN-001
    triggering_connection_id: CON-001
    coupon_type_id: CPT-001
    expiry: "Permanent"
    justification: "Auto-generated for network flow between different security zones (vanilla-dmz to external)."
    inherited_properties:
      from_CouponType:
        coupon_type_name: Firewall Flow
        source_security_domain: MSBIC_MDEX
        source_security_zone: vanilla-dmz
        destination_security_domain: MSBIC_MDEX
        destination_security_zone: external
        destination_protocol: TCP
        destination_port: [7012, 3022, 5022, 8099, 9112, 9004, 7032]
  - coupon_id: CPN-002
    triggering_connection_id: CON-002
    coupon_type_id: CPT-001
    expiry: "Permanent"
    justification: "Auto-generated for network flow between different security zones (ms-dmz to external)."
    inherited_properties:
      from_CouponType:
        coupon_type_name: Firewall Flow
        source_security_domain: MSBIC_MDEX
        source_security_zone: ms-dmz
        destination_security_domain: MSBIC_MDEX
        destination_security_zone: external
        destination_protocol: TCP
        destination_port: [7012, 3022, 5022, 8099, 9112, 9004, 7032]
  - coupon_id: CPN-003
    triggering_connection_id: CON-003
    coupon_type_id: CPT-001
    expiry: "Permanent"
    justification: "Auto-generated for network flow between different security zones (int-broa to ms-dmz)."
    inherited_properties:
      from_CouponType:
        coupon_type_name: Firewall Flow
        source_security_domain: MSBIC_OA
        source_security_zone: int-broa
        destination_security_domain: MSBIC_MDEX
        destination_security_zone: ms-dmz
        destination_protocol: TCP
        destination_port: 3389
  - coupon_id: CPN-004
    triggering_connection_id: CON-004
    coupon_type_id: CPT-001
    expiry: "Permanent"
    justification: "Auto-generated for network flow between different security zones (branch-oa to ms-dmz)."
    inherited_properties:
      from_CouponType:
        coupon_type_name: Firewall Flow
        source_security_domain: COD_MSMS
        source_security_zone: branch-oa
        destination_security_domain: MSBIC_MDEX
        destination_security_zone: ms-dmz
        destination_protocol: TCP
        destination_port: 3389
  - coupon_id: CPN-005
    triggering_connection_id: CON-001
    coupon_type_id: CPT-002
    expiry: "Permanent"
    justification: "Auto-generated for proxy flow policy triggered by network connection from vanilla-dmz to external."
    inherited_properties:
      from_CouponType:
        coupon_type_name: Proxy Flow
        source_security_domain: MSBIC_MDEX
        source_security_zone: vanilla-dmz
        destination_security_domain: MSBIC_MDEX
        destination_security_zone: external
        destination_external_service_resource: ["https://report.smartensemble.com:5020"]
        proxy_type: SOCKS
        proxy_ssli: Disabled
        proxy_auth: Non-Auth
  - coupon_id: CPN-006
    triggering_connection_id: CON-002
    coupon_type_id: CPT-002
    expiry: "Permanent"
    justification: "Auto-generated for proxy flow policy triggered by network connection from ms-dmz to external."
    inherited_properties:
      from_CouponType:
        coupon_type_name: Proxy Flow
        source_security_domain: MSBIC_MDEX
        source_security_zone: ms-dmz
        destination_security_domain: MSBIC_MDEX
        destination_security_zone: external
        destination_external_service_resource: ["https://report.smartensemble.com:5020"]
        proxy_type: SOCKS
        proxy_ssli: Disabled
        proxy_auth: Non-Auth
```

### 3.4 审计实体定义

#### SecurityFragment

```yaml
SecurityFragment:
  - fragment_id: SFR-001
    fragment_name: "Network flow to MDEX (scope)"
    target_entity: Connection
    fragment_description: "Reusable scope: any network communication (CTP-001) whose destination security domain is MSBIC_MDEX."
    condition:
      and:
        - attribute: "properties.connection_type_id"
          operator: "equals"
          value: "CTP-001"
        - attribute: "properties.destination_security_domain"
          operator: "equals"
          value: "MSBIC_MDEX"
```

#### SecurityBlueprint

```yaml
SecurityBlueprint:
  - blueprint_id: BLP-001
    blueprint_name: "MDEX RDP access control (COD identity)"
    rules:
      - rule_id: RUL-001
        rule_description: "Enforce COD identity-based authentication/authorization for RDP access to MDEX."
        target_entity: Connection
        definitions:
          - definition_id: DEF-001
            pre_condition:
              and:
                - security_fragment_ref: "SFR-001"
                - attribute: "properties.destination_port"
                  operator: "equals"
                  value: 3389
            SecurityCondition:
              or:
                - not:
                    attribute: "properties.destination_authentication_methods"
                    operator: "equals"
                    value: "Kerberos"
                - not:
                    attribute: "properties.destination_authorization_methods"
                    operator: "equals"
                    value: "AD Group"
            outcome:
              risk: High
              finding: "Detected RDP access to MDEX without Kerberos/AD Group controls on destination. (Current destination uses Local Account/Local Group)"
              requirement:
                - description: "Adopt COD AD group and IAM TAC to track and manage RDP authentication and authorization."
                  tech_control_id: "TEC-026"
                - description: "Onboard system entitlements into COD standard IGA (SailPoint)."
                  tech_control_id: "TEC-026"
  - blueprint_id: BLP-002
    blueprint_name: "Core banking binary reversing lab scan"
    rules:
      - rule_id: RUL-002
        rule_description: "Core banking software package must pass reversing lab/security scans."
        target_entity: ServiceInstance
        definitions:
          - definition_id: DEF-002
            pre_condition:
              and:
                - attribute: "properties.svcid"
                  operator: "equals"
                  value: "SVC-003"
            SecurityCondition:
              or:
                - not:
                    attribute: "properties.sast_status"
                    operator: "equals"
                    value: "Passed"
                - not:
                    attribute: "properties.dast_status"
                    operator: "equals"
                    value: "Passed"
            outcome:
              risk: High
              finding: "Core banking service instance has not passed reversing lab/security scans (SAST/DAST)."
              requirement:
                - description: "Core banking software package must pass reversing lab scan."
                  tech_control_id: "TEC-452"
  - blueprint_id: BLP-003
    blueprint_name: "MDEX segregation against lateral movement"
    rules:
      - rule_id: RUL-003
        rule_description: "Prevent lateral movement/crosstalk by enforcing segregation for intra-MDEX network flows."
        target_entity: Connection
        definitions:
          - definition_id: DEF-003
            pre_condition:
              and:
                - security_fragment_ref: "SFR-001"
                - attribute: "properties.source_security_domain"
                  operator: "equals"
                  value: "MSBIC_MDEX"
                - attribute: "properties.destination_security_domain"
                  operator: "equals"
                  value: "MSBIC_MDEX"
            SecurityCondition:
              or:
                - not:
                    attribute: "properties.source_security_zone"
                    operator: "equals"
                    value: "destination_security_zone"
            outcome:
              risk: High
              finding: "Potential intra-MDEX lateral movement: cross-zone network flow detected without explicit segregation evidence."
              requirement:
                - description: "Deploy dedicated VLAN and VLAN ACL on MDEX network switches."
                  tech_control_id: "TEC-162"
                - description: "Deploy leased line and IP address validation controls on MDEX network."
                  tech_control_id: "TEC-162"
```

#### ReviewFinding

```yaml
ReviewFinding:
  - finding_id: FIN-001
    triggered_blueprint_id: BLP-002
    triggered_rule_id: RUL-002
    triggered_definition_id: DEF-002
    violating_entity_type: ServiceInstance
    violating_entity_id: SIN-003
    violation_summary: "Core banking service instance has not passed reversing lab/security scans (SAST/DAST)."
    violating_condition_snapshot:
      or:
        - not:
            attribute: "properties.sast_status"
            operator: "equals"
            value: "Passed"
        - not:
            attribute: "properties.dast_status"
            operator: "equals"
            value: "Passed"
    risk: High
    requirement:
      - description: "Core banking software package must pass reversing lab scan."
        tech_control_id: "TEC-452"
    status: open
  - finding_id: FIN-002
    triggered_blueprint_id: BLP-003
    triggered_rule_id: RUL-003
    triggered_definition_id: DEF-003
    violating_entity_type: Connection
    violating_entity_id: CON-001
    violation_summary: "Intra-MDEX cross-zone flow detected (vanilla-dmz -> external). Segregation controls (VLAN ACL, IP validation) required."
    violating_condition_snapshot:
      security_fragment_ref: "SFR-001"
    risk: High
    requirement:
      - description: "Deploy dedicated VLAN and VLAN ACL on MDEX network switches."
        tech_control_id: "TEC-162"
      - description: "Deploy leased line and IP address validation on MDEX network."
        tech_control_id: "TEC-162"
    status: open
  - finding_id: FIN-003
    triggered_blueprint_id: BLP-001
    triggered_rule_id: RUL-001
    triggered_definition_id: DEF-001
    violating_entity_type: Connection
    violating_entity_id: CON-003
    violation_summary: "RDP access to MDEX without Kerberos/AD Group controls detected (destination uses Local Account/Local Group)."
    violating_condition_snapshot:
      or:
        - not:
            attribute: "properties.destination_authentication_methods"
            operator: "equals"
            value: "Kerberos"
        - not:
            attribute: "properties.destination_authorization_methods"
            operator: "equals"
            value: "AD Group"
    risk: High
    requirement:
      - description: "Adopt COD AD group and IAM TAC to track and manage RDP authentication and authorization."
        rule_instance_id: "TEC-026"
      - description: "Onboard system entitlements into COD standard IGA (SailPoint)."
        rule_instance_id: "TEC-026"
    status: open
```

### 3.5 UI视图模型对象实例定义

本章节展示了`Node`对象的具体实例。`Node`是一个非持久化的视图模型，其目的是为前端UI提供一个聚合的、易于渲染的数据结构。每个`Node`与一个`Application`一一对应，并展现了该应用下的所有`Component`信息。

```yaml
Node:
  - node_id: NOD-001
    node_name: Corebanking Client (Vanilla)
    appid: APP-001
    components:
      - cmpid: CMP-001
        cmpname: Corebanking Client Service Instance in Corebanking Client (Vanilla)
  - node_id: NOD-002
    node_name: Corebanking Client (MS-DMZ)
    appid: APP-002
    components:
      - cmpid: CMP-002
        cmpname: Corebanking Client Service Instance in Corebanking Client (MS-DMZ)
      - cmpid: CMP-006
        cmpname: Remote Desktop Service Instance in Corebanking Client (MS-DMZ)
  - node_id: NOD-003
    node_name: Corebanking Service
    appid: APP-003
    components:
      - cmpid: CMP-003
        cmpname: Corebanking Backend Service Instance - Core in Corebanking Service
      - cmpid: CMP-007
        cmpname: Corebanking Backend Service Instance - Counter in Corebanking Service
      - cmpid: CMP-008
        cmpname: Corebanking Backend Service Instance - Reporter in Corebanking Service
      - cmpid: CMP-009
        cmpname: Corebanking Backend Service Instance - Operation Management in Corebanking Service
      - cmpid: CMP-010
        cmpname: Corebanking Backend Service Instance - Endpoint Authorization in Corebanking Service
      - cmpid: CMP-011
        cmpname: Corebanking Backend Service Instance - Judicial control in Corebanking Service
      - cmpid: CMP-012
        cmpname: Corebanking Backend Service Instance - AntiMoney Landering in Corebanking Service
  - node_id: NOD-004
    node_name: MSBIC Branch OA Desktop
    appid: APP-004
    components:
      - cmpid: CMP-004
        cmpname: Remote Desktop Client Instance in MSBIC Branch OA Desktop
  - node_id: NOD-005
    node_name: MSMS Branch OA Desktop
    appid: APP-005
    components:
      - cmpid: CMP-005
        cmpname: Remote Desktop Client Instance in MSMS Branch OA Desktop
```

### 3.6 实例属性与关系总览

本章节通过一系列表格，对第三章中定义的所有核心实例及其关系进行摘要，以便快速查阅。对于`Component`、`Connection`、`Coupon`，本节仅展示它们与其他实体实例的继承与引用关系（外键/来源），不再展开聚合属性；对于`Node`，则详细列出其对应 `Application` 所包含的 `Component` 实例列表。

#### `System` 实例

| cmdb_sysid (PK) | sysname | description | information_sensetivity_classification | asset_risk_ranking |
| :--- | :--- | :--- | :--- | :--- |
| `SYS-001` | Corebanking System | Corebanking system with thick clients deployed in branches and data centers. | Highly Restricted | P1 |

#### `Application` 实例

| appid (PK) | appname | cmdb_sysid (FK) | deployment_model_id (FK) | location | security_environment | security_domain | security_zone |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `APP-001` | Corebanking Client (Vanilla) | `SYS-001` | `DTP-002` | Onprem_DC_SH | Prod | MSBIC_MDEX | vanilla-dmz |
| `APP-002` | Corebanking Client (MS-DMZ) | `SYS-001` | `DTP-001` | Onprem_DC_SH | Prod | MSBIC_MDEX | ms-dmz |
| `APP-003` | Corebanking Service | `SYS-001` | `DTP-003` | Cloud_Other | Prod | MSBIC_MDEX | external |
| `APP-004` | MSBIC Branch OA Desktop | `SYS-001` | `DTP-002` | Onprem_DC_SH | Prod | MSBIC_OA | int-broa |
| `APP-005` | MSMS Branch OA Desktop | `SYS-001` | `DTP-002` | Onprem_DC_SH | Prod | COD_MSMS | branch-oa |

#### `Service` 实例

| svcid (PK) | svcname | appid (FK) | architecture_model_id (FK) | authentication_methods | authorization_methods | listening_port | listening_protocol |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `SVC-001` | Corebanking Client Service | `["APP-001", "APP-002"]` | `AML-001` | Corebanking Client Account | RBAC | N/A | N/A |
| `SVC-002` | Remote Desktop Service | `["APP-002"]` | `AML-001` | Local Account | Local Group | 3389 | TCP |
| `SVC-003` | Corebanking Backend Service | `APP-003` | `AML-002` | Corebanking Client Account | RBAC | [7012, 3022, 5022, 8099, 9112, 9004, 7032] | TCP |
| `SVC-004` | Desktop RDP Client | `["APP-004", "APP-005"]` | `AML-001` | N/A | N/A | N/A | N/A |

#### `ServiceInstance` 实例

| svcint_id (PK) | svcintname | svcid (FK) | sast_status | dast_status | input_validation_methods |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `SIN-001` | Corebanking Client Service Instance | `SVC-001` | N/A | N/A | N/A |
| `SIN-002` | Remote Desktop Service Instance | `SVC-002` | Passed | Passed | TypeChecking |
| `SIN-003` | Corebanking Backend Service Instance - Core | `SVC-003` | N/A | N/A | N/A |
| `SIN-004` | Corebanking Backend Service Instance - Counter | `SVC-003` | N/A | N/A | N/A |
| `SIN-005` | Corebanking Backend Service Instance - Reporter | `SVC-003` | N/A | N/A | N/A |
| `SIN-006` | Corebanking Backend Service Instance - Operation Management | `SVC-003` | N/A | N/A | N/A |
| `SIN-007` | Corebanking Backend Service Instance - Endpoint Authorization | `SVC-003` | N/A | N/A | N/A |
| `SIN-008` | Corebanking Backend Service Instance - Judicial control | `SVC-003` | N/A | N/A | N/A |
| `SIN-009` | Corebanking Backend Service Instance - AntiMoney Landering | `SVC-003` | N/A | N/A | N/A |
| `SIN-010` | Remote Desktop Client Instance | `SVC-004` | Passed | Passed | TypeChecking |

#### `Component` 实例

| cmpid (PK) | cmpname | svcint_id (FK) | from_Service.svcid | from_Application.appid | from_System.cmdb_sysid | from_DeploymentModel.deployment_model_id | from_ArchitectureModel.architecture_model_id |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `CMP-001` | Corebanking Client Service Instance in Corebanking Client (Vanilla) | `SIN-001` | `SVC-001` | `APP-001` | `SYS-001` | `DTP-002` | `AML-001` |
| `CMP-002` | Corebanking Client Service Instance in Corebanking Client (MS-DMZ) | `SIN-001` | `SVC-001` | `APP-002` | `SYS-001` | `DTP-001` | `AML-001` |
| `CMP-003` | Corebanking Backend Service Instance - Core in Corebanking Service | `SIN-003` | `SVC-003` | `APP-003` | `SYS-001` | `DTP-003` | `AML-002` |
| `CMP-004` | Remote Desktop Client Instance in MSBIC Branch OA Desktop | `SIN-010` | `SVC-004` | `APP-004` | `SYS-001` | `DTP-002` | `AML-001` |
| `CMP-005` | Remote Desktop Client Instance in MSMS Branch OA Desktop | `SIN-010` | `SVC-004` | `APP-005` | `SYS-001` | `DTP-002` | `AML-001` |
| `CMP-006` | Remote Desktop Service Instance in Corebanking Client (MS-DMZ) | `SIN-002` | `SVC-002` | `APP-002` | `SYS-001` | `DTP-001` | `AML-001` |
| `CMP-007` | Corebanking Backend Service Instance - Counter in Corebanking Service | `SIN-004` | `SVC-003` | `APP-003` | `SYS-001` | `DTP-003` | `AML-002` |
| `CMP-008` | Corebanking Backend Service Instance - Reporter in Corebanking Service | `SIN-005` | `SVC-003` | `APP-003` | `SYS-001` | `DTP-003` | `AML-002` |
| `CMP-009` | Corebanking Backend Service Instance - Operation Management in Corebanking Service | `SIN-006` | `SVC-003` | `APP-003` | `SYS-001` | `DTP-003` | `AML-002` |
| `CMP-010` | Corebanking Backend Service Instance - Endpoint Authorization in Corebanking Service | `SIN-007` | `SVC-003` | `APP-003` | `SYS-001` | `DTP-003` | `AML-002` |
| `CMP-011` | Corebanking Backend Service Instance - Judicial control in Corebanking Service | `SIN-008` | `SVC-003` | `APP-003` | `SYS-001` | `DTP-003` | `AML-002` |
| `CMP-012` | Corebanking Backend Service Instance - AntiMoney Landering in Corebanking Service | `SIN-009` | `SVC-003` | `APP-003` | `SYS-001` | `DTP-003` | `AML-002` |

#### `Connection` 实例

| conid (PK) | source_cmpid (FK) | destination_cmpid (FK) | connection_type_id (FK) |
| :--- | :--- | :--- | :--- |
| `CON-001` | `CMP-001` | `CMP-003` | `CTP-001` |
| `CON-002` | `CMP-002` | `CMP-003` | `CTP-001` |
| `CON-003` | `CMP-004` | `CMP-006` | `CTP-001` |
| `CON-004` | `CMP-005` | `CMP-006` | `CTP-001` |
| `CON-005` | `CMP-012` | `CMP-011` | `CTP-002` |
| `CON-006` | `CMP-010` | `CMP-009` | `CTP-002` |
| `CON-007` | `CMP-012` | `CMP-008` | `CTP-002` |

#### `Coupon` 实例

| coupon_id (PK) | triggering_connection_id (FK) | coupon_type_id (FK) | source_cmpid (FK) | destination_cmpid (FK) | justification |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `CPN-001` | `CON-001` | `CPT-001` | `CMP-001` | `CMP-003` | Auto-generated for network flow between zones. |
| `CPN-002` | `CON-002` | `CPT-001` | `CMP-002` | `CMP-003` | Auto-generated for network flow between zones. |
| `CPN-003` | `CON-003` | `CPT-001` | `CMP-004` | `CMP-006` | Auto-generated for network flow between zones. |
| `CPN-004` | `CON-004` | `CPT-001` | `CMP-005` | `CMP-006` | Auto-generated for network flow between zones. |
| `CPN-005` | `CON-003` | `CPT-002` | `CMP-004` | `CMP-006` | Auto-generated for proxy flow policy. |
| `CPN-006` | `CON-004` | `CPT-002` | `CMP-005` | `CMP-006` | Auto-generated for proxy flow policy. |

#### `Node` 实例 (UI视图模型)

| node_id (PK) | node_name | appid (FK) | components (cmpids) |
| :--- | :--- | :--- | :--- |
| `NOD-001` | Corebanking Client (Vanilla) | `APP-001` | `[CMP-001]` |
| `NOD-002` | Corebanking Client (MS-DMZ) | `APP-002` | `[CMP-002, CMP-006]` |
| `NOD-003` | Corebanking Service | `APP-003` | `[CMP-003, CMP-007, CMP-008, CMP-009, CMP-010, CMP-011, CMP-012]` |
| `NOD-004` | MSBIC Branch OA Desktop | `APP-004` | `[CMP-004]` |
| `NOD-005` | MSMS Branch OA Desktop | `APP-005` | `[CMP-005]` |

### 3.7 架构总览与关键场景描述

#### 1. 总体架构概述

本设计描绘了一个名为 **Corebanking System (`SYS-001`)** 的核心业务系统。该系统被定为**高度受限 (Highly Restricted)**信息敏感等级和 **P1** 资产风险等级，这表明其所有相关的架构决策都必须以高安全标准为前提。系统采用混合部署模式，其组件分布在本地数据中心和外部云服务中。

#### 2. 应用系统分解与角色

整个系统被分解为五个逻辑应用 (`Application`)，每个应用都扮演着独特的角色：

- **核心银行后端服务 (`APP-003`)**: 这是系统的业务核心，作为一个逻辑上的**外部服务 (`DTP-003`)** 进行部署。它承载了所有核心业务模块，包括交易核心(`SIN-003`)、柜台(`SIN-004`)、报表(`SIN-005`)、反洗钱(`SIN-009`)等多个微服务实例。所有这些服务实例共同构成了后端复杂业务逻辑。

- **核心银行客户端 (MS-DMZ) (`APP-002`)**: 这是一个部署在数据中心`ms-dmz`安全区的**安全访问客户端**。它被部署为**虚拟机 (`DTP-001`)**，暗示了这是一个受到严格管控的、标准化的访问环境，需要通过安全跳转机或堡垒机访问的虚拟桌面。

- **核心银行客户端 (Vanilla) (`APP-001`)**: 这是一个部署在数据中心`vanilla-dmz`安全区的**普通客户端**。它直接部署在**桌面环境 (`DTP-002`)**，代表了另一种安全级别较低的访问模式。

- **办公桌面 (`APP-004`, `APP-005`)**: 这两个应用代表了来自不同安全域（`MSBIC_OA` 和 `COD_MSMS`）的终端用户环境。它们是所有访问流程的发起点，同样是**桌面环境 (`DTP-002`)**。用户需要从他们的终端桌面访问核心银行客户端，以此为跳板从而再进一步访问到核心银行后端服务。

#### 3. 关键数据流分析

通过`Connection`实例清晰地展现系统中的几种关键交互数据流：

- **核心业务访问流 (`CON-001`, `CON-002`)**: 这两条连接描述了两种客户端（`CMP-001` 和 `CMP-002`）访问后端核心服务 (`CMP-003`) 的路径。这是一个典型的客户端-服务器网络通信，使用TCP协议访问后端定义的一系列端口（7012, 3022等），并采用"核心银行客户端账户"进行认证。

- **安全远程访问流 (`CON-003`, `CON-004`)**: 这两条连接是整个架构的关键。它们描绘了终端用户（`CMP-004`, `CMP-005`）如何访问`ms-dmz`区的安全客户端 (`CMP-006`)。此访问通过 **TCP/3389 (RDP)** 协议进行。当前样例中，`CON-003` 的目的端采用 **Local Account/Local Group** 控制（因此触发 `FIN-003`），而非 Kerberos/AD Group。

- **后端进程间通信(IPC)流 (`CON-005`, `CON-006`, `CON-007`)**: 这三条连接非常特殊，它们的类型是`Inter-Process Communication`。这表明它们不是网络连接，而是发生在`APP-003`应用内部不同服务模块之间的本地通信。例如，反洗钱模块(`CMP-012`)会与司法管控模块(`CMP-011`)和报表模块(`CMP-008`)进行直接的进程间数据交换。

#### 4. 安全策略与自动化凭证

通过`Coupon`实例展示系统的自动化治理逻辑，即特定的连接会自动触发相应的安全策略凭证：

- **防火墙策略 (`CPN-001` 至 `CPN-004`)**: 所有跨越了不同安全区（如`vanilla-dmz` -> `external`, `int-broa` -> `ms-dmz`）的网络连接，都无一例外地自动生成了**防火墙流 (`CPT-001`)**凭证。这些凭证构成了需要网络安全团队审批和配置的防火墙规则集。
- **代理策略 (`CPN-005`, `CPN-006`)**: 核心业务访问流（`CON-001`, `CON-002`）不仅触发了防火墙凭证，还**额外触发了代理流 (`CPT-002`)**凭证。这揭示了一个更深层次的安全设计：从数据中心的核心银行客户端到`external`核心银行后端服务的连接，**需要通过一个SOCKS代理**进行额外的安全控制。

此外，本系统设计在审核后触发了三条 ReviewFinding：`FIN-001`（扫描未通过）、`FIN-002`（MDEX 跨区东西向流）与 `FIN-003`（MDEX RDP 目的端控制缺失）。

#### 5. 已发现的风险

1. Unauthenticated and unauthorized user to access the MDEX servers and core-banking application  
   Enable authn and authz for user to user COD identity to RDP login the MDEX sever:  

   - Adopt COD AD group and IAM's TAC control to track and manage user authn and authz who need to RDP login 
   - Entitlements of the system must be managed under adopt COD access management process and therefore onboard to COD standard IGA (Sailpoint)  

   TEC-026

2. Malware, vulnerability or other security issue in core-banking software binary  

   Passing reversing lab scan of core-banking software package  

   TEC-452

3. Lateral movement / unsolicited network traffic or cross-talk due to inadequate network segregation on core-banking server from other server  
   Segregation with other server installed on MSBIC MDEX:

   - Dedicated vlan and vlan ACL to be deployed on MDEX network swtiches  
   - Leased line and IP address validation to be deployed on MDEX network 

   TEC-162

---

## 4. 属性模式定义

### 4.1. 上下文实体模式 (Context Entity Schemas)

这些实体构成了架构的上下文。它们的属性定义了其在架构中的具体角色和配置。

#### `System`

**固有属性 (Inherent Properties)**

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | :--- |
| `cmdb_sysid` | 记录在CMDB系统中的本系统的唯一标识符 (PK)。 | `string` | - |
| `sysname` | 系统的可读名称。 | `string` | - |
| `description` | 对系统的详细描述。 | `string` | - |
| `information_sensetivity_classification` | 定义资产或系统的信息敏感度分类。 | `string` | Enum: `Public`, `Confidential`, `Highly Restricted` |
| `asset_risk_ranking` | 定义资产或系统的业务风险等级。 | `string` | Enum: `P1`, `P2`, `P3`, `P4` |

*此实体没有定义特殊属性。*

---

#### `Application`

**固有属性 (Inherent Properties)**

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | :--- |
| `appid` | 应用的唯一标识符 (PK)。 | `string` | - |
| `appname` | 应用的可读名称。 | `string` | - |
| `cmdb_sysid` | 所属系统的外键 (FK)。 | `string` | 关联至 `System` |
| `deployment_model_id` | 部署类型的外键 (FK)，作为类型选择器。 | `string` | 关联至 `DeploymentModel` |
| `location` | 应用部署的物理或逻辑位置。 | `string` | Enum: `Office`, `Onprem_DC_SH`, `Onprem_DC_BJ`, `Cloud_AWS`, `Cloud_Azure`, `Cloud_Other` |
| `security_environment` | 应用部署的环境类型。 | `string` | Enum: `Prod`, `AppDev`, `InfraDev` |
| `security_domain` | 应用所属的安全域。 | `string` | Enum: `COD_MSMS`, `MSBIC_OA`, `MSBIC_MDEX` |
| `security_zone` | 应用所在的更具体的网络安全区。 | `string` | Enum: `ms-dmz`, `vanilla-dmz`, `ms-dmznonprod`, `int-broa`, `external`, `branch-oa`, `mdex_ad` |

*此实体没有定义特殊属性。*

---

#### `Service`

**固有属性 (Inherent Properties)**

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | :--- |
| `svcid` | 服务的唯一标识符 (PK)。 | `string` | - |
| `svcname` | 服务的可读名称。 | `string` | - |
| `appid` | 所属应用的外键 (FK)。 | `Array` | 关联至单个或多个 `Application` |
| `architecture_model_id` | 架构层类型的外键 (FK)，作为类型选择器。 | `string` | 关联至 `ArchitectureModel` |
| `authentication_methods` | 支持的身份验证方法列表。 | `string | array<string>` | 推荐值：`Kerberos`, `OIDC/OAuth2`, `HTTP_Digest` |
| `authorization_methods` | 支持的授权机制列表。 | `string | array<string>` | 推荐值：`RBAC`, `ABAC` |
| `encryption_in_transit_algorithms` | 允许传输中网络流量的加密算法。 | `array` | - |
| `encryption_in_transit_key_strength` | 传输中网络流量加密所要求的最小密钥强度（以位为单位）。 | `integer` | - |
| `encryption_at_rest_algorithms` | 允许的静态加密算法列表。 | `array` | Enum: `AES`, `DES` |
| `encryption_at_rest_key_strength` | 静态加密所要求的最小密钥强度（以位为单位）。 | `integer` | - |
| `logging_retention_days` | 日志需要保留的最短天数。 | `integer` | - |
| `logging_cyber_detection_feed` | 将日志发送到什么网络安全检测系统。 | `string` | 建议值：`SIEM`, `SIEM Splunk`, `LaaS Loki`, `Syslog Server` |
| `listening_port` | 服务监听的端口号。 | `integer | array<integer>` | - |
| `listening_protocol` | 服务监听的协议类型。 | `string` | Enum: `TCP`, `UDP`, `ICMP`, `ESP` |

*此实体没有定义特殊属性。*

---

#### `ServiceInstance`

**固有属性 (Inherent Properties)**

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | :--- |
| `svcint_id` | 服务实例的唯一标识符 (PK)。 | `string` | - |
| `svcintname` | 服务实例的可读名称。 | `string` | - |
| `svcid` | 所属服务的外键 (FK)。 | `string` | 关联至 `Service` |
| `ipc_authentication_methods` | 进程间通信支持的身份验证方法列表。 | `array` | Enum: `PIPE`, `Socket`, `Shared_Memory`, `Signal`, `Queue` |
| `ipc_authorization_methods` | 进程间通信支持的授权机制列表。 | `array` | Enum: `ACL`, `MAC` |
| `sast_status` | 静态应用安全测试(SAST)的最新扫描结果。 | `string` | Enum: `Passed`, `Failed`, `Not Scanned` |
| `dast_status` | 动态应用安全测试(DAST)的最新扫描结果。 | `string` | Enum: `Passed`, `Failed`, `Not Scanned` |
| `parameterized_queries_status` | 是否要求此实例在与数据库交互时使用参数化查询。 | `string` | Enum: `Enabled`, `Disabled` |
| `input_validation_methods` | 此实例采用的输入验证方法列表。 | `array` | Enum: `TypeChecking`, `LengthValidation`, `RangeValidation`, `PatternMatching (Regex)`, `AllowlistValidation` |
| `output_encoding_contexts` | 此实例在将数据显示给用户时使用的输出编码上下文。 | `array` | Enum: `HTMLBody`, `HTMLAttribute`, `JavaScript`, `URL`, `CSS` |
| `csrf_protection_mechanism` | 采用的跨站请求伪造(CSRF)保护机制。 | `string` | Enum: `Token-Based`, `SameSite-Strict-Cookies`, `Header-Check`, `None` |
| `race_condition_sync` | 用于防止竞争条件的同步机制。 | `string` | Enum: `Mutex`, `Semaphore`, `File Lock` |

*此实体没有定义特殊属性。*

---

### 4.2. 物化实体模式 (Materialized Entity Schemas)

#### `Component`

**固有属性 (Inherent Properties)**

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | :--- |
| `cmpid` | 组件的唯一标识符 (PK)。 | `string` | - |
| `cmpname` | 组件的可读名称。 | `string` | - |
| `svcint_id` | 对应服务实例的外键 (FK)。 | `string` | 关联至 `ServiceInstance` |

*此实体没有在架构层面定义任何自身的特殊属性。其`properties`字段完全由系统通过聚合父级上下文实体和字典实体的属性来动态填充。*

---

#### `Connection`

**固有属性 (Inherent Properties)**

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | :--- |
| `conid` | 连接的唯一标识符 (PK)。 | `string` | - |
| `source_cmpid` | 源组件的外键 (FK)。 | `string` | 关联至 `Component` |
| `destination_cmpid` | 目标组件的外键 (FK)。 | `string` | 关联至 `Component` |
| `connection_type_id` | 连接类型的外键 (FK)。 | `string` | 关联至 `ConnectionType` |
| `description` | 对此连接用途的可读描述。 | `string` | - |

*此实体的 `properties` 字段是一个动态聚合的物化视图，其具体的结构和数据来源，由其关联的 `ConnectionType` 中定义的模式决定。*

---

#### `Coupon`

**固有属性 (Inherent Properties)**

| 属性 (Attribute)           | 描述 (Description)          | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :------------------------- | :-------------------------- | :---------- | -------------------------------------------- |
| `coupon_id`                | 凭证的唯一标识符 (PK)。     | `string`    | -                                            |
| `triggering_connection_id` | 触发此凭证的连接外键 (FK)。 | `string`    | 关联至 `Connection`                          |
| `source_cmpid`             | 源组件的外键 (FK)。         | `string`    | 关联至 `Component`                           |
| `destination_cmpid`        | 目标组件的外键 (FK)。       | `string`    | 关联至 `Component`                           |
| `coupon_type_id`           | 凭证类型的外键 (FK)。       | `string`    | 关联至 `CouponType`                          |
| `expiry`                   | 凭证的到期时间。            | `string`    | Enum: `Permanent` or ISO 8601 Date           |
| `justification`            | 创建此凭证的理由。          | `string`    | -                                            |

*此实体的 `properties` 字段是一个静态的、不可变的，根据对应`connection`实体而生成的属性快照，其具体的结构和数据来源，由其关联的 `CouponType` 中定义的模式决定。*

---

### 4.3. 字典实体模式 (Dictionary Entity Schemas)

字典实体提供了标准化的、可复用的定义，是整个模型的可扩展性的基础。

#### `DeploymentModel`

**固有属性 (Inherent Properties)**

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | :--- |
| `deployment_model_id` | 部署类型的唯一标识符 (PK)。 | `string` | - |
| `deployment_model` | 部署类型的名称，作为类型选择器。 | `string` | - |
| `deployment_model_name` | 部署类型的名称，作为类型选择器。 | `string` | Enum: `Host/Bare Metal Server`, `Virtual Machine`, `Container`, `Serverless`, `External Service`, `Device/Applicance`, `Desktop`, `Mobile` |
| `trusted_platform_module_status` | 可信平台模块(TPM)。 | `string` | Enum: `Enabled`, `Disabled`, `N/A` |
| `secure_boot_status` | 安全启动。 | `string` | Enum: `Enabled`, `Disabled`, `N/A` |

**特殊属性 (Specific Properties)**

***当 `deployment_model_name: Virtual Machine`***

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | :--- |
| `hypervisor_os` | Hypervisor的系统。 | `string` | Enum: `KVM`, `ESXi`, `Hyper-V` |
| `guest_os` | 虚拟机的客户操作系统。 | `string` | Enum: `RHEL 9`, `Windows 11`, `Windows Server 2024` |
| `vm_escape_protection` | 是否部署了虚拟机逃逸保护机制。 | `string` | Enum: `Enabled`, `Disabled`, `N/A` |
| `sec_baseline_golden_image` | 是否基于安全黄金镜像部署。 | `string` | Enum: `Enabled`, `Disabled`, `N/A` |

***当 `deployment_model_name: Host/Bare Metal Server`***

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | :--- |
| `host_os` | 物理机的客户操作系统。 | `string` | Enum: `RHEL 9`, `Windows 11`, `Windows Server 2024` |
| `sec_baseline_golden_image` | 是否基于安全黄金镜像部署。 | `string` | Enum: `Enabled`, `Disabled`, `N/A` |

***当 `deployment_model_name: External Service`***

| 属性 (Attribute)            | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :-------------------------- | :----------------- | :---------- | :------------------------------------------- |
| `external_service_resource` | 外部服务资源。     | `string`    | -                                            |

***当 `deployment_model_name: Desktop`***

| 属性 (Attribute)                   | 描述 (Description)   | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--------------------------------- | :------------------- | :---------- | :------------------------------------------- |
| `os`                               | 操作系统。           | `string`    | Enum: `Windows 10`                           |
| `host_firewall`                    | 主机防火墙（建议值）。 | `string`    | 示例：`Windows Firewall`, `UFW`, `N/A`        |
| `endpoint_antivirus`               | 终端杀毒软件（建议值）。 | `string`    | 示例：`Windows Defender`, `CrowdStrike`, `N/A` |
| `endpoint_detection_response`      | 终端威胁检测与响应（建议值）。 | `string`    | 示例：`Cortex XDR`, `Microsoft Defender for Endpoint`, `N/A` |
| `endpoint_data_leakage_protection` | 终端数据泄漏保护（建议值）。 | `string`    | 示例：`Symantec DLP`, `N/A`                  |
| `domain_gpo_policy`                | 终端域组策略。       | `string`    | Enum: `Enabled`, `Disabled`, `N/A`           |

---

#### `ArchitectureModel`

**固有属性 (Inherent Properties)**

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | :--- |
| `architecture_model_id` | 架构层类型的唯一标识符 (PK)。 | `string` | - |
| `architecture_model_category` | 架构层的分类。 | `string` | Enum: `AccessLayer`, `ApplicationLayer`, `DataLayer` |
| `architecture_model` | 架构层的名称，作为类型选择器。 | `string` | Enum: `Gateway`, `Application Server`, `Relational Database`, `Cache`, `Message Queue`, `Client` |
| `tool_licensing_model` | 实现该架构层角色的工具的授权许可模式。 | `string` | Enum: `Open Source`, `Proprietary` |
| `tool` | 实现该架构层角色的工具名称。 | `string` | - |
| `tool_name` | 实现该架构层角色的工具名称。 | `string` | Enum: `Nginx`, `WebLogic`, `Redis`, `Oracle` |

**特殊属性 (Specific Properties)**

***当 `tool_name: Nginx`***

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | :--- |
| `reverse_proxy_access_control` | 反向代理的访问控制。 | `string` | Enum: `Enabled`, `Disabled`, `N/A` |

***当 `tool_name: WebLogic`***

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | :--- |
| `console_access_control` | WebLogic 控制台访问控制。 | `string` | Enum: `Enabled`, `Disabled`, `N/A` |

***当 `tool_name: Redis`***

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | :--- |
| `dangerous_cmd_protection` | Redis危险命令保护。 | `string` | Enum: `Replaced`, `Disabled`, `N/A` |

***当 `tool_name: Oracle`***

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | :--- |
| `licenser_limitation` | Oracle数据库监听器限制。 | `string` | Enum: `Enabled`, `Disabled`, `N/A` |

---

#### `ConnectionType`

**固有属性 (Inherent Properties)**

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | :--- |
| `connection_type_id` | 连接类型的唯一标识符 (PK)。 | `string` | - |
| `connection_type` | 连接类型的名称，作为类型选择器。 | `string` | - |
| `connection_type_name` | 连接类型的名称，作为类型选择器。 | `string` | Enum: `Network Communication`, `Inter-Process Communication` |

**特殊属性 (Specific Properties, from Connection's Aggregation Logic)**

定义了当一个 `Connection` 实体关联到此 `ConnectionType` 时，其 `properties` 字段应如何被动态聚合。

***当 `connection_type_name:  Network Communication`***

| 目标属性 (Target Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | ---- |
| `destination_port` | 连接的目标端口。 | - | 继承自`Connection.destination_cmpid.inherited_properties.from_Service.listening_port` 字段。 |
| `destination_protocol` | 连接使用的协议。 | - | 继承自`Connection.destination_cmpid.inherited_properties.from_Service.listening_protocol` 字段。 |
| `source_security_domain` | 连接源组件所属的安全域。 | - | 继承自`Connection.source_cmpid.inherited_properties.from_Application.security_domain` 字段。 |
| `source_security_zone` | 连接源组件所属的安全区。 | - | 继承自`Connection.source_cmpid.inherited_properties.from_Application.security_zone` 字段。 |
| `destination_security_domain` | 连接目标组件所属的安全域。 | - | 继承自`Connection.destination_cmpid.inherited_properties.from_Application.security_domain` 字段。 |
| `destination_security_zone` | 连接目标组件所属的安全区。 | - | 继承自`Connection.destination_cmpid.inherited_properties.from_Application.security_zone` 字段。 |
| `destination_authentication_methods` | 连接身份验证方式。 | - | 继承自`Connection.destination_cmpid.inherited_properties.from_Service.authentication_methods` 字段。 |
| `destination_authorization_methods` | 连接授权方式。 | - | 继承自`Connection.destination_cmpid.inherited_properties.from_Service.authorization_methods` 字段。 |
| `destination_encryption_in_transit_algorithms` | 连接传输中加密方式。 | - | 继承自`Connection.destination_cmpid.inherited_properties.from_Service.encryption_in_transit_algorithms` 字段。 |

***当 `connection_type_name: Inter-Process Communication`***

| 目标属性 (Target Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | ---- |
| `destination_ipc_authentication_methods` | 进程间通信使用的身份验证方法。 | - | 继承自`Connection.destination_cmpid.inherited_properties.from_ServiceInstance.ipc_authentication_methods` 字段。 |
| `destination_ipc_authorization_methods` | 进程间通信使用的授权方法。 | - | 继承自`Connection.destination_cmpid.inherited_properties.from_ServiceInstance.ipc_authorization_methods` 字段。 |
| `destination_race_condition_sync` | 进程间通信的竞争条件同步机制。 | - | 继承自`Connection.destination_cmpid.inherited_properties.from_ServiceInstance.race_condition_sync` 字段。 |

---

#### `CouponType`

**固有属性 (Inherent Properties)**

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | :--- |
| `coupon_type_id` | 凭证类型的唯一标识符 (PK)。 | `string` | - |
| `coupon_type` | 凭证类型的名称，作为类型选择器。 | `string` | - |
| `coupon_type_name` | 凭证类型的名称，作为类型选择器。 | `string` | Enum: `Firewall Flow`, `Proxy Flow` |

**特殊属性 (Defines Coupon's Snapshot Logic)**

定义了当一个 `Coupon` 实体关联到此 `CouponType` 时，其 `properties` 字段应如何被静态填充。

***当 `coupon_type_name: Firewall Flow`***

| 目标属性 (Target Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | ---- |
| `source_security_domain` | 源安全域。 | - | `Connection.properties.source_security_domain` |
| `source_security_zone` | 源安全区。 | - | `Connection.properties.source_security_zone` |
| `destination_security_domain` | 目标安全域。 | - | `Connection.properties.destination_security_domain` |
| `destination_security_zone` | 目标安全区。 | - | `Connection.properties.destination_security_zone` |
| `destination_protocol` | 连接协议。 | - | `Connection.properties.destination_protocol` |
| `destination_port` | 连接端口。 | - | `Connection.properties.destination_port` |

***当 `coupon_type_name: Proxy Flow`***

| 目标属性 (Target Attribute) | 描述 (Description) | 类型 (Type) | 约束 / 可选值 (Constraints / Allowed Values) |
| :--- | :--- | :--- | ---- |
| `destination_security_domain` | 目标安全域。 | - | `Connection.properties.destination_security_domain` |
| `destination_security_zone` | 目标安全区。 | - | `Connection.properties.destination_security_zone` |
| `destination_external_service_resource` | 目标外部服务的具体资源标识。 | - | 继承自 `Connection.destination_cmpid.inherited_properties.from_DeploymentModel.deployment_model.external_service_resource`。仅当目标组件的 `DeploymentModel` 为 `External Service` 时填充。 |
| `proxy_type` | 代理类型。 | `String` | Enum: `HTTP Proxy`, `SOCKS Proxy` |
| `proxy_ssli` | 代理SSLi。 | `String` | Enum: `Enabled`, `Disabled`, `N/A` |
| `proxy_auth` | 代理认证方式。 | `String` | Enum: `Auth`, `Non-Auth`, `N/A` |

---

### 4.4. 审计实体模式 (Review Entity Schemas)

这些实体是模型分析或工作流处理的结果，其结构相对固定，不采用动态的"特殊属性"模式，但可通过可嵌套的、包含and/or/not操作符的逻辑树结构来表示复杂的条件逻辑。

#### `SecurityFragment`

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) |
| :--- | :--- | :--- |
| `fragment_id` | 安全片段的唯一标识符 (PK)。 | `string` |
| `fragment_name` | 安全片段的可读名称。 | `string` |
| `target_entity` | 此片段的目标实体类型。 | `string` |
| `fragment_description` | 对该安全片段用途的详细描述。 | `string` |
| `condition` | 定义了可嵌套的、包含and/or/not操作符的逻辑树结构。 | `object` |

---

#### `SecurityBlueprint`

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) |
| :--- | :--- | :--- |
| `blueprint_id` | 蓝图的唯一标识符 (PK)。 | `string` |
| `blueprint_name` | 蓝图的可读名称。 | `string` |
| `rules` | 包含一个或多个rule对象的数组。 | `array` |
| `rules[].rule_id` | 规则的唯一标识符。 | `string` |
| `rules[].rule_description` | 对该规则安全目标的详细描述。 | `string` |
| `rules[].target_entity` | 规则的目标实体类型。 | `string` |
| `rules[].definitions` | 一个或多个"违规定义"对象的列表。 | `array` |
| `rules[].definitions[].definition_id` | 该违规定义的唯一ID。 | `string` |
| `rules[].definitions[].pre_condition` | 前置条件，用于筛选要检查的实体。 | `object` |
| `rules[].definitions[].SecurityCondition` | 安全条件，定义了具体的检查逻辑。 | `object` |
| `rules[].definitions[].outcome` | 当条件满足时，定义生成的`ReviewFinding`的内容。 | `object` |

---

#### `ReviewFinding`

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) |
| :--- | :--- | :--- |
| `finding_id` | 审查发现的唯一标识符 (PK)。 | `string` |
| `triggered_blueprint_id` | 触发此发现的蓝图ID (FK)。 | `string` |
| `triggered_rule_id` | 触发此发现的规则ID (FK)。 | `string` |
| `triggered_definition_id` | 触发此发现的具体违规定义ID。 | `string` |
| `violating_entity_type` | 违规实体的类型。 | `string` |
| `violating_entity_id` | 违规实体的ID (FK)。 | `string` |
| `violating_condition_snapshot` | 触发违规的`SecurityCondition`的结构化快照。 | `object` |
| `violation_summary` | 对人类友好的违规摘要。 | `string` |
| `risk` | 从outcome中继承的风险等级。 | `string` |
| `requirement` / `recommendation` | 从outcome中继承的修复要求或建议。 | `array` |
| `status` | 审查发现的当前状态。 | `string` |


---

### 4.5. UI视图模型模式 (UI View Model Schemas)

此部分定义了非持久化的、用于前端展示的视图模型。

#### `Node`

| 属性 (Attribute) | 描述 (Description) | 类型 (Type) |
| :--- | :--- | :--- |
| `node_id` | 节点的唯一标识符，通常基于应用ID生成。 | `string` |
| `node_name` | 节点的可读名称，继承自`Application.appname`。 | `string` |
| `appid` | 关联的`Application`的ID。 | `string` |
| `components` | 一个对象数组，列出了此节点包含的所有组件。 | `array` |
| `components[].cmpid` | 组件的唯一标识符。 | `string` |
| `components[].cmpname` | 组件的可读名称。 | `string` |

---

## 5. 实体生成逻辑

本章详细阐述CALM模型中各实体数据的生成逻辑。理解此流程的关键在于认识到：**第四部分"属性模式定义"是整个系统的基石和唯一事实来源(Single Source of Truth)**。它由模型管理员预先定义，规定了所有实体的数据结构、类型和可选值。所有后续的数据生成，无论是用户手动输入还是系统自动处理，都必须严格遵循第四部分定义的模式。

整个流程可分为三个主要阶段：

1.  **设计时输入 (Design-Time Input):** 用户在由第四部分模式严格约束的界面中，输入描述其架构设计的核心信息。
2.  **系统性物化 (Systemic Materialization):** 系统根据用户输入，自动进行属性聚合和关系派生，生成完整的、可供分析的"物化视图"。
3.  **自动化审计 (Automated Auditing):** 系统使用预定义的安全蓝图，对物化视图进行全面审计，并自动生成最终的审查发现。

---

### **5.1. 阶段一：设计时输入 (手动操作)**

此阶段，用户通过结构化界面(如Web表单)填写其设计方案。界面上的所有输入框、下拉菜单、复选框均由第四部分的模式动态生成。

#### **字典实体 (Dictionary Entities)**

这些实体是用户设计中可复用的"标准件"。用户须首先确保设计中将用到的全部标准均已在此定义。

*   **`DeploymentModel` (部署类型):**
    *   **目的:** 定义标准化的基础设施平台与部署模式。
*   **`ArchitectureModel` (架构层类型):**
    *   **目的:** 定义标准化的逻辑架构分层及其对应的技术栈。
*   **`ConnectionType` (连接类型):**
    *   **目的:** 为不同性质的交互方式提供分类标签。这是后续`Connection`属性自动生成的关键"选择器"。
*   **`CouponType` (凭证类型):**
    *   **目的:** 为系统自动生成的、可行动的"实施工单"提供分类。

#### **上下文实体 (Context Entities)**

用户通过填写这些实体，来描述其具体的设计蓝图。

*   **`System` (系统):**
    *   **目的:** 定义设计的最高层级容器，承载全局业务属性。
*   **`Application` (应用):**
    *   **目的:** 将系统分解为可独立部署的功能应用单元及其安全环境。
*   **`Service` (服务):**
    *   **目的:** 定义各应用提供的核心服务及其安全与服务契约。
*   **`ServiceInstance` (服务实例):**
    *   **目的:** 将服务进一步分解为最细粒度的功能模块，并描述其内部实现的安全状态。

#### **物化实体 (Materialized Entities)**

*   **`Connection` (连接 - 手动部分):**
    *   **目的:** 建立两个组件间的交互关系。用户需手动输入该实体中某些固有属性来确定两个组件之间的关系。

---

### **5.2. 阶段二：系统性物化 (系统自动操作)**

当用户完成上述所有信息的"填写"并提交后，CALM系统的自动化流程开始运行。

#### 物化实体 (Materialized Entities)

*   **`Component` (组件):**
    *   **目的:** 作为`ServiceInstance`在完整上下文中的最终体现，是属性聚合的核心，会自动继承父级上下文实体属性和字典实体属性。
*   **`Connection` (连接 - 自动部分):**
    *   **目的:** 建立两个组件间的交互关系。除上述手动输入的固有属性外，此实体还会根据`ConnectionType`动态派生对应的特殊属性，使其成为一个包含完整交互上下文的可分析实体。
*   **`Coupon` (凭证):**
    *   **目的:** 在审核流程完毕后，基于被触发的`Connection`实体生成可传递至下游系统执行的、标准化的"工单"快照。

#### **UI友好视图对象 (按需生成)**

*   **`Node` (节点):**
    *   **目的:** 为前端UI提供一个聚合的、易于渲染的数据结构对象。Node与Application层级一一对应，可以展现一个Application及其内部Components间的交互逻辑，或者多个Application的Components之间的交互逻辑。`Node`对象是**非持久化的**，可按需构建。

---

### **5.3. 阶段三：自动化审计 (系统自动操作)**

在所有`Component`和`Connection`的属性都已物化完成后，系统的审计和工单生成引擎启动。

*   **`SecurityFragment` 与 `SecurityBlueprint` (审核标准):**
    *   **目的:** 基于iDesigner BPM/SecBlue/Control Baseline而创建的CALM-based审核标准规则数据库及相应控制要求。
    
*   **`ReviewFinding` (审查发现):**
    *   **目的:** 记录设计中所有违反预定义安全蓝图的事件以及违反规则的属性来源。

---

### 5.4. 流程总览图

```mermaid
flowchart TD
  A[USER INPUT <br/><br/>System / Application / Service / ServiceInstance<br/>and Connection] --> B[MATERIALIZATION]
  subgraph B [MATERIALIZATION]
    B1[Base on ServiceInstance auto-generate Component<br/>Congregate properties <br/><br/>from_ServiceInstance / from_Service / from_Application / from_System / from_DeploymentModel / from_ArchitectureModel]
    B2[Base on Components and ConnectionType auto-generate Connection properties]
  end
  B1 --> B2
  B --> C[REVIEW]
  subgraph C [REVIEW]
    C1[SECURITYBLUEPRINT & SECURITYFRAGMENT <br/><br/>pre_condition filter <br/>scope<br/>]
    C2[definitions define <br/>rules]
    C3[Compare Component entities properties and SecurityBlueprint entities properties]
    C4[REVIEWFINDING <br/><br/>Auto-generate ReviewFinding]
  end
  B2 --> C1 --> C2 --> C3 --> C4
  C4 --> D[SYSTEM OUTPUT]
  D --> D1[Coupon Snapshots<br/>（FW flow/Proxy flow）]
  D --> D2[Risk Findings<br/>]
```

### 5.5. Security Blueprint Authoring Pipeline

为支持大规模安全策略转换为 CALM，我们采用三层流水线：

1. **语言解析层**：使用人工/LLM 辅助把人类语言策略拆解为结构化片段（目标实体、条件、风险、控制要求），并由安全专家复核。
2. **中间配置层**：将结构化片段写入统一的 YAML/JSON（或 CSV）格式，仅包含 `entity`、`condition`、`risk`、`requirement` 等核心字段，并引用公司控制词典，方便批量维护与版本管理。
3. **CALM 生成层**：由脚本读取中间配置，自动生成 CALM `SecurityFragment` 与 `SecurityBlueprint`，同时注入 ReviewFinding 模板。这样既能快速扩充蓝图库，又能确保输出遵循本章定义的实体结构。

通过该分层模式，策略作者只需专注于语言解析与配置层，转换器负责与 CALM 模型对齐，实现可追溯、可重复的大规模蓝图生成。

---

## 附录1：第三章实体实例（JSON 版）

本附录为第3章中各实体实例的等价 JSON 表达，仅用于程序化消费。第3章原有的 YAML 内容保持不变。

### 1：字典实体

#### DeploymentModel（JSON）

```json
{
  "DeploymentModel": [
    {
      "deployment_model_id": "DTP-001",
      "deployment_model": {
        "deployment_model_name": "Virtual Machine",
        "hypervisor_os": "ESXi 7.0",
        "guest_os": "Windows Server 2019",
        "vm_escape_protection": "Enabled",
        "sec_baseline_golden_image": "Enabled",
        "trusted_platform_module_status": "Enabled",
        "secure_boot_status": "Enabled"
      }
    },
    {
      "deployment_model_id": "DTP-002",
      "deployment_model": {
        "deployment_model_name": "Desktop",
        "os": "Windows 10",
        "host_firewall": "Windows Firewall",
        "endpoint_antivirus": "Windows Defender",
        "endpoint_detection_response": "Cortex XDR",
        "endpoint_data_leakage_protection": "Disabled",
        "Windows_gpo_policy": "Enabled",
        "trusted_platform_module_status": "Enabled",
        "secure_boot_status": "Enabled"
      }
    },
    {
      "deployment_model_id": "DTP-003",
      "deployment_model": {
        "deployment_model_name": "External Service",
        "external_service_resource": [
          "https://report.smartensemble.com:5020"
        ],
        "trusted_platform_module_status": "N/A",
        "secure_boot_status": "N/A"
      }
    }
  ]
}
```

#### ArchitectureModel（JSON）

```json
{
  "ArchitectureModel": [
    {
      "architecture_model_id": "AML-001",
      "architecture_model_category": "AccessLayer",
      "architecture_model": "Client",
      "tool_licensing_model": null,
      "tool": {
        "tool_name": "Core Banking Thick Client",
        "software_runas": "Normal Account"
      }
    },
    {
      "architecture_model_id": "AML-002",
      "architecture_model_category": "ApplicationLayer",
      "architecture_model": "Application Service",
      "tool_licensing_model": null,
      "tool": {
        "tool_name": "Core Banking",
        "console_access_control": "Enabled"
      }
    }
  ]
}
```

#### ConnectionType（JSON）

```json
{
  "ConnectionType": [
    {
      "connection_type_id": "CTP-001",
      "connection_type": {
        "connection_type_name": "Network Communication",
        "source_security_domain": "Connection.source_cmpid.inherited_properties.from_Application.security_domain",
        "source_security_zone": "Connection.source_cmpid.inherited_properties.from_Application.security_zone",
        "destination_security_domain": "Connection.destination_cmpid.inherited_properties.from_Application.security_domain",
        "destination_security_zone": "Connection.destination_cmpid.inherited_properties.from_Application.security_zone",
        "destination_protocol": "Connection.destination_cmpid.inherited_properties.from_Service.listening_protocol",
        "destination_port": "Connection.destination_cmpid.inherited_properties.from_Service.listening_port",
        "destination_authentication_methods": "Connection.destination_cmpid.inherited_properties.from_Service.authentication_methods",
        "destination_authorization_methods": "Connection.destination_cmpid.inherited_properties.from_Service.authorization_methods",
        "destination_encryption_in_transit_algorithms": "Connection.destination_cmpid.inherited_properties.from_Service.encryption_in_transit_algorithms"
      }
    },
    {
      "connection_type_id": "CTP-002",
      "connection_type": {
        "connection_type_name": "Inter-Process Communication",
        "destination_ipc_authentication_methods": "Connection.destination_cmpid.inherited_properties.from_ServiceInstance.ipc_authentication_methods",
        "destination_ipc_authorization_methods": "Connection.destination_cmpid.inherited_properties.from_ServiceInstance.ipc_authorization_methods",
        "destination_race_condition_sync": "Connection.destination_cmpid.inherited_properties.from_ServiceInstance.race_condition_sync"
      }
    }
  ]
}
```

#### CouponType（JSON）

```json
{
  "CouponType": [
    {
      "coupon_type_id": "CPT-001",
      "coupon_type": {
        "coupon_type_name": "Firewall Flow",
        "source_security_domain": "Connection.source_cmpid.inherited_properties.from_Application.security_domain",
        "source_security_zone": "Connection.source_cmpid.inherited_properties.from_Application.security_zone",
        "destination_security_domain": "Connection.destination_cmpid.inherited_properties.from_Application.security_domain",
        "destination_security_zone": "Connection.destination_cmpid.inherited_properties.from_Application.security_zone",
        "destination_protocol": "Connection.destination_cmpid.inherited_properties.from_Service.listening_protocol",
        "destination_port": "Connection.destination_cmpid.inherited_properties.from_Service.listening_port"
      }
    },
    {
      "coupon_type_id": "CPT-002",
      "coupon_type": {
        "coupon_type_name": "Proxy Flow",
        "source_security_domain": "Connection.source_cmpid.inherited_properties.from_Application.security_domain",
        "source_security_zone": "Connection.source_cmpid.inherited_properties.from_Application.security_zone",
        "destination_security_domain": "Connection.destination_cmpid.inherited_properties.from_Application.security_domain",
        "destination_security_zone": "Connection.destination_cmpid.inherited_properties.from_Application.security_zone",
        "destination_external_service_resource": "Connection.destination_cmpid.inherited_properties.from_DeploymentModel.deployment_model.external_service_resource",
        "proxy_type": "SOCKS",
        "proxy_ssli": "Disabled",
        "proxy_auth": "Non-Auth"
      }
    }
  ]
}
```

### 2：上下文实体

#### System（JSON）

```json
{
  "System": [
    {
      "cmdb_sysid": "SYS-001",
      "sysname": "Corebanking System",
      "description": "Corebanking system with thick clients deployed in branches and data centers.",
      "information_sensetivity_classification": "Highly Restricted",
      "asset_risk_ranking": "P1"
    }
  ]
}
```

#### Application（JSON）

```json
{
  "Application": [
    {
      "appid": "APP-001",
      "appname": "Corebanking Client (Vanilla)",
      "cmdb_sysid": "SYS-001",
      "deployment_model_id": "DTP-002",
      "location": "Onprem_DC_SH",
      "security_environment": "Prod",
      "security_domain": "MSBIC_MDEX",
      "security_zone": "vanilla-dmz"
    },
    {
      "appid": "APP-002",
      "appname": "Corebanking Client (MS-DMZ)",
      "cmdb_sysid": "SYS-001",
      "deployment_model_id": "DTP-001",
      "location": "Onprem_DC_SH",
      "security_environment": "Prod",
      "security_domain": "MSBIC_MDEX",
      "security_zone": "ms-dmz"
    },
    {
      "appid": "APP-003",
      "appname": "Corebanking Service",
      "cmdb_sysid": "SYS-001",
      "deployment_model_id": "DTP-003",
      "location": "Cloud_Other",
      "security_environment": "Prod",
      "security_domain": "MSBIC_MDEX",
      "security_zone": "external"
    },
    {
      "appid": "APP-004",
      "appname": "MSBIC Branch OA Desktop",
      "cmdb_sysid": "SYS-001",
      "deployment_model_id": "DTP-002",
      "location": "Onprem_DC_SH",
      "security_environment": "Prod",
      "security_domain": "MSBIC_OA",
      "security_zone": "int-broa"
    },
    {
      "appid": "APP-005",
      "appname": "MSMS Branch OA Desktop",
      "cmdb_sysid": "SYS-001",
      "deployment_model_id": "DTP-002",
      "location": "Onprem_DC_SH",
      "security_environment": "Prod",
      "security_domain": "COD_MSMS",
      "security_zone": "branch-oa"
    }
  ]
}
```

#### Service（JSON）

```json
{
  "Service": [
    {
      "svcid": "SVC-001",
      "svcname": "Corebanking Client Service",
      "appid": ["APP-001", "APP-002"],
      "architecture_model_id": "AML-001",
      "authentication_methods": "Corebanking Client Account",
      "authorization_methods": "RBAC",
      "encryption_in_transit_algorithms": "N/A",
      "encryption_in_transit_key_strength": "N/A",
      "encryption_at_rest_algorithms": "N/A",
      "encryption_at_rest_key_strength": "N/A",
      "logging_retention_days": "N/A",
      "logging_cyber_detection_feed": "N/A",
      "listening_port": "N/A",
      "listening_protocol": "N/A"
    },
    {
      "svcid": "SVC-002",
      "svcname": "Remote Desktop Service",
      "appid": ["APP-002"],
      "architecture_model_id": "AML-001",
      "authentication_methods": "Local Account",
      "authorization_methods": "Local Group",
      "encryption_in_transit_algorithms": ["TLS 1.2", "RSA", "AES", "SHA-2"],
      "encryption_in_transit_key_strength": ["RSA2048", "AES_256_GCM", "SHA256"],
      "encryption_at_rest_algorithms": "N/A",
      "encryption_at_rest_key_strength": "N/A",
      "logging_retention_days": "N/A",
      "logging_cyber_detection_feed": "SIEM",
      "listening_port": 3389,
      "listening_protocol": "TCP"
    },
    {
      "svcid": "SVC-003",
      "svcname": "Corebanking Backend Service",
      "appid": "APP-003",
      "architecture_model_id": "AML-002",
      "authentication_methods": "Corebanking Client Account",
      "authorization_methods": "RBAC",
      "encryption_in_transit_algorithms": "N/A",
      "encryption_in_transit_key_strength": "N/A",
      "encryption_at_rest_algorithms": "N/A",
      "encryption_at_rest_key_strength": "N/A",
      "logging_retention_days": "N/A",
      "logging_cyber_detection_feed": "N/A",
      "listening_port": [7012, 3022, 5022, 8099, 9112, 9004, 7032],
      "listening_protocol": "TCP"
    },
    {
      "svcid": "SVC-004",
      "svcname": "Desktop RDP Client",
      "appid": ["APP-004", "APP-005"],
      "architecture_model_id": "AML-001",
      "authentication_methods": "N/A",
      "authorization_methods": "N/A",
      "encryption_in_transit_algorithms": "N/A",
      "encryption_in_transit_key_strength": "N/A",
      "encryption_at_rest_algorithms": "N/A",
      "encryption_at_rest_key_strength": "N/A",
      "logging_retention_days": "N/A",
      "logging_cyber_detection_feed": "N/A",
      "listening_port": "N/A",
      "listening_protocol": "N/A"
    }
  ]
}
```

#### ServiceInstance（JSON）

```json
{
  "ServiceInstance": [
    {
      "svcint_id": "SIN-001",
      "svcintname": "Corebanking Client Service Instance",
      "svcid": "SVC-001",
      "ipc_authentication_methods": "N/A",
      "ipc_authorization_methods": "N/A",
      "sast_status": "N/A",
      "dast_status": "N/A",
      "parameterized_queries_status": "N/A",
      "input_validation_methods": "N/A",
      "output_encoding_contexts": "N/A",
      "csrf_protection_mechanism": "N/A",
      "race_condition_sync": "N/A"
    },
    {
      "svcint_id": "SIN-002",
      "svcintname": "Remote Desktop Service Instance",
      "svcid": "SVC-002",
      "ipc_authentication_methods": "N/A",
      "ipc_authorization_methods": "N/A",
      "sast_status": "Passed",
      "dast_status": "Passed",
      "parameterized_queries_status": "N/A",
      "input_validation_methods": "TypeChecking",
      "output_encoding_contexts": "N/A",
      "csrf_protection_mechanism": "N/A",
      "race_condition_sync": "N/A"
    },
    {
      "svcint_id": "SIN-003",
      "svcintname": "Corebanking Backend Service Instance - Core",
      "svcid": "SVC-003",
      "ipc_authentication_methods": "N/A",
      "ipc_authorization_methods": "N/A",
      "sast_status": "N/A",
      "dast_status": "N/A",
      "parameterized_queries_status": "N/A",
      "input_validation_methods": "N/A",
      "output_encoding_contexts": "N/A",
      "csrf_protection_mechanism": "N/A",
      "race_condition_sync": "N/A"
    },
    {
      "svcint_id": "SIN-004",
      "svcintname": "Corebanking Backend Service Instance - Counter",
      "svcid": "SVC-003",
      "ipc_authentication_methods": "N/A",
      "ipc_authorization_methods": "N/A",
      "sast_status": "N/A",
      "dast_status": "N/A",
      "parameterized_queries_status": "N/A",
      "input_validation_methods": "N/A",
      "output_encoding_contexts": "N/A",
      "csrf_protection_mechanism": "N/A",
      "race_condition_sync": "N/A"
    },
    {
      "svcint_id": "SIN-005",
      "svcintname": "Corebanking Backend Service Instance - Reporter",
      "svcid": "SVC-003",
      "ipc_authentication_methods": "N/A",
      "ipc_authorization_methods": "N/A",
      "sast_status": "N/A",
      "dast_status": "N/A",
      "parameterized_queries_status": "N/A",
      "input_validation_methods": "N/A",
      "output_encoding_contexts": "N/A",
      "csrf_protection_mechanism": "N/A",
      "race_condition_sync": "N/A"
    },
    {
      "svcint_id": "SIN-006",
      "svcintname": "Corebanking Backend Service Instance - Operation Management",
      "svcid": "SVC-003",
      "ipc_authentication_methods": "N/A",
      "ipc_authorization_methods": "N/A",
      "sast_status": "N/A",
      "dast_status": "N/A",
      "parameterized_queries_status": "N/A",
      "input_validation_methods": "N/A",
      "output_encoding_contexts": "N/A",
      "csrf_protection_mechanism": "N/A",
      "race_condition_sync": "N/A"
    },
    {
      "svcint_id": "SIN-007",
      "svcintname": "Corebanking Backend Service Instance - Endpoint Authorization",
      "svcid": "SVC-003",
      "ipc_authentication_methods": "N/A",
      "ipc_authorization_methods": "N/A",
      "sast_status": "N/A",
      "dast_status": "N/A",
      "parameterized_queries_status": "N/A",
      "input_validation_methods": "N/A",
      "output_encoding_contexts": "N/A",
      "csrf_protection_mechanism": "N/A",
      "race_condition_sync": "N/A"
    },
    {
      "svcint_id": "SIN-008",
      "svcintname": "Corebanking Backend Service Instance - Judicial control",
      "svcid": "SVC-003",
      "ipc_authentication_methods": "N/A",
      "ipc_authorization_methods": "N/A",
      "sast_status": "N/A",
      "dast_status": "N/A",
      "parameterized_queries_status": "N/A",
      "input_validation_methods": "N/A",
      "output_encoding_contexts": "N/A",
      "csrf_protection_mechanism": "N/A",
      "race_condition_sync": "N/A"
    },
    {
      "svcint_id": "SIN-009",
      "svcintname": "Corebanking Backend Service Instance - AntiMoney Landering",
      "svcid": "SVC-003",
      "ipc_authentication_methods": "N/A",
      "ipc_authorization_methods": "N/A",
      "sast_status": "N/A",
      "dast_status": "N/A",
      "parameterized_queries_status": "N/A",
      "input_validation_methods": "N/A",
      "output_encoding_contexts": "N/A",
      "csrf_protection_mechanism": "N/A",
      "race_condition_sync": "N/A"
    },
    {
      "svcint_id": "SIN-010",
      "svcintname": "Remote Desktop Client Instance",
      "svcid": "SVC-004",
      "ipc_authentication_methods": "N/A",
      "ipc_authorization_methods": "N/A",
      "sast_status": "Passed",
      "dast_status": "Passed",
      "parameterized_queries_status": "N/A",
      "input_validation_methods": "TypeChecking",
      "output_encoding_contexts": "N/A",
      "csrf_protection_mechanism": "N/A",
      "race_condition_sync": "N/A"
    }
  ]
}
```

### 3：物化实体

#### Component（JSON）

```json
{
  "Component": [
    {
      "cmpid": "CMP-001",
      "cmpname": "Corebanking Client Service Instance in Corebanking Client (Vanilla)",
      "svcint_id": "SIN-001",
      "inherited_properties": {
        "from_ServiceInstance": {
          "svcint_id": "SIN-001",
          "svcintname": "Corebanking Client Service Instance",
          "svcid": "SVC-001",
          "ipc_authentication_methods": "N/A",
          "ipc_authorization_methods": "N/A",
          "sast_status": "N/A",
          "dast_status": "N/A",
          "parameterized_queries_status": "N/A",
          "input_validation_methods": "N/A",
          "output_encoding_contexts": "N/A",
          "csrf_protection_mechanism": "N/A",
          "race_condition_sync": "N/A"
        },
        "from_Service": {
          "svcid": "SVC-001",
          "svcname": "Corebanking Client Service",
          "appid": ["APP-001", "APP-002"],
          "architecture_model_id": "AML-001",
          "authentication_methods": "Corebanking Client Account",
          "authorization_methods": "RBAC",
          "encryption_in_transit_algorithms": "N/A",
          "encryption_in_transit_key_strength": "N/A",
          "encryption_at_rest_algorithms": "N/A",
          "encryption_at_rest_key_strength": "N/A",
          "logging_retention_days": "N/A",
          "logging_cyber_detection_feed": "N/A",
          "listening_port": "N/A",
          "listening_protocol": "N/A"
        },
        "from_Application": {
          "appid": "APP-001",
          "appname": "Corebanking Client (Vanilla)",
          "cmdb_sysid": "SYS-001",
          "deployment_model_id": "DTP-002",
          "location": "Onprem_DC_SH",
          "security_environment": "Prod",
          "security_domain": "MSBIC_MDEX",
          "security_zone": "vanilla-dmz"
        },
        "from_System": {
          "cmdb_sysid": "SYS-001",
          "sysname": "Corebanking System",
          "description": "Corebanking system with thick clients deployed in branches and data centers.",
          "information_sensetivity_classification": "Highly Restricted",
          "asset_risk_ranking": "P1"
        },
        "from_DeploymentModel": {
          "deployment_model_id": "DTP-002",
          "deployment_model": {
            "deployment_model_name": "Desktop",
            "os": "Windows 10",
            "host_firewall": "Windows Firewall",
            "endpoint_antivirus": "Windows Defender",
            "endpoint_detection_response": "Cortex XDR",
            "endpoint_data_leakage_protection": "Disabled",
            "Windows_gpo_policy": "Enabled",
            "trusted_platform_module_status": "Enabled",
            "secure_boot_status": "Enabled"
          }
        },
        "from_ArchitectureModel": {
          "architecture_model_id": "AML-001",
          "architecture_model_category": "AccessLayer",
          "architecture_model": "Client",
          "tool_licensing_model": null,
          "tool": {
            "tool_name": "Core Banking Thick Client",
            "software_runas": "Normal Account"
          }
        }
      }
    },
    {
      "cmpid": "CMP-002",
      "cmpname": "Corebanking Client Service Instance in Corebanking Client (MS-DMZ)",
      "svcint_id": "SIN-001",
      "inherited_properties": {
        "from_ServiceInstance": {
          "svcint_id": "SIN-001",
          "svcintname": "Corebanking Client Service Instance",
          "svcid": "SVC-001",
          "ipc_authentication_methods": "N/A",
          "ipc_authorization_methods": "N/A",
          "sast_status": "N/A",
          "dast_status": "N/A",
          "parameterized_queries_status": "N/A",
          "input_validation_methods": "N/A",
          "output_encoding_contexts": "N/A",
          "csrf_protection_mechanism": "N/A",
          "race_condition_sync": "N/A"
        },
        "from_Service": {
          "svcid": "SVC-001",
          "svcname": "Corebanking Client Service",
          "appid": ["APP-001", "APP-002"],
          "architecture_model_id": "AML-001",
          "authentication_methods": "Corebanking Client Account",
          "authorization_methods": "RBAC",
          "encryption_in_transit_algorithms": "N/A",
          "encryption_in_transit_key_strength": "N/A",
          "encryption_at_rest_algorithms": "N/A",
          "encryption_at_rest_key_strength": "N/A",
          "logging_retention_days": "N/A",
          "logging_cyber_detection_feed": "N/A",
          "listening_port": "N/A",
          "listening_protocol": "N/A"
        },
        "from_Application": {
          "appid": "APP-002",
          "appname": "Corebanking Client (MS-DMZ)",
          "cmdb_sysid": "SYS-001",
          "deployment_model_id": "DTP-001",
          "location": "Onprem_DC_SH",
          "security_environment": "Prod",
          "security_domain": "MSBIC_MDEX",
          "security_zone": "ms-dmz"
        },
        "from_System": {
          "cmdb_sysid": "SYS-001",
          "sysname": "Corebanking System",
          "description": "Corebanking system with thick clients deployed in branches and data centers.",
          "information_sensetivity_classification": "Highly Restricted",
          "asset_risk_ranking": "P1"
        },
        "from_DeploymentModel": {
          "deployment_model_id": "DTP-001",
          "deployment_model": {
            "deployment_model_name": "Virtual Machine",
            "hypervisor_os": "ESXi 7.0",
            "guest_os": "Windows Server 2019",
            "vm_escape_protection": "Enabled",
            "sec_baseline_golden_image": "Enabled",
            "trusted_platform_module_status": "Enabled",
            "secure_boot_status": "Enabled"
          }
        },
        "from_ArchitectureModel": {
          "architecture_model_id": "AML-001",
          "architecture_model_category": "AccessLayer",
          "architecture_model": "Client",
          "tool_licensing_model": null,
          "tool": {
            "tool_name": "Core Banking Thick Client",
            "software_runas": "Normal Account"
          }
        }
      }
    },
    {
      "cmpid": "CMP-003",
      "cmpname": "Corebanking Backend Service Instance - Core in Corebanking Service",
      "svcint_id": "SIN-003",
      "inherited_properties": {
        "from_ServiceInstance": {
          "svcint_id": "SIN-003",
          "svcintname": "Corebanking Backend Service Instance - Core",
          "svcid": "SVC-003",
          "ipc_authentication_methods": "N/A",
          "ipc_authorization_methods": "N/A",
          "sast_status": "N/A",
          "dast_status": "N/A",
          "parameterized_queries_status": "N/A",
          "input_validation_methods": "N/A",
          "output_encoding_contexts": "N/A",
          "csrf_protection_mechanism": "N/A",
          "race_condition_sync": "N/A"
        },
        "from_Service": {
          "svcid": "SVC-003",
          "svcname": "Corebanking Backend Service",
          "appid": "APP-003",
          "architecture_model_id": "AML-002",
          "authentication_methods": "Corebanking Client Account",
          "authorization_methods": "RBAC",
          "encryption_in_transit_algorithms": "N/A",
          "encryption_in_transit_key_strength": "N/A",
          "encryption_at_rest_algorithms": "N/A",
          "encryption_at_rest_key_strength": "N/A",
          "logging_retention_days": "N/A",
          "logging_cyber_detection_feed": "N/A",
          "listening_port": [7012, 3022, 5022, 8099, 9112, 9004, 7032],
          "listening_protocol": "TCP"
        },
        "from_Application": {
          "appid": "APP-003",
          "appname": "Corebanking Service",
          "cmdb_sysid": "SYS-001",
          "deployment_model_id": "DTP-003",
          "location": "Cloud_Other",
          "security_environment": "Prod",
          "security_domain": "MSBIC_MDEX",
          "security_zone": "external"
        },
        "from_System": {
          "cmdb_sysid": "SYS-001",
          "sysname": "Corebanking System",
          "description": "Corebanking system with thick clients deployed in branches and data centers.",
          "information_sensetivity_classification": "Highly Restricted",
          "asset_risk_ranking": "P1"
        },
        "from_DeploymentModel": {
          "deployment_model_id": "DTP-003",
          "deployment_model": {
            "deployment_model_name": "External Service",
            "external_service_resource": ["https://report.smartensemble.com:5020"],
            "trusted_platform_module_status": "N/A",
            "secure_boot_status": "N/A"
          }
        },
        "from_ArchitectureModel": {
          "architecture_model_id": "AML-002",
          "architecture_model_category": "ApplicationLayer",
          "architecture_model": "Application Service",
          "tool_licensing_model": null,
          "tool": {
            "tool_name": "Core Banking",
            "console_access_control": "Enabled"
          }
        }
      }
    },
    {
      "cmpid": "CMP-004",
      "cmpname": "Remote Desktop Client Instance in MSBIC Branch OA Desktop",
      "svcint_id": "SIN-010",
      "inherited_properties": {
        "from_ServiceInstance": {
          "svcint_id": "SIN-010",
          "svcintname": "Remote Desktop Client Instance",
          "svcid": "SVC-004",
          "ipc_authentication_methods": "N/A",
          "ipc_authorization_methods": "N/A",
          "sast_status": "Passed",
          "dast_status": "Passed",
          "parameterized_queries_status": "N/A",
          "input_validation_methods": "TypeChecking",
          "output_encoding_contexts": "N/A",
          "csrf_protection_mechanism": "N/A",
          "race_condition_sync": "N/A"
        },
        "from_Service": {
          "svcid": "SVC-004",
          "svcname": "Desktop RDP Client",
          "appid": ["APP-004", "APP-005"],
          "architecture_model_id": "AML-001",
          "authentication_methods": "N/A",
          "authorization_methods": "N/A",
          "encryption_in_transit_algorithms": "N/A",
          "encryption_in_transit_key_strength": "N/A",
          "encryption_at_rest_algorithms": "N/A",
          "encryption_at_rest_key_strength": "N/A",
          "logging_retention_days": "N/A",
          "logging_cyber_detection_feed": "N/A",
          "listening_port": "N/A",
          "listening_protocol": "N/A"
        },
        "from_Application": {
          "appid": "APP-004",
          "appname": "MSBIC Branch OA Desktop",
          "cmdb_sysid": "SYS-001",
          "deployment_model_id": "DTP-002",
          "location": "Onprem_DC_SH",
          "security_environment": "Prod",
          "security_domain": "MSBIC_OA",
          "security_zone": "int-broa"
        },
        "from_System": {
          "cmdb_sysid": "SYS-001",
          "sysname": "Corebanking System",
          "description": "Corebanking system with thick clients deployed in branches and data centers.",
          "information_sensetivity_classification": "Highly Restricted",
          "asset_risk_ranking": "P1"
        },
        "from_DeploymentModel": {
          "deployment_model_id": "DTP-002",
          "deployment_model": {
            "deployment_model_name": "Desktop",
            "os": "Windows 10",
            "host_firewall": "Windows Firewall",
            "endpoint_antivirus": "Windows Defender",
            "endpoint_detection_response": "Cortex XDR",
            "endpoint_data_leakage_protection": "Disabled",
            "Windows_gpo_policy": "Enabled",
            "trusted_platform_module_status": "Enabled",
            "secure_boot_status": "Enabled"
          }
        },
        "from_ArchitectureModel": {
          "architecture_model_id": "AML-001",
          "architecture_model_category": "AccessLayer",
          "architecture_model": "Client",
          "tool_licensing_model": null,
          "tool": {
            "tool_name": "Core Banking Thick Client",
            "software_runas": "Normal Account"
          }
        }
      }
    },
    {
      "cmpid": "CMP-005",
      "cmpname": "Remote Desktop Client Instance in MSMS Branch OA Desktop",
      "svcint_id": "SIN-010",
      "inherited_properties": {
        "from_ServiceInstance": {
          "svcint_id": "SIN-010",
          "svcintname": "Remote Desktop Client Instance",
          "svcid": "SVC-004",
          "ipc_authentication_methods": "N/A",
          "ipc_authorization_methods": "N/A",
          "sast_status": "Passed",
          "dast_status": "Passed",
          "parameterized_queries_status": "N/A",
          "input_validation_methods": "TypeChecking",
          "output_encoding_contexts": "N/A",
          "csrf_protection_mechanism": "N/A",
          "race_condition_sync": "N/A"
        },
        "from_Service": {
          "svcid": "SVC-004",
          "svcname": "Desktop RDP Client",
          "appid": ["APP-004", "APP-005"],
          "architecture_model_id": "AML-001",
          "authentication_methods": "N/A",
          "authorization_methods": "N/A",
          "encryption_in_transit_algorithms": "N/A",
          "encryption_in_transit_key_strength": "N/A",
          "encryption_at_rest_algorithms": "N/A",
          "encryption_at_rest_key_strength": "N/A",
          "logging_retention_days": "N/A",
          "logging_cyber_detection_feed": "N/A",
          "listening_port": "N/A",
          "listening_protocol": "N/A"
        },
        "from_Application": {
          "appid": "APP-005",
          "appname": "MSMS Branch OA Desktop",
          "cmdb_sysid": "SYS-001",
          "deployment_model_id": "DTP-002",
          "location": "Onprem_DC_SH",
          "security_environment": "Prod",
          "security_domain": "COD_MSMS",
          "security_zone": "branch-oa"
        },
        "from_System": {
          "cmdb_sysid": "SYS-001",
          "sysname": "Corebanking System",
          "description": "Corebanking system with thick clients deployed in branches and data centers.",
          "information_sensetivity_classification": "Highly Restricted",
          "asset_risk_ranking": "P1"
        },
        "from_DeploymentModel": {
          "deployment_model_id": "DTP-002",
          "deployment_model": {
            "deployment_model_name": "Desktop",
            "os": "Windows 10",
            "host_firewall": "Windows Firewall",
            "endpoint_antivirus": "Windows Defender",
            "endpoint_detection_response": "Cortex XDR",
            "endpoint_data_leakage_protection": "Disabled",
            "Windows_gpo_policy": "Enabled",
            "trusted_platform_module_status": "Enabled",
            "secure_boot_status": "Enabled"
          }
        },
        "from_ArchitectureModel": {
          "architecture_model_id": "AML-001",
          "architecture_model_category": "AccessLayer",
          "architecture_model": "Client",
          "tool_licensing_model": null,
          "tool": {
            "tool_name": "Core Banking Thick Client",
            "software_runas": "Normal Account"
          }
        }
      }
    },
    {
      "cmpid": "CMP-006",
      "cmpname": "Remote Desktop Service Instance in Corebanking Client (MS-DMZ)",
      "svcint_id": "SIN-002",
      "inherited_properties": {
        "from_ServiceInstance": {
          "svcint_id": "SIN-002",
          "svcintname": "Remote Desktop Service Instance",
          "svcid": "SVC-002",
          "ipc_authentication_methods": "N/A",
          "ipc_authorization_methods": "N/A",
          "sast_status": "Passed",
          "dast_status": "Passed",
          "parameterized_queries_status": "N/A",
          "input_validation_methods": "TypeChecking",
          "output_encoding_contexts": "N/A",
          "csrf_protection_mechanism": "N/A",
          "race_condition_sync": "N/A"
        },
        "from_Service": {
          "svcid": "SVC-002",
          "svcname": "Remote Desktop Service",
          "appid": ["APP-001", "APP-002"],
          "architecture_model_id": "AML-001",
          "authentication_methods": "Local Account",
          "authorization_methods": "Local Group",
          "encryption_in_transit_algorithms": ["TLS 1.2", "RSA", "AES", "SHA-2"],
          "encryption_in_transit_key_strength": ["RSA2048", "AES_256_GCM", "SHA256"],
          "encryption_at_rest_algorithms": "N/A",
          "encryption_at_rest_key_strength": "N/A",
          "logging_retention_days": "N/A",
          "logging_cyber_detection_feed": "SIEM",
          "listening_port": 3389,
          "listening_protocol": "TCP"
        },
        "from_Application": {
          "appid": "APP-002",
          "appname": "Corebanking Client (MS-DMZ)",
          "cmdb_sysid": "SYS-001",
          "deployment_model_id": "DTP-001",
          "location": "Onprem_DC_SH",
          "security_environment": "Prod",
          "security_domain": "MSBIC_MDEX",
          "security_zone": "ms-dmz"
        },
        "from_System": {
          "cmdb_sysid": "SYS-001",
          "sysname": "Corebanking System",
          "description": "Corebanking system with thick clients deployed in branches and data centers.",
          "information_sensetivity_classification": "Highly Restricted",
          "asset_risk_ranking": "P1"
        },
        "from_DeploymentModel": {
          "deployment_model_id": "DTP-001",
          "deployment_model": {
            "deployment_model_name": "Virtual Machine",
            "hypervisor_os": "ESXi 7.0",
            "guest_os": "Windows Server 2019",
            "vm_escape_protection": "Enabled",
            "sec_baseline_golden_image": "Enabled",
            "trusted_platform_module_status": "Enabled",
            "secure_boot_status": "Enabled"
          }
        },
        "from_ArchitectureModel": {
          "architecture_model_id": "AML-001",
          "architecture_model_category": "AccessLayer",
          "architecture_model": "Client",
          "tool_licensing_model": null,
          "tool": {
            "tool_name": "Core Banking Thick Client",
            "software_runas": "Normal Account"
          }
        }
      }
    },
    {
      "cmpid": "CMP-007",
      "cmpname": "Corebanking Backend Service Instance - Counter in Corebanking Service",
      "svcint_id": "SIN-004",
      "inherited_properties": {
        "from_ServiceInstance": {
          "svcint_id": "SIN-004",
          "svcintname": "Corebanking Backend Service Instance - Counter",
          "svcid": "SVC-003",
          "ipc_authentication_methods": "N/A",
          "ipc_authorization_methods": "N/A",
          "sast_status": "N/A",
          "dast_status": "N/A",
          "parameterized_queries_status": "N/A",
          "input_validation_methods": "N/A",
          "output_encoding_contexts": "N/A",
          "csrf_protection_mechanism": "N/A",
          "race_condition_sync": "N/A"
        },
        "from_Service": {
          "svcid": "SVC-003",
          "svcname": "Corebanking Backend Service",
          "appid": "APP-003",
          "architecture_model_id": "AML-002",
          "authentication_methods": "Corebanking Client Account",
          "authorization_methods": "RBAC",
          "encryption_in_transit_algorithms": "N/A",
          "encryption_in_transit_key_strength": "N/A",
          "encryption_at_rest_algorithms": "N/A",
          "encryption_at_rest_key_strength": "N/A",
          "logging_retention_days": "N/A",
          "logging_cyber_detection_feed": "N/A",
          "listening_port": [7012, 3022, 5022, 8099, 9112, 9004, 7032],
          "listening_protocol": "TCP"
        },
        "from_Application": {
          "appid": "APP-003",
          "appname": "Corebanking Service",
          "cmdb_sysid": "SYS-001",
          "deployment_model_id": "DTP-003",
          "location": "Cloud_Other",
          "security_environment": "Prod",
          "security_domain": "MSBIC_MDEX",
          "security_zone": "external"
        },
        "from_System": {
          "cmdb_sysid": "SYS-001",
          "sysname": "Corebanking System",
          "description": "Corebanking system with thick clients deployed in branches and data centers.",
          "information_sensetivity_classification": "Highly Restricted",
          "asset_risk_ranking": "P1"
        },
        "from_DeploymentModel": {
          "deployment_model_id": "DTP-003",
          "deployment_model": {
            "deployment_model_name": "External Service",
            "external_service_resource": ["https://report.smartensemble.com:5020"],
            "trusted_platform_module_status": "N/A",
            "secure_boot_status": "N/A"
          }
        },
        "from_ArchitectureModel": {
          "architecture_model_id": "AML-002",
          "architecture_model_category": "ApplicationLayer",
          "architecture_model": "Application Service",
          "tool_licensing_model": null,
          "tool": {
            "tool_name": "Core Banking",
            "console_access_control": "Enabled"
          }
        }
      }
    },
    {
      "cmpid": "CMP-008",
      "cmpname": "Corebanking Backend Service Instance - Reporter in Corebanking Service",
      "svcint_id": "SIN-005",
      "inherited_properties": {
        "from_ServiceInstance": {
          "svcint_id": "SIN-005",
          "svcintname": "Corebanking Backend Service Instance - Reporter",
          "svcid": "SVC-003",
          "ipc_authentication_methods": "N/A",
          "ipc_authorization_methods": "N/A",
          "sast_status": "N/A",
          "dast_status": "N/A",
          "parameterized_queries_status": "N/A",
          "input_validation_methods": "N/A",
          "output_encoding_contexts": "N/A",
          "csrf_protection_mechanism": "N/A",
          "race_condition_sync": "N/A"
        },
        "from_Service": {
          "svcid": "SVC-003",
          "svcname": "Corebanking Backend Service",
          "appid": "APP-003",
          "architecture_model_id": "AML-002",
          "authentication_methods": "Corebanking Client Account",
          "authorization_methods": "RBAC",
          "encryption_in_transit_algorithms": "N/A",
          "encryption_in_transit_key_strength": "N/A",
          "encryption_at_rest_algorithms": "N/A",
          "encryption_at_rest_key_strength": "N/A",
          "logging_retention_days": "N/A",
          "logging_cyber_detection_feed": "N/A",
          "listening_port": [7012, 3022, 5022, 8099, 9112, 9004, 7032],
          "listening_protocol": "TCP"
        },
        "from_Application": {
          "appid": "APP-003",
          "appname": "Corebanking Service",
          "cmdb_sysid": "SYS-001",
          "deployment_model_id": "DTP-003",
          "location": "Cloud_Other",
          "security_environment": "Prod",
          "security_domain": "MSBIC_MDEX",
          "security_zone": "external"
        },
        "from_System": {
          "cmdb_sysid": "SYS-001",
          "sysname": "Corebanking System",
          "description": "Corebanking system with thick clients deployed in branches and data centers.",
          "information_sensetivity_classification": "Highly Restricted",
          "asset_risk_ranking": "P1"
        },
        "from_DeploymentModel": {
          "deployment_model_id": "DTP-003",
          "deployment_model": {
            "deployment_model_name": "External Service",
            "external_service_resource": ["https://report.smartensemble.com:5020"],
            "trusted_platform_module_status": "N/A",
            "secure_boot_status": "N/A"
          }
        },
        "from_ArchitectureModel": {
          "architecture_model_id": "AML-002",
          "architecture_model_category": "ApplicationLayer",
          "architecture_model": "Application Service",
          "tool_licensing_model": null,
          "tool": {
            "tool_name": "Core Banking",
            "console_access_control": "Enabled"
          }
        }
      }
    },
    {
      "cmpid": "CMP-009",
      "cmpname": "Corebanking Backend Service Instance - Operation Management in Corebanking Service",
      "svcint_id": "SIN-006",
      "inherited_properties": {
        "from_ServiceInstance": {
          "svcint_id": "SIN-006",
          "svcintname": "Corebanking Backend Service Instance - Operation Management",
          "svcid": "SVC-003",
          "ipc_authentication_methods": "N/A",
          "ipc_authorization_methods": "N/A",
          "sast_status": "N/A",
          "dast_status": "N/A",
          "parameterized_queries_status": "N/A",
          "input_validation_methods": "N/A",
          "output_encoding_contexts": "N/A",
          "csrf_protection_mechanism": "N/A",
          "race_condition_sync": "N/A"
        },
        "from_Service": {
          "svcid": "SVC-003",
          "svcname": "Corebanking Backend Service",
          "appid": "APP-003",
          "architecture_model_id": "AML-002",
          "authentication_methods": "Corebanking Client Account",
          "authorization_methods": "RBAC",
          "encryption_in_transit_algorithms": "N/A",
          "encryption_in_transit_key_strength": "N/A",
          "encryption_at_rest_algorithms": "N/A",
          "encryption_at_rest_key_strength": "N/A",
          "logging_retention_days": "N/A",
          "logging_cyber_detection_feed": "N/A",
          "listening_port": [7012, 3022, 5022, 8099, 9112, 9004, 7032],
          "listening_protocol": "TCP"
        },
        "from_Application": {
          "appid": "APP-003",
          "appname": "Corebanking Service",
          "cmdb_sysid": "SYS-001",
          "deployment_model_id": "DTP-003",
          "location": "Cloud_Other",
          "security_environment": "Prod",
          "security_domain": "MSBIC_MDEX",
          "security_zone": "external"
        },
        "from_System": {
          "cmdb_sysid": "SYS-001",
          "sysname": "Corebanking System",
          "description": "Corebanking system with thick clients deployed in branches and data centers.",
          "information_sensetivity_classification": "Highly Restricted",
          "asset_risk_ranking": "P1"
        },
        "from_DeploymentModel": {
          "deployment_model_id": "DTP-003",
          "deployment_model": {
            "deployment_model_name": "External Service",
            "external_service_resource": ["https://report.smartensemble.com:5020"],
            "trusted_platform_module_status": "N/A",
            "secure_boot_status": "N/A"
          }
        },
        "from_ArchitectureModel": {
          "architecture_model_id": "AML-002",
          "architecture_model_category": "ApplicationLayer",
          "architecture_model": "Application Service",
          "tool_licensing_model": null,
          "tool": {
            "tool_name": "Core Banking",
            "console_access_control": "Enabled"
          }
        }
      }
    },
    {
      "cmpid": "CMP-010",
      "cmpname": "Corebanking Backend Service Instance - Endpoint Authorization in Corebanking Service",
      "svcint_id": "SIN-007",
      "inherited_properties": {
        "from_ServiceInstance": {
          "svcint_id": "SIN-007",
          "svcintname": "Corebanking Backend Service Instance - Endpoint Authorization",
          "svcid": "SVC-003",
          "ipc_authentication_methods": "N/A",
          "ipc_authorization_methods": "N/A",
          "sast_status": "N/A",
          "dast_status": "N/A",
          "parameterized_queries_status": "N/A",
          "input_validation_methods": "N/A",
          "output_encoding_contexts": "N/A",
          "csrf_protection_mechanism": "N/A",
          "race_condition_sync": "N/A"
        },
        "from_Service": {
          "svcid": "SVC-003",
          "svcname": "Corebanking Backend Service",
          "appid": "APP-003",
          "architecture_model_id": "AML-002",
          "authentication_methods": "Corebanking Client Account",
          "authorization_methods": "RBAC",
          "encryption_in_transit_algorithms": "N/A",
          "encryption_in_transit_key_strength": "N/A",
          "encryption_at_rest_algorithms": "N/A",
          "encryption_at_rest_key_strength": "N/A",
          "logging_retention_days": "N/A",
          "logging_cyber_detection_feed": "N/A",
          "listening_port": [7012, 3022, 5022, 8099, 9112, 9004, 7032],
          "listening_protocol": "TCP"
        },
        "from_Application": {
          "appid": "APP-003",
          "appname": "Corebanking Service",
          "cmdb_sysid": "SYS-001",
          "deployment_model_id": "DTP-003",
          "location": "Cloud_Other",
          "security_environment": "Prod",
          "security_domain": "MSBIC_MDEX",
          "security_zone": "external"
        },
        "from_System": {
          "cmdb_sysid": "SYS-001",
          "sysname": "Corebanking System",
          "description": "Corebanking system with thick clients deployed in branches and data centers.",
          "information_sensetivity_classification": "Highly Restricted",
          "asset_risk_ranking": "P1"
        },
        "from_DeploymentModel": {
          "deployment_model_id": "DTP-003",
          "deployment_model": {
            "deployment_model_name": "External Service",
            "external_service_resource": ["https://report.smartensemble.com:5020"],
            "trusted_platform_module_status": "N/A",
            "secure_boot_status": "N/A"
          }
        },
        "from_ArchitectureModel": {
          "architecture_model_id": "AML-002",
          "architecture_model_category": "ApplicationLayer",
          "architecture_model": "Application Service",
          "tool_licensing_model": null,
          "tool": {
            "tool_name": "Core Banking",
            "console_access_control": "Enabled"
          }
        }
      }
    },
    {
      "cmpid": "CMP-011",
      "cmpname": "Corebanking Backend Service Instance - Judicial control in Corebanking Service",
      "svcint_id": "SIN-008",
      "inherited_properties": {
        "from_ServiceInstance": {
          "svcint_id": "SIN-008",
          "svcintname": "Corebanking Backend Service Instance - Judicial control",
          "svcid": "SVC-003",
          "ipc_authentication_methods": "N/A",
          "ipc_authorization_methods": "N/A",
          "sast_status": "N/A",
          "dast_status": "N/A",
          "parameterized_queries_status": "N/A",
          "input_validation_methods": "N/A",
          "output_encoding_contexts": "N/A",
          "csrf_protection_mechanism": "N/A",
          "race_condition_sync": "N/A"
        },
        "from_Service": {
          "svcid": "SVC-003",
          "svcname": "Corebanking Backend Service",
          "appid": "APP-003",
          "architecture_model_id": "AML-002",
          "authentication_methods": "Corebanking Client Account",
          "authorization_methods": "RBAC",
          "encryption_in_transit_algorithms": "N/A",
          "encryption_in_transit_key_strength": "N/A",
          "encryption_at_rest_algorithms": "N/A",
          "encryption_at_rest_key_strength": "N/A",
          "logging_retention_days": "N/A",
          "logging_cyber_detection_feed": "N/A",
          "listening_port": [7012, 3022, 5022, 8099, 9112, 9004, 7032],
          "listening_protocol": "TCP"
        },
        "from_Application": {
          "appid": "APP-003",
          "appname": "Corebanking Service",
          "cmdb_sysid": "SYS-001",
          "deployment_model_id": "DTP-003",
          "location": "Cloud_Other",
          "security_environment": "Prod",
          "security_domain": "MSBIC_MDEX",
          "security_zone": "external"
        },
        "from_System": {
          "cmdb_sysid": "SYS-001",
          "sysname": "Corebanking System",
          "description": "Corebanking system with thick clients deployed in branches and data centers.",
          "information_sensetivity_classification": "Highly Restricted",
          "asset_risk_ranking": "P1"
        },
        "from_DeploymentModel": {
          "deployment_model_id": "DTP-003",
          "deployment_model": {
            "deployment_model_name": "External Service",
            "external_service_resource": ["https://report.smartensemble.com:5020"],
            "trusted_platform_module_status": "N/A",
            "secure_boot_status": "N/A"
          }
        },
        "from_ArchitectureModel": {
          "architecture_model_id": "AML-002",
          "architecture_model_category": "ApplicationLayer",
          "architecture_model": "Application Service",
          "tool_licensing_model": null,
          "tool": {
            "tool_name": "Core Banking",
            "console_access_control": "Enabled"
          }
        }
      }
    },
    {
      "cmpid": "CMP-012",
      "cmpname": "Corebanking Backend Service Instance - AntiMoney Landering in Corebanking Service",
      "svcint_id": "SIN-009",
      "inherited_properties": {
        "from_ServiceInstance": {
          "svcint_id": "SIN-009",
          "svcintname": "Corebanking Backend Service Instance - AntiMoney Landering",
          "svcid": "SVC-003",
          "ipc_authentication_methods": "N/A",
          "ipc_authorization_methods": "N/A",
          "sast_status": "N/A",
          "dast_status": "N/A",
          "parameterized_queries_status": "N/A",
          "input_validation_methods": "N/A",
          "output_encoding_contexts": "N/A",
          "csrf_protection_mechanism": "N/A",
          "race_condition_sync": "N/A"
        },
        "from_Service": {
          "svcid": "SVC-003",
          "svcname": "Corebanking Backend Service",
          "appid": "APP-003",
          "architecture_model_id": "AML-002",
          "authentication_methods": "Corebanking Client Account",
          "authorization_methods": "RBAC",
          "encryption_in_transit_algorithms": "N/A",
          "encryption_in_transit_key_strength": "N/A",
          "encryption_at_rest_algorithms": "N/A",
          "encryption_at_rest_key_strength": "N/A",
          "logging_retention_days": "N/A",
          "logging_cyber_detection_feed": "N/A",
          "listening_port": [7012, 3022, 5022, 8099, 9112, 9004, 7032],
          "listening_protocol": "TCP"
        },
        "from_Application": {
          "appid": "APP-003",
          "appname": "Corebanking Service",
          "cmdb_sysid": "SYS-001",
          "deployment_model_id": "DTP-003",
          "location": "Cloud_Other",
          "security_environment": "Prod",
          "security_domain": "MSBIC_MDEX",
          "security_zone": "external"
        },
        "from_System": {
          "cmdb_sysid": "SYS-001",
          "sysname": "Corebanking System",
          "description": "Corebanking system with thick clients deployed in branches and data centers.",
          "information_sensetivity_classification": "Highly Restricted",
          "asset_risk_ranking": "P1"
        },
        "from_DeploymentModel": {
          "deployment_model_id": "DTP-003",
          "deployment_model": {
            "deployment_model_name": "External Service",
            "external_service_resource": ["https://report.smartensemble.com:5020"],
            "trusted_platform_module_status": "N/A",
            "secure_boot_status": "N/A"
          }
        },
        "from_ArchitectureModel": {
          "architecture_model_id": "AML-002",
          "architecture_model_category": "ApplicationLayer",
          "architecture_model": "Application Service",
          "tool_licensing_model": null,
          "tool": {
            "tool_name": "Core Banking",
            "console_access_control": "Enabled"
          }
        }
      }
    }
  ]
}
```

#### Connection（JSON）

```json
{
  "Connection": [
    {
      "conid": "CON-001",
      "source_cmpid": "CMP-001",
      "destination_cmpid": "CMP-003",
      "connection_type_id": "CTP-001",
      "inherited_properties": {
        "source_security_domain": "MSBIC_MDEX",
        "source_security_zone": "vanilla-dmz",
        "destination_security_domain": "MSBIC_MDEX",
        "destination_security_zone": "external",
        "destination_protocol": "TCP",
        "destination_port": [7012, 3022, 5022, 8099, 9112, 9004, 7032],
        "destination_authentication_methods": "Corebanking Client Account",
        "destination_authorization_methods": "RBAC",
        "destination_encryption_in_transit_algorithms": "N/A"
      }
    },
    {
      "conid": "CON-002",
      "source_cmpid": "CMP-002",
      "destination_cmpid": "CMP-003",
      "connection_type_id": "CTP-001",
      "inherited_properties": {
        "source_security_domain": "MSBIC_MDEX",
        "source_security_zone": "ms-dmz",
        "destination_security_domain": "MSBIC_MDEX",
        "destination_security_zone": "external",
        "destination_protocol": "TCP",
        "destination_port": [7012, 3022, 5022, 8099, 9112, 9004, 7032],
        "destination_authentication_methods": "Corebanking Client Account",
        "destination_authorization_methods": "RBAC",
        "destination_encryption_in_transit_algorithms": "N/A"
      }
    },
    {
      "conid": "CON-003",
      "source_cmpid": "CMP-004",
      "destination_cmpid": "CMP-006",
      "connection_type_id": "CTP-001",
      "inherited_properties": {
        "source_security_domain": "MSBIC_OA",
        "source_security_zone": "int-broa",
        "destination_security_domain": "MSBIC_MDEX",
        "destination_security_zone": "ms-dmz",
        "destination_protocol": "TCP",
        "destination_port": 3389,
        "destination_authentication_methods": "Local Account",
        "destination_authorization_methods": "Local Group",
        "destination_encryption_in_transit_algorithms": ["TLS 1.2", "RSA", "AES", "SHA-2"]
      }
    },
    {
      "conid": "CON-004",
      "source_cmpid": "CMP-005",
      "destination_cmpid": "CMP-006",
      "connection_type_id": "CTP-001",
      "inherited_properties": {
        "source_security_domain": "COD_MSMS",
        "source_security_zone": "branch-oa",
        "destination_security_domain": "MSBIC_MDEX",
        "destination_security_zone": "ms-dmz",
        "destination_protocol": "TCP",
        "destination_port": 3389,
        "destination_authentication_methods": "Local Account",
        "destination_authorization_methods": "Local Group",
        "destination_encryption_in_transit_algorithms": ["TLS 1.2", "RSA", "AES", "SHA-2"]
      }
    },
    {
      "conid": "CON-005",
      "source_cmpid": "CMP-012",
      "destination_cmpid": "CMP-011",
      "connection_type_id": "CTP-002",
      "inherited_properties": {
        "destination_ipc_authentication_methods": "N/A",
        "destination_ipc_authorization_methods": "N/A",
        "destination_race_condition_sync": "N/A"
      }
    },
    {
      "conid": "CON-006",
      "source_cmpid": "CMP-010",
      "destination_cmpid": "CMP-009",
      "connection_type_id": "CTP-002",
      "inherited_properties": {
        "destination_ipc_authentication_methods": "N/A",
        "destination_ipc_authorization_methods": "N/A",
        "destination_race_condition_sync": "N/A"
      }
    },
    {
      "conid": "CON-007",
      "source_cmpid": "CMP-012",
      "destination_cmpid": "CMP-008",
      "connection_type_id": "CTP-002",
      "inherited_properties": {
        "destination_ipc_authentication_methods": "N/A",
        "destination_ipc_authorization_methods": "N/A",
        "destination_race_condition_sync": "N/A"
      }
    }
  ]
}
```

#### Coupon（JSON）

```json
{
  "Coupon": [
    {
      "coupon_id": "CPN-001",
      "triggering_connection_id": "CON-001",
      "coupon_type_id": "CPT-001",
      "expiry": "Permanent",
      "justification": "Auto-generated for network flow between different security zones (vanilla-dmz to external).",
      "inherited_properties": {
        "from_CouponType": {
          "coupon_type_name": "Firewall Flow",
          "source_security_domain": "MSBIC_MDEX",
          "source_security_zone": "vanilla-dmz",
          "destination_security_domain": "MSBIC_MDEX",
          "destination_security_zone": "external",
          "destination_protocol": "TCP",
          "destination_port": [7012, 3022, 5022, 8099, 9112, 9004, 7032]
        }
      }
    },
    {
      "coupon_id": "CPN-002",
      "triggering_connection_id": "CON-002",
      "coupon_type_id": "CPT-001",
      "expiry": "Permanent",
      "justification": "Auto-generated for network flow between different security zones (ms-dmz to external).",
      "inherited_properties": {
        "from_CouponType": {
          "coupon_type_name": "Firewall Flow",
          "source_security_domain": "MSBIC_MDEX",
          "source_security_zone": "ms-dmz",
          "destination_security_domain": "MSBIC_MDEX",
          "destination_security_zone": "external",
          "destination_protocol": "TCP",
          "destination_port": [7012, 3022, 5022, 8099, 9112, 9004, 7032]
        }
      }
    },
    {
      "coupon_id": "CPN-003",
      "triggering_connection_id": "CON-003",
      "coupon_type_id": "CPT-001",
      "expiry": "Permanent",
      "justification": "Auto-generated for network flow between different security zones (int-broa to ms-dmz).",
      "inherited_properties": {
        "from_CouponType": {
          "coupon_type_name": "Firewall Flow",
          "source_security_domain": "MSBIC_OA",
          "source_security_zone": "int-broa",
          "destination_security_domain": "MSBIC_MDEX",
          "destination_security_zone": "ms-dmz",
          "destination_protocol": "TCP",
          "destination_port": 3389
        }
      }
    },
    {
      "coupon_id": "CPN-004",
      "triggering_connection_id": "CON-004",
      "coupon_type_id": "CPT-001",
      "expiry": "Permanent",
      "justification": "Auto-generated for network flow between different security zones (branch-oa to ms-dmz).",
      "inherited_properties": {
        "from_CouponType": {
          "coupon_type_name": "Firewall Flow",
          "source_security_domain": "COD_MSMS",
          "source_security_zone": "branch-oa",
          "destination_security_domain": "MSBIC_MDEX",
          "destination_security_zone": "ms-dmz",
          "destination_protocol": "TCP",
          "destination_port": 3389
        }
      }
    },
    {
      "coupon_id": "CPN-005",
      "triggering_connection_id": "CON-001",
      "coupon_type_id": "CPT-002",
      "expiry": "Permanent",
      "justification": "Auto-generated for proxy flow policy triggered by network connection from vanilla-dmz to external.",
      "inherited_properties": {
        "from_CouponType": {
          "coupon_type_name": "Proxy Flow",
          "source_security_domain": "MSBIC_MDEX",
          "source_security_zone": "vanilla-dmz",
          "destination_security_domain": "MSBIC_MDEX",
          "destination_security_zone": "external",
          "destination_external_service_resource": ["https://report.smartensemble.com:5020"],
          "proxy_type": "SOCKS",
          "proxy_ssli": "Disabled",
          "proxy_auth": "Non-Auth"
        }
      }
    },
    {
      "coupon_id": "CPN-006",
      "triggering_connection_id": "CON-002",
      "coupon_type_id": "CPT-002",
      "expiry": "Permanent",
      "justification": "Auto-generated for proxy flow policy triggered by network connection from ms-dmz to external.",
      "inherited_properties": {
        "from_CouponType": {
          "coupon_type_name": "Proxy Flow",
          "source_security_domain": "MSBIC_MDEX",
          "source_security_zone": "ms-dmz",
          "destination_security_domain": "MSBIC_MDEX",
          "destination_security_zone": "external",
          "destination_external_service_resource": ["https://report.smartensemble.com:5020"],
          "proxy_type": "SOCKS",
          "proxy_ssli": "Disabled",
          "proxy_auth": "Non-Auth"
        }
      }
    }
  ]
}
```

### 4：审计实体与 UI 视图模型

#### SecurityFragment（JSON）

```json
{
  "SecurityFragment": [
    {
      "fragment_id": "SFR-001",
      "fragment_name": "Network flow to MDEX (scope)",
      "target_entity": "Connection",
      "fragment_description": "Reusable scope: any network communication (CTP-001) whose destination security domain is MSBIC_MDEX.",
      "condition": {
        "and": [
          {
            "attribute": "properties.connection_type_id",
            "operator": "equals",
            "value": "CTP-001"
          },
          {
            "attribute": "properties.destination_security_domain",
            "operator": "equals",
            "value": "MSBIC_MDEX"
          }
        ]
      }
    }
  ]
}
```

#### SecurityBlueprint（JSON）

```json
{
  "SecurityBlueprint": [
    {
      "blueprint_id": "BLP-001",
      "blueprint_name": "MDEX RDP access control (COD identity)",
      "rules": [
        {
          "rule_id": "RUL-001",
          "rule_description": "Enforce COD identity-based authentication/authorization for RDP access to MDEX.",
          "target_entity": "Connection",
          "definitions": [
            {
              "definition_id": "DEF-001",
              "pre_condition": {
                "and": [
                  {
                    "security_fragment_ref": "SFR-001"
                  },
                  {
                    "attribute": "properties.destination_port",
                    "operator": "equals",
                    "value": 3389
                  }
                ]
              },
              "SecurityCondition": {
                "or": [
                  {
                    "not": {
                      "attribute": "properties.destination_authentication_methods",
                      "operator": "equals",
                      "value": "Kerberos"
                    }
                  },
                  {
                    "not": {
                      "attribute": "properties.destination_authorization_methods",
                      "operator": "equals",
                      "value": "AD Group"
                    }
                  }
                ]
              },
              "outcome": {
                "risk": "High",
                "finding": "Detected RDP access to MDEX without Kerberos/AD Group controls on destination. (Current destination uses Local Account/Local Group)",
                "requirement": [
                  {
                    "description": "Adopt COD AD group and IAM TAC to track and manage RDP authentication and authorization.",
                    "tech_control_id": "TEC-026"
                  },
                  {
                    "description": "Onboard system entitlements into COD standard IGA (SailPoint).",
                    "tech_control_id": "TEC-026"
                  }
                ]
              }
            }
          ]
        }
      ]
    },
    {
      "blueprint_id": "BLP-002",
      "blueprint_name": "Core banking binary reversing lab scan",
      "rules": [
        {
          "rule_id": "RUL-002",
          "rule_description": "Core banking software package must pass reversing lab/security scans.",
          "target_entity": "ServiceInstance",
          "definitions": [
            {
              "definition_id": "DEF-002",
              "pre_condition": {
                "and": [
                  {
                    "attribute": "properties.svcid",
                    "operator": "equals",
                    "value": "SVC-003"
                  }
                ]
              },
              "SecurityCondition": {
                "or": [
                  {
                    "not": {
                      "attribute": "properties.sast_status",
                      "operator": "equals",
                      "value": "Passed"
                    }
                  },
                  {
                    "not": {
                      "attribute": "properties.dast_status",
                      "operator": "equals",
                      "value": "Passed"
                    }
                  }
                ]
              },
              "outcome": {
                "risk": "High",
                "finding": "Core banking service instance has not passed reversing lab/security scans (SAST/DAST).",
                "requirement": [
                  {
                    "description": "Core banking software package must pass reversing lab scan.",
                    "tech_control_id": "TEC-452"
                  }
                ]
              }
            }
          ]
        }
      ]
    },
    {
      "blueprint_id": "BLP-003",
      "blueprint_name": "MDEX segregation against lateral movement",
      "rules": [
        {
          "rule_id": "RUL-003",
          "rule_description": "Prevent lateral movement/crosstalk by enforcing segregation for intra-MDEX network flows.",
          "target_entity": "Connection",
          "definitions": [
            {
              "definition_id": "DEF-003",
              "pre_condition": {
                "and": [
                  {
                    "security_fragment_ref": "SFR-001"
                  },
                  {
                    "attribute": "properties.source_security_domain",
                    "operator": "equals",
                    "value": "MSBIC_MDEX"
                  },
                  {
                    "attribute": "properties.destination_security_domain",
                    "operator": "equals",
                    "value": "MSBIC_MDEX"
                  }
                ]
              },
              "SecurityCondition": {
                "or": [
                  {
                    "not": {
                      "attribute": "properties.source_security_zone",
                      "operator": "equals",
                      "value": "destination_security_zone"
                    }
                  }
                ]
              },
              "outcome": {
                "risk": "High",
                "finding": "Potential intra-MDEX lateral movement: cross-zone network flow detected without explicit segregation evidence.",
                "requirement": [
                  {
                    "description": "Deploy dedicated VLAN and VLAN ACL on MDEX network switches.",
                    "tech_control_id": "TEC-162"
                  },
                  {
                    "description": "Deploy leased line and IP address validation controls on MDEX network.",
                    "tech_control_id": "TEC-162"
                  }
                ]
              }
            }
          ]
        }
      ]
    }
  ]
}
```

#### ReviewFinding（JSON）

```json
{
  "ReviewFinding": [
    {
      "finding_id": "FIN-001",
      "triggered_blueprint_id": "BLP-002",
      "triggered_rule_id": "RUL-002",
      "triggered_definition_id": "DEF-002",
      "violating_entity_type": "ServiceInstance",
      "violating_entity_id": "SIN-003",
      "violation_summary": "Core banking service instance has not passed reversing lab/security scans (SAST/DAST).",
      "violating_condition_snapshot": {
        "or": [
          {
            "not": {
              "attribute": "properties.sast_status",
              "operator": "equals",
              "value": "Passed"
            }
          },
          {
            "not": {
              "attribute": "properties.dast_status",
              "operator": "equals",
              "value": "Passed"
            }
          }
        ]
      },
      "risk": "High",
      "requirement": [
        {
          "description": "Core banking software package must pass reversing lab scan.",
          "tech_control_id": "TEC-452"
        }
      ],
      "status": "open"
    },
    {
      "finding_id": "FIN-002",
      "triggered_blueprint_id": "BLP-003",
      "triggered_rule_id": "RUL-003",
      "triggered_definition_id": "DEF-003",
      "violating_entity_type": "Connection",
      "violating_entity_id": "CON-001",
      "violation_summary": "Intra-MDEX cross-zone flow detected (vanilla-dmz -> external). Segregation controls (VLAN ACL, IP validation) required.",
      "violating_condition_snapshot": {
        "security_fragment_ref": "SFR-001"
      },
      "risk": "High",
      "requirement": [
        {
          "description": "Deploy dedicated VLAN and VLAN ACL on MDEX network switches.",
          "tech_control_id": "TEC-162"
        },
        {
          "description": "Deploy leased line and IP address validation on MDEX network.",
          "tech_control_id": "TEC-162"
        }
      ],
      "status": "open"
    },
    {
      "finding_id": "FIN-003",
      "triggered_blueprint_id": "BLP-001",
      "triggered_rule_id": "RUL-001",
      "triggered_definition_id": "DEF-001",
      "violating_entity_type": "Connection",
      "violating_entity_id": "CON-003",
      "violation_summary": "RDP access to MDEX without Kerberos/AD Group controls detected (destination uses Local Account/Local Group).",
      "violating_condition_snapshot": {
        "or": [
          {
            "not": {
              "attribute": "properties.destination_authentication_methods",
              "operator": "equals",
              "value": "Kerberos"
            }
          },
          {
            "not": {
              "attribute": "properties.destination_authorization_methods",
              "operator": "equals",
              "value": "AD Group"
            }
          }
        ]
      },
      "risk": "High",
      "requirement": [
        {
          "description": "Adopt COD AD group and IAM TAC to track and manage RDP authentication and authorization.",
          "rule_instance_id": "TEC-026"
        },
        {
          "description": "Onboard system entitlements into COD standard IGA (SailPoint).",
          "rule_instance_id": "TEC-026"
        }
      ],
      "status": "open"
    }
  ]
}
```

#### Node（JSON）

```json
{
  "Node": [
    {
      "node_id": "NOD-001",
      "node_name": "Corebanking Client (Vanilla)",
      "appid": "APP-001",
      "components": [
        {
          "cmpid": "CMP-001",
          "cmpname": "Corebanking Client Service Instance in Corebanking Client (Vanilla)"
        }
      ]
    },
    {
      "node_id": "NOD-002",
      "node_name": "Corebanking Client (MS-DMZ)",
      "appid": "APP-002",
      "components": [
        {
          "cmpid": "CMP-002",
          "cmpname": "Corebanking Client Service Instance in Corebanking Client (MS-DMZ)"
        },
        {
          "cmpid": "CMP-006",
          "cmpname": "Remote Desktop Service Instance in Corebanking Client (MS-DMZ)"
        }
      ]
    },
    {
      "node_id": "NOD-003",
      "node_name": "Corebanking Service",
      "appid": "APP-003",
      "components": [
        {
          "cmpid": "CMP-003",
          "cmpname": "Corebanking Backend Service Instance - Core in Corebanking Service"
        },
        {
          "cmpid": "CMP-007",
          "cmpname": "Corebanking Backend Service Instance - Counter in Corebanking Service"
        },
        {
          "cmpid": "CMP-008",
          "cmpname": "Corebanking Backend Service Instance - Reporter in Corebanking Service"
        },
        {
          "cmpid": "CMP-009",
          "cmpname": "Corebanking Backend Service Instance - Operation Management in Corebanking Service"
        },
        {
          "cmpid": "CMP-010",
          "cmpname": "Corebanking Backend Service Instance - Endpoint Authorization in Corebanking Service"
        },
        {
          "cmpid": "CMP-011",
          "cmpname": "Corebanking Backend Service Instance - Judicial control in Corebanking Service"
        },
        {
          "cmpid": "CMP-012",
          "cmpname": "Corebanking Backend Service Instance - AntiMoney Landering in Corebanking Service"
        }
      ]
    },
    {
      "node_id": "NOD-004",
      "node_name": "MSBIC Branch OA Desktop",
      "appid": "APP-004",
      "components": [
        {
          "cmpid": "CMP-004",
          "cmpname": "Remote Desktop Client Instance in MSBIC Branch OA Desktop"
        }
      ]
    },
    {
      "node_id": "NOD-005",
      "node_name": "MSMS Branch OA Desktop",
      "appid": "APP-005",
      "components": [
        {
          "cmpid": "CMP-005",
          "cmpname": "Remote Desktop Client Instance in MSMS Branch OA Desktop"
        }
      ]
    }
  ]
}
```

---

## 附录2：完整架构关系图

基于第3章所有实体实例，以下mermaid图展示了完整的CALM架构关系：以Node为视图参照，展示Node-App-Component三层结构、连接关系、继承关系以及审计实体。

```mermaid
graph TB
    %% === Top Section: Inheritance and Audit ===
    subgraph TOP[" "]
        direction LR
        %% === Inheritance Relationship ===
        subgraph LEGEND["📖 Inheritance Relationship"]
            direction LR
            LG1["Component"] -.-> |"inherits from"| LG2["System → Application <br/>→ Service → ServiceInstance"]
            LG2 -.-> LG3["DeploymentModel + <br/>ArchitectureModel"]
            LG5["Coupon"] -.-> |"snapshot of"| LG4["Connection"] 
            LG4 <--> |"associates"| LG1
        end
        
        %% === Audit Entities Area ===
        subgraph AUDIT["🔍 Audit Entities"]
            direction TB
            SFR001["📋 SFR-001<br/>Network flow to MDEX<br/>(scope)"]
            
            subgraph BLUEPRINTS["📘 SecurityBlueprints"]
                BLP001["BLP-001<br/>MDEX RDP access control"]
                BLP002["BLP-002<br/>Core banking scan"]
                BLP003["BLP-003<br/>MDEX segregation"]
            end
            
            subgraph FINDINGS["⚠️ ReviewFindings"]
                FIN001["🔴 FIN-001<br/>SAST/DAST Failed<br/>SIN-003"]
                FIN002["🔴 FIN-002<br/>Cross-zone Flow<br/>CON-001"]
                FIN003["🔴 FIN-003<br/>RDP Auth Issue<br/>CON-003"]
            end
            
            SFR001 --> BLP001
            SFR001 --> BLP003
            BLP002 --> FIN001
            BLP003 --> FIN002
            BLP001 --> FIN003
        end
    end

    %% === Bottom Section: Main Architecture ===
    subgraph MAIN["CALM Architecture View"]
        direction TB
        subgraph NOD001["🖥️ NOD-001: Corebanking <br/>Client (Vanilla)<br/>📱 APP-001"]
            SPACE001[" "]
            CMP001["CMP-001<br/>Corebanking Client<br/>Service Instance<br/>🔵 SVC-001 → SIN-001"]
            SPACE001 ~~~ CMP001
        end
        
        subgraph NOD002["🖥️ NOD-002: Corebanking <br/>Client (MS-DMZ)<br/>📱 APP-002"]
            SPACE002[" "]
            CMP002["CMP-002<br/>Corebanking Client<br/>Service Instance<br/>🔵 SVC-001 → SIN-001"]
            CMP006["CMP-006<br/>Remote Desktop<br/>Service Instance<br/>🟠 SVC-002 → SIN-002"]
            SPACE002 ~~~ CMP002
            SPACE002 ~~~ CMP006
        end
        
        subgraph NOD003["☁️ NOD-003: Corebanking <br/> Service 📱 APP-003"]
            CMP003["CMP-003<br/>Core<br/>🟢 SVC-003 → SIN-003"]
            CMP007["CMP-007<br/>Counter<br/>🟢 SVC-003 → SIN-004"]
            CMP008["CMP-008<br/>Reporter<br/>🟢 SVC-003 → SIN-005"]
            CMP009["CMP-009<br/>Operation Mgmt<br/>🟢 SVC-003 → SIN-006"]
            CMP010["CMP-010<br/>Endpoint Auth<br/>🟢 SVC-003 → SIN-007"]
            CMP011["CMP-011<br/>Judicial Control<br/>🟢 SVC-003 → SIN-008"]
            CMP012["CMP-012<br/>AntiMoney Landering<br/>🟢 SVC-003 → SIN-009"]
        end
        
        subgraph NOD004["🖥️ NOD-004: MSBIC Branch <br/>OA Desktop<br/>📱 APP-004"]
            SPACE004[" "]
            CMP004["CMP-004<br/>Remote Desktop<br/>Client Instance<br/>🟡 SVC-004 → SIN-010"]
            SPACE004 ~~~ CMP004
        end
        
        subgraph NOD005["🖥️ NOD-005: MSMS Branch <br/>OA Desktop<br/>📱 APP-005"]
            SPACE005[" "]
            CMP005["CMP-005<br/>Remote Desktop<br/>Client Instance<br/>🟡 SVC-004 → SIN-010"]
            SPACE005 ~~~ CMP005
        end

        %% === Connection Relationships ===
        CMP001 -->|CON-001<br/>🌐 Network<br/>TCP:7012,3022...| CMP003
        CMP002 -->|CON-002<br/>🌐 Network<br/>TCP:7012,3022...| CMP003
        CMP004 -->|CON-003<br/>🖥️ RDP<br/>TCP:3389| CMP006
        CMP005 -->|CON-004<br/>🖥️ RDP<br/>TCP:3389| CMP006
        CMP012 -.->|CON-005<br/>🔄 IPC| CMP011
        CMP010 -.->|CON-006<br/>🔄 IPC| CMP009
        CMP012 -.->|CON-007<br/>🔄 IPC| CMP008
    end

    %% Invisible connection to control layout
    TOP ~~~ MAIN

    %% Style Definitions
    classDef nodeStyle fill:#f9f9f9,stroke:#333,stroke-width:2px
    classDef clientComp fill:#e3f2fd,stroke:#1976d2,stroke-width:2px
    classDef serviceComp fill:#e8f5e8,stroke:#388e3c,stroke-width:2px
    classDef rdpComp fill:#fff3e0,stroke:#f57c00,stroke-width:2px
    classDef auditStyle fill:#fff8e1,stroke:#fbc02d,stroke-width:2px
    classDef findingStyle fill:#ffebee,stroke:#d32f2f,stroke-width:2px
    classDef topContainer fill:none,stroke:none
    classDef spacer fill:none,stroke:none,color:transparent

    class NOD001,NOD002,NOD003,NOD004,NOD005 nodeStyle
    class CMP001,CMP002 clientComp
    class CMP003,CMP007,CMP008,CMP009,CMP010,CMP011,CMP012 serviceComp
    class CMP004,CMP005,CMP006 rdpComp
    class SFR001,BLP001,BLP002,BLP003 auditStyle
    class FIN001,FIN002,FIN003 findingStyle
    class TOP topContainer
    class SPACE001,SPACE002,SPACE003,SPACE004,SPACE005 spacer
```

---

---

## Raw Payload → CALM 字段映射表（Control Exception）

下表用于说明 **Control Exception 表单原始输入（raw payload）** 与 **CALM 实体字段** 的对应关系，便于基于 YAML 规则直接引用字段而无需改代码。

| Raw payload 路径 | CALM 实体路径 | 说明 |
| --- | --- | --- |
| `metadata.checklist.data_perimeter.pii` | `ServiceInstance.properties.data_perimeter.pii` | 同时会写入 `System.properties.from_control_exception_form.data_perimeter.pii` |
| `metadata.checklist.data_perimeter.mnpi` | `ServiceInstance.properties.data_perimeter.mnpi` | 同上 |
| `metadata.checklist.scenario_options.privileged_access` | `System.properties.from_control_exception_form.scenario_options.privileged_access` | 同时写入每条 `Connection.properties.scenario_options` |
| `metadata.checklist.data_connections[].src_object` | `Connection.properties.source_object` | 每行 Data Connection → 一条 Connection |
| `metadata.checklist.data_connections[].src_domain` | `Connection.properties.source_domain` |  |
| `metadata.checklist.data_connections[].src_zone` | `Connection.properties.source_zone` |  |
| `metadata.checklist.data_connections[].dst_object` | `Connection.properties.destination_object` |  |
| `metadata.checklist.data_connections[].dst_domain` | `Connection.properties.destination_domain` |  |
| `metadata.checklist.data_connections[].dst_zone` | `Connection.properties.destination_zone` |  |
| `metadata.checklist.data_connections[].accessed_protocol` | `Connection.properties.protocol` | 用于协议/认证相关规则 |
| `metadata.checklist.data_connections[].payload_data` | `Connection.properties.payload_data` | 用于数据敏感性/加密规则 |
| `metadata.checklist.data_connections[].control_exception_types[]` | `Connection.connection_type_id` + `Connection.properties.control_exception_types[]` | `connection_type_id` 由类型映射生成 |
| `metadata.checklist.data_connections[].implemented_controls.authn_authz.value` | `Connection.properties.implemented_controls.authn_authz.value` |  |
| `metadata.checklist.data_connections[].implemented_controls.encryption.value` | `Connection.properties.implemented_controls.encryption.value` |  |
| `metadata.checklist.data_connections[].implemented_controls.privileged_access.value` | `Connection.properties.implemented_controls.privileged_access.value` |  |
| `metadata.checklist.exception_expiry` | `System.properties.from_control_exception_form.exception_expiry` |  |
| `metadata.checklist.business_justification` | `System.sysname` / `Application.properties.business_context` | 作为系统/业务上下文 |
| `metadata.checklist.firewall_details[]` | `Coupon (Firewall Flow)` | 生成 Coupon 快照 |
| `metadata.checklist.proxy_details[]` | `Coupon (Proxy Flow)` | 生成 Coupon 快照 |

---

## Control Exception CALM v4（最终定稿）

以下为 **Control Exception Review** 的最终 CALM 样式格式（v4）。该版本遵循 CALM 的层级结构，不改动现有表单输入的键和值，仅调整展现层级与映射落位。

### 1) ID 命名规则

- `System`：`cmdb_sysid` 与 `sysname` 目前保持空值（未来由 CMDB 提供）。
- `Application / Service / ServiceInstance / Component / Connection` 的 `xxname` 均为空值。
- `xxid` 依实体数量顺序生成：  
  - `APP-01`, `APP-02`  
  - `SVC-01`, `SVC-02`  
  - `SVCINT-01`, `SVCINT-02`  
  - `CMP-01`, `CMP-02`  
  - `CON-01`, `CON-02`  
  - `CONTYP-01`, `CONTYP-02`  
  - `COPTYP-01`, `COPTYP-02`  
  - `COP-01`, `COP-02`  
  - `ARCHM-01`, `DEPM-01`

### 2) 实体继承关系（核心层级逻辑）

- **Component** 不自行产生业务属性，仅继承：  
  `from_system` / `from_application` / `from_service` / `from_serviceinstance`
- **Connection** 不自行产生业务属性，仅继承：  
  `properties.from_connection_type`  
  同时通过 `source` / `destination` 指向 Component，并在其 `properties.from_component` 中体现来源。
- **Coupon** 不自行产生业务属性，仅继承：  
  `properties.from_connection` + `properties.from_coupon_type`

### 3) v4 CALM 样式结构（示意）

```json
{
  "System": [
    {
      "cmdb_sysid": "",
      "sysname": "",
      "description": "",
      "properties": {
        "from_control_exception_form": {
          "basis_options": {},
          "scenario_options": {},
          "scenario_other_context": "",
          "business_justification": "",
          "data_perimeter": {
            "arr20": { "question": "ARR 2.0", "value": "" },
            "isc": { "question": "ISC", "value": "" },
            "pii": { "question": "PII", "value": "" },
            "mnpi": { "question": "MNPI", "value": "" },
            "external_transfer": { "question": "Any data involving update, upgrade, upload or download accessed through External?", "value": "" },
            "prod_data": { "question": "Any PROD Data involved?", "value": "" },
            "prod_mdex": { "question": "Any connection through [Prod] COD MDEX domains?", "value": "" },
            "prod_mssip": { "question": "Any connection through [Prod] COD MSSIP domains?", "value": "" }
          },
          "architecture_description": "",
          "architecture_files": [],
          "exception_expiry": "",
          "integrator_reviewer": ""
        }
      }
    }
  ],
  "Application": [
    { "appid": "APP-01", "appname": "", "cmdb_sysid": "" }
  ],
  "Service": [
    { "svcid": "SVC-01", "svcname": "", "appid": "APP-01" }
  ],
  "ServiceInstance": [
    {
      "svcint_id": "SVCINT-01",
      "svcintname": "",
      "svcid": "SVC-01",
      "properties": {
        "from_control_exception_form": {
          "src_object": "",
          "src_domain": "",
          "src_zone": ""
        }
      }
    },
    {
      "svcint_id": "SVCINT-02",
      "svcintname": "",
      "svcid": "SVC-01",
      "properties": {
        "from_control_exception_form": {
          "dst_object": "",
          "dst_domain": "",
          "dst_zone": ""
        }
      }
    }
  ],
  "Component": [
    {
      "cmpid": "CMP-01",
      "cmpname": "",
      "svcint_id": "SVCINT-01",
      "properties": {
        "from_system": { "...": "..." },
        "from_application": { "...": "..." },
        "from_service": { "...": "..." },
        "from_serviceinstance": { "...": "..." }
      }
    }
  ],
  "ConnectionType": [
    {
      "connection_type_id": "CONTYP-01",
      "connection_type_name": "",
      "properties": {
        "from_control_exception_form": {
          "id": "#1",
          "original_id": "",
          "row_index": 1,
          "control_exception_types": [],
          "accessed_protocol": "",
          "payload_data": "",
          "implemented_controls": {},
          "purpose": ""
        }
      }
    }
  ],
  "Connection": [
    {
      "conid": "CON-01",
      "source": {
        "component_id": "CMP-01",
        "properties": { "from_component": { "...": "..." } }
      },
      "destination": {
        "component_id": "CMP-02",
        "properties": { "from_component": { "...": "..." } }
      },
      "connection_type_id": "CONTYP-01",
      "properties": {
        "from_connection_type": { "...": "..." }
      }
    }
  ],
  "CouponType": [
    {
      "coupon_type_id": "COPTYP-01",
      "coupon_type_name": "FIREWALL_FLOW",
      "properties": { "from_control_exception_form": { "...": "..." } }
    }
  ],
  "Coupon": [
    {
      "coupon_id": "COP-01",
      "coupon_type_id": "COPTYP-01",
      "triggering_connection_id": "CON-01",
      "expiry": "",
      "justification": "",
      "properties": {
        "from_connection": { "...": "..." },
        "from_coupon_type": { "...": "..." }
      }
    }
  ],
  "ArchitectureModel": [
    {
      "architecture_model_id": "ARCHM-01",
      "architecture_model": "",
      "properties": { "from_control_exception_form": { "...": "..." } }
    }
  ],
  "DeploymentModel": [
    { "deployment_model_id": "DEPM-01", "deployment_model_name": "" }
  ],
  "SecurityFragment": [
    { "fragment_id": "FRG-00001", "fragment_name": "", "target_entity": "", "condition": {} }
  ],
  "SecurityBlueprint": [
    {
      "pattern_id": "00001",
      "blueprint_name": "",
      "target_entity": "",
      "rules": [
        {
          "rule_id": "00001",
          "target_entity": "Connection",
          "definitions": [
            {
              "tcep_cr_id": "DS-EN01-R4",
              "condition": { "security_fragment_ref": "FRG-00001" },
              "outcome": {
                "violation_summary": "",
                "risk": "Moderate",
                "requirement": [{ "description": "" }]
              }
            }
          ]
        }
      ]
    }
  ],
  "ReviewFinding": [
    {
      "finding_id": "FIN-01",
      "pattern_id": "00001",
      "tcep_cr_id": "DS-EN01-R4",
      "violating_entity_type": "Connection",
      "violating_entity_id": "CON-01",
      "violating_condition_snapshot": {
        "connection_index": 1,
        "matched_conditions": []
      },
      "violation_summary": "",
      "risk": "Moderate",
      "requirement": [{ "description": "" }],
      "recommendation": [],
      "status": "open",
      "properties": {
        "from_review_process": {
          "finding_type": "Rule-Based Pre-Review",
          "classification": "Requirement",
          "suppress": false
        }
      }
    }
  ]
}
```

### 4) 关键字段更新说明

- `expected_exception` 统一升级为 `exception_expiry`。  
- Data Perimeter 使用「问题文本 + 值」形式展示（question/value）。  
- ReviewFinding 风险等级使用 `Low / Moderate / High / Critical`。  
- SecurityFragment / SecurityBlueprint / ReviewFinding 保留 `fragment_id / pattern_id / tcep_cr_id`。
- ConnectionType 行号：`from_control_exception_form.id` 使用 `#<row_index>`，原始表单行 id 放在 `original_id`。
- ReviewFinding 快照：`violating_condition_snapshot` 仅保留 `connection_index` 与 `matched_conditions`（不包含连接全量属性）。
- `firewall_details` / `proxy_details` 不再出现在 `System`，仅用于生成 `Coupon` 快照。
