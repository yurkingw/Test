# HTTPS Certificates Guide

This note explains how CSAD handles HTTPS certificates in local/dev and how to swap in enterprise-issued certs later.

## Local Self-Signed Setup

- Certificate files live under `certs/` (ignored by Git).
- Docker mounts `certs/` into the backend and frontend containers at `/certs`.
- Backend HTTPS config is read from `backend/app/config/app_config.yaml` and environment variables.

Current defaults:

- `backend/.env`
  - `HTTPS_ENABLED=true`
  - `HTTPS_CERT_PATH=/certs/localhost.crt`
  - `HTTPS_KEY_PATH=/certs/localhost.key`
  - `HTTPS_CA_PATH=` (empty unless you have a CA chain)
- `docker-compose.yml`
  - `./certs:/certs:ro`

## Enterprise CA Certificates

When you have real certificates:

1. Replace files under `certs/` with your enterprise-issued cert and key.
2. Update `backend/.env` to point to the new paths if needed.
3. Keep `certs/` in `.gitignore` to avoid committing private keys.

## Browser Trust (Local)

When using self-signed certs, your browser may block API calls until the cert is trusted.

- Open `https://localhost:8000` and accept the warning.
- Then open `https://localhost:3000`.

