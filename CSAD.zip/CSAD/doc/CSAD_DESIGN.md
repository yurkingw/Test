# CSAD: System Design and Development Plan

This document provides a comprehensive overview of the system design, architecture, and development plan for the CALM Security Architecture Designer (CSAD).

---

## 1. Project Vision & Goals

**Vision**: To create an intelligent, enterprise-ready platform for security architecture design and auditing.

**Core Objectives**:
- **Modeling**: Describe complex system architectures using the structured and traceable **CALM** model.
- **Automation**: Automatically analyze architectures, identify risks, and manage review cases.
- **Standardization**: Conduct compliance audits based on predefined **Security Blueprints**.
- **Integration**: Seamlessly integrate with enterprise workflows like **Jira** and **Active Directory**.

---

## 2. Core Concept: The CALM Model

**CALM**: **C**ontextual, **A**ctionable, **L**ayered, **M**aterialized

- **Layered**: `System` -> `Application` -> `Service` -> `Component`
- **Contextual**: Each layer carries its own properties (e.g., security domain).
- **Materialized**: Component properties are aggregated from their context, ensuring full traceability.
- **Actionable**: Automatically generate risk reports (`Finding`) and configuration credentials (`Coupon`).

---

## 3. System Architecture

We will adopt a modern, decoupled frontend-backend architecture, containerized with Docker.

```mermaid
graph TD;
    subgraph User Side
        A[User Browser]
    end
    subgraph Server Side (Docker Compose)
        B(Frontend - React)
        C(Backend - FastAPI)
        D(Database - PostgreSQL)
    end

    A -- HTTPS --> B;
    B -- REST API --> C;
    C -- SQLAlchemy --> D;
```

- **Frontend (Client)**: A single-page application (SPA) built with React. It will provide the user interface for file uploads, displaying generated security designs, and an AI chat window.
- **Backend (Server)**: A RESTful API server built with Python and FastAPI. It handles the core logic, including document parsing, analysis, artifact generation, and external integrations.
- **Processing Engine**: A module within the backend responsible for implementing the rule-based (CALM) and LLM-based analysis.
- **Data Store**: A **PostgreSQL database** is the solution for storing core entities. It will use the `JSONB` data type to store the flexible `SecurityBlueprint` and `ReviewFinding` entities.

### Enterprise Integration Architecture

Two key features elevate the system to an enterprise-grade application:

#### Jira Service Management Integration
- **Inbound (Webhook)**: Jira tickets automatically create `CaseReview` tasks in CSAD.
- **Outbound (REST API)**: CSAD updates the Jira ticket status upon task completion.

#### Multi-Tenancy & Security
- **Authentication**: Integrate with Enterprise AD/AAD using OAuth2/OIDC.
- **Data Isolation**: Add `user_id` and `group_id` to all relevant data models. All database queries **MUST** filter by the current user's context to prevent data leakage.

---

## 4. Core Components & Functionality

### 4.1. Web UI

-   **AI Chat Window**: A conversational interface allowing users to interact with a design consultation AI.
-   **File Upload**: A component for uploading design documents.
-   **Control Panel**: Options to select the analysis engine (e.g., "Rule-Based" or "AI-Powered").
-   **Results Display**: Sections to render the structured design, Mermaid.js diagrams, and IaC coupons.

### 4.2. Document Parser & Analyzer

This is the core of the backend. It will extract text and pass it to the selected **Processing Engine**.

#### 4.2.1. CALM-Based Engine (Rule-Based)
-   Queries the PostgreSQL database for `SecurityBlueprint` and `ReviewFinding` entities.
-   Searches for keywords and patterns in the input to identify components and data flows.
-   Retrieves associated risks and controls.

#### 4.2.2. LLM-Based Engine (AI-Powered)
-   Sends the document's text or chat messages to an external LLM API (e.g., OpenAI).
-   Uses a carefully crafted prompt to instruct the LLM to identify components, data flows, risks, and controls, and to format the output.

### 4.3. Architecture Diagram Generator

-   Generates a textual representation of the architecture in **Mermaid.js syntax** based on the identified components and data flows.

### 4.4. Coupon Generator

-   Analyzes data flows to generate structured JSON files for IaC (Infrastructure-as-Code) purposes, such as firewall rules, proxy configurations, or IAM policies.

---

## 5. Data Models

### 5.1. CALM Data Models (PostgreSQL/JSONB)

The core entities `SecurityBlueprint` and `ReviewFinding` will be stored in PostgreSQL using the `JSONB` data type.

**Table Structure:**
1.  `security_blueprints`: `id`, `component_type`, `details` (JSONB)
2.  `review_findings`: `id`, `blueprint_id`, `details` (JSONB)
3.  `users`: For storing user profiles.
4.  `case_reviews`: For tracking tasks from Jira.

**Note**: For multi-tenancy, tables will be extended with `user_id` and/or `group_id` foreign keys.

### 5.2. IaC Coupon (JSON Output)

A structured JSON format for IaC artifacts.

**Example (Firewall Rule):**
```json
{
  "coupon_type": "firewall_rule",
  "version": "1.0",
  "rules": [
    {
      "name": "Allow WebApp to APIGateway",
      "source_component": "WebApp",
      "destination_component": "APIGateway",
      "protocol": "TCP",
      "port": 443,
      "action": "ALLOW"
    }
  ]
}
```

---

## 6. Technology Stack

- **Backend**
  - **Language**: Python 3.11
  - **Framework**: FastAPI
  - **ORM**: SQLAlchemy
  - **Authentication**: `fastapi-users` (for Auth)
  - **HTTP Client**: `httpx` (for Jira API)
  - **Document Processing**: `python-docx`, `mistune`

- **Frontend**
  - **Language**: JavaScript (ES6+) / TypeScript
  - **Framework**: React
  - **Diagramming**: `React Flow`
  - **HTTP Client**: Axios

- **Database**: PostgreSQL

- **Deployment**
  - **Container**: Docker
  - **Orchestration**: Docker Compose

---

## 7. Project MVP1 Requirement Summary

### 7.1. As-Is: Current Completed Status
**Backend Infrastructure**:
- A well-structured (layered into api, core, crud, db, models, schemas) and scalable backend project based on FastAPI has been established.
- Basic services such as configuration management (`core/config.py`) and database session management (`db/session.py`) are ready.
- The project is capable of being deployed via Docker containerization.

**Database & Core Models**:
- A connection to the PostgreSQL database has been established via SQLAlchemy ORM.
- Alembic has been configured for database migrations and has successfully created the two core data tables: `security_blueprints` and `review_findings`.
- The database models (`models`) and data validation models (`schemas`) for SecurityBlueprint and ReviewFinding are fully defined.

**Basic API Services**:
- Standard CRUD (Create, Read, Update, Delete) functionalities have been implemented for SecurityBlueprint and ReviewFinding.
- These functions are exposed via a RESTful API (`/api/v1/endpoints/`), allowing the backend to currently function as a "database for blueprints and risks."

### 7.2. To-Be: Core Features to be Developed for MVP1
**Core Business Logic Engine**:
- **Goal**: To implement the "brain" of the system, enabling it to automatically analyze, match, and generate data, rather than just storing it.
- **Key Task**: Develop an analysis engine that can automatically parse user input, match it against SecurityBlueprints, and intelligently generate ReviewFindings.

**Authentication & Multi-tenancy**:
- **Goal**: To establish a complete user and permission system and implement data isolation.
- **Key Tasks**:
  - **Authentication**: Integrate with enterprise Active Directory / Azure AD for Single Sign-On (SSO).
  - **Permission Model (RBAC)**: Establish Role-Based Access Control, supporting the binding of AD/AAD or local users/groups to roles.
  - **Data Model**: Add new data models related to Users.
  - **Data Isolation**: Add `user_id` and `group_id` fields to all relevant data tables and refactor all CRUD operations to ensure users can only access data belonging to their group.

**Jira Integration**:
- **Goal**: To achieve two-way task synchronization with Jira Service Management.
- **Key Tasks**:
  - **Webhook Reception**: Create an API endpoint to receive Webhook events from Jira.
  - **Data Model**: Add a `CaseReview` data model to manage local review tasks.
  - **Status Synchronization**: Develop logic to call the Jira API to update the status of a Jira Ticket after the local task is completed.

**Artifact Generator (Coupon Generator)**:
- **Goal**: To automatically generate configuration artifacts for other systems based on the analysis results.
- **Key Task**: Develop a feature that can convert approved designs (e.g., firewall, proxy rules) into structured JSON format data (Coupons).

### 7.3. MVP1 Core User Flow: "Control Exception Review"
This is an end-to-end flow that integrates several of the core features mentioned above:

1.  **Input**: The user uploads a Word document in a fixed format as a review request.
2.  **Parsing**: The backend parses the document content into CALM data structure entities based on predefined rules.
3.  **Analysis & Matching**:
    - The user-input CALM entities are compared against predefined SecurityBlueprints (which are also CALM entities).
    - Non-compliant parts are identified, and a list of ReviewFindings (CALM entities) is generated.
4.  **User Interaction & Decision**:
    - The system presents all ReviewFindings to the user in a report format.
    - Each ReviewFinding provides "Accept" or "Reject" options.
    - **Accept**: An evidence upload box appears, requiring the user to upload evidence of implementing the corresponding control (documents/screenshots).
    - **Reject**: The task can be assigned to another designated user for further processing.
5.  **Process Closure & Output**:
    - When the process is finally approved and closed:
    - The system saves all data and the final report for this review.
    - The status of the associated Jira Ticket is updated synchronously.
    - JSON Coupons are generated for relevant designs (e.g., firewall, proxy) for consumption by downstream systems.

### 7.4. AI Feature Integration Strategy
In the "Analysis & Matching" stage, two optional modes will be provided to the user:

- **Rule-Based Mode**: Generates ReviewFindings deterministically through predefined parsing and matching rules.
- **AI-Powered Mode**: Calls the OpenAI API, sending the content of the user-uploaded document and a guiding prompt to the AI, which then directly handles parsing, comparison, and the generation of ReviewFindings.
- The user can **explicitly choose** which mode to use at runtime.

---

## 8. Development Roadmap

| Phase | Key Tasks | Status |
| :--- | :--- | :--- |
| **Phase 1: Foundation & MVP Core** | 1. **Implement User Auth (AAD)** & Data Isolation | ⏳ **Next Up** |
| | 2. DB & Backend Setup | ✅ Completed |
| | 3. Core CALM Engine API (CRUD) | ✅ Completed |
| | 4. **Jira Integration** (Inbound & Outbound) | To-Do |
| | 5. Core Generators (Diagram/Coupon) | To-Do |
| | 6. Frontend Integration for MVP | ✅ Partially Completed |
| **Phase 2: Advanced Features** | 1. Interactive Diagram Builder (`React Flow`) | To-Do |
| | 2. AI Chat & LLM Integration | To-Do |
| | 3. Admin Interface for Data Management | To-Do |
| **Phase 3: Enterprise-Ready** | 1. Extend Coupon Generator (Proxy, IAM) | To-Do |
| | 2. Full CI/CD Pipeline | To-Do |
| | 3. Advanced User/Permission Management | To-Do |
