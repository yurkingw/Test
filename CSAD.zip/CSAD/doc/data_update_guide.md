# Data Update Guide (CSV)

This guide documents how to update CSV-backed reference data without touching code.

## SecDesign Members

Source file:
- `backend/secdesign_members.sample.csv` (sample format)
- Actual path configured by `SECDESIGN_MEMBERS_CSV` in `backend/.env`

CSV headers:
- `SecDesign Member Name`
- `SecDesign Member LoginID`

How to update:
1. Edit the CSV at the path configured in `SECDESIGN_MEMBERS_CSV`.
2. Apply the update by either:
   - Restarting the backend (auto sync on startup), or
   - Calling `POST /api/v1/secdesign-members/refresh`.

## Security Domain / Security Zone Options

Source file:
- `backend/security_options.sample.csv` (sample format)
- Actual path configured by `SECURITY_OPTIONS_CSV` in `backend/.env`

CSV headers:
- `Security Domain`
- `Security Zone`
- `Component`
- `Subnet Boundary`
- `Protocol Port`

How to update:
1. Edit the CSV at the path configured in `SECURITY_OPTIONS_CSV`.
2. Apply the update by either:
   - Restarting the backend (auto sync on startup), or
   - Calling `POST /api/v1/insight/refresh`.

Notes:
- The domain/zone/component/subnet/protocol options are read from the local database only.
- The UI refresh button for domain/zone was hidden for MVP1.

## AAD (Entra ID) Group Sync

Purpose:
- Sync AAD group members to local role assignments (Requestor/Reviewer/Auditor).

Configuration:
- `backend/.env` (or injected env in Docker):
  - `AAD_CLIENT_ID`
  - `AAD_CLIENT_SECRET`
  - `AAD_TENANT_ID`
  - `AAD_AUTHORITY`
  - `AAD_REDIRECT_URI`
  - `AAD_FRONTEND_REDIRECT_URI`
  - `AAD_GRAPH_BASE_URL`
  - `AAD_GRAPH_SCOPE`
  - `AAD_GROUP_TO_ROLES_JSON` (JSON map of AAD group object ID → role list)

How to sync:
1. Ensure AAD env vars are set.
2. Call `POST /api/v1/auth/aad/sync-groups`.
3. Query `GET /api/v1/auth/aad/groups` to verify cached users.

Notes:
- The sync uses client-credentials flow and AAD Graph API.
- Update `AAD_GROUP_TO_ROLES_JSON` to change role bindings.
