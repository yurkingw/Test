"""Add security component/subnet boundary options tables.

Revision ID: 20250320_05
Revises: 20250320_04
Create Date: 2025-03-20 00:00:05
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "20250320_05"
down_revision = "20250320_04"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "security_component_options",
        sa.Column("name", sa.String(), primary_key=True, index=True),
        sa.Column("fetched_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )
    op.create_table(
        "subnet_boundary_options",
        sa.Column("value", sa.String(), primary_key=True, index=True),
        sa.Column("fetched_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )


def downgrade() -> None:
    op.drop_table("subnet_boundary_options")
    op.drop_table("security_component_options")
