"""Add protocol port options table.

Revision ID: 20250320_06
Revises: 20250320_05
Create Date: 2025-03-20 00:00:06
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "20250320_06"
down_revision = "20250320_05"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "protocol_port_options",
        sa.Column("value", sa.String(), primary_key=True, index=True),
        sa.Column("fetched_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )


def downgrade() -> None:
    op.drop_table("protocol_port_options")
