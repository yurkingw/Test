"""Add SecDesign member table.

Revision ID: 20250320_04
Revises: 20250320_03
Create Date: 2025-12-18
"""

from alembic import op
import sqlalchemy as sa


revision = "20250320_04"
down_revision = "20250320_03"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "secdesign_members",
        sa.Column("login_id", sa.String(), primary_key=True, index=True),
        sa.Column("name", sa.String(), nullable=False),
    )


def downgrade() -> None:
    op.drop_table("secdesign_members")
