"""Add security domain/zone option tables.

Revision ID: 20250320_03
Revises: 20250320_02
Create Date: 2025-12-18
"""

from alembic import op
import sqlalchemy as sa


revision = "20250320_03"
down_revision = "20250320_02"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "security_domain_options",
        sa.Column("name", sa.String(), primary_key=True, index=True),
        sa.Column("fetched_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )
    op.create_table(
        "security_zone_options",
        sa.Column("name", sa.String(), primary_key=True, index=True),
        sa.Column("fetched_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )


def downgrade() -> None:
    op.drop_table("security_zone_options")
    op.drop_table("security_domain_options")
