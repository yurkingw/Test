"""add aad users table

Revision ID: 20250320_07
Revises: 20250320_06_add_protocol_port_options
Create Date: 2025-03-20
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision = "20250320_07"
down_revision = "20250320_06_add_protocol_port_options"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "aad_users",
        sa.Column("login_id", sa.String(), primary_key=True),
        sa.Column("display_name", sa.String(), nullable=True),
        sa.Column("email", sa.String(), nullable=True),
        sa.Column("role", sa.String(), nullable=True),
        sa.Column("group_ids", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("updated_at", sa.DateTime(), server_default=sa.func.now(), nullable=False),
    )


def downgrade() -> None:
    op.drop_table("aad_users")
