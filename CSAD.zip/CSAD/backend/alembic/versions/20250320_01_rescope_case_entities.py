"""Rescope case entities to string IDs, new status set, evidence/chat/coupon/history

Revision ID: rescope_case_entities
Revises: 9e917facf687
Create Date: 2025-03-20 00:00:00
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "rescope_case_entities"
down_revision: Union[str, Sequence[str], None] = "8925221ba749"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Strong cleanup to avoid dependency errors that abort the transaction
    op.execute("DROP TABLE IF EXISTS evidence CASCADE")
    op.execute("DROP TABLE IF EXISTS chat_messages CASCADE")
    op.execute("DROP TABLE IF EXISTS coupons CASCADE")
    op.execute("DROP TABLE IF EXISTS status_history CASCADE")
    op.execute("DROP TABLE IF EXISTS review_findings CASCADE")
    op.execute("DROP TABLE IF EXISTS case_reviews CASCADE")

    # Drop legacy enums to prevent name collisions
    op.execute('DROP TYPE IF EXISTS "casestatus" CASCADE')
    op.execute('DROP TYPE IF EXISTS "evidencedecision" CASCADE')
    op.execute('DROP TYPE IF EXISTS "chatsender" CASCADE')

    # Use simple VARCHAR columns for status/decision/sender to avoid enum collisions
    status_enum = None
    evidence_enum = None
    chat_enum = None

    op.create_table(
        "case_reviews",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("name", sa.String(), nullable=False, index=True),
        sa.Column("description", sa.String(), nullable=True),
        sa.Column("status", sa.String(), nullable=False, server_default="draft"),
        sa.Column("review_type", sa.String(), nullable=False, server_default="control_exception"),
        sa.Column("ticket_id", sa.String(), nullable=True, index=True),
        sa.Column("owner_id", sa.String(), nullable=True, index=True),
        sa.Column("design_payload", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("final_snapshot", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column("system_id", sa.String(), sa.ForeignKey("systems.cmdb_sysid"), nullable=True),
    )

    op.create_table(
        "review_findings",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("summary", sa.String(), nullable=True),
        sa.Column("risk_level", sa.String(), nullable=True),
        sa.Column("classification", sa.String(), nullable=True),
        sa.Column("requirement", sa.String(), nullable=True),
        sa.Column("source_ref", sa.String(), nullable=True),
        sa.Column("kind", sa.String(), nullable=True),
        sa.Column("details", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("blueprint_id", sa.Integer(), sa.ForeignKey("security_blueprints.id"), nullable=True),
        sa.Column("case_review_id", sa.String(), sa.ForeignKey("case_reviews.id", ondelete="CASCADE"), nullable=True, index=True),
    )

    op.create_table(
        "evidence",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("case_id", sa.String(), sa.ForeignKey("case_reviews.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("finding_id", sa.String(), sa.ForeignKey("review_findings.id", ondelete="CASCADE"), nullable=True, index=True),
        sa.Column("description", sa.String(), nullable=True),
        sa.Column("decision", sa.String(), nullable=False, server_default="accept"),
        sa.Column("attachments", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )

    op.create_table(
        "chat_messages",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("case_id", sa.String(), sa.ForeignKey("case_reviews.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("sender", sa.String(), nullable=False),
        sa.Column("message_md", sa.String(), nullable=False),
        sa.Column("attachments", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )

    op.create_table(
        "coupons",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("case_id", sa.String(), sa.ForeignKey("case_reviews.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("coupon_type", sa.String(), nullable=False),
        sa.Column("payload", postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )

    op.create_table(
        "status_history",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("case_id", sa.String(), sa.ForeignKey("case_reviews.id", ondelete="CASCADE"), nullable=False, index=True),
        sa.Column("from_status", sa.String(), nullable=True),
        sa.Column("to_status", sa.String(), nullable=False),
        sa.Column("changed_by", sa.String(), nullable=True),
        sa.Column("changed_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )


def downgrade() -> None:
    for tbl in ["status_history", "coupons", "chat_messages", "evidence", "review_findings", "case_reviews"]:
        try:
            op.drop_table(tbl)
        except Exception:
            pass
    try:
        op.execute("DROP TYPE IF EXISTS casestatus")
        op.execute("DROP TYPE IF EXISTS evidencedecision")
        op.execute("DROP TYPE IF EXISTS chatsender")
    except Exception:
        pass
