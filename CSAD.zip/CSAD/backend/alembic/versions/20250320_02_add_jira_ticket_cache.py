"""Add jira_ticket cache table.

Revision ID: 20250320_02
Revises: rescope_case_entities
Create Date: 2025-12-18
"""

from alembic import op
import sqlalchemy as sa


revision = "20250320_02"
down_revision = "rescope_case_entities"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "jira_tickets",
        sa.Column("id", sa.String(), primary_key=True, index=True),
        sa.Column("summary", sa.String(), nullable=True),
        sa.Column("project_key", sa.String(), nullable=True, index=True),
        sa.Column("fetched_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )


def downgrade() -> None:
    op.drop_table("jira_tickets")
