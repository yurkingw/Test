"""
API Dependencies.

This module defines dependency-injection functions that are used across the API
endpoints. Dependencies in FastAPI are a way to declare resources that are
required by path operation functions, such as a database session.
"""

from typing import Generator
from sqlalchemy.orm import Session
from app.db.session import SessionLocal

def get_db() -> Generator[Session, None, None]:
    """
    FastAPI dependency to get a database session.

    This function is a generator that creates a new SQLAlchemy Session for each
    incoming request and ensures that the session is properly closed afterward,
    even if an error occurs.

    Yields:
        Generator[Session, None, None]: A SQLAlchemy Session object.
    """
    db = SessionLocal()
    try:
        # Yield the session to the path operation function.
        yield db
    finally:
        # Ensure the session is closed after the request is finished.
        # This releases the database connection back to the pool.
        db.close()