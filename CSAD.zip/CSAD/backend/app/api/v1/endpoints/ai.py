'''
API endpoint for AI-powered features.
'''

import json
from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel, ValidationError
from typing import Optional, List, Dict

from app.api import deps
from app.services import ai_service
from app.services.review_config import DEFAULT_REVIEW_TYPE
from app import crud, schemas, models

router = APIRouter()

class ChatMessage(BaseModel):
    sender: str
    text: str

class ConversationRequest(BaseModel):
    review_type: str = DEFAULT_REVIEW_TYPE
    messages: List[ChatMessage]


@router.post("/chat")
async def chat_with_ai(
    conversation: Optional[str] = Form(default="[]"),
    message: str = Form(default=""),
    files: Optional[List[UploadFile]] = File(default=None),
    security_designs: Optional[List[UploadFile]] = File(default=None),
    review_type: str = Form(default=DEFAULT_REVIEW_TYPE),
) -> Dict[str, str]:
    """
    Chat endpoint that supports text messages and optional file uploads.
    """
    try:
        conversation_payload = json.loads(conversation) if conversation else []
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid conversation payload.")

    if not isinstance(conversation_payload, list):
        raise HTTPException(status_code=400, detail="Conversation payload must be a list.")

    sanitized_conversation: List[Dict[str, str]] = []
    for item in conversation_payload:
        if not isinstance(item, dict):
            continue
        sender = item.get("sender", "")
        text = item.get("text", "")
        if not sender:
            continue
        sanitized_conversation.append({"sender": sender, "text": text})

    latest_message_text = message or (sanitized_conversation[-1]["text"] if sanitized_conversation else "")
    has_files = bool(files)
    has_templates = bool(security_designs)
    if not latest_message_text and not has_files and not has_templates:
        raise HTTPException(status_code=400, detail="Message or attachment required.")

    if sanitized_conversation:
        if sanitized_conversation[-1]["sender"].lower() != "user" and latest_message_text:
            sanitized_conversation.append({"sender": "user", "text": latest_message_text})
        elif not sanitized_conversation[-1]["text"] and latest_message_text:
            sanitized_conversation[-1]["text"] = latest_message_text
    elif latest_message_text:
        sanitized_conversation.append({"sender": "user", "text": latest_message_text})

    prepared_files = []
    if files:
        for upload in files:
            content = await upload.read()
            prepared_files.append((content, upload.filename))

    prepared_security = []
    if security_designs:
        for upload in security_designs:
            content = await upload.read()
            prepared_security.append((content, upload.filename))

    selected_review_type = review_type or DEFAULT_REVIEW_TYPE

    reply = ai_service.generate_chat_reply(
        conversation=sanitized_conversation,
        latest_user_text=latest_message_text,
        file_attachments=prepared_files,
        security_attachments=prepared_security,
        review_type=selected_review_type,
    )

    return reply

@router.post("/complete-review", response_model=List[schemas.review_finding.ReviewFinding])
def complete_review(
    *,
    db: Session = Depends(deps.get_db),
    conversation: ConversationRequest
) -> List[models.ReviewFinding]:
    """
    Completes the AI review process, generating, saving, and returning findings.
    """
    findings_data = ai_service.generate_findings_from_conversation(
        conversation.messages, conversation.review_type or DEFAULT_REVIEW_TYPE
    )
    
    if not findings_data:
        return []

    created_findings = []
    for finding_data in findings_data:
        try:
            finding_in = schemas.ReviewFindingCreate(**finding_data)
            finding = crud.review_finding.create(db=db, obj_in=finding_in)
            created_findings.append(finding)
        except ValidationError as e:
            print(f"AI response failed validation for a finding: {e}")
            continue
        except Exception as e:
            print(f"Error creating finding in DB: {e}")
            continue

    return created_findings
