"""
API endpoints for managing Security Blueprints.

This module provides RESTful API endpoints for performing CRUD (Create, Read,
Update, Delete) operations on Security Blueprint resources.
"""

from typing import List, Any
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import crud, schemas
from app.api import deps

# Create a new router for security blueprint endpoints.
router = APIRouter()

@router.get("/", response_model=List[schemas.SecurityBlueprint])
def read_security_blueprints(
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
) -> Any:
    """
    Retrieve multiple security blueprints with pagination.

    Args:
        db (Session): The database session, injected by FastAPI.
        skip (int): The number of records to skip (for pagination).
        limit (int): The maximum number of records to return.

    Returns:
        Any: A list of security blueprint objects.
    """
    blueprints = crud.security_blueprint.get_multi(db, skip=skip, limit=limit)
    return blueprints


@router.post("/", response_model=schemas.SecurityBlueprint, status_code=201)
def create_security_blueprint(
    *,
    db: Session = Depends(deps.get_db),
    blueprint_in: schemas.SecurityBlueprintCreate,
) -> Any:
    """
    Create a new security blueprint.

    Args:
        db (Session): The database session, injected by FastAPI.
        blueprint_in (schemas.SecurityBlueprintCreate): The data for the new blueprint.

    Returns:
        Any: The newly created security blueprint object.
    """
    blueprint = crud.security_blueprint.create(db=db, obj_in=blueprint_in)
    return blueprint


@router.get("/{id}", response_model=schemas.SecurityBlueprint)
def read_security_blueprint(
    *,
    db: Session = Depends(deps.get_db),
    id: int,
) -> Any:
    """
    Retrieve a specific security blueprint by its ID.

    Args:
        db (Session): The database session, injected by FastAPI.
        id (int): The ID of the security blueprint to retrieve.

    Raises:
        HTTPException: If a security blueprint with the specified ID is not found.

    Returns:
        Any: The requested security blueprint object.
    """
    blueprint = crud.security_blueprint.get(db=db, id=id)
    if not blueprint:
        raise HTTPException(status_code=404, detail="Security blueprint not found")
    return blueprint