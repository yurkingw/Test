'''
API endpoint for running CALM audits.
'''

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List, Any

from app.schemas.audit import AuditSubmission
from app.schemas.review_finding import ReviewFinding
from app.api import deps
from app.services import calm_audit, ai_service

router = APIRouter()

@router.post("/", response_model=List[ReviewFinding])
def run_calm_audit(
    *,
    db: Session = Depends(deps.get_db),
    payload: AuditSubmission,
) -> Any:
    """
    Run a CALM audit on a user-submitted design.
    
    This endpoint accepts a full user design, triggers the audit service,
    and returns a list of findings.
    """
    findings = calm_audit.run_audit(
        db=db,
        user_design=payload.user_design.model_dump(),
        review_type=payload.review_type,
    )
    return findings


@router.post("/ai", response_model=List[ReviewFinding])
def run_ai_pre_review(
    *,
    db: Session = Depends(deps.get_db),
    payload: AuditSubmission,
) -> Any:
    """
    Run AI pre-review by combining rule-based findings with AI-generated findings.
    """
    user_design = payload.user_design.model_dump()
    rule_findings = calm_audit.run_audit(
        db=db,
        user_design=user_design,
        review_type=payload.review_type,
    )
    ai_findings = ai_service.generate_ai_pre_review_findings(
        user_design=user_design,
        review_type=payload.review_type,
    )
    return [*rule_findings, *ai_findings]
