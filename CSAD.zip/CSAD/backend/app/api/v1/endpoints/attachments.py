"""
Attachment upload/download endpoints.
"""

from __future__ import annotations

from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from pathlib import Path
from typing import List, Dict
import uuid
import os

from app.core.config import settings

router = APIRouter()


def _get_storage_root() -> Path:
    root = Path(settings.ATTACHMENTS_DIR).resolve()
    root.mkdir(parents=True, exist_ok=True)
    return root


def _safe_join(root: Path, rel_path: str) -> Path:
    target = (root / rel_path).resolve()
    if not str(target).startswith(str(root)):
        raise HTTPException(status_code=400, detail="Invalid attachment path.")
    return target


@router.post("/", response_model=List[Dict[str, str]])
async def upload_attachments(files: List[UploadFile] = File(...)) -> List[Dict[str, str]]:
    """
    Store uploaded files on disk and return metadata with relative paths.
    """
    root = _get_storage_root()
    results: List[Dict[str, str]] = []
    for upload in files:
        contents = await upload.read()
        if contents is None:
            continue
        ext = Path(upload.filename or "").suffix
        fname = f"{uuid.uuid4().hex}{ext}"
        rel_dir = Path("uploads")
        rel_path = str(rel_dir / fname)
        target = _safe_join(root, rel_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        with open(target, "wb") as handle:
            handle.write(contents)
        results.append(
            {
                "name": upload.filename or fname,
                "type": upload.content_type or "application/octet-stream",
                "size": str(len(contents)),
                "path": rel_path,
            }
        )
    return results


@router.get("/{file_path:path}")
def download_attachment(file_path: str) -> FileResponse:
    """
    Download a stored attachment by relative path.
    """
    root = _get_storage_root()
    target = _safe_join(root, file_path)
    if not target.exists():
        raise HTTPException(status_code=404, detail="Attachment not found.")
    return FileResponse(path=str(target), filename=os.path.basename(target))
