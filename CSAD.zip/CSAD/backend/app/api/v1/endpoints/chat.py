from typing import List, Any
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api import deps
from app import crud, schemas

router = APIRouter()


@router.get("/cases/{case_id}", response_model=List[schemas.ChatMessage])
def list_chat_for_case(
    *,
    db: Session = Depends(deps.get_db),
    case_id: str,
) -> Any:
    case = crud.case_review.get(db, id=case_id)
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    return crud.chat_message.get_by_case(db, case_id=case_id)


@router.post("/cases/{case_id}", response_model=schemas.ChatMessage, status_code=201)
def post_chat_message(
    *,
    db: Session = Depends(deps.get_db),
    case_id: str,
    chat_in: schemas.ChatMessageCreate,
) -> Any:
    case = crud.case_review.get(db, id=case_id)
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    data = chat_in.dict()
    if not data.get("id"):
        data["id"] = f"CHAT-{uuid4()}"
    if not data.get("case_id"):
        data["case_id"] = case_id
    return crud.chat_message.create(db, obj_in=schemas.ChatMessageCreate(**data))
