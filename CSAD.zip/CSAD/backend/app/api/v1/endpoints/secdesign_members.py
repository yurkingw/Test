"""
SecDesign member lookup endpoints.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import Dict, List

from app.api import deps
from app.models.secdesign_member import SecDesignMember
from app.services.secdesign_members import sync_secdesign_members_from_csv

router = APIRouter()


@router.get("/", response_model=List[Dict[str, str]])
def list_members(db: Session = Depends(deps.get_db)) -> List[Dict[str, str]]:
    rows = db.query(SecDesignMember).order_by(SecDesignMember.name.asc()).all()
    return [{"name": row.name, "login_id": row.login_id} for row in rows]


@router.post("/refresh")
def refresh_members(db: Session = Depends(deps.get_db)) -> Dict[str, object]:
    inserted, updated = sync_secdesign_members_from_csv(db)
    return {"inserted": inserted, "updated": updated}
