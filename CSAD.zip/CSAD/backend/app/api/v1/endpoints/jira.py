"""
Jira Service Management integration endpoints.
"""

from __future__ import annotations

from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Dict, List, Optional
import httpx
import threading
import time

from app.api import deps
from app.models.jira_ticket import JiraTicket
from app.services.app_config import get_app_config

router = APIRouter()


def _get_jira_config() -> Dict[str, object]:
    config = get_app_config().get("jira") or {}
    return config


@router.get("/tickets")
def list_jira_tickets(
    query: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=200),
    db: Session = Depends(deps.get_db),
) -> Dict[str, object]:
    """
    Return cached Jira tickets from the database (shared cache).
    """
    base = db.query(JiraTicket)
    if query:
        digits = "".join([c for c in query if c.isdigit()])
        keyword = digits or query
        base = base.filter(JiraTicket.id.ilike(f"%{keyword}%"))

    total = base.count()
    items = (
        base.order_by(JiraTicket.id.asc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )
    last_refreshed = db.query(func.max(JiraTicket.fetched_at)).scalar()
    return {
        "items": [{"id": item.id, "summary": item.summary or ""} for item in items],
        "total": total,
        "page": page,
        "page_size": page_size,
        "last_refreshed": last_refreshed.isoformat() if last_refreshed else None,
    }


_refresh_lock = threading.Lock()
_last_refresh_ts: float = 0.0


def _build_http_client(cfg: Dict[str, object], timeout_seconds: int) -> httpx.Client:
    cert_path = str(cfg.get("mtls_cert_path") or "").strip()
    key_path = str(cfg.get("mtls_key_path") or "").strip()
    ca_path = str(cfg.get("mtls_ca_path") or "").strip()
    cert = None
    if cert_path and key_path:
        cert = (cert_path, key_path)
    elif cert_path:
        cert = cert_path
    verify = ca_path or True
    return httpx.Client(timeout=timeout_seconds, cert=cert, verify=verify)


@router.post("/tickets/refresh")
def refresh_jira_tickets(db: Session = Depends(deps.get_db)) -> Dict[str, object]:
    """
    Refresh cached Jira tickets from JSM and store them in the database.
    """
    cfg = _get_jira_config()
    base_url = str(cfg.get("base_url") or "").rstrip("/")
    api_path = str(cfg.get("api_path") or "/rest/api/3")
    username = str(cfg.get("username") or "")
    api_token = str(cfg.get("api_token") or "")
    jql = str(cfg.get("jql_query") or "")
    timeout_seconds = int(cfg.get("timeout_seconds") or 15)
    project_key = str(cfg.get("project_key") or "")

    if not base_url or not username or not api_token:
        raise HTTPException(status_code=503, detail="Jira integration not configured.")

    global _last_refresh_ts
    now_ts = time.time()
    cooldown = int(cfg.get("cache_ttl_seconds") or 60)
    with _refresh_lock:
        if _last_refresh_ts and (now_ts - _last_refresh_ts) < cooldown:
            remaining = int(cooldown - (now_ts - _last_refresh_ts))
            return {
                "count": 0,
                "last_refreshed": datetime.utcfromtimestamp(_last_refresh_ts).isoformat(),
                "cooldown_remaining": max(0, remaining),
            }

    url = f"{base_url}{api_path}/search"
    start_at = 0
    max_results = 100
    issues: List[Dict[str, object]] = []
    total = None

    try:
        with _build_http_client(cfg, timeout_seconds) as client:
            while True:
                params = {
                    "jql": jql,
                    "maxResults": max_results,
                    "startAt": start_at,
                    "fields": "summary",
                }
                resp = client.get(url, params=params, auth=(username, api_token))
                resp.raise_for_status()
                payload = resp.json()
                batch = payload.get("issues") or []
                issues.extend(batch)
                total = payload.get("total", total)
                if total is None or start_at + max_results >= total:
                    break
                start_at += max_results
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"Failed to fetch Jira tickets: {exc}") from exc

    now = datetime.utcnow()
    db.query(JiraTicket).delete()
    for issue in issues:
        key = issue.get("key")
        if not key:
            continue
        summary = (issue.get("fields") or {}).get("summary") or ""
        db.add(JiraTicket(id=key, summary=summary, project_key=project_key, fetched_at=now))
    db.commit()
    _last_refresh_ts = now_ts

    return {"count": len(issues), "last_refreshed": now.isoformat()}
