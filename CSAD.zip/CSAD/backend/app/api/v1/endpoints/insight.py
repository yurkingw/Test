"""
Security domain/zone endpoints backed by local CSV sync.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Dict

from app.api import deps
from app.models.security_domain_option import SecurityDomainOption
from app.models.security_zone_option import SecurityZoneOption
from app.models.security_component_option import SecurityComponentOption
from app.models.subnet_boundary_option import SubnetBoundaryOption
from app.models.protocol_port_option import ProtocolPortOption
from app.services.security_options import sync_security_options_from_csv

router = APIRouter()

@router.get("/domains")
def list_security_domains(db: Session = Depends(deps.get_db)) -> Dict[str, object]:
    items = db.query(SecurityDomainOption).order_by(SecurityDomainOption.name.asc()).all()
    last_refreshed = db.query(func.max(SecurityDomainOption.fetched_at)).scalar()
    return {
        "items": [item.name for item in items],
        "last_refreshed": last_refreshed.isoformat() if last_refreshed else None,
    }


@router.get("/zones")
def list_security_zones(db: Session = Depends(deps.get_db)) -> Dict[str, object]:
    items = db.query(SecurityZoneOption).order_by(SecurityZoneOption.name.asc()).all()
    last_refreshed = db.query(func.max(SecurityZoneOption.fetched_at)).scalar()
    return {
        "items": [item.name for item in items],
        "last_refreshed": last_refreshed.isoformat() if last_refreshed else None,
    }

@router.get("/components")
def list_security_components(db: Session = Depends(deps.get_db)) -> Dict[str, object]:
    items = db.query(SecurityComponentOption).order_by(SecurityComponentOption.name.asc()).all()
    last_refreshed = db.query(func.max(SecurityComponentOption.fetched_at)).scalar()
    return {
        "items": [item.name for item in items],
        "last_refreshed": last_refreshed.isoformat() if last_refreshed else None,
    }


@router.get("/subnet-boundaries")
def list_subnet_boundaries(db: Session = Depends(deps.get_db)) -> Dict[str, object]:
    items = db.query(SubnetBoundaryOption).all()
    values = [item.value for item in items]
    values.sort(key=lambda value: int(value.lstrip("/")) if value.startswith("/") else 0, reverse=True)
    last_refreshed = db.query(func.max(SubnetBoundaryOption.fetched_at)).scalar()
    return {
        "items": values,
        "last_refreshed": last_refreshed.isoformat() if last_refreshed else None,
    }


@router.get("/protocol-ports")
def list_protocol_ports(db: Session = Depends(deps.get_db)) -> Dict[str, object]:
    items = db.query(ProtocolPortOption).order_by(ProtocolPortOption.value.asc()).all()
    last_refreshed = db.query(func.max(ProtocolPortOption.fetched_at)).scalar()
    return {
        "items": [item.value for item in items],
        "last_refreshed": last_refreshed.isoformat() if last_refreshed else None,
    }


@router.post("/refresh")
def refresh_security_domain_zone(db: Session = Depends(deps.get_db)) -> Dict[str, object]:
    domain_count, zone_count, component_count, subnet_count, protocol_port_count = sync_security_options_from_csv(db)
    last_refreshed = (
        db.query(func.max(SecurityDomainOption.fetched_at)).scalar()
        or db.query(func.max(SecurityZoneOption.fetched_at)).scalar()
        or db.query(func.max(SecurityComponentOption.fetched_at)).scalar()
        or db.query(func.max(SubnetBoundaryOption.fetched_at)).scalar()
        or db.query(func.max(ProtocolPortOption.fetched_at)).scalar()
    )
    return {
        "domains": domain_count,
        "zones": zone_count,
        "components": component_count,
        "subnet_boundaries": subnet_count,
        "protocol_ports": protocol_port_count,
        "last_refreshed": last_refreshed.isoformat() if last_refreshed else None,
    }
