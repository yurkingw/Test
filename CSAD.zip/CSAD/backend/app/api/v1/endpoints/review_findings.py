"""
API endpoints for managing Review Findings.

This module provides RESTful API endpoints for performing CRUD operations on
Review Finding resources, including custom queries like retrieving findings
associated with a specific Security Blueprint.
"""

from typing import List, Any
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import crud, schemas
from app.api import deps

router = APIRouter()


@router.get("/by-blueprint/{blueprint_id}", response_model=List[schemas.ReviewFinding])
def read_findings_by_blueprint(
    blueprint_id: int,
    db: Session = Depends(deps.get_db),
    skip: int = 0,
    limit: int = 100,
) -> Any:
    findings = crud.review_finding.get_multi_by_blueprint(
        db, blueprint_id=blueprint_id, skip=skip, limit=limit
    )
    return findings


@router.post("/", response_model=schemas.ReviewFinding, status_code=201)
def create_review_finding(
    *,
    db: Session = Depends(deps.get_db),
    finding_in: schemas.ReviewFindingCreate,
) -> Any:
    data = finding_in.dict()
    if not data.get("id"):
        data["id"] = f"FIND-{uuid4()}"
    finding = crud.review_finding.create(db=db, obj_in=schemas.ReviewFindingCreate(**data))
    return finding


@router.get("/{id}", response_model=schemas.ReviewFinding)
def read_review_finding(
    *,
    db: Session = Depends(deps.get_db),
    id: str,
) -> Any:
    finding = crud.review_finding.get(db=db, id=id)
    if not finding:
        raise HTTPException(status_code=404, detail="Review finding not found")
    return finding
