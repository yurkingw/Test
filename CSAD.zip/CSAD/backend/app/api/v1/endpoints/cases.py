'''
API endpoints for managing and interacting with Cases.
'''

from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.orm import Session
from starlette.responses import Response
from typing import Any, List
from uuid import uuid4

from app.api import deps
from app import crud
from app.schemas.case_review import CaseReviewCreate, CaseReview, CaseReviewUpdate
from app.schemas.status_history import StatusHistoryCreate
from app.models.case_review import CaseStatus
from app.services.calm_v4 import build_calm_summary_v4
from app.services.security_blueprint_pattern import generate_calm_blueprints_from_templates

router = APIRouter()


@router.post("", response_model=CaseReview)
def create_case(
    *,
    db: Session = Depends(deps.get_db),
    case_in: CaseReviewCreate,
) -> Any:
    """
    Create a new case. Caller should supply name/description/review_type/owner/ticket.
    """
    if not case_in.id:
        case_in.id = f"CASE-{uuid4()}"
    existing = crud.case_review.get(db, id=case_in.id)
    if existing:
        raise HTTPException(status_code=400, detail="Case ID already exists")
    db_obj = crud.case_review.create(db=db, obj_in=case_in)
    crud.status_history.create(
        db,
        obj_in=StatusHistoryCreate(
            id=str(uuid4()),
            case_id=db_obj.id,
            from_status=None,
            to_status=db_obj.status.value if hasattr(db_obj.status, "value") else str(db_obj.status),
            changed_by=case_in.owner_id,
        ),
    )
    return db_obj


@router.get("", response_model=List[CaseReview])
def list_cases(
    *,
    db: Session = Depends(deps.get_db),
    status: str | None = None,
    owner_id: str | None = None,
) -> Any:
    query = db.query(crud.case_review.model)
    if status:
        query = query.filter(crud.case_review.model.status == status)
    if owner_id:
        query = query.filter(crud.case_review.model.owner_id == owner_id)
    return query.all()


@router.patch("/{case_id}", response_model=CaseReview)
def update_case(
    *,
    db: Session = Depends(deps.get_db),
    case_id: str,
    case_in: CaseReviewUpdate,
) -> Any:
    db_obj = crud.case_review.get(db, id=case_id)
    if not db_obj:
        raise HTTPException(status_code=404, detail="Case not found")
    updated = crud.case_review.update(db=db, db_obj=db_obj, obj_in=case_in)
    return updated


@router.get("/{case_id}", response_model=CaseReview)
def get_case(
    *,
    db: Session = Depends(deps.get_db),
    case_id: str,
) -> Any:
    db_obj = crud.case_review.get(db, id=case_id)
    if not db_obj:
        raise HTTPException(status_code=404, detail="Case not found")
    return db_obj


@router.post("/{case_id}/status", response_model=CaseReview)
def transition_status(
    *,
    db: Session = Depends(deps.get_db),
    case_id: str,
    to_status: str = Body(..., embed=True),
    changed_by: str | None = None,
) -> Any:
    db_obj = crud.case_review.get(db, id=case_id)
    if not db_obj:
        raise HTTPException(status_code=404, detail="Case not found")
    try:
        status_enum = CaseStatus(to_status)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid status value")
    previous = db_obj.status
    updated = crud.case_review.update(db=db, db_obj=db_obj, obj_in={"status": status_enum})
    crud.status_history.create(
        db,
        obj_in=StatusHistoryCreate(
            id=str(uuid4()),
            case_id=case_id,
            from_status=previous.value if hasattr(previous, "value") else str(previous),
            to_status=status_enum.value if hasattr(status_enum, "value") else str(status_enum),
            changed_by=changed_by,
        ),
    )
    return updated


@router.get("/{case_id}/report")
def get_case_report(
    *,
    db: Session = Depends(deps.get_db),
    case_id: str,
) -> Response:
    """
    Generates and returns a final report for a completed case.
    """
    case = crud.case_review.get_full_details(db=db, id=case_id)
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")

    status_val = case.status.value if hasattr(case.status, "value") else str(case.status)
    report_content = (
        f"# Security Design Review: {case.name}\n\n"
        f"**Case ID:** {case.id}\n"
        f"**Status:** {status_val}\n"
        f"**Description:**\n{case.description or 'N/A'}\n\n"
        "---\n\n## Review Findings\n\n"
    )

    if not case.findings:
        report_content += "No findings for this case.\n"
    else:
        for i, finding in enumerate(case.findings, 1):
            report_content += f"### Finding {i}\n\n"
            if finding.summary:
                report_content += f"**Summary:** {finding.summary}\n"
            if finding.risk_level:
                report_content += f"**Risk Level:** {finding.risk_level}\n"
            if finding.classification:
                report_content += f"**Classification:** {finding.classification}\n"
            details = finding.details or {}
            for key, value in details.items():
                report_content += f"- **{key.replace('_', ' ').title()}:** {value}\n"
            report_content += "\n"

    return Response(content=report_content, media_type="text/markdown")


@router.get("/{case_id}/coupon")
def get_case_coupon(
    *,
    db: Session = Depends(deps.get_db),
    case_id: str,
) -> Any:
    """
    Generates and returns a "Coupon" JSON for a completed case.
    """
    coupon = db.query(crud.coupon.model).filter(crud.coupon.model.case_id == case_id).first() if hasattr(crud, "coupon") else None
    if coupon:
        return coupon.payload
    mock_coupon = {
        "coupon_id": f"CPN-{case_id}-001",
        "coupon_type": "Firewall Flow",
        "source_ip": "192.168.1.10",
        "destination_ip": "10.0.0.5",
        "destination_port": 443,
        "protocol": "TCP",
        "status": "Approved"
    }
    return mock_coupon


@router.post("/rebuild-calm")
def rebuild_calm_summary(
    *,
    db: Session = Depends(deps.get_db),
    case_id: str | None = Body(default=None, embed=True),
) -> Any:
    """
    Rebuild and persist v4 CALM summaries for stored cases.
    """
    templates = generate_calm_blueprints_from_templates()
    query = db.query(crud.case_review.model)
    if case_id:
        query = query.filter(crud.case_review.model.id == case_id)
    cases = query.all()
    updated = 0
    for case in cases:
        payload = case.design_payload or {}
        if not payload:
            continue
        calm_summary = build_calm_summary_v4(
            payload,
            case.findings or [],
            case.reviewer_extra_findings or [],
            templates,
        )
        if not calm_summary:
            continue
        payload = {**payload, "calmSummary": calm_summary}
        crud.case_review.update(db=db, db_obj=case, obj_in={"design_payload": payload})
        updated += 1
    return {"updated": updated, "case_id": case_id}
