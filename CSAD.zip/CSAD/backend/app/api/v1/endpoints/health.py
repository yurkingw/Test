"""
API endpoint for health checks.

This module provides a simple endpoint to verify that the application is running
and able to respond to requests.
"""

from fastapi import APIRouter

# Create a new router for health check related endpoints.
router = APIRouter()

@router.get("/", status_code=200)
def health_check() -> dict[str, str]:
    """
    Health Check Endpoint.

    Provides a simple, unauthenticated endpoint to check the service status.
    This is useful for load balancers, uptime monitors, or simple manual checks.

    Returns:
        dict[str, str]: A dictionary with a "status" key indicating the service is "ok".
    """
    return {"status": "ok"}