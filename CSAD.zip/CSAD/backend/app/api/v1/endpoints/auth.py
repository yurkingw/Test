from typing import Any, Dict, List
import urllib.parse
import jwt

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import RedirectResponse, JSONResponse
from sqlalchemy.orm import Session

from app.api import deps
from app.models.aad_user import AadUser
from app.schemas.aad_user import AadUser as AadUserSchema
from app.services.aad import (
    build_authorize_url,
    exchange_code_for_token,
    fetch_user_profile,
    fetch_user_groups,
    fetch_group_members,
    client_credentials_token,
    map_groups_to_role,
    _aad_config,
)

router = APIRouter()


def _decode_id_token(id_token: str) -> Dict[str, Any]:
    return jwt.decode(id_token, options={"verify_signature": False, "verify_aud": False})


def _upsert_aad_user(db: Session, payload: Dict[str, Any]) -> AadUser:
    login_id = payload.get("login_id")
    if not login_id:
        raise HTTPException(status_code=400, detail="Missing login_id")
    obj = db.query(AadUser).filter(AadUser.login_id == login_id).first()
    if not obj:
        obj = AadUser(**payload)
        db.add(obj)
    else:
        for key, value in payload.items():
            setattr(obj, key, value)
    db.commit()
    db.refresh(obj)
    return obj


@router.get("/aad/login")
def aad_login() -> Any:
    url, _state = build_authorize_url()
    return RedirectResponse(url)


@router.get("/aad/callback")
def aad_callback(
    *,
    db: Session = Depends(deps.get_db),
    code: str | None = Query(default=None),
    error: str | None = Query(default=None),
    error_description: str | None = Query(default=None),
) -> Any:
    if error:
        raise HTTPException(status_code=400, detail=f"AAD error: {error_description or error}")
    if not code:
        raise HTTPException(status_code=400, detail="Missing authorization code")

    tokens = exchange_code_for_token(code)
    access_token = tokens.get("access_token")
    id_token = tokens.get("id_token")
    if not access_token and not id_token:
        raise HTTPException(status_code=400, detail="Token exchange failed")

    claims = _decode_id_token(id_token) if id_token else {}
    profile = fetch_user_profile(access_token) if access_token else {}
    group_ids = claims.get("groups") or []
    if access_token and not group_ids:
        try:
            group_ids = fetch_user_groups(access_token)
        except Exception:
            group_ids = []

    cfg = _aad_config()
    role = map_groups_to_role(group_ids, cfg)
    login_id = profile.get("userPrincipalName") or profile.get("mail") or claims.get("preferred_username")
    display_name = profile.get("displayName") or claims.get("name")
    email = profile.get("mail") or claims.get("preferred_username")

    _upsert_aad_user(
        db,
        {
            "login_id": login_id,
            "display_name": display_name,
            "email": email,
            "role": role,
            "group_ids": group_ids,
        },
    )

    frontend_redirect = cfg.get("frontend_redirect_uri") or "http://localhost:3000/"
    params = {
        "aad_login": "1",
        "aad_user": login_id or "",
        "aad_role": role,
        "aad_display": display_name or "",
        "aad_email": email or "",
    }
    target = f"{frontend_redirect.rstrip('/')}/?{urllib.parse.urlencode(params)}"
    return RedirectResponse(target)


@router.get("/aad/groups", response_model=List[AadUserSchema])
def list_aad_users(*, db: Session = Depends(deps.get_db)) -> Any:
    return db.query(AadUser).all()


@router.post("/aad/sync-groups", response_model=List[AadUserSchema])
def sync_aad_groups(*, db: Session = Depends(deps.get_db)) -> Any:
    cfg = _aad_config()
    mapping = cfg.get("group_map_raw")
    if not mapping:
        raise HTTPException(status_code=400, detail="AAD group-role mapping is not configured")

    token = client_credentials_token()
    if not token:
        raise HTTPException(status_code=400, detail="Failed to obtain AAD access token")

    from app.services.aad import _group_map  # local import to avoid circular

    group_map = _group_map(cfg)
    aggregated: Dict[str, Dict[str, Any]] = {}

    for group_id in group_map.keys():
        members = fetch_group_members(token, group_id)
        for member in members:
            login_id = member.get("userPrincipalName") or member.get("mail") or member.get("id")
            if not login_id:
                continue
            record = aggregated.setdefault(login_id, {
                "login_id": login_id,
                "display_name": member.get("displayName"),
                "email": member.get("mail") or member.get("userPrincipalName"),
                "group_ids": [],
            })
            if group_id not in record["group_ids"]:
                record["group_ids"].append(group_id)

    results = []
    for record in aggregated.values():
        record["role"] = map_groups_to_role(record.get("group_ids", []), cfg)
        results.append(_upsert_aad_user(db, record))
    return results
