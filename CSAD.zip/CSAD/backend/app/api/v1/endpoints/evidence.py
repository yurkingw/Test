from typing import List, Any
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api import deps
from app import crud, schemas

router = APIRouter()


@router.get("/cases/{case_id}", response_model=List[schemas.Evidence])
def list_evidence_for_case(
    *,
    db: Session = Depends(deps.get_db),
    case_id: str,
) -> Any:
    case = crud.case_review.get(db, id=case_id)
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    return crud.evidence.get_by_case(db, case_id=case_id)


@router.post("/cases/{case_id}", response_model=schemas.Evidence, status_code=201)
def create_evidence_for_case(
    *,
    db: Session = Depends(deps.get_db),
    case_id: str,
    evidence_in: schemas.EvidenceCreate,
) -> Any:
    case = crud.case_review.get(db, id=case_id)
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    data = evidence_in.dict()
    if not data.get("id"):
        data["id"] = f"EVD-{uuid4()}"
    if not data.get("case_id"):
        data["case_id"] = case_id
    ev = crud.evidence.create(db, obj_in=schemas.EvidenceCreate(**data))
    return ev


@router.patch("/{evidence_id}", response_model=schemas.Evidence)
def update_evidence(
    *,
    db: Session = Depends(deps.get_db),
    evidence_id: str,
    evidence_in: schemas.EvidenceUpdate,
) -> Any:
    db_obj = crud.evidence.get(db, id=evidence_id)
    if not db_obj:
        raise HTTPException(status_code=404, detail="Evidence not found")
    return crud.evidence.update(db, db_obj=db_obj, obj_in=evidence_in)
