"""
API endpoint for previewing generated CALM SecurityBlueprint/SecurityFragment
structures derived from intermediate templates.
"""

from fastapi import APIRouter

from app.services.security_blueprint_pattern import generate_calm_blueprints_from_templates

router = APIRouter()


@router.get("/", summary="Preview generated CALM blueprints from templates")
def list_blueprint_templates():
    """
    Return the CALM SecurityFragment/SecurityBlueprint objects that are generated
    from the intermediate YAML templates. This helps security SMEs verify that
    their template edits translate into CALM-compliant entities.
    """
    return generate_calm_blueprints_from_templates()
