from typing import List, Any
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api import deps
from app import crud, schemas

router = APIRouter()


@router.get("/cases/{case_id}", response_model=List[schemas.Coupon])
def list_coupons_for_case(
    *,
    db: Session = Depends(deps.get_db),
    case_id: str,
) -> Any:
    case = crud.case_review.get(db, id=case_id)
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    return crud.coupon.get_by_case(db, case_id=case_id)


@router.post("/cases/{case_id}", response_model=schemas.Coupon, status_code=201)
def create_coupon_for_case(
    *,
    db: Session = Depends(deps.get_db),
    case_id: str,
    coupon_in: schemas.CouponCreate,
) -> Any:
    case = crud.case_review.get(db, id=case_id)
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    data = coupon_in.dict()
    if not data.get("id"):
        data["id"] = f"CPN-{uuid4()}"
    if not data.get("case_id"):
        data["case_id"] = case_id
    return crud.coupon.create(db, obj_in=schemas.CouponCreate(**data))
