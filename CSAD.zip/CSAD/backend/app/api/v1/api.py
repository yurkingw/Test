'''
Main API router for version 1 of the application.
'''

from fastapi import APIRouter

from app.api.v1.endpoints import (
    health,
    security_blueprints,
    review_findings,
    audits,
    ai,
    cases,
    blueprint_templates,
    evidence,
    chat,
    coupons,
    attachments,
    jira,
    insight,
    secdesign_members,
    auth,
)

# Create the main router for the v1 API.
api_router = APIRouter()

# Include routers from different endpoints
api_router.include_router(health.router, tags=["Health"])
api_router.include_router(security_blueprints.router, prefix="/blueprints", tags=["Security Blueprints"])
api_router.include_router(review_findings.router, prefix="/findings", tags=["Review Findings"])
api_router.include_router(audits.router, prefix="/audits", tags=["Audits"])
api_router.include_router(ai.router, prefix="/ai", tags=["AI"])
api_router.include_router(cases.router, prefix="/cases", tags=["Cases"])
api_router.include_router(blueprint_templates.router, prefix="/blueprint-templates", tags=["Security Blueprints"])
api_router.include_router(evidence.router, prefix="/evidence", tags=["Evidence"])
api_router.include_router(chat.router, prefix="/chat", tags=["Chat"])
api_router.include_router(coupons.router, prefix="/coupons", tags=["Coupons"])
api_router.include_router(attachments.router, prefix="/attachments", tags=["Attachments"])
api_router.include_router(jira.router, prefix="/jira", tags=["Jira"])
api_router.include_router(insight.router, prefix="/insight", tags=["Insight"])
api_router.include_router(secdesign_members.router, prefix="/secdesign-members", tags=["SecDesign Members"])
api_router.include_router(auth.router, prefix="/auth", tags=["Auth"])
