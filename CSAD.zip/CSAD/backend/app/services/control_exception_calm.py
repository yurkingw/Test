"""
Control Exception review helpers for CALM mapping and evaluation.

This module takes the raw Self-Pre-Review Control Exception payload, converts
the inputs into CALM-friendly structures, generates Coupon snapshots for
firewall / proxy flows, and evaluates a lightweight blueprint rule-set to
produce ReviewFinding style dictionaries that can be returned to the API.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import uuid

from app.schemas.system import InfoSensitivityEnum, RiskRankingEnum
from app.schemas.application import (
    LocationEnum,
    SecurityEnvEnum,
    SecurityDomainEnum,
    SecurityZoneEnum,
)
from app.schemas.service_instance import (
    IpcAuthnEnum,
    IpcAuthzEnum,
    ScanStatusEnum,
    ParamQueriesEnum,
    CsrfEnum,
    RaceCondEnum,
)


# --- Blueprint evaluation (DSL-based) ----------------------------------------
from app.services.blueprint_dsl import evaluate_blueprint_templates


# --- Data containers ----------------------------------------------------------

def _generate_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}".upper()


@dataclass
class CalmConnection:
    data: Dict[str, Any]
    index: int

    @property
    def connection_id(self) -> str:
        return self.data.get("conid", "")

    @property
    def properties(self) -> Dict[str, Any]:
        return self.data.setdefault("properties", {})


@dataclass
class CalmCoupon:
    coupon_id: str
    coupon_type: str
    connection_id: str
    properties: Dict[str, Any]


@dataclass
class ControlExceptionCalmBundle:
    metadata: Dict[str, Any]
    system: Dict[str, Any]
    application: Dict[str, Any]
    service: Dict[str, Any]
    service_instance: Dict[str, Any]
    connections: List[CalmConnection]
    coupons: List[CalmCoupon]


# --- Mapping logic ------------------------------------------------------------

def map_payload_to_calm(user_design: Dict[str, Any]) -> ControlExceptionCalmBundle:
    """
    Convert the incoming Control Exception submission metadata into the CALM
    hierarchy needed for downstream blueprint evaluation.
    """
    metadata = user_design.get("metadata") or {}
    checklist = metadata.get("checklist") or {}
    data_connections = checklist.get("data_connections") or []
    data_perimeter = checklist.get("data_perimeter") or {}
    scenario_options = checklist.get("scenario_options") or {}
    basis_options = checklist.get("basis_options") or {}
    firewall_detail_rows = checklist.get("firewall_details") or []
    proxy_detail_rows = checklist.get("proxy_details") or []
    exception_expiry = checklist.get("exception_expiry") or checklist.get("expected_exception", "")
    business_justification = checklist.get("business_justification", "")
    compensating_control = checklist.get("compensating_control") or {}

    system_name = business_justification or "Control Exception Request"
    system_description = exception_expiry or "Control exception submission"
    system_cmdb = _generate_id("CE-SYS")

    system = {
        "id": system_cmdb,
        "cmdb_sysid": system_cmdb,
        "sysname": system_name,
        "description": system_description,
        "information_sensetivity_classification": InfoSensitivityEnum.confidential.value,
        "asset_risk_ranking": RiskRankingEnum.p2.value,
        "properties": {
            "from_control_exception_form": {
                "basis_options": basis_options,
                "scenario_options": scenario_options,
                "scenario_other_context": checklist.get("scenario_other_context", ""),
                "business_justification": business_justification,
                "architecture_description": checklist.get("architecture_description", ""),
                "architecture_files": checklist.get("architecture_files") or [],
                "exception_expiry": exception_expiry,
                "data_perimeter": data_perimeter,
                "data_connections": data_connections,
                "firewall_details": firewall_detail_rows,
                "proxy_details": proxy_detail_rows,
            }
        },
    }

    application = {
        "appid": _generate_id("CE-APP"),
        "appname": f"{system_name} Application",
        "cmdb_sysid": system_cmdb,
        "deployment_model_id": "DTP-CONTROL-EXCEPTION",
        "location": LocationEnum.cloud_other.value,
        "security_environment": SecurityEnvEnum.appdev.value,
        "security_domain": SecurityDomainEnum.cod_msms.value,
        "security_zone": SecurityZoneEnum.ms_dmz.value,
        "properties": {
            "business_context": business_justification,
        },
    }

    service = {
        "svcid": _generate_id("CE-SVC"),
        "svcname": f"{system_name} Service",
        "architecture_model_id": "AML-CONTROL-EXCEPTION",
        "authentication_methods": None,
        "authorization_methods": None,
        "encryption_in_transit_algorithms": None,
        "encryption_in_transit_key_strength": None,
        "encryption_at_rest_algorithms": None,
        "encryption_at_rest_key_strength": None,
        "logging_retention_days": None,
        "logging_cyber_detection_feed": None,
        "listening_port": None,
        "listening_protocol": None,
        "application_ids": [application["appid"]],
        "properties": {},
    }

    service_instance = {
        "svcint_id": _generate_id("CE-SVCINST"),
        "svcintname": f"{system_name} Instance",
        "svcid": service["svcid"],
        "ipc_authentication_methods": IpcAuthnEnum.na.value,
        "ipc_authorization_methods": IpcAuthzEnum.na.value,
        "sast_status": ScanStatusEnum.not_scanned.value,
        "dast_status": ScanStatusEnum.not_scanned.value,
        "parameterized_queries_status": ParamQueriesEnum.na.value,
        "input_validation_methods": None,
        "output_encoding_contexts": None,
        "csrf_protection_mechanism": CsrfEnum.none.value,
        "race_condition_sync": RaceCondEnum.na.value,
        "properties": {
            "exception_expiry": exception_expiry,
            "data_perimeter": data_perimeter,
            "compensating_control": compensating_control,
        },
    }

    connections = _build_connections(
        data_connections,
        scenario_options,
        basis_options,
        service_instance["svcint_id"],
    )
    coupons = _build_coupons(connections, firewall_detail_rows, proxy_detail_rows)

    return ControlExceptionCalmBundle(
        metadata=metadata,
        system=system,
        application=application,
        service=service,
        service_instance=service_instance,
        connections=connections,
        coupons=coupons,
    )


def _build_connections(
    data_connections: List[Dict[str, Any]],
    scenario_options: Dict[str, Any],
    basis_options: Dict[str, Any],
    service_instance_id: str,
) -> List[CalmConnection]:
    rows = data_connections

    connections: List[CalmConnection] = []
    for index, row in enumerate(rows, start=1):
        connection = {
            "conid": _generate_id("CE-CONN"),
            "description": row.get("purpose", "").strip() or "Control exception flow",
            "source_cmpid": f"{service_instance_id}-SRC-{index}",
            "destination_cmpid": f"{service_instance_id}-DST-{index}",
            "connection_type_id": _map_connection_type(row.get("control_exception_types") or []),
            "properties": {},
        }
        properties = connection["properties"]
        src_domain = row.get("src_domain", "").strip() or row.get("src_domain_zone", "").strip()
        dst_domain = row.get("dst_domain", "").strip() or row.get("dst_domain_zone", "").strip()
        src_zone = row.get("src_zone", "").strip()
        dst_zone = row.get("dst_zone", "").strip()
        implemented_controls = row.get("implemented_controls", "")
        if isinstance(implemented_controls, dict):
            implemented_value = implemented_controls
        else:
            implemented_value = str(implemented_controls).strip() if implemented_controls else ""
        properties.update(
            {
                "source_object": row.get("src_object", "").strip(),
                "source_domain": src_domain,
                "source_zone": src_zone,
                "destination_object": row.get("dst_object", "").strip(),
                "destination_domain": dst_domain,
                "destination_zone": dst_zone,
                "protocol": row.get("accessed_protocol", "").strip(),
                "payload_data": row.get("payload_data", "").strip(),
                "implemented_controls": implemented_value,
                "purpose": row.get("purpose", "").strip(),
                "control_exception_types": row.get("control_exception_types") or [],
                "scenario_options": scenario_options,
                "basis_options": basis_options,
            })
        connections.append(CalmConnection(connection, index))
    return connections


def _map_connection_type(control_types: List[str]) -> str:
    if "firewall_flow" in control_types:
        return "CONN-FIREWALL"
    if "proxy_flow" in control_types:
        return "CONN-PROXY"
    if "privileged_access" in control_types:
        return "CONN-PRIVILEGED"
    if "enable_poc_testing" in control_types:
        return "CONN-POC"
    return "CONN-GENERIC"


def _build_coupons(
    connections: List[CalmConnection],
    firewall_rows: List[Dict[str, Any]],
    proxy_rows: List[Dict[str, Any]],
) -> List[CalmCoupon]:
    coupons: List[CalmCoupon] = []
    connection_lookup = {index + 1: connection for index, connection in enumerate(connections)}

    for detail in firewall_rows:
        connection = _lookup_connection(connection_lookup, detail.get("connection_ref"))
        if not connection:
            continue
        coupons.append(
            CalmCoupon(
                coupon_id=_generate_id("ce-coupon"),
                coupon_type="FIREWALL_FLOW",
                connection_id=connection.connection_id,
                properties={
                    "connection_ref": detail.get("connection_ref"),
                    "source": {
                        "eonid": detail.get("source_eonid", ""),
                        "application": detail.get("source_application", ""),
                        "component": detail.get("source_component", ""),
                        "domain": detail.get("source_domain", ""),
                        "zone": detail.get("source_zone", ""),
                        "subnet": detail.get("source_subnet", ""),
                    },
                    "destination": {
                        "eonid": detail.get("destination_eonid", ""),
                        "application": detail.get("destination_application", ""),
                        "component": detail.get("destination_component", ""),
                        "domain": detail.get("destination_domain", ""),
                        "zone": detail.get("destination_zone", ""),
                        "subnet": detail.get("destination_subnet", ""),
                    },
                    "protocol_ports": detail.get("protocol_ports") or (
                        [detail.get("protocol_port")] if detail.get("protocol_port") else []
                    ),
                    "business_justification": detail.get("business_justification", ""),
                    "expiry_date": detail.get("expiry_date"),
                },
            )
        )

    for detail in proxy_rows:
        connection = _lookup_connection(connection_lookup, detail.get("connection_ref"))
        if not connection:
            continue
        coupons.append(
            CalmCoupon(
                coupon_id=_generate_id("ce-coupon"),
                coupon_type="PROXY_FLOW",
                connection_id=connection.connection_id,
                properties={
                    "connection_ref": detail.get("connection_ref"),
                    "target_urls": detail.get("target_urls") or [],
                    "proxy_type": detail.get("proxy_type"),
                    "proxy_authentication": detail.get("proxy_authentication"),
                    "proxy_ssl_inspection": detail.get("proxy_ssl_inspection"),
                    "proxy_antivirus": detail.get("proxy_antivirus"),
                    "expiry_date": detail.get("expiry_date"),
                },
            )
        )

    return coupons


def _lookup_connection(
    connection_lookup: Dict[int, CalmConnection],
    reference: Any,
) -> Optional[CalmConnection]:
    try:
        index = int(reference)
    except (TypeError, ValueError):
        return None
    if index < 1:
        return None
    return connection_lookup.get(index)


# --- Blueprint evaluation -----------------------------------------------------

def evaluate_control_exception_blueprints(
    bundle: ControlExceptionCalmBundle,
    raw_payload: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """
    Evaluate bundle data against DSL blueprint rules loaded from YAML configuration.
    """
    return evaluate_blueprint_templates(
        raw_payload=raw_payload,
        calm_bundle=bundle,
        review_type="control_exception",
    )
