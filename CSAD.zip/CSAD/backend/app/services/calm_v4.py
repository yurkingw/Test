from __future__ import annotations

from typing import Any, Dict, List, Optional
import re

from app.services.security_blueprint_pattern import generate_calm_blueprints_from_templates


QUESTION_LABELS = {
    "arr20": "ARR 2.0",
    "isc": "ISC",
    "pii": "PII",
    "mnpi": "MNPI",
    "external_transfer": "Any data involving update, upgrade, upload or download accessed through External?",
    "prod_data": "Any PROD Data involved?",
    "prod_mdex": "Any connection through [Prod] COD MDEX domains?",
    "prod_mssip": "Any connection through [Prod] COD MSSIP domains?",
}


def _to_array(value: Any) -> List[Any]:
    if isinstance(value, list):
        return value
    if value is None:
        return []
    return [value]


def _format_pattern_id(raw: Any, width: int = 5) -> str:
    if raw is None:
        return ""
    raw_str = str(raw)
    if raw_str.isdigit():
        return raw_str.zfill(width)
    digits = re.sub(r"\D", "", raw_str)
    if digits:
        return digits.zfill(width)
    return raw_str


def _format_fragment_id(raw: Any, width: int = 5) -> str:
    if raw is None:
        return ""
    raw_str = str(raw)
    if raw_str.startswith("FRG-"):
        return raw_str
    digits = re.sub(r"\D", "", raw_str)
    if digits:
        return f"FRG-{digits.zfill(width)}"
    return f"FRG-{raw_str}"


def _format_connection_id(index: Any) -> str:
    if index is None:
        return ""
    try:
        number = int(index)
    except (TypeError, ValueError):
        return ""
    return f"CON-{number:02d}"


def _build_data_perimeter(data_perimeter: Dict[str, Any]) -> Dict[str, Any]:
    return {
        key: {"question": QUESTION_LABELS.get(key, key), "value": data_perimeter.get(key, "")}
        for key in QUESTION_LABELS
    }


def _build_finding_type(finding: Any) -> str:
    kind = _get_attr(finding, "kind") or ""
    fid = _get_attr(finding, "id") or ""
    if kind == "ai" or str(fid).startswith("AI-"):
        return "AI Pre-Review"
    if kind == "manual":
        return "Manual Review"
    return "Rule-Based Pre-Review"


def _normalize_requirement(value: Any) -> List[Dict[str, Any]]:
    if not value:
        return []
    if isinstance(value, list):
        return [
            item if isinstance(item, dict) else {"description": str(item)}
            for item in value
            if item is not None
        ]
    if isinstance(value, dict):
        return [value]
    return [{"description": str(value)}]


def _normalize_recommendation(risk: Any, requirement: Any) -> List[Dict[str, Any]]:
    if isinstance(risk, str) and "low" in risk.lower():
        return _normalize_requirement(requirement)
    return []


def _get_attr(obj: Any, key: str, default: Any = None) -> Any:
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _resolve_finding_text(finding: Any) -> Dict[str, Any]:
    details = _get_attr(finding, "details") or {}
    return {
        "violation_summary": details.get("violation_summary")
        or _get_attr(finding, "riskDescription")
        or details.get("riskDescription")
        or "—",
        "risk": details.get("risk") or _get_attr(finding, "riskLevel") or "—",
        "classification": details.get("classification")
        or _get_attr(finding, "classification")
        or "—",
        "requirement": details.get("requirement")
        or _get_attr(finding, "requirement")
        or details.get("control_requirement")
        or "",
        "issue_context": details.get("issue_context")
        or details.get("issueContext")
        or _get_attr(finding, "issueContext")
        or "",
    }


def _resolve_pattern_id(finding: Any) -> str:
    details = _get_attr(finding, "details") or {}
    raw = (
        details.get("triggered_blueprint_id")
        or _get_attr(finding, "pattern_id")
        or _get_attr(finding, "blueprint_id")
        or ""
    )
    return _format_pattern_id(raw)


def _resolve_tcep_id(finding: Any) -> str:
    details = _get_attr(finding, "details") or {}
    return (
        details.get("tcep_cr_id")
        or (details.get("violating_condition_snapshot") or {}).get("tcep_cr_id")
        or _get_attr(finding, "tcep_cr_id")
        or ""
    )


def _build_review_findings(findings: List[Any], manual_findings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    combined: List[Any] = list(findings or [])
    for item in manual_findings or []:
        combined.append(
            {
                **item,
                "kind": "manual",
                "details": {
                    "violation_summary": item.get("riskDescription", ""),
                    "risk": item.get("riskLevel", ""),
                    "classification": item.get("classification", ""),
                    "requirement": item.get("requirement", ""),
                    "issue_context": item.get("issueContext", ""),
                    "suppressed": item.get("suppressed", False),
                },
            }
        )

    output: List[Dict[str, Any]] = []
    for idx, finding in enumerate(combined, start=1):
        details = _get_attr(finding, "details") or {}
        resolved = _resolve_finding_text(finding)
        status = details.get("status") or _get_attr(finding, "status") or "open"
        snapshot = dict(details.get("violating_condition_snapshot") or {})
        if "connection_properties" in snapshot:
            snapshot.pop("connection_properties", None)
        if resolved["issue_context"]:
            snapshot["issue_context"] = resolved["issue_context"]
        normalized_requirement = _normalize_requirement(resolved["requirement"])
        recommendation = _normalize_recommendation(resolved["risk"], resolved["requirement"])
        connection_index = snapshot.get("connection_index")
        violating_entity_id = (
            _format_connection_id(connection_index)
            if connection_index
            else details.get("violating_entity_id") or _get_attr(finding, "violating_entity_id") or ""
        )
        violating_entity_type = (
            "Connection"
            if connection_index
            else details.get("violating_entity_type")
            or _get_attr(finding, "violating_entity_type")
            or "System"
        )
        output.append(
            {
                "finding_id": f"FIN-{idx:02d}",
                "pattern_id": _resolve_pattern_id(finding),
                "tcep_cr_id": _resolve_tcep_id(finding),
                "violating_entity_type": violating_entity_type,
                "violating_entity_id": violating_entity_id,
                "violating_condition_snapshot": snapshot,
                "violation_summary": resolved["violation_summary"],
                "risk": resolved["risk"],
                "requirement": normalized_requirement,
                "recommendation": recommendation,
                "status": status,
                "properties": {
                    "from_review_process": {
                        "finding_type": _build_finding_type(finding),
                        "classification": resolved["classification"],
                        "suppress": bool(
                            _get_attr(finding, "suppressed") or details.get("suppressed")
                        ),
                    }
                },
            }
        )
    return output


def _build_security_blueprints(templates: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    fragments: List[Dict[str, Any]] = []
    fragment_registry: Dict[str, Dict[str, Any]] = {}

    for fragment in _to_array(templates.get("security_fragments")):
        raw_id = fragment.get("fragment_id") or fragment.get("pattern_id") or fragment.get("id") or ""
        fragment_id = _format_fragment_id(raw_id)
        if fragment_id in fragment_registry:
            continue
        payload = {
            "fragment_id": fragment_id,
            "fragment_name": fragment.get("fragment_name") or fragment.get("name") or "",
            "target_entity": fragment.get("target_entity") or "",
            "condition": fragment.get("condition") or fragment.get("when") or {},
        }
        fragment_registry[fragment_id] = payload
        fragments.append(payload)

    blueprints: List[Dict[str, Any]] = []
    for blueprint in _to_array(templates.get("security_blueprints")):
        raw_pattern = blueprint.get("pattern_id") or blueprint.get("blueprint_id") or blueprint.get("id") or ""
        pattern_id = _format_pattern_id(raw_pattern)
        fragment_ref = _format_fragment_id(
            blueprint.get("fragment_id") or blueprint.get("security_fragment_ref") or raw_pattern
        )
        if fragment_ref not in fragment_registry:
            fallback = {
                "fragment_id": fragment_ref,
                "fragment_name": blueprint.get("blueprint_name") or blueprint.get("name") or "",
                "target_entity": blueprint.get("target_entity") or "",
                "condition": blueprint.get("condition") or blueprint.get("when") or {},
            }
            fragment_registry[fragment_ref] = fallback
            fragments.append(fallback)

        rules: List[Dict[str, Any]] = []
        for rule in _to_array(blueprint.get("rules")):
            rule_id = _format_pattern_id(rule.get("rule_id") or raw_pattern)
            definitions: List[Dict[str, Any]] = []
            for definition in _to_array(rule.get("definitions")):
                cond = definition.get("condition") or {}
                cond = {
                    **cond,
                    "security_fragment_ref": _format_fragment_id(
                        cond.get("security_fragment_ref") or fragment_ref
                    ),
                }
                definitions.append({**definition, "condition": cond})
            rules.append({**rule, "rule_id": rule_id, "definitions": definitions})

        if not rules:
            review_template = blueprint.get("review_finding_template") or {}
            rules = [
                {
                    "rule_id": _format_pattern_id(raw_pattern),
                    "target_entity": blueprint.get("target_entity") or "",
                    "definitions": [
                        {
                            "tcep_cr_id": review_template.get("tcep_cr_id") or "",
                            "condition": {"security_fragment_ref": _format_fragment_id(fragment_ref)},
                            "outcome": {
                                "violation_summary": review_template.get("violation_summary") or "",
                                "risk": review_template.get("risk") or "",
                                "requirement": review_template.get("requirement") or [],
                            },
                        }
                    ],
                }
            ]

        blueprints.append(
            {
                "pattern_id": pattern_id,
                "blueprint_name": blueprint.get("blueprint_name") or blueprint.get("name") or "",
                "target_entity": blueprint.get("target_entity") or "",
                "rules": rules,
            }
        )

    return {"security_fragments": fragments, "security_blueprints": blueprints}


def build_control_exception_calm(
    payload: Dict[str, Any],
    findings: List[Any],
    manual_findings: Optional[List[Dict[str, Any]]] = None,
    templates: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    checklist = (payload.get("metadata") or {}).get("checklist") or {}
    data_connections = _to_array(checklist.get("data_connections"))
    firewall_details = _to_array(checklist.get("firewall_details"))
    proxy_details = _to_array(checklist.get("proxy_details"))
    exception_expiry = checklist.get("exception_expiry") or checklist.get("expected_exception") or ""

    system = [
        {
            "cmdb_sysid": "",
            "sysname": "",
            "description": "",
            "properties": {
                "from_control_exception_form": {
                    "basis_options": checklist.get("basis_options") or {},
                    "scenario_options": checklist.get("scenario_options") or {},
                    "scenario_other_context": checklist.get("scenario_other_context") or "",
                    "business_justification": checklist.get("business_justification") or "",
                    "architecture_description": checklist.get("architecture_description") or "",
                    "architecture_files": checklist.get("architecture_files") or [],
                    "data_perimeter": _build_data_perimeter(checklist.get("data_perimeter") or {}),
                    "exception_expiry": exception_expiry,
                    "integrator_reviewer": checklist.get("integrator_reviewer") or "",
                }
            },
        }
    ]

    application = [{"appid": "APP-01", "appname": "", "cmdb_sysid": ""}]
    service = [{"svcid": "SVC-01", "svcname": "", "appid": "APP-01"}]

    service_instances: List[Dict[str, Any]] = []
    components: List[Dict[str, Any]] = []
    connection_types: List[Dict[str, Any]] = []
    connections: List[Dict[str, Any]] = []
    coupon_types: List[Dict[str, Any]] = []
    coupons: List[Dict[str, Any]] = []

    svcint_counter = 1
    component_counter = 1
    connection_type_counter = 1
    connection_counter = 1
    coupon_type_counter = 1
    coupon_counter = 1

    connection_id_by_row: Dict[int, str] = {}

    for index, row in enumerate(data_connections, start=1):
        source_svc_id = f"SVCINT-{svcint_counter:02d}"
        svcint_counter += 1
        dest_svc_id = f"SVCINT-{svcint_counter:02d}"
        svcint_counter += 1

        service_instances.append(
            {
                "svcint_id": source_svc_id,
                "svcintname": "",
                "svcid": "SVC-01",
                "properties": {
                    "from_control_exception_form": {
                        "src_object": row.get("src_object") or "",
                        "src_domain": row.get("src_domain") or "",
                        "src_zone": row.get("src_zone") or "",
                    }
                },
            }
        )
        service_instances.append(
            {
                "svcint_id": dest_svc_id,
                "svcintname": "",
                "svcid": "SVC-01",
                "properties": {
                    "from_control_exception_form": {
                        "dst_object": row.get("dst_object") or "",
                        "dst_domain": row.get("dst_domain") or "",
                        "dst_zone": row.get("dst_zone") or "",
                    }
                },
            }
        )

        source_component_id = f"CMP-{component_counter:02d}"
        component_counter += 1
        dest_component_id = f"CMP-{component_counter:02d}"
        component_counter += 1

        source_instance = service_instances[-2]
        dest_instance = service_instances[-1]
        components.append(
            {
                "cmpid": source_component_id,
                "cmpname": "",
                "svcint_id": source_svc_id,
                "properties": {
                    "from_system": system[0].get("properties") or {},
                    "from_application": application[0].get("properties") or {},
                    "from_service": service[0].get("properties") or {},
                    "from_serviceinstance": source_instance.get("properties") or {},
                },
            }
        )
        components.append(
            {
                "cmpid": dest_component_id,
                "cmpname": "",
                "svcint_id": dest_svc_id,
                "properties": {
                    "from_system": system[0].get("properties") or {},
                    "from_application": application[0].get("properties") or {},
                    "from_service": service[0].get("properties") or {},
                    "from_serviceinstance": dest_instance.get("properties") or {},
                },
            }
        )

        connection_type_id = f"CONTYP-{connection_type_counter:02d}"
        connection_type_counter += 1
        connection_types.append(
            {
                "connection_type_id": connection_type_id,
                "connection_type_name": "",
                "properties": {
                    "from_control_exception_form": {
                        "id": f"#{index}",
                        "original_id": row.get("id") or "",
                        "row_index": index,
                        "control_exception_types": row.get("control_exception_types") or [],
                        "accessed_protocol": row.get("accessed_protocol") or "",
                        "payload_data": row.get("payload_data") or "",
                        "implemented_controls": row.get("implemented_controls") or {},
                        "purpose": row.get("purpose") or "",
                    }
                },
            }
        )

        connection_id = f"CON-{connection_counter:02d}"
        connection_counter += 1
        connection_id_by_row[index] = connection_id

        source_component = components[-2]
        dest_component = components[-1]
        connections.append(
            {
                "conid": connection_id,
                "source": {
                    "component_id": source_component_id,
                    "properties": {"from_component": source_component.get("properties") or {}},
                },
                "destination": {
                    "component_id": dest_component_id,
                    "properties": {"from_component": dest_component.get("properties") or {}},
                },
                "connection_type_id": connection_type_id,
                "properties": {
                    "from_connection_type": connection_types[-1].get("properties") or {}
                },
            }
        )

    def _build_coupon_type(detail: Dict[str, Any], type_name: str) -> Dict[str, Any]:
        nonlocal coupon_type_counter
        coupon_type_id = f"COPTYP-{coupon_type_counter:02d}"
        coupon_type_counter += 1
        payload = {
            "coupon_type_id": coupon_type_id,
            "coupon_type_name": type_name,
            "properties": {"from_control_exception_form": {**detail}},
        }
        coupon_types.append(payload)
        return payload

    def _build_coupon(detail: Dict[str, Any], type_name: str, connection_ref: Any) -> None:
        nonlocal coupon_counter
        coupon_type = _build_coupon_type(detail, type_name)
        coupon_id = f"COP-{coupon_counter:02d}"
        coupon_counter += 1
        conn_id = connection_id_by_row.get(int(connection_ref) if connection_ref else 0, "")
        coupons.append(
            {
                "coupon_id": coupon_id,
                "coupon_type_id": coupon_type.get("coupon_type_id"),
                "triggering_connection_id": conn_id,
                "expiry": detail.get("expiry_date") or "",
                "justification": detail.get("business_justification") or "",
                "properties": {
                    "from_connection": next(
                        (conn.get("properties") for conn in connections if conn.get("conid") == conn_id),
                        {},
                    ),
                    "from_coupon_type": coupon_type.get("properties") or {},
                },
            }
        )

    for detail in firewall_details:
        _build_coupon(detail, "FIREWALL_FLOW", detail.get("connection_ref"))
    for detail in proxy_details:
        _build_coupon(detail, "PROXY_FLOW", detail.get("connection_ref"))

    architecture_model = [
        {
            "architecture_model_id": "ARCHM-01",
            "architecture_model": "",
            "properties": {
                "from_control_exception_form": {
                    "architecture_description": checklist.get("architecture_description") or "",
                    "architecture_files": checklist.get("architecture_files") or [],
                }
            },
        }
    ]

    deployment_model = [
        {"deployment_model_id": "DEPM-01", "deployment_model_name": ""}
    ]

    if templates is None:
        templates = generate_calm_blueprints_from_templates()
    blueprint_payload = _build_security_blueprints(templates or {})

    return {
        "System": system,
        "Application": application,
        "Service": service,
        "ServiceInstance": service_instances,
        "Component": components,
        "Connection": connections,
        "ConnectionType": connection_types,
        "CouponType": coupon_types,
        "Coupon": coupons,
        "ArchitectureModel": architecture_model,
        "DeploymentModel": deployment_model,
        "SecurityFragment": blueprint_payload.get("security_fragments") or [],
        "SecurityBlueprint": blueprint_payload.get("security_blueprints") or [],
        "ReviewFinding": _build_review_findings(findings or [], manual_findings or []),
    }


def strip_attachment_data(value: Any) -> Any:
    if isinstance(value, list):
        return [strip_attachment_data(item) for item in value]
    if isinstance(value, dict):
        cleaned: Dict[str, Any] = {}
        for key, val in value.items():
            if key in ("dataUrl", "data_url"):
                continue
            if key in ("attachments", "files") and isinstance(val, list):
                cleaned[key] = [
                    {
                        "name": item.get("name"),
                        "type": item.get("type"),
                        "size": item.get("size"),
                    }
                    if isinstance(item, dict)
                    else item
                    for item in val
                ]
                continue
            cleaned[key] = strip_attachment_data(val)
        return cleaned
    return value


def build_calm_summary_v4(
    payload: Dict[str, Any],
    findings: List[Any],
    manual_findings: Optional[List[Dict[str, Any]]] = None,
    templates: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    review_type = payload.get("review_type") or payload.get("reviewType") or ""
    inferred = review_type or ("control_exception" if payload.get("metadata", {}).get("checklist") else "")
    if inferred != "control_exception":
        return payload.get("calmSummary") or {}
    calm_summary = build_control_exception_calm(payload, findings, manual_findings, templates)
    return strip_attachment_data(calm_summary)
