"""
Load and cache application config from YAML with env substitution.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict
import os
import re
import time
import yaml

CONFIG_PATH = Path(__file__).resolve().parent.parent / "config" / "app_config.yaml"
ENV_PATTERN = re.compile(r"\$\{([^}:]+)(?::-(.+))?\}")


@dataclass
class _ConfigCache:
    data: Dict[str, Any] | None = None
    loaded_at: float = 0.0


_cache = _ConfigCache()


def _expand_env(value: Any) -> Any:
    if isinstance(value, str):
        def replace(match: re.Match[str]) -> str:
            key = match.group(1)
            default = match.group(2)
            return os.getenv(key, default or "")

        return ENV_PATTERN.sub(replace, value)
    if isinstance(value, list):
        return [_expand_env(item) for item in value]
    if isinstance(value, dict):
        return {key: _expand_env(val) for key, val in value.items()}
    return value


def load_app_config() -> Dict[str, Any]:
    if not CONFIG_PATH.exists():
        return {}
    with open(CONFIG_PATH, "r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle) or {}
    return _expand_env(raw)


def get_app_config(force_refresh: bool = False) -> Dict[str, Any]:
    now = time.time()
    if force_refresh or _cache.data is None:
        _cache.data = load_app_config()
        _cache.loaded_at = now
    return _cache.data or {}
