"""
Service for interacting with the OpenAI API.
"""

import base64
import json
import mimetypes
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple

import docx
import PyPDF2
import io
from openai import OpenAI

from app.core.config import settings
from app.services.app_config import get_app_config
from app.services.review_config import get_review_config, DEFAULT_REVIEW_TYPE

# Initialize the OpenAI client with the API key (and optional org/project) from settings
_client_kwargs: Dict[str, Any] = {"api_key": settings.OPENAI_API_KEY}
if settings.OPENAI_ORG_ID:
    _client_kwargs["organization"] = settings.OPENAI_ORG_ID
if settings.OPENAI_PROJECT:
    _client_kwargs["project"] = settings.OPENAI_PROJECT

client = OpenAI(**_client_kwargs)

TEXT_FILE_EXTENSIONS = (".txt", ".md", ".csv", ".json")
DOCUMENT_EXTENSIONS = (".docx", ".pdf")
IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp")

def _get_sampling_params() -> Dict[str, Any]:
    config = get_app_config()
    ai_config = config.get("ai_assistant", {})
    temperature = ai_config.get("temperature", 0)
    top_p = ai_config.get("top_p", 0.2)
    try:
        temperature = float(temperature)
    except (TypeError, ValueError):
        temperature = 0
    try:
        top_p = float(top_p)
    except (TypeError, ValueError):
        top_p = 0.2
    return {"temperature": temperature, "top_p": top_p}


def _load_pre_review_prompt() -> str:
    config = get_app_config()
    prompt_path = (
        config.get("ai_assistant", {}).get("pre_review_prompt_path")
        or "/app/app/prompts/ai_pre_review_prompt.md"
    )
    fallback_path = Path(__file__).resolve().parent.parent / "prompts" / "ai_pre_review_prompt.md"
    try:
        path = Path(prompt_path)
        if path.exists():
            return path.read_text(encoding="utf-8")
        if fallback_path.exists():
            return fallback_path.read_text(encoding="utf-8")
        return ""
    except Exception as exc:
        print(f"AI pre-review prompt load failed: {exc}")
        return ""


def _classification_from_risk(risk: Any) -> str:
    if isinstance(risk, str) and "low" in risk.lower():
        return "Recommendation"
    return "Requirement"

def _parse_file_content(file_content: bytes, filename: str) -> str:
    """Extract plain text from supported document types."""
    text = ""
    try:
        lower_name = filename.lower()
        if lower_name.endswith(TEXT_FILE_EXTENSIONS):
            text = file_content.decode("utf-8")
        elif lower_name.endswith(".docx"):
            doc = docx.Document(io.BytesIO(file_content))
            for para in doc.paragraphs:
                text += para.text + "\n"
        elif lower_name.endswith(".pdf"):
            reader = PyPDF2.PdfReader(io.BytesIO(file_content))
            for page in reader.pages:
                extracted = page.extract_text()
                if extracted:
                    text += extracted + "\n"
        else:
            text = file_content.decode("utf-8", errors="ignore")
    except Exception as exc:
        print(f"Error parsing file {filename}: {exc}")
        return f"Error parsing file: {filename}. The system could not extract the text content."
    return text.strip()

def _prepare_attachment_payload(file_bytes: bytes, filename: str) -> Dict[str, Any]:
    """Prepare attachment payload for OpenAI messages."""
    lower_name = filename.lower()
    if lower_name.endswith(IMAGE_EXTENSIONS):
        mime_type = mimetypes.guess_type(filename)[0] or "image/png"
        b64 = base64.b64encode(file_bytes).decode("utf-8")
        data_url = f"data:{mime_type};base64,{b64}"
        return {"type": "image", "filename": filename, "data_url": data_url}

    # Fallback to text extraction for documents
    extracted_text = _parse_file_content(file_bytes, filename)
    return {"type": "text", "filename": filename, "text": extracted_text}

def _build_openai_messages(
    conversation: List[Dict[str, str]],
    latest_user_text: str,
    file_attachments: List[Dict[str, Any]],
    security_attachments: List[Dict[str, Any]],
    review_type: str,
) -> List[Dict[str, Any]]:
    """Construct the message payload for Chat Completions."""
    config = get_review_config(review_type)
    system_prompt = config["chat_system_prompt"]

    messages_payload: List[Dict[str, Any]] = [
        {
            "role": "system",
            "content": [{"type": "text", "text": system_prompt}],
        }
    ]

    conversation_copy = [
        {"sender": msg.get("sender", "user"), "text": msg.get("text", "")}
        for msg in conversation
    ]

    if conversation_copy and conversation_copy[-1]["sender"].lower() == "user":
        conversation_copy[-1]["text"] = latest_user_text
    else:
        conversation_copy.append({"sender": "user", "text": latest_user_text})

    for index, msg in enumerate(conversation_copy):
        role = "user" if msg["sender"].lower() == "user" else "assistant"
        base_text = msg.get("text", "")
        content_blocks: List[Dict[str, Any]] = [{"type": "text", "text": base_text or ""}]

        is_latest_user_message = role == "user" and index == len(conversation_copy) - 1
        if is_latest_user_message:
            for attachment in [*(file_attachments or []), *(security_attachments or [])]:
                if not attachment:
                    continue
                if attachment["type"] == "text":
                    attachment_text = attachment["text"]
                    attachment_header = (
                        f"\n\n---\nAttachment: {attachment['filename']}\n{attachment_text}\n---\n"
                    )
                    content_blocks.append({"type": "text", "text": attachment_header})
                elif attachment["type"] == "image":
                    content_blocks.append(
                        {
                            "type": "image_url",
                            "image_url": {"url": attachment["data_url"]},
                        }
                    )

        messages_payload.append({"role": role, "content": content_blocks})

    return messages_payload

def generate_chat_reply(
    conversation: List[Dict[str, str]],
    latest_user_text: str,
    file_attachments: List[Tuple[bytes, str]],
    security_attachments: List[Tuple[bytes, str]],
    review_type: str,
) -> Dict[str, str]:
    """Generate a reply for the AI chat workflow."""
    prepared_files = [
        _prepare_attachment_payload(content, name) for content, name in file_attachments
    ] if file_attachments else []
    prepared_security = [
        _prepare_attachment_payload(content, name) for content, name in security_attachments
    ] if security_attachments else []

    openai_messages = _build_openai_messages(
        conversation=conversation,
        latest_user_text=latest_user_text,
        file_attachments=prepared_files,
        security_attachments=prepared_security,
        review_type=review_type,
    )

    try:
        sampling_params = _get_sampling_params()
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=openai_messages,
            temperature=sampling_params["temperature"],
            top_p=sampling_params["top_p"],
        )
        reply_text = response.choices[0].message.content or ""
    except Exception as exc:
        print(f"Error calling OpenAI API: {exc}")
        return {
            "reply": "The AI assistant encountered an error while processing your request. "
                     "Please try again later.",
            "analysis_markdown": "## AI Processing Error\nUnable to complete the analysis. Please retry.",
        }

    formatted_reply = reply_text

    return {
        "reply": reply_text,
        "analysis_markdown": formatted_reply,
    }

def generate_findings_from_conversation(messages: List[Dict[str, str]], review_type: str) -> List[Dict]:
    """
    Analyzes a conversation and generates a structured list of security findings.
    """
    config = get_review_config(review_type)
    type_specific_intro = config["finding_prompt_intro"]

    review_finding_schema_prompt = {
        "details": {
            "violation_summary": "A concise, one-sentence summary of the finding.",
            "risk": "The estimated risk level (e.g., High, Medium, Low).",
            "requirement": [
                {
                    "description": "A specific, actionable requirement to mitigate the risk.",
                    "tech_control_id": "A reference to a technical control standard (e.g., TEC-026)."
                }
            ]
        },
        "blueprint_id": "The ID of the security blueprint that was violated (use a placeholder like 1 if unknown)."
    }

    system_prompt = f'''
    You are a security analyst bot. Your task is to analyze the following conversation between a user and an AI assistant.
    The conversation is about a system design.
    Your goal is to identify all the potential security risks or findings that were discussed.
    {type_specific_intro}
    You must output a single, valid JSON object. This JSON object must have a single key named "findings", which is an array of finding objects.
    Each object in the "findings" array must conform to the following structure.
    Do NOT output any text or explanation before or after the JSON object.

    JSON Schema for each finding object:
    {json.dumps(review_finding_schema_prompt, indent=2)}

    Conversation History:
    '''

    conversation_text = "".join([f"{msg['sender'].capitalize()}: {msg['text']}\n" for msg in messages])
    full_prompt = system_prompt + conversation_text

    try:
        sampling_params = _get_sampling_params()
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a helpful assistant that only outputs valid JSON."},
                {"role": "user", "content": full_prompt},
            ],
            temperature=sampling_params["temperature"],
            top_p=sampling_params["top_p"],
            response_format={"type": "json_object"},
        )
        
        response_content = response.choices[0].message.content
        findings_data = json.loads(response_content)
        return findings_data.get("findings", [])

    except Exception as e:
        print(f"Error generating findings from conversation: {e}")
        return []


def generate_ai_pre_review_findings(user_design: Dict[str, Any], review_type: str) -> List[Dict[str, Any]]:
    """
    Generate AI-assisted pre-review findings based on the submitted design payload.
    """
    config = get_app_config()
    prompt_template = _load_pre_review_prompt()
    model_name = config.get("ai_assistant", {}).get("model") or "gpt-4o-mini"
    if not prompt_template:
        return []

    payload_json = json.dumps(user_design, indent=2)
    prompt = prompt_template.replace("{{USER_DESIGN_JSON}}", payload_json)

    try:
        sampling_params = _get_sampling_params()
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": "You only output valid JSON."},
                {"role": "user", "content": prompt},
            ],
            temperature=sampling_params["temperature"],
            top_p=sampling_params["top_p"],
            response_format={"type": "json_object"},
        )
        response_content = response.choices[0].message.content or "{}"
        payload = json.loads(response_content)
    except Exception as exc:
        print(f"AI pre-review generation failed: {exc}")
        return []

    findings = payload.get("findings", [])
    data_connections = (
        (user_design.get("metadata") or {})
        .get("checklist", {})
        .get("data_connections", [])
    )
    id_to_index = {
        str(item.get("id")): idx + 1
        for idx, item in enumerate(data_connections)
        if item.get("id")
    }
    normalized: List[Dict[str, Any]] = []
    for idx, item in enumerate(findings, start=1):
        requirement = item.get("requirement") or []
        if isinstance(requirement, dict):
            requirement = [requirement]
        issue_context = item.get("issue_context", "")
        if issue_context:
            for conn_id, conn_index in id_to_index.items():
                if conn_id in issue_context:
                    issue_context = issue_context.replace(conn_id, f"#{conn_index}")
        risk_value = item.get("risk", "Moderate")
        classification = _classification_from_risk(risk_value)
        detail = {
            "finding_id": f"AI-FIN-{idx:03}",
            "triggered_blueprint_id": "AI-PRE-REVIEW",
            "triggered_rule_id": f"AI-RUL-{idx:03}",
            "triggered_definition_id": f"AI-DEF-{idx:03}",
            "violating_entity_type": "UserDesign",
            "violating_entity_id": "USER-DESIGN",
            "violation_summary": item.get("violation_summary", ""),
            "risk": risk_value,
            "classification": classification,
            "requirement": requirement,
            "issue_context": issue_context,
        }
        normalized.append(
            {
                "id": detail["finding_id"],
                "blueprint_id": 0,
                "kind": "ai",
                "classification": classification,
                "details": detail,
            }
        )
    return normalized
