from __future__ import annotations

from typing import Dict, List, Any, Tuple
import json
import urllib.parse
import uuid

import httpx

from app.services.app_config import get_app_config

ROLE_PRIORITY = ["Reviewer", "Requestor", "Auditor", "Peer Reviewer"]


def _aad_config() -> Dict[str, Any]:
    cfg = get_app_config()
    aad_block = cfg.get("aad", {}) or {}
    auth_block = cfg.get("auth", {}) or {}
    aad_app = auth_block.get("aad_app", {}) or {}
    return {
        "tenant_id": aad_block.get("tenant_id") or aad_app.get("tenant_id"),
        "client_id": aad_block.get("client_id") or aad_app.get("client_id"),
        "client_secret": aad_block.get("client_secret") or aad_app.get("client_secret"),
        "authority": aad_block.get("authority") or aad_app.get("authority"),
        "redirect_uri": aad_block.get("redirect_uri") or aad_app.get("redirect_uri"),
        "frontend_redirect_uri": aad_block.get("frontend_redirect_uri"),
        "scopes": aad_block.get("scopes") or ["openid", "profile", "email"],
        "graph_base_url": aad_block.get("graph_base_url") or "https://graph.microsoft.com/v1.0",
        "graph_scope": aad_block.get("graph_scope") or "https://graph.microsoft.com/.default",
        "group_map_raw": auth_block.get("aad_group_map_env") or "{}",
    }


def _group_map(cfg: Dict[str, Any]) -> Dict[str, List[str]]:
    raw = cfg.get("group_map_raw") or "{}"
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, dict):
            return {key: (value if isinstance(value, list) else [value]) for key, value in parsed.items()}
    except Exception:
        return {}
    return {}


def map_groups_to_role(group_ids: List[str], cfg: Dict[str, Any]) -> str:
    mapping = _group_map(cfg)
    matched_roles: List[str] = []
    for gid in group_ids:
        roles = mapping.get(gid)
        if roles:
            matched_roles.extend(roles)
    for role in ROLE_PRIORITY:
        if role in matched_roles:
            return role
    return "Requestor"


def build_authorize_url() -> Tuple[str, str]:
    cfg = _aad_config()
    state = str(uuid.uuid4())
    authority = cfg.get("authority", "").rstrip("/")
    params = {
        "client_id": cfg.get("client_id"),
        "response_type": "code",
        "redirect_uri": cfg.get("redirect_uri"),
        "response_mode": "query",
        "scope": " ".join(cfg.get("scopes") or []),
        "state": state,
    }
    url = f"{authority}/oauth2/v2.0/authorize?{urllib.parse.urlencode(params)}"
    return url, state


def exchange_code_for_token(code: str) -> Dict[str, Any]:
    cfg = _aad_config()
    authority = cfg.get("authority", "").rstrip("/")
    token_url = f"{authority}/oauth2/v2.0/token"
    data = {
        "client_id": cfg.get("client_id"),
        "client_secret": cfg.get("client_secret"),
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": cfg.get("redirect_uri"),
        "scope": " ".join(cfg.get("scopes") or []),
    }
    with httpx.Client(timeout=20) as client:
        resp = client.post(token_url, data=data)
    resp.raise_for_status()
    return resp.json()


def fetch_graph(path: str, access_token: str) -> Dict[str, Any]:
    cfg = _aad_config()
    base = cfg.get("graph_base_url", "").rstrip("/")
    url = f"{base}/{path.lstrip('/')}"
    with httpx.Client(timeout=20) as client:
        resp = client.get(url, headers={"Authorization": f"Bearer {access_token}"})
    resp.raise_for_status()
    return resp.json()


def fetch_user_profile(access_token: str) -> Dict[str, Any]:
    return fetch_graph("me?$select=id,displayName,mail,userPrincipalName", access_token)


def fetch_user_groups(access_token: str) -> List[str]:
    data = fetch_graph("me/memberOf?$select=id", access_token)
    values = data.get("value", []) or []
    return [item.get("id") for item in values if item.get("id")]


def fetch_group_members(access_token: str, group_id: str) -> List[Dict[str, Any]]:
    data = fetch_graph(f"groups/{group_id}/members?$select=id,displayName,mail,userPrincipalName", access_token)
    return data.get("value", []) or []


def client_credentials_token() -> str:
    cfg = _aad_config()
    authority = cfg.get("authority", "").rstrip("/")
    token_url = f"{authority}/oauth2/v2.0/token"
    data = {
        "client_id": cfg.get("client_id"),
        "client_secret": cfg.get("client_secret"),
        "grant_type": "client_credentials",
        "scope": cfg.get("graph_scope"),
    }
    with httpx.Client(timeout=20) as client:
        resp = client.post(token_url, data=data)
    resp.raise_for_status()
    return resp.json().get("access_token")
