'''
Service for running a CALM audit.
'''

from sqlalchemy.orm import Session
from typing import List, Dict, Any

from app import crud, models, schemas
from app.services.review_config import get_review_config, DEFAULT_REVIEW_TYPE
from app.services.control_exception_calm import (
    map_payload_to_calm,
    evaluate_control_exception_blueprints,
)

def run_audit(
    db: Session,
    *,
    user_design: Dict[str, Any],
    review_type: str = DEFAULT_REVIEW_TYPE,
) -> List[Dict[str, Any]]:
    '''
    Runs a CALM audit on a user-submitted design.

    This function will:
    1. Process the incoming user_design data (already done by Pydantic).
    2. Persist the user's design to the database.
    3. Materialize the components and connections.
    4. Fetch the relevant security blueprints.
    5. Evaluate the design against the blueprint rules.
    6. Generate and return a list of review findings.
    '''
    if review_type == "control_exception":
        return _run_control_exception_audit(user_design)

    # --- Placeholder Logic --- #
    config = get_review_config(review_type)
    print(f"Running CALM audit for {config['label']}...")
    print("Received User Design:", user_design)

    dummy_finding = {
        "id": "DUMMY-FIN-001",
        "details": {
            "violation_summary": "This is a dummy finding for a non-compliant RDP connection.",
            "risk": "High",
            "triggered_blueprint_id": "BLP-DUMMY-001"
        },
        "blueprint_id": 1 # Assuming a blueprint with id 1 exists
    }

    return [dummy_finding]


def _run_control_exception_audit(user_design: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Dedicated pipeline for Control Exception Review submissions. This covers:
    1) Mapping user metadata into CALM-style entities,
    2) Evaluating the request against Control Exception blueprint heuristics,
    3) Returning ReviewFinding-like responses that the frontend already expects.
    """
    bundle = map_payload_to_calm(user_design)
    raw_findings = evaluate_control_exception_blueprints(bundle, user_design)

    findings: List[Dict[str, Any]] = []
    for idx, finding in enumerate(raw_findings, start=1):
        details_payload = {
            **finding,
            "finding_id": f"CE-FIN-{idx:03}",
        }
        raw_blueprint_id = finding.get("triggered_blueprint_id")
        blueprint_id = raw_blueprint_id if isinstance(raw_blueprint_id, int) else 0
        findings.append(
            {
                "id": f"CE-FIN-{idx:03}",
                "blueprint_id": blueprint_id,
                "kind": "rule",
                "details": details_payload,
            }
        )
    return findings
