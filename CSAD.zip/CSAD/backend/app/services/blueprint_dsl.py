"""
Lightweight DSL evaluator for CALM security blueprints.

The DSL evaluates rules declared in YAML against a context that includes:
  - raw: the original user design payload
  - calm: normalized CALM entities (system/application/service/service_instance/connections/coupons)
  - connection: current connection (when scope=connection)
  - connection_index: 1-based index of the connection
"""

from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional
import re
import yaml


PATTERN_PATH = Path(__file__).resolve().parent.parent / "config" / "security_blueprint_pattern.yaml"


def _load_config(path: Path = PATTERN_PATH) -> Dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Blueprint DSL config not found: {path}")
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle) or {}


def _normalize_text(value: Any) -> Any:
    if isinstance(value, str):
        return value.strip().lower()
    return value


def _classification_from_risk(risk: Any) -> str:
    if isinstance(risk, str) and "low" in risk.lower():
        return "Recommendation"
    return "Requirement"


def _resolve_path(context: Dict[str, Any], path: str) -> Any:
    current: Any = context
    for key in path.split("."):
        if current is None:
            return None
        if isinstance(current, dict):
            current = current.get(key)
        else:
            return None
    return current


def _resolve_condition_path(context: Dict[str, Any], path: str) -> Any:
    path = path.strip()
    if path.startswith(("raw.", "calm.", "connection.", "system.")):
        return _resolve_path(context, path)
    # Template shorthand defaults to raw metadata checklist
    return _resolve_path(context, f"raw.metadata.checklist.{path}")


def _to_list(value: Any) -> List[Any]:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    return [value]


def _to_number(value: Any) -> Optional[float]:
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _parse_date(value: Any) -> Optional[datetime]:
    if not value:
        return None
    if isinstance(value, datetime):
        return value
    for fmt in ("%Y-%m-%d", "%Y/%m/%d"):
        try:
            return datetime.strptime(str(value), fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def _eval_op(op: str, actual: Any, expected: Any) -> bool:
    op = (op or "equals").lower()
    if op == "equals":
        if isinstance(actual, str) and isinstance(expected, str):
            return _normalize_text(actual) == _normalize_text(expected)
        return actual == expected
    if op == "not_equals":
        return not _eval_op("equals", actual, expected)
    if op == "in":
        if not isinstance(expected, list):
            expected = [expected]
        actual_norm = _normalize_text(actual)
        expected_norm = [_normalize_text(item) for item in expected]
        return actual_norm in expected_norm
    if op == "not_in":
        return not _eval_op("in", actual, expected)
    if op == "contains":
        if isinstance(actual, list):
            return expected in actual
        if isinstance(actual, str):
            return str(expected) in actual
        return False
    if op == "contains_any":
        candidates = _to_list(expected)
        if isinstance(actual, list):
            return any(item in actual for item in candidates)
        if isinstance(actual, str):
            return any(str(item) in actual for item in candidates)
        return False
    if op == "contains_all":
        candidates = _to_list(expected)
        if isinstance(actual, list):
            return all(item in actual for item in candidates)
        if isinstance(actual, str):
            return all(str(item) in actual for item in candidates)
        return False
    if op == "any_true":
        if isinstance(actual, dict):
            return any(bool(value) for value in actual.values())
        if isinstance(actual, list):
            return any(bool(value) for value in actual)
        return bool(actual) is True
    if op == "regex":
        if not isinstance(actual, str):
            return False
        try:
            return re.search(str(expected), actual) is not None
        except re.error:
            return False
    if op == "is_true":
        return bool(actual) is True
    if op == "is_false":
        return bool(actual) is False
    if op == "exists":
        return actual is not None and actual != "" and actual != []
    if op == "not_exists":
        return not _eval_op("exists", actual, expected)
    if op == "min_length":
        return isinstance(actual, str) and len(actual.strip()) >= int(expected)
    if op == "max_length":
        return isinstance(actual, str) and len(actual.strip()) <= int(expected)
    if op == "min_items":
        return isinstance(actual, list) and len(actual) >= int(expected)
    if op == "max_items":
        return isinstance(actual, list) and len(actual) <= int(expected)
    if op in ("gt", "gte", "lt", "lte"):
        actual_num = _to_number(actual)
        expected_num = _to_number(expected)
        if actual_num is None or expected_num is None:
            return False
        if op == "gt":
            return actual_num > expected_num
        if op == "gte":
            return actual_num >= expected_num
        if op == "lt":
            return actual_num < expected_num
        return actual_num <= expected_num
    if op == "between":
        actual_num = _to_number(actual)
        if actual_num is None or not isinstance(expected, list) or len(expected) < 2:
            return False
        low = _to_number(expected[0])
        high = _to_number(expected[1])
        if low is None or high is None:
            return False
        return low <= actual_num <= high
    if op == "max_days_from_now":
        date_value = _parse_date(actual)
        if not date_value:
            return False
        max_allowed = datetime.now(timezone.utc) + timedelta(days=int(expected))
        return date_value <= max_allowed
    if op == "min_days_from_now":
        date_value = _parse_date(actual)
        if not date_value:
            return False
        min_allowed = datetime.now(timezone.utc) + timedelta(days=int(expected))
        return date_value >= min_allowed
    return False


def _eval_condition(condition: Dict[str, Any], context: Dict[str, Any]) -> bool:
    if "all" in condition:
        return all(_eval_condition(item, context) for item in condition.get("all", []))
    if "any" in condition:
        return any(_eval_condition(item, context) for item in condition.get("any", []))
    if "not" in condition:
        return not _eval_condition(condition.get("not") or {}, context)
    path = condition.get("path")
    if not path:
        return False
    actual = _resolve_condition_path(context, path)
    return _eval_op(condition.get("op", "equals"), actual, condition.get("value"))


def _format_text(template: str, **context: Any) -> str:
    if not template:
        return ""
    try:
        return template.format(**context)
    except KeyError:
        return template


def _collect_matched_conditions(condition: Dict[str, Any], context: Dict[str, Any]) -> List[Dict[str, Any]]:
    if "all" in condition:
        matched: List[Dict[str, Any]] = []
        for item in condition.get("all", []):
            if not _eval_condition(item, context):
                return []
            matched.extend(_collect_matched_conditions(item, context))
        return matched
    if "any" in condition:
        matched: List[Dict[str, Any]] = []
        for item in condition.get("any", []):
            if _eval_condition(item, context):
                matched.extend(_collect_matched_conditions(item, context))
        return matched
    if "not" in condition:
        inner = condition.get("not") or {}
        if _eval_condition(inner, context):
            return []
        return _collect_matched_conditions(inner, context)
    path = condition.get("path")
    if not path:
        return []
    actual = _resolve_condition_path(context, path)
    op = condition.get("op", "equals")
    expected = condition.get("value")
    if not _eval_op(op, actual, expected):
        return []
    return [{"path": path, "op": op, "expected": expected, "actual": actual}]


def _build_finding(rule: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    outcome = rule.get("outcome") or {}
    requirement = outcome.get("requirement") or []
    requirement_list = [{"description": item} if isinstance(item, str) else item for item in requirement]
    recommendation = outcome.get("recommendation") or []
    recommendation_list = [{"description": item} if isinstance(item, str) else item for item in recommendation]
    entity_type = outcome.get("violating_entity_type") or context.get("violating_entity_type") or "System"
    entity_id = context.get("violating_entity_id") or context.get("system_id") or ""
    matched_conditions = _collect_matched_conditions(rule.get("when", {}), context)
    snapshot = {
        "connection_index": context.get("connection_index"),
        "tcep_cr_id": outcome.get("tcep_cr_id"),
        "matched_conditions": matched_conditions,
    }
    summary = _format_text(outcome.get("violation_summary", ""), **context)
    risk_value = outcome.get("risk", "")
    classification = _classification_from_risk(risk_value)
    return {
        "triggered_blueprint_id": rule.get("pattern_id") or rule.get("blueprint_id"),
        "triggered_rule_id": rule.get("rule_id") or rule.get("pattern_id"),
        "triggered_definition_id": rule.get("rule_id") or rule.get("pattern_id"),
        "violating_entity_type": entity_type,
        "violating_entity_id": entity_id,
        "violating_condition_snapshot": snapshot,
        "violation_summary": summary,
        "risk": risk_value,
        "classification": classification,
        "tcep_cr_id": outcome.get("tcep_cr_id"),
        "requirement": requirement_list,
        "recommendation": recommendation_list,
        "status": "open",
    }


def evaluate_blueprint_rules(
    *,
    raw_payload: Dict[str, Any],
    calm_bundle: Any,
    review_type: str = "control_exception",
    path: Path = PATTERN_PATH,
) -> List[Dict[str, Any]]:
    config = _load_config(path)
    rules = config.get("rules") or []
    calm = {
        "system": calm_bundle.system,
        "application": calm_bundle.application,
        "service": calm_bundle.service,
        "service_instance": calm_bundle.service_instance,
        "connections": [conn.data for conn in calm_bundle.connections],
        "coupons": [asdict(coupon) for coupon in calm_bundle.coupons],
    }
    findings: List[Dict[str, Any]] = []

    for rule in rules:
        if rule.get("review_type") and rule.get("review_type") != review_type:
            continue
        scope = (rule.get("scope") or "system").lower()
        if scope == "connection":
            for conn in calm_bundle.connections:
                context = {
                    "raw": raw_payload,
                    "calm": calm,
                    "connection": conn.data,
                    "connection_index": conn.index,
                    "violating_entity_type": "Connection",
                    "violating_entity_id": conn.connection_id,
                    "system_id": calm_bundle.system.get("id"),
                }
                if not _eval_condition(rule.get("when", {}), context):
                    continue
                findings.append(_build_finding(rule, context))
        else:
            context = {
                "raw": raw_payload,
                "calm": calm,
                "violating_entity_type": "System",
                "violating_entity_id": calm_bundle.system.get("id"),
                "system_id": calm_bundle.system.get("id"),
            }
            if _eval_condition(rule.get("when", {}), context):
                findings.append(_build_finding(rule, context))
    return findings


def evaluate_blueprint_templates(
    *,
    raw_payload: Dict[str, Any],
    calm_bundle: Any,
    review_type: str = "control_exception",
    path: Path = PATTERN_PATH,
) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle) or {}
    templates = config.get("templates") or []
    calm = {
        "system": calm_bundle.system,
        "application": calm_bundle.application,
        "service": calm_bundle.service,
        "service_instance": calm_bundle.service_instance,
        "connections": [conn.data for conn in calm_bundle.connections],
        "coupons": [asdict(coupon) for coupon in calm_bundle.coupons],
    }
    findings: List[Dict[str, Any]] = []
    for template in templates:
        if template.get("review_type") and template.get("review_type") != review_type:
            continue
        scope = (template.get("scope") or "system").lower()
        targets = calm_bundle.connections if scope == "connection" else [None]
        for conn in targets:
            fragments = template.get("fragments") or []
            template_condition = template.get("condition") or {}
            failed_fragments: List[Dict[str, Any]] = []
            fragment_results: List[bool] = []
            context = {
                "raw": raw_payload,
                "calm": calm,
                "violating_entity_type": template.get("target_entity") or ("Connection" if conn else "System"),
                "violating_entity_id": conn.connection_id if conn else calm_bundle.system.get("id"),
                "system_id": calm_bundle.system.get("id"),
            }
            if conn:
                context["connection"] = conn.data
                context["connection_index"] = conn.index
            violation_condition = template.get("when")
            if violation_condition:
                if not _eval_condition(violation_condition, context):
                    continue
                matched_conditions = _collect_matched_conditions(violation_condition, context)
                outcome = template.get("review_finding") or {}
                requirement = outcome.get("requirement") or []
                requirement_list = [{"description": item} if isinstance(item, str) else item for item in requirement]
                recommendation = outcome.get("recommendation") or []
                recommendation_list = [{"description": item} if isinstance(item, str) else item for item in recommendation]
                snapshot = {
                    "matched_conditions": matched_conditions,
                }
                if conn:
                    snapshot.update(
                        {
                            "connection_index": conn.index,
                        }
                    )
                risk_value = outcome.get("risk", "")
                findings.append(
                    {
                        "triggered_blueprint_id": template.get("pattern_id"),
                        "triggered_rule_id": template.get("pattern_id"),
                        "triggered_definition_id": matched_conditions[0].get("path") if matched_conditions else template.get("pattern_id"),
                        "violating_entity_type": context["violating_entity_type"],
                        "violating_entity_id": context["violating_entity_id"],
                        "violating_condition_snapshot": snapshot,
                        "violation_summary": outcome.get("violation_summary", ""),
                        "risk": risk_value,
                        "classification": _classification_from_risk(risk_value),
                        "tcep_cr_id": outcome.get("tcep_cr_id"),
                        "requirement": requirement_list,
                        "recommendation": recommendation_list,
                        "status": "open",
                    }
                )
                continue
            for fragment in fragments:
                condition = fragment.get("condition") or {}
                condition_type = condition.get("type") or condition.get("op") or "equals"
                condition_path = condition.get("path") or ""
                condition_value = condition.get("value")
                actual = _resolve_condition_path(context, condition_path)
                passed = _eval_op(condition_type, actual, condition_value)
                fragment_results.append(passed)
                if not passed:
                    failed_fragments.append(
                        {
                            "fragment_id": fragment.get("fragment_id"),
                            "name": fragment.get("name"),
                            "path": condition_path,
                            "op": condition_type,
                            "expected": condition_value,
                            "actual": actual,
                        }
                    )
            if template_condition:
                condition_type = template_condition.get("type") or template_condition.get("op") or "equals"
                condition_path = template_condition.get("path") or ""
                condition_value = template_condition.get("value")
                actual = _resolve_condition_path(context, condition_path)
                passed = _eval_op(condition_type, actual, condition_value)
                fragment_results.append(passed)
                if not passed:
                    failed_fragments.append(
                    {
                        "fragment_id": template.get("pattern_id"),
                            "name": f"{template.get('name') or 'Blueprint'} (template condition)",
                            "path": condition_path,
                            "op": condition_type,
                            "expected": condition_value,
                            "actual": actual,
                        }
                    )
            logic = (template.get("fragments_logic") or "all").lower()
            if logic == "any":
                blueprint_passed = any(fragment_results)
            elif logic == "none":
                blueprint_passed = not any(fragment_results)
            else:
                blueprint_passed = all(fragment_results)

            if blueprint_passed:
                continue
            outcome = template.get("review_finding") or {}
            requirement = outcome.get("requirement") or []
            requirement_list = [{"description": item} if isinstance(item, str) else item for item in requirement]
            recommendation = outcome.get("recommendation") or []
            recommendation_list = [{"description": item} if isinstance(item, str) else item for item in recommendation]
            snapshot = {
                "failed_fragments": failed_fragments,
            }
            if conn:
                snapshot.update(
                    {
                        "connection_index": conn.index,
                    }
                )
            risk_value = outcome.get("risk", "")
            findings.append(
                {
                    "triggered_blueprint_id": template.get("pattern_id"),
                    "triggered_rule_id": template.get("pattern_id"),
                    "triggered_definition_id": failed_fragments[0].get("fragment_id") if failed_fragments else template.get("pattern_id"),
                    "violating_entity_type": context["violating_entity_type"],
                    "violating_entity_id": context["violating_entity_id"],
                    "violating_condition_snapshot": snapshot,
                    "violation_summary": outcome.get("violation_summary", ""),
                    "risk": risk_value,
                    "classification": _classification_from_risk(risk_value),
                    "tcep_cr_id": outcome.get("tcep_cr_id"),
                    "requirement": requirement_list,
                    "recommendation": recommendation_list,
                    "status": "open",
                }
            )
    return findings
