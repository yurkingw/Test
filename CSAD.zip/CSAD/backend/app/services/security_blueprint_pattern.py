"""
Generate CALM SecurityBlueprint/SecurityFragment structures from intermediate
template configuration.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List
import yaml

PATTERN_PATH = Path(__file__).resolve().parent.parent / "config" / "security_blueprint_pattern.yaml"


def load_template_document(path: Path = PATTERN_PATH) -> Dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"Security blueprint pattern config not found: {path}")
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle) or {}


def generate_calm_blueprints_from_templates(path: Path = PATTERN_PATH) -> Dict[str, List[Dict[str, Any]]]:
    """
    Convert intermediate template documents into CALM-style fragments/blueprints.
    """
    document = load_template_document(path)
    templates = document.get("templates") or []

    fragment_registry: Dict[str, Dict[str, Any]] = {}
    fragments: List[Dict[str, Any]] = []
    blueprints: List[Dict[str, Any]] = []

    for template in templates:
        pattern_id = template.get("pattern_id") or template.get("name")
        fragment_refs: List[Dict[str, Any]] = []
        for fragment_def in template.get("fragments", []):
            fragment_id = fragment_def.get("fragment_id")
            if not fragment_id:
                continue
            if fragment_id not in fragment_registry:
                fragment_payload = {
                    "fragment_id": fragment_id,
                    "fragment_name": fragment_def.get("name"),
                    "target_entity": fragment_def.get("target_entity") or template.get("target_entity"),
                    "condition": fragment_def.get("condition"),
                }
                fragment_registry[fragment_id] = fragment_payload
                fragments.append(fragment_payload)
            fragment_refs.append({"fragment_id": fragment_id})

        blueprints.append(
            {
                "pattern_id": pattern_id,
                "blueprint_name": template.get("name"),
                "target_entity": template.get("target_entity"),
                "description": template.get("description"),
                "condition": template.get("when") or template.get("condition"),
                "fragments": fragment_refs,
                "review_finding_template": template.get("review_finding"),
            }
        )

    return {"security_fragments": fragments, "security_blueprints": blueprints}
