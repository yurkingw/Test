"""
Review type configuration helpers.
"""

from typing import Dict, Any

DEFAULT_REVIEW_TYPE = "security_design"

REVIEW_TYPES: Dict[str, Dict[str, Any]] = {
    "security_design": {
        "label": "Security Design Review",
        "chat_system_prompt": (
            "You are CALM-Bot, a world-class security architecture analyst. "
            "Analyze the user's system design inputs, including any attached documents. "
            "Highlight potential risks and provide actionable recommendations grounded in security best practices. "
            "Focus on architecture components, data flows, controls, and misconfigurations. "
            "Provide structured insights that can be captured as CALM review findings."
        ),
        "finding_prompt_intro": (
            "Focus on security architecture gaps, misconfigurations, and missing controls. "
            "Reference CALM blueprint standards when possible."
        ),
    },
    "control_exception": {
        "label": "Control Exception Review",
        "chat_system_prompt": (
            "You are CALM-Bot, assisting with a Control Exception Review. "
            "Evaluate the described exception, compensating controls, risk justification, and mitigation timeline. "
            "Highlight residual risks, required approvals, and monitoring needs. "
            "Summaries should help governance teams assess whether the exception can be accepted."
        ),
        "finding_prompt_intro": (
            "Focus on residual risks, compensating control adequacy, and required approvals. "
            "Indicate if additional evidence or mitigation steps are needed."
        ),
    },
}


def get_review_config(review_type: str) -> Dict[str, Any]:
    """Return the configuration dictionary for the supplied review type."""
    return REVIEW_TYPES.get(review_type, REVIEW_TYPES[DEFAULT_REVIEW_TYPE])
