"""
SecDesign member CSV sync helpers.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Dict, Tuple

from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.models.secdesign_member import SecDesignMember
from app.services.app_config import get_app_config


def resolve_secdesign_members_csv_path() -> Path:
    cfg = get_app_config().get("secdesign_members") or {}
    csv_path = str(cfg.get("csv_path") or "").strip()
    if not csv_path:
        raise HTTPException(status_code=400, detail="SecDesign member CSV path not configured.")
    path = Path(csv_path).expanduser()
    if not path.exists():
        raise HTTPException(status_code=404, detail="SecDesign member CSV file not found.")
    return path


def sync_secdesign_members_from_csv(db: Session) -> Tuple[int, int]:
    path = resolve_secdesign_members_csv_path()
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)

    def get_value(row: Dict[str, str], *keys: str) -> str:
        for key in keys:
            if key in row and row[key]:
                return row[key].strip()
        return ""

    inserted = 0
    updated = 0
    for row in rows:
        name = get_value(row, "SecDesign Member Name", "name", "Name")
        login_id = get_value(row, "SecDesign Member LoginID", "login_id", "LoginID", "loginId")
        if not name or not login_id:
            continue
        existing = db.query(SecDesignMember).filter(SecDesignMember.login_id == login_id).first()
        if existing:
            if existing.name != name:
                existing.name = name
                updated += 1
        else:
            db.add(SecDesignMember(name=name, login_id=login_id))
            inserted += 1
    db.commit()
    return inserted, updated
