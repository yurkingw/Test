"""
Security domain/zone CSV sync helpers.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Dict, Tuple

from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.models.security_domain_option import SecurityDomainOption
from app.models.security_zone_option import SecurityZoneOption
from app.models.security_component_option import SecurityComponentOption
from app.models.subnet_boundary_option import SubnetBoundaryOption
from app.models.protocol_port_option import ProtocolPortOption
from app.services.app_config import get_app_config


def resolve_security_options_csv_path() -> Path:
    cfg = get_app_config().get("security_options") or {}
    csv_path = str(cfg.get("csv_path") or "").strip()
    if not csv_path:
        raise HTTPException(status_code=400, detail="Security options CSV path not configured.")
    path = Path(csv_path).expanduser()
    if not path.exists():
        raise HTTPException(status_code=404, detail="Security options CSV file not found.")
    return path


def sync_security_options_from_csv(db: Session) -> Tuple[int, int, int, int, int]:
    path = resolve_security_options_csv_path()
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)

    def get_value(row: Dict[str, str], *keys: str) -> str:
        for key in keys:
            if key in row and row[key]:
                return row[key].strip()
        return ""

    domains = {get_value(row, "Security Domain", "domain", "Domain") for row in rows}
    zones = {get_value(row, "Security Zone", "zone", "Zone") for row in rows}
    components = {get_value(row, "Component", "component", "Component Name") for row in rows}
    subnets = {get_value(row, "Subnet Boundary", "subnet", "Subnet") for row in rows}
    protocol_ports = {get_value(row, "Protocol Port", "protocol_port", "Protocol|Port") for row in rows}
    domains = {value for value in domains if value}
    zones = {value for value in zones if value}
    components = {value for value in components if value}
    subnets = {value for value in subnets if value}

    protocol_ports = {value for value in protocol_ports if value}

    if not domains and not zones and not components and not subnets and not protocol_ports:
        raise HTTPException(status_code=400, detail="Security options CSV contains no values.")

    db.query(SecurityDomainOption).delete()
    db.query(SecurityZoneOption).delete()
    db.query(SecurityComponentOption).delete()
    db.query(SubnetBoundaryOption).delete()
    db.query(ProtocolPortOption).delete()
    for name in sorted(domains):
        db.add(SecurityDomainOption(name=name))
    for name in sorted(zones):
        db.add(SecurityZoneOption(name=name))
    for name in sorted(components):
        db.add(SecurityComponentOption(name=name))
    for value in sorted(subnets):
        db.add(SubnetBoundaryOption(value=value))
    for value in sorted(protocol_ports):
        db.add(ProtocolPortOption(value=value))
    db.commit()
    return len(domains), len(zones), len(components), len(subnets), len(protocol_ports)
