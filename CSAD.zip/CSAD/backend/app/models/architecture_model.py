'''
SQLAlchemy ORM Model for an ArchitectureModel.
'''

from sqlalchemy import Column, String, JSON
from app.db.base import Base

class ArchitectureModel(Base):
    '''
    Represents an architecture model in the database.
    This is a dictionary entity in the CALM model.
    '''
    __tablename__ = "architecture_models"

    architecture_model_id = Column(String, primary_key=True, index=True)
    architecture_model_category = Column(String, nullable=False)
    architecture_model = Column(String, nullable=False)
    tool_licensing_model = Column(String, nullable=True)
    tool = Column(String, nullable=True)
    tool_name = Column(String, nullable=True)
    # Properties will store the specific attributes for each architecture model type
    properties = Column(JSON, nullable=True)
