"""
Database model for SecDesign members.
"""

from sqlalchemy import Column, String
from app.db.base import Base


class SecDesignMember(Base):
    __tablename__ = "secdesign_members"

    login_id = Column(String, primary_key=True, index=True)
    name = Column(String, nullable=False)
