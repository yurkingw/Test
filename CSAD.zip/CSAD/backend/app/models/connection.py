'''
SQLAlchemy ORM Model for a Connection.

This module defines the `Connection` class, which maps to the `connections` table
in the database. It represents a connection between two Components in the CALM model.
'''

from sqlalchemy import Column, String, ForeignKey
from sqlalchemy.orm import relationship

from app.db.base import Base

class Connection(Base):
    '''
    Represents a connection between two components in the database.
    '''
    __tablename__ = "connections"

    conid = Column(String, primary_key=True, index=True)
    description = Column(String, nullable=True)

    # --- Foreign Keys ---
    source_cmpid = Column(String, ForeignKey("components.cmpid"), nullable=False)
    destination_cmpid = Column(String, ForeignKey("components.cmpid"), nullable=False)
    
    # This will be a FK to ConnectionType later
    connection_type_id = Column(String, nullable=False)

    # --- Relationships ---
    source_component = relationship(
        "Component", 
        foreign_keys=[source_cmpid], 
        back_populates="source_for_connections"
    )
    destination_component = relationship(
        "Component", 
        foreign_keys=[destination_cmpid], 
        back_populates="destination_for_connections"
    )
