'''
SQLAlchemy ORM Model for a ServiceInstance.

This module defines the `ServiceInstance` class, which maps to the `service_instances` table
in the database. It represents a specific instance of a Service in the CALM model.
'''

from sqlalchemy import Column, String, Enum, ForeignKey
from sqlalchemy.orm import relationship

from app.db.base import Base

class ServiceInstance(Base):
    '''
    Represents a service instance in the database.
    '''
    __tablename__ = "service_instances"

    svcint_id = Column(String, primary_key=True, index=True)
    svcintname = Column(String, index=True, nullable=False)
    
    # Foreign Key to Service
    svcid = Column(String, ForeignKey("services.svcid"), nullable=False)

    # These fields use Enums to enforce allowed values from the CALM design.
    ipc_authentication_methods = Column(Enum("PIPE", "Socket", "Shared_Memory", "Signal", "Queue", "N/A", name="ipc_authn_enum"), nullable=True)
    ipc_authorization_methods = Column(Enum("ACL", "MAC", "N/A", name="ipc_authz_enum"), nullable=True)
    sast_status = Column(Enum("Passed", "Failed", "Not Scanned", name="sast_status_enum"), nullable=True)
    dast_status = Column(Enum("Passed", "Failed", "Not Scanned", name="dast_status_enum"), nullable=True)
    parameterized_queries_status = Column(Enum("Enabled", "Disabled", "N/A", name="param_queries_enum"), nullable=True)
    input_validation_methods = Column(String, nullable=True) # Can be a list
    output_encoding_contexts = Column(String, nullable=True) # Can be a list
    csrf_protection_mechanism = Column(Enum("Token-Based", "SameSite-Strict-Cookies", "Header-Check", "None", name="csrf_enum"), nullable=True)
    race_condition_sync = Column(Enum("Mutex", "Semaphore", "File Lock", "N/A", name="race_cond_enum"), nullable=True)

    # --- Relationships ---
    service = relationship("Service", back_populates="service_instances")
    # The relationship to Component is defined in the Component model via `back_populates`
    # component = relationship("Component", back_populates="service_instance", uselist=False)
