'''
SQLAlchemy ORM Model for an Application.

This module defines the `Application` class, which maps to the `applications` table
in the database. It represents a logical application within a System in the CALM model.
'''

from sqlalchemy import Column, String, Enum, ForeignKey, Table
from sqlalchemy.orm import relationship

from app.db.base import Base

# Association Table for the many-to-many relationship between Service and Application
service_application_association = Table(
    'service_application', Base.metadata,
    Column('service_svcid', String, ForeignKey('services.svcid'), primary_key=True),
    Column('application_appid', String, ForeignKey('applications.appid'), primary_key=True)
)

class Application(Base):
    '''
    Represents an application in the database.
    '''
    __tablename__ = "applications"

    appid = Column(String, primary_key=True, index=True)
    appname = Column(String, index=True, nullable=False)
    
    # Foreign Key to System
    cmdb_sysid = Column(String, ForeignKey("systems.cmdb_sysid"), nullable=False)
    
    # This will be a FK to DeploymentModel later
    deployment_model_id = Column(String, nullable=False)

    location = Column(
        Enum("Office", "Onprem_DC_SH", "Onprem_DC_BJ", "Cloud_AWS", "Cloud_Azure", "Cloud_Other", name="location_enum"),
        nullable=False
    )
    security_environment = Column(
        Enum("Prod", "AppDev", "InfraDev", name="security_env_enum"),
        nullable=False
    )
    security_domain = Column(
        Enum("COD_MSMS", "MSBIC_OA", "MSBIC_MDEX", name="security_domain_enum"),
        nullable=False
    )
    security_zone = Column(
        Enum("ms-dmz", "vanilla-dmz", "ms-dmznonprod", "int-broa", "external", "branch-oa", "mdex_ad", name="security_zone_enum"),
        nullable=False
    )

    # --- Relationships ---
    system = relationship("System", back_populates="applications")
    services = relationship(
        "Service",
        secondary=service_application_association,
        back_populates="applications"
    )