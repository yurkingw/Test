'''
SQLAlchemy ORM Model for a ConnectionType.
'''

from sqlalchemy import Column, String
from app.db.base import Base

class ConnectionType(Base):
    '''
    Represents a connection type in the database.
    This is a dictionary entity in the CALM model.
    '''
    __tablename__ = "connection_types"

    connection_type_id = Column(String, primary_key=True, index=True)
    connection_type_name = Column(String, nullable=False, unique=True)
