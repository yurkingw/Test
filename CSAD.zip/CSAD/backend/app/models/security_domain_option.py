"""
Database model for cached Security Domain options.
"""

from sqlalchemy import Column, DateTime, String, func
from app.db.base import Base


class SecurityDomainOption(Base):
    __tablename__ = "security_domain_options"

    name = Column(String, primary_key=True, index=True)
    fetched_at = Column(DateTime, nullable=False, server_default=func.now())
