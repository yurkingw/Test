from sqlalchemy import Column, String, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime
from app.db.base import Base


class StatusHistory(Base):
    __tablename__ = "status_history"

    id = Column(String, primary_key=True, index=True)
    case_id = Column(String, ForeignKey("case_reviews.id", ondelete="CASCADE"), nullable=False, index=True)
    from_status = Column(String, nullable=True)
    to_status = Column(String, nullable=False)
    changed_by = Column(String, nullable=True)
    changed_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    case_review = relationship("CaseReview", back_populates="status_history")
