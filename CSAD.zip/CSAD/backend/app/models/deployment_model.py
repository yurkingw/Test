'''
SQLAlchemy ORM Model for a DeploymentModel.
'''

from sqlalchemy import Column, String, JSON
from app.db.base import Base

class DeploymentModel(Base):
    '''
    Represents a deployment model in the database.
    This is a dictionary entity in the CALM model.
    '''
    __tablename__ = "deployment_models"

    deployment_model_id = Column(String, primary_key=True, index=True)
    deployment_model_name = Column(String, nullable=False, unique=True)
    # Properties will store the specific attributes for each deployment model type
    properties = Column(JSON, nullable=True)
