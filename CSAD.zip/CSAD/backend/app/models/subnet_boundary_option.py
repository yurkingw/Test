"""
Database model for cached Subnet Boundary options.
"""

from sqlalchemy import Column, DateTime, String, func
from app.db.base import Base


class SubnetBoundaryOption(Base):
    __tablename__ = "subnet_boundary_options"

    value = Column(String, primary_key=True, index=True)
    fetched_at = Column(DateTime, nullable=False, server_default=func.now())
