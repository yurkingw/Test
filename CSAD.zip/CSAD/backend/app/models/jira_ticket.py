"""
Database model for cached Jira Service Management tickets.
"""

from sqlalchemy import Column, DateTime, String, func
from app.db.base import Base


class JiraTicket(Base):
    __tablename__ = "jira_tickets"

    id = Column(String, primary_key=True, index=True)
    summary = Column(String, nullable=True)
    project_key = Column(String, nullable=True, index=True)
    fetched_at = Column(DateTime, nullable=False, server_default=func.now())
