"""
SQLAlchemy ORM Model for Security Blueprints.

This module defines the `SecurityBlueprint` class, which maps to the
`security_blueprints` table in the database.
"""

from sqlalchemy import Column, Integer, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship

from app.db.base import Base

class SecurityBlueprint(Base):
    """
    Represents a security blueprint in the database.

    A security blueprint defines a standard or requirement for a specific type
    of system component.
    """
    __tablename__ = "security_blueprints"

    # The primary key for the table.
    id = Column(Integer, primary_key=True, index=True)
    
    # The type of component this blueprint applies to (e.g., 'firewall', 'proxy').
    component_type = Column(String, index=True, nullable=False)
    
    # A JSONB column to store the detailed configuration, rules, or attributes
    # of the blueprint in a flexible, schema-less format.
    details = Column(JSONB, nullable=False)

    # --- Relationships ---
    # Defines a one-to-many relationship with the ReviewFinding model.
    # If a blueprint is deleted, all of its associated findings will also be deleted.
    findings = relationship(
        "ReviewFinding", 
        back_populates="blueprint", 
        cascade="all, delete-orphan"
    )