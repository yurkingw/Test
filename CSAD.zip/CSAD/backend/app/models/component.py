'''
SQLAlchemy ORM Model for a Component.

This module defines the `Component` class, which maps to the `components` table
in the database. A Component is the materialized, context-aware representation of a ServiceInstance.
'''

from sqlalchemy import Column, String, ForeignKey
from sqlalchemy.orm import relationship

from app.db.base import Base

class Component(Base):
    '''
    Represents a materialized component in the database.
    '''
    __tablename__ = "components"

    cmpid = Column(String, primary_key=True, index=True)
    cmpname = Column(String, index=True, nullable=False)
    
    # Foreign Key to ServiceInstance, ensuring a one-to-one relationship
    svcint_id = Column(String, ForeignKey("service_instances.svcint_id"), unique=True, nullable=False)

    # --- Relationships ---
    # Defines the one-to-one relationship back to ServiceInstance
    service_instance = relationship("ServiceInstance") #, back_populates="component")
    
    # Defines the one-to-many relationships to Connection (as a source and as a destination)
    source_for_connections = relationship("Connection", foreign_keys="[Connection.source_cmpid]", back_populates="source_component")
    destination_for_connections = relationship("Connection", foreign_keys="[Connection.destination_cmpid]", back_populates="destination_component")
