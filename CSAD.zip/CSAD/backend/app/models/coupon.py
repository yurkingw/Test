from sqlalchemy import Column, String, ForeignKey, DateTime
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from datetime import datetime
from app.db.base import Base


class Coupon(Base):
    __tablename__ = "coupons"

    id = Column(String, primary_key=True, index=True)
    case_id = Column(String, ForeignKey("case_reviews.id", ondelete="CASCADE"), nullable=False, index=True)
    coupon_type = Column(String, nullable=False)  # firewall_flow / proxy_flow / etc.
    payload = Column(JSONB, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    case_review = relationship("CaseReview", back_populates="coupons")
