'''
SQLAlchemy ORM Model for a System.

This module defines the `System` class, which maps to the `systems` table
in the database. It represents the highest-level container in the CALM model.
'''

from sqlalchemy import Column, String, Enum
from sqlalchemy.orm import relationship

from app.db.base import Base

class System(Base):
    '''
    Represents a system in the database.

    A system is the top-level entity in the CALM model, containing applications.
    '''
    __tablename__ = "systems"

    # The primary key for the table, using the CMDB system ID.
    cmdb_sysid = Column(String, primary_key=True, index=True)
    
    # The human-readable name of the system.
    sysname = Column(String, index=True, nullable=False)
    
    # A detailed description of the system.
    description = Column(String, nullable=True)
    
    # Information sensitivity classification.
    information_sensetivity_classification = Column(
        Enum("Public", "Confidential", "Highly Restricted", name="info_sensitivity_enum"),
        nullable=False
    )
    
    # Business risk ranking of the asset.
    asset_risk_ranking = Column(
        Enum("P1", "P2", "P3", "P4", name="risk_ranking_enum"),
        nullable=False
    )

    # --- Relationships ---
    # Defines a one-to-many relationship with the Application model.
    applications = relationship("Application", back_populates="system")
    case_reviews = relationship("CaseReview", back_populates="system")
