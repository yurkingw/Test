'''
SQLAlchemy ORM Model for a Service.

This module defines the `Service` class, which maps to the `services` table
in the database. It represents a logical service within an Application in the CALM model.
'''

from sqlalchemy import Column, String, JSON, ForeignKey
from sqlalchemy.orm import relationship

from app.db.base import Base
from app.models.application import service_application_association

class Service(Base):
    '''
    Represents a service in the database.
    '''
    __tablename__ = "services"

    svcid = Column(String, primary_key=True, index=True)
    svcname = Column(String, index=True, nullable=False)
    
    # This will be a FK to ArchitectureModel later
    architecture_model_id = Column(String, nullable=False)

    # Using JSON to accommodate flexible data types (string or array)
    authentication_methods = Column(JSON, nullable=True)
    authorization_methods = Column(JSON, nullable=True)
    encryption_in_transit_algorithms = Column(JSON, nullable=True)
    encryption_in_transit_key_strength = Column(JSON, nullable=True)
    encryption_at_rest_algorithms = Column(JSON, nullable=True)
    encryption_at_rest_key_strength = Column(JSON, nullable=True)
    logging_retention_days = Column(String, nullable=True)
    logging_cyber_detection_feed = Column(String, nullable=True)
    listening_port = Column(JSON, nullable=True)
    listening_protocol = Column(String, nullable=True)

    # --- Relationships ---
    applications = relationship(
        "Application",
        secondary=service_application_association,
        back_populates="services"
    )
    service_instances = relationship("ServiceInstance", back_populates="service")
