from sqlalchemy import Column, String, ForeignKey, DateTime, Enum
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from app.db.base import Base


class ChatSender(str, enum.Enum):
    USER = "user"
    AI = "ai"
    SYSTEM = "system"


class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id = Column(String, primary_key=True, index=True)
    case_id = Column(String, ForeignKey("case_reviews.id", ondelete="CASCADE"), nullable=False, index=True)
    sender = Column(Enum(ChatSender, native_enum=False), nullable=False)
    message_md = Column(String, nullable=False)
    attachments = Column(JSONB, nullable=True)  # [{name,type,url,size,sha256,inline_preview}]
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    case_review = relationship("CaseReview", back_populates="chat_messages")
