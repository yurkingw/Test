from sqlalchemy import Column, String, ForeignKey, Enum, DateTime
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from datetime import datetime
from app.db.base import Base
import enum


class CaseStatus(str, enum.Enum):
    DRAFT = "draft"
    SUBMITTED = "submitted"
    RETURNED = "returned"
    RESUBMITTED = "resubmitted"
    CLOSED_APPROVE = "closed_approve"
    CLOSED_DENY = "closed_deny"
    CANCELLED = "cancelled"


class CaseReview(Base):
    __tablename__ = "case_reviews"

    # Use string IDs to align with front-end generated IDs (e.g., CASE-<timestamp>)
    id = Column(String, primary_key=True, index=True)
    name = Column(String, index=True, nullable=False)
    description = Column(String)
    status = Column(Enum(CaseStatus, native_enum=False), nullable=False, default=CaseStatus.DRAFT)
    review_type = Column(String, nullable=False, default="control_exception")
    ticket_id = Column(String, index=True, nullable=True)
    owner_id = Column(String, index=True, nullable=True)

    design_payload = Column(JSONB, nullable=True)
    final_snapshot = Column(JSONB, nullable=True)
    reviewer_comment = Column(String, nullable=True)
    reviewer_comment_files = Column(JSONB, nullable=True)
    reviewer_extra_findings = Column(JSONB, nullable=True)
    evidence = Column(JSONB, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Optional linkage to CMDB system
    system_id = Column(String, ForeignKey("systems.cmdb_sysid"), nullable=True)
    system = relationship("System", back_populates="case_reviews")

    findings = relationship("ReviewFinding", back_populates="case_review", cascade="all, delete-orphan")
    evidence_items = relationship("Evidence", back_populates="case_review", cascade="all, delete-orphan")
    chat_messages = relationship("ChatMessage", back_populates="case_review", cascade="all, delete-orphan")
    coupons = relationship("Coupon", back_populates="case_review", cascade="all, delete-orphan")
    status_history = relationship("StatusHistory", back_populates="case_review", cascade="all, delete-orphan")
