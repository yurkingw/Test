"""
Database model for cached Security Component options.
"""

from sqlalchemy import Column, DateTime, String, func
from app.db.base import Base


class SecurityComponentOption(Base):
    __tablename__ = "security_component_options"

    name = Column(String, primary_key=True, index=True)
    fetched_at = Column(DateTime, nullable=False, server_default=func.now())
