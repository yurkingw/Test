"""
SQLAlchemy ORM Model for Review Findings.

This module defines the `ReviewFinding` class, which maps to the
`review_findings` table in the database.
"""

from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from app.db.base import Base


class ReviewFinding(Base):
    """
    Represents a review finding in the database.
    """
    __tablename__ = "review_findings"

    id = Column(String, primary_key=True, index=True)
    summary = Column(String, nullable=True)
    risk_level = Column(String, nullable=True)
    classification = Column(String, nullable=True)  # Requirement / Recommendation
    requirement = Column(String, nullable=True)
    source_ref = Column(String, nullable=True)  # blueprint/rule id
    kind = Column(String, nullable=True)  # auto / reviewer / requestor

    details = Column(JSONB, nullable=True)
    blueprint_id = Column(Integer, ForeignKey("security_blueprints.id"), nullable=True)
    case_review_id = Column(String, ForeignKey("case_reviews.id", ondelete="CASCADE"), nullable=True, index=True)

    blueprint = relationship("SecurityBlueprint", back_populates="findings")
    case_review = relationship("CaseReview", back_populates="findings")
    evidence_items = relationship("Evidence", back_populates="finding", cascade="all, delete-orphan")
