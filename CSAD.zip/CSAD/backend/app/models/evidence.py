from sqlalchemy import Column, String, ForeignKey, DateTime, Enum
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from app.db.base import Base


class EvidenceDecision(str, enum.Enum):
    ACCEPT = "accept"
    REJECT = "reject"


class Evidence(Base):
    __tablename__ = "evidence"

    id = Column(String, primary_key=True, index=True)
    case_id = Column(String, ForeignKey("case_reviews.id", ondelete="CASCADE"), nullable=False, index=True)
    finding_id = Column(String, ForeignKey("review_findings.id", ondelete="CASCADE"), nullable=True, index=True)
    description = Column(String, nullable=True)
    decision = Column(Enum(EvidenceDecision, native_enum=False), nullable=False, default=EvidenceDecision.ACCEPT)
    attachments = Column(JSONB, nullable=True)  # [{name,type,url,size,sha256,inline_preview}]
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    case_review = relationship("CaseReview", back_populates="evidence_items")
    finding = relationship("ReviewFinding", back_populates="evidence_items")
