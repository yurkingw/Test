"""
Database model for cached Protocol/Port options.
"""

from sqlalchemy import Column, DateTime, String, func
from app.db.base import Base


class ProtocolPortOption(Base):
    __tablename__ = "protocol_port_options"

    value = Column(String, primary_key=True, index=True)
    fetched_at = Column(DateTime, nullable=False, server_default=func.now())
