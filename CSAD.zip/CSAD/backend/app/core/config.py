'''
Application Configuration Management.

This module defines the configuration settings for the application, loading them
from environment variables and/or a .env file using Pydantic's BaseSettings.
This provides a centralized and type-safe way to manage configuration.
'''

from pydantic_settings import BaseSettings
import os

class Settings(BaseSettings):
    """
    Defines the application's configuration settings.

    Pydantic's BaseSettings automatically reads variables from the environment.
    For example, a DATABASE_URL environment variable will populate the `DATABASE_URL`
    attribute. It also supports loading from a .env file.
    """
    
    # --- Project Metadata ---
    PROJECT_NAME: str = "CALM Security Architecture Designer"
    API_V1_STR: str = "/api/v1"

    # --- Database Configuration ---
    DATABASE_URL: str

    # --- OpenAI API Configuration ---
    OPENAI_API_KEY: str
    OPENAI_ORG_ID: str | None = None
    OPENAI_PROJECT: str | None = None

    # --- Jira API Configuration ---
    JIRA_BASE_URL: str | None = None
    JIRA_USERNAME: str | None = None
    JIRA_API_TOKEN: str | None = None
    JIRA_MTLS_CERT: str | None = None
    JIRA_MTLS_KEY: str | None = None
    JIRA_MTLS_CA: str | None = None

    # --- Attachment Storage ---
    ATTACHMENTS_DIR: str = "/data/attachments"

    # --- HTTPS/TLS (optional) ---
    HTTPS_ENABLED: str | None = None
    HTTPS_CERT_PATH: str | None = None
    HTTPS_KEY_PATH: str | None = None
    HTTPS_CA_PATH: str | None = None

    # --- CSV Data Sources ---
    SECDESIGN_MEMBERS_CSV: str | None = None
    SECURITY_OPTIONS_CSV: str | None = None

    # --- Azure AD / Entra OIDC Configuration (optional) ---
    OIDC_AUTHORITY: str | None = None
    OIDC_CLIENT_ID: str | None = None
    OIDC_TENANT_ID: str | None = None
    OIDC_SCOPE: str | None = None
    # Comma-separated mapping: aad_group_id=Role
    OIDC_GROUP_ROLE_MAP: str | None = None

    class Config:
        """
        Pydantic configuration class.
        
        Specifies the source of the configuration values, in this case, a file
        named .env in the project's root directory.
        """
        case_sensitive = True
        env_file = ".env"
        extra = "allow"

# Create a single, globally accessible instance of the Settings object.
settings = Settings()
