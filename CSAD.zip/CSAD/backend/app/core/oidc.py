"""
Lightweight OIDC/AAD integration scaffolding.

This module does not enforce authentication yet; it provides a parser for
Azure AD/Entra access tokens and maps group IDs to internal roles
(Requestor/Reviewer/Peer Reviewer) via configuration.
"""

from typing import List, Optional
import jwt
from fastapi import HTTPException, status
from app.core.config import settings

ROLE_REQUESTOR = "Requestor"
ROLE_REVIEWER = "Reviewer"
ROLE_PEER = "Peer Reviewer"


def _group_map() -> dict:
    mapping = {}
    if not settings.OIDC_GROUP_ROLE_MAP:
        return mapping
    pairs = [item.strip() for item in settings.OIDC_GROUP_ROLE_MAP.split(",") if item.strip()]
    for pair in pairs:
        if "=" not in pair:
            continue
        group_id, role = pair.split("=", 1)
        mapping[group_id.strip()] = role.strip()
    return mapping


def map_groups_to_role(group_ids: List[str]) -> str:
    """
    Map AAD group object IDs to internal roles.
    Returns Requestor when no mapping matches.
    """
    mapping = _group_map()
    for gid in group_ids:
        role = mapping.get(gid)
        if role:
            return role
    return ROLE_REQUESTOR


def decode_bearer_token(token: str) -> dict:
    """
    Decode JWT without verification (scaffolding).
    In production, validate signature against AAD JWKS and audience.
    """
    try:
        return jwt.decode(token, options={"verify_signature": False, "verify_aud": False})
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail=f"Invalid token: {exc}"
        ) from exc


def resolve_role_from_token(token: str) -> str:
    payload = decode_bearer_token(token)
    group_ids = payload.get("groups", []) or []
    return map_groups_to_role(group_ids)
