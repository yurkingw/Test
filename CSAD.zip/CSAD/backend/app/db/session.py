"""
Database session management.

This module sets up the SQLAlchemy database engine and session factory, which are
fundamental components for interacting with the database.
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.core.config import settings

# Create the SQLAlchemy engine.
# The engine is the starting point for any SQLAlchemy application. It's the
# "home base" for the actual database and its DBAPI, delivering a Dialect
# and a Pool of connections to the database.
# `pool_pre_ping=True` enables a feature that tests connections for liveness
# before they are used, which helps prevent issues with stale connections.
engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True)

# Create a configured "Session" class.
# The sessionmaker factory generates new Session objects when called.
# `autocommit=False` and `autoflush=False` are standard settings for using
# sessions with FastAPI, where database commits are handled explicitly within
# dependency-injected session scopes.
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)