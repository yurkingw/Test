"""
SQLAlchemy Declarative Base.

This module provides the central `Base` class that all SQLAlchemy ORM models
in the application will inherit from. This base class contains the metadata
that SQLAlchemy uses to map the Python objects to database tables.
"""

from sqlalchemy.ext.declarative import declarative_base

# Create a new DeclarativeMeta instance, which is the base for all ORM models.
# Any model class that inherits from `Base` will be registered with SQLAlchemy's
# metadata system, allowing it to be mapped to a database table.
Base = declarative_base()