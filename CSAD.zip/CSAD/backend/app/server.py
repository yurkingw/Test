"""
Uvicorn entrypoint that reads HTTPS settings from app_config.yaml.
"""

from __future__ import annotations

import uvicorn

from app.services.app_config import get_app_config


def _to_bool(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def main() -> None:
    cfg = get_app_config()
    server_cfg = cfg.get("server") or {}
    https_cfg = server_cfg.get("https") or {}
    host = server_cfg.get("host") or "0.0.0.0"
    port = int(server_cfg.get("port") or 8000)
    enabled = _to_bool(https_cfg.get("enabled"))

    kwargs = {
        "host": host,
        "port": port,
        "reload": True,
    }

    if enabled:
        cert_path = https_cfg.get("cert_path")
        key_path = https_cfg.get("key_path")
        if not cert_path or not key_path:
            raise RuntimeError("HTTPS is enabled but cert_path/key_path is missing.")
        kwargs["ssl_certfile"] = cert_path
        kwargs["ssl_keyfile"] = key_path
        ca_path = https_cfg.get("ca_path")
        if ca_path:
            kwargs["ssl_ca_certs"] = ca_path

    uvicorn.run("app.main:app", **kwargs)


if __name__ == "__main__":
    main()
