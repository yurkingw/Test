"""
Main application file for the FastAPI backend.

This file is the entry point for the CSAD application. It initializes the FastAPI app,
configures middleware, includes API routers, and defines root-level endpoints.
"""

import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.v1.api import api_router
from app.core.config import settings
from app.db.session import SessionLocal
from app.services.app_config import get_app_config
from app.services.secdesign_members import sync_secdesign_members_from_csv
from app.services.security_options import sync_security_options_from_csv

# Initialize the FastAPI application instance.
# The title, description, and version are loaded from the project settings.
# The OpenAPI URL is also customized based on the API version string.
app = FastAPI(
    title=settings.PROJECT_NAME,
    description="CALM Security Architecture Designer (CSAD) Backend API",
    version="1.0.0",
    openapi_url=f"{settings.API_V1_STR}/openapi.json"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://localhost:3000",
        "https://127.0.0.1:3000",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost",
        "http://127.0.0.1",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include the main API router from the v1 API module.
# All routes defined in `api_router` will be available under the prefix specified
# in `settings.API_V1_STR` (e.g., /api/v1).
app.include_router(api_router, prefix=settings.API_V1_STR)

@app.on_event("startup")
def sync_secdesign_members_on_startup() -> None:
    cfg = get_app_config().get("secdesign_members") or {}
    if not cfg.get("auto_sync_on_startup", True):
        return
    logger = logging.getLogger(__name__)
    db = SessionLocal()
    try:
        inserted, updated = sync_secdesign_members_from_csv(db)
        logger.info("SecDesign members synced from CSV (inserted=%s, updated=%s).", inserted, updated)
    except Exception as exc:
        logger.warning("SecDesign member CSV sync skipped: %s", exc)
    finally:
        db.close()


@app.on_event("startup")
def sync_security_options_on_startup() -> None:
    cfg = get_app_config().get("security_options") or {}
    if not cfg.get("auto_sync_on_startup", True):
        return
    logger = logging.getLogger(__name__)
    db = SessionLocal()
    try:
        domains, zones, components, subnets, protocol_ports = sync_security_options_from_csv(db)
        logger.info(
            "Security options synced from CSV (domains=%s, zones=%s, components=%s, subnets=%s, protocol_ports=%s).",
            domains,
            zones,
            components,
            subnets,
            protocol_ports,
        )
    except Exception as exc:
        logger.warning("Security options CSV sync skipped: %s", exc)
    finally:
        db.close()

@app.get("/", tags=["Root"])
def read_root():
    """
    Root endpoint for the application.

    This endpoint can be used as a simple health check to confirm that the
    application is running and responsive.

    Returns:
        dict: A dictionary with a welcome message.
    """
    return {"message": "Welcome to the CALM Security Architecture Designer Backend!"}
