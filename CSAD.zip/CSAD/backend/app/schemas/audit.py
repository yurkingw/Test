'''
Pydantic schemas for Audits.
'''

from pydantic import BaseModel, Field
from typing import List, Dict, Any

from app.schemas.system import SystemCreate
from app.schemas.application import ApplicationCreate
from app.schemas.service import ServiceCreate
from app.schemas.service_instance import ServiceInstanceCreate
from app.schemas.connection import ConnectionCreate

class UserDesign(BaseModel):
    '''Represents the full user design submitted for an audit.'''
    systems: List[SystemCreate] = Field(default_factory=list)
    applications: List[ApplicationCreate] = Field(default_factory=list)
    services: List[ServiceCreate] = Field(default_factory=list)
    service_instances: List[ServiceInstanceCreate] = Field(default_factory=list)
    connections: List[ConnectionCreate] = Field(default_factory=list)
    metadata: Dict[str, Any] | None = None

class AuditSubmission(BaseModel):
    """Audit submission payload containing the review type and user design data."""
    review_type: str
    user_design: UserDesign
