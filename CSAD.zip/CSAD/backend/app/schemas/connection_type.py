'''
Pydantic schemas for ConnectionTypes.
'''

from pydantic import BaseModel
from typing import Optional

# --- Base Schema --- #
class ConnectionTypeBase(BaseModel):
    '''Shared properties for a connection type.'''
    connection_type_id: str
    connection_type_name: str

# --- Create Schema --- #
class ConnectionTypeCreate(ConnectionTypeBase):
    '''Schema for creating a new connection type.'''
    pass

# --- Update Schema --- #
class ConnectionTypeUpdate(BaseModel):
    '''Schema for updating an existing connection type.'''
    connection_type_name: Optional[str] = None

# --- Response Schema --- #
class ConnectionType(ConnectionTypeBase):
    '''Schema for representing a connection type in API responses.'''
    class Config:
        from_attributes = True
