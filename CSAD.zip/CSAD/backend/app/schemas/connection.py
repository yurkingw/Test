'''
Pydantic schemas for Connections.
'''

from pydantic import BaseModel
from typing import Optional

# --- Base Schema --- #
class ConnectionBase(BaseModel):
    '''Shared properties for a connection.'''
    conid: str
    description: Optional[str] = None
    source_cmpid: str
    destination_cmpid: str
    connection_type_id: str

# --- Create Schema --- #
class ConnectionCreate(ConnectionBase):
    '''Schema for creating a new connection.'''
    pass

# --- Update Schema --- #
class ConnectionUpdate(BaseModel):
    '''Schema for updating an existing connection.'''
    description: Optional[str] = None
    source_cmpid: Optional[str] = None
    destination_cmpid: Optional[str] = None
    connection_type_id: Optional[str] = None

# --- Response Schema --- #
class Connection(ConnectionBase):
    '''Schema for representing a connection in API responses.'''
    class Config:
        from_attributes = True
