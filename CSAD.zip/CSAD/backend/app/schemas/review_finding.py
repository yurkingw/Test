"""
Pydantic schemas for Review Findings.

These schemas define the data structures for creating, reading, and updating
Review Finding resources via the API, ensuring data validation and serialization.
"""

from pydantic import BaseModel, ConfigDict
from typing import Any, Dict, Optional

# --- Base Schema --- #
class ReviewFindingBase(BaseModel):
    """
    Shared properties for a review finding.
    
    Defines the common fields for all finding-related schemas.
    """
    summary: Optional[str] = None
    risk_level: Optional[str] = None
    classification: Optional[str] = None
    requirement: Optional[str] = None
    source_ref: Optional[str] = None
    kind: Optional[str] = None
    details: Optional[Dict[str, Any]] = None
    blueprint_id: Optional[int] = None
    case_review_id: Optional[str] = None

# --- Create Schema --- #
class ReviewFindingCreate(ReviewFindingBase):
    """
    Schema for creating a new review finding.
    
    This is the expected data structure for POST requests.
    """
    id: str

# --- Update Schema --- #
class ReviewFindingUpdate(BaseModel):
    """
    Schema for updating an existing review finding.
    
    All fields are optional to allow for partial updates.
    """
    details: Optional[Dict[str, Any]] = None
    blueprint_id: Optional[int] = None
    case_review_id: Optional[str] = None
    summary: Optional[str] = None
    risk_level: Optional[str] = None
    classification: Optional[str] = None
    requirement: Optional[str] = None
    source_ref: Optional[str] = None
    kind: Optional[str] = None

# --- Response Schema --- #
class ReviewFinding(ReviewFindingBase):
    """
    Schema for representing a review finding in API responses.
    
    Includes the database-generated ID.
    """
    id: str
    model_config = ConfigDict(from_attributes=True, populate_by_name=True, arbitrary_types_allowed=True)
