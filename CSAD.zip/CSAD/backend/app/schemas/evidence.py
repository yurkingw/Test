from typing import Optional, Any
from pydantic import BaseModel
from app.models.evidence import EvidenceDecision


class EvidenceBase(BaseModel):
    case_id: str
    finding_id: Optional[str] = None
    description: Optional[str] = None
    decision: EvidenceDecision = EvidenceDecision.ACCEPT
    attachments: Optional[Any] = None


class EvidenceCreate(EvidenceBase):
    id: str


class EvidenceUpdate(BaseModel):
    description: Optional[str] = None
    decision: Optional[EvidenceDecision] = None
    attachments: Optional[Any] = None


class Evidence(EvidenceBase):
    id: str

    class Config:
        orm_mode = True
