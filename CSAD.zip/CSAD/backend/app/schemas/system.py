'''
Pydantic schemas for Systems.

This module defines the data structures for creating, reading, and updating
System resources via the API.
'''

from pydantic import BaseModel
from typing import Optional, List
from enum import Enum

# Enums from CALM Design
class InfoSensitivityEnum(str, Enum):
    public = "Public"
    confidential = "Confidential"
    highly_restricted = "Highly Restricted"

class RiskRankingEnum(str, Enum):
    p1 = "P1"
    p2 = "P2"
    p3 = "P3"
    p4 = "P4"

# --- Base Schema --- #
class SystemBase(BaseModel):
    '''
    Shared properties for a system.
    '''
    cmdb_sysid: str
    sysname: str
    description: Optional[str] = None
    information_sensetivity_classification: InfoSensitivityEnum
    asset_risk_ranking: RiskRankingEnum

# --- Create Schema --- #
class SystemCreate(SystemBase):
    '''
    Schema for creating a new system.
    '''
    pass

# --- Update Schema --- #
class SystemUpdate(BaseModel):
    '''
    Schema for updating an existing system.
    All fields are optional to allow for partial updates.
    '''
    sysname: Optional[str] = None
    description: Optional[str] = None
    information_sensetivity_classification: Optional[InfoSensitivityEnum] = None
    asset_risk_ranking: Optional[RiskRankingEnum] = None

# --- Response Schema --- #
class System(SystemBase):
    '''
    Schema for representing a system in API responses.
    '''
    # Note: The 'applications' field will be added later once the Application schema is defined.

    class Config:
        '''
        Pydantic model configuration.
        `from_attributes = True` enables creating the schema from an ORM object.
        '''
        from_attributes = True
