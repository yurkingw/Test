'''
Pydantic schemas for Services.
'''

from pydantic import BaseModel
from typing import Optional, List, Union

# --- Base Schema --- #
class ServiceBase(BaseModel):
    '''Shared properties for a service.'''
    svcid: str
    svcname: str
    architecture_model_id: str
    authentication_methods: Optional[Union[str, List[str]]] = None
    authorization_methods: Optional[Union[str, List[str]]] = None
    encryption_in_transit_algorithms: Optional[List[str]] = None
    encryption_in_transit_key_strength: Optional[Union[int, str]] = None # Can be string like "RSA2048"
    encryption_at_rest_algorithms: Optional[List[str]] = None
    encryption_at_rest_key_strength: Optional[int] = None
    logging_retention_days: Optional[Union[int, str]] = None # Can be N/A
    logging_cyber_detection_feed: Optional[str] = None
    listening_port: Optional[Union[int, List[int], str]] = None # Can be N/A
    listening_protocol: Optional[str] = None

# --- Create Schema --- #
class ServiceCreate(ServiceBase):
    '''Schema for creating a new service.'''
    # This will hold the appids for the many-to-many relationship
    application_ids: List[str] = []

# --- Update Schema --- #
class ServiceUpdate(BaseModel):
    '''Schema for updating an existing service.'''
    svcname: Optional[str] = None
    architecture_model_id: Optional[str] = None
    authentication_methods: Optional[Union[str, List[str]]] = None
    authorization_methods: Optional[Union[str, List[str]]] = None
    encryption_in_transit_algorithms: Optional[List[str]] = None
    encryption_in_transit_key_strength: Optional[Union[int, str]] = None
    encryption_at_rest_algorithms: Optional[List[str]] = None
    encryption_at_rest_key_strength: Optional[int] = None
    logging_retention_days: Optional[Union[int, str]] = None
    logging_cyber_detection_feed: Optional[str] = None
    listening_port: Optional[Union[int, List[int], str]] = None
    listening_protocol: Optional[str] = None
    application_ids: Optional[List[str]] = None

# --- Response Schema --- #
class Service(ServiceBase):
    '''Schema for representing a service in API responses.'''
    # Note: The 'service_instances' and 'applications' fields will be added later.

    class Config:
        from_attributes = True
