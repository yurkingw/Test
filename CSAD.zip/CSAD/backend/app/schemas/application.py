'''
Pydantic schemas for Applications.
'''

from pydantic import BaseModel
from typing import Optional, List
from enum import Enum

# Enums from CALM Design
class LocationEnum(str, Enum):
    office = "Office"
    onprem_dc_sh = "Onprem_DC_SH"
    onprem_dc_bj = "Onprem_DC_BJ"
    cloud_aws = "Cloud_AWS"
    cloud_azure = "Cloud_Azure"
    cloud_other = "Cloud_Other"

class SecurityEnvEnum(str, Enum):
    prod = "Prod"
    appdev = "AppDev"
    infradev = "InfraDev"

class SecurityDomainEnum(str, Enum):
    cod_msms = "COD_MSMS"
    msbic_oa = "MSBIC_OA"
    msbic_mdex = "MSBIC_MDEX"

class SecurityZoneEnum(str, Enum):
    ms_dmz = "ms-dmz"
    vanilla_dmz = "vanilla-dmz"
    ms_dmznonprod = "ms-dmznonprod"
    int_broa = "int-broa"
    external = "external"
    branch_oa = "branch-oa"
    mdex_ad = "mdex_ad"


# --- Base Schema --- #
class ApplicationBase(BaseModel):
    '''Shared properties for an application.'''
    appid: str
    appname: str
    cmdb_sysid: str
    deployment_model_id: str
    location: LocationEnum
    security_environment: SecurityEnvEnum
    security_domain: SecurityDomainEnum
    security_zone: SecurityZoneEnum

# --- Create Schema --- #
class ApplicationCreate(ApplicationBase):
    '''Schema for creating a new application.'''
    pass

# --- Update Schema --- #
class ApplicationUpdate(BaseModel):
    '''Schema for updating an existing application.'''
    appname: Optional[str] = None
    deployment_model_id: Optional[str] = None
    location: Optional[LocationEnum] = None
    security_environment: Optional[SecurityEnvEnum] = None
    security_domain: Optional[SecurityDomainEnum] = None
    security_zone: Optional[SecurityZoneEnum] = None

# --- Response Schema --- #
class Application(ApplicationBase):
    '''Schema for representing an application in API responses.'''
    # Note: The 'services' field will be added later once the Service schema is defined.

    class Config:
        from_attributes = True
