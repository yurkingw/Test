from typing import Optional, List, Any
from pydantic import BaseModel
from pydantic import ConfigDict
from app.models.case_review import CaseStatus
from app.schemas.review_finding import ReviewFinding


class CaseReviewBase(BaseModel):
    id: Optional[str] = None
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[CaseStatus] = CaseStatus.DRAFT
    review_type: Optional[str] = "control_exception"
    ticket_id: Optional[str] = None
    owner_id: Optional[str] = None
    design_payload: Optional[Any] = None
    final_snapshot: Optional[Any] = None
    reviewer_comment: Optional[str] = None
    reviewer_comment_files: Optional[Any] = None
    reviewer_extra_findings: Optional[Any] = None
    evidence: Optional[Any] = None
    system_id: Optional[str] = None
    created_at: Optional[Any] = None
    updated_at: Optional[Any] = None
    findings: Optional[List[ReviewFinding]] = None
    reviewer_comment: Optional[str] = None
    reviewer_extra_findings: Optional[List[Any]] = None
    evidence: Optional[Any] = None


class CaseReviewCreate(CaseReviewBase):
    name: str


class CaseReviewUpdate(CaseReviewBase):
    pass


class CaseReviewInDBBase(CaseReviewBase):
    id: str

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)


class CaseReview(CaseReviewInDBBase):
    class Config:
        orm_mode = True
        from_attributes = True


class CaseReviewInDB(CaseReviewInDBBase):
    class Config:
        orm_mode = True
        from_attributes = True
