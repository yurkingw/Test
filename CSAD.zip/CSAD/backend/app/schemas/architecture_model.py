'''
Pydantic schemas for ArchitectureModels.
'''

from pydantic import BaseModel
from typing import Optional, Dict, Any

# --- Base Schema --- #
class ArchitectureModelBase(BaseModel):
    '''Shared properties for an architecture model.'''
    architecture_model_id: str
    architecture_model_category: str
    architecture_model: str
    tool_licensing_model: Optional[str] = None
    tool: Optional[str] = None
    tool_name: Optional[str] = None
    properties: Optional[Dict[str, Any]] = None

# --- Create Schema --- #
class ArchitectureModelCreate(ArchitectureModelBase):
    '''Schema for creating a new architecture model.'''
    pass

# --- Update Schema --- #
class ArchitectureModelUpdate(BaseModel):
    '''Schema for updating an existing architecture model.'''
    architecture_model_category: Optional[str] = None
    architecture_model: Optional[str] = None
    tool_licensing_model: Optional[str] = None
    tool: Optional[str] = None
    tool_name: Optional[str] = None
    properties: Optional[Dict[str, Any]] = None

# --- Response Schema --- #
class ArchitectureModel(ArchitectureModelBase):
    '''Schema for representing an architecture model in API responses.'''
    class Config:
        from_attributes = True
