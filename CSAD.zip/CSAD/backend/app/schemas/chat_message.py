from typing import Optional, Any
from pydantic import BaseModel
from app.models.chat_message import ChatSender


class ChatMessageBase(BaseModel):
    case_id: str
    sender: ChatSender
    message_md: str
    attachments: Optional[Any] = None


class ChatMessageCreate(ChatMessageBase):
    id: str


class ChatMessage(ChatMessageBase):
    id: str

    class Config:
        orm_mode = True
