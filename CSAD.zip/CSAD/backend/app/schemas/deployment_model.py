'''
Pydantic schemas for DeploymentModels.
'''

from pydantic import BaseModel
from typing import Optional, Dict, Any

# --- Base Schema --- #
class DeploymentModelBase(BaseModel):
    '''Shared properties for a deployment model.'''
    deployment_model_id: str
    deployment_model_name: str
    properties: Optional[Dict[str, Any]] = None

# --- Create Schema --- #
class DeploymentModelCreate(DeploymentModelBase):
    '''Schema for creating a new deployment model.'''
    pass

# --- Update Schema --- #
class DeploymentModelUpdate(BaseModel):
    '''Schema for updating an existing deployment model.'''
    deployment_model_name: Optional[str] = None
    properties: Optional[Dict[str, Any]] = None

# --- Response Schema --- #
class DeploymentModel(DeploymentModelBase):
    '''Schema for representing a deployment model in API responses.'''
    class Config:
        from_attributes = True
