'''
Pydantic schemas for ServiceInstances.
'''

from pydantic import BaseModel
from typing import Optional, List
from enum import Enum

# --- Enums for validation ---
class IpcAuthnEnum(str, Enum):
    pipe = "PIPE"
    socket = "Socket"
    shared_memory = "Shared_Memory"
    signal = "Signal"
    queue = "Queue"
    na = "N/A"

class IpcAuthzEnum(str, Enum):
    acl = "ACL"
    mac = "MAC"
    na = "N/A"

class ScanStatusEnum(str, Enum):
    passed = "Passed"
    failed = "Failed"
    not_scanned = "Not Scanned"

class ParamQueriesEnum(str, Enum):
    enabled = "Enabled"
    disabled = "Disabled"
    na = "N/A"

class CsrfEnum(str, Enum):
    token_based = "Token-Based"
    samesite = "SameSite-Strict-Cookies"
    header_check = "Header-Check"
    none = "None"

class RaceCondEnum(str, Enum):
    mutex = "Mutex"
    semaphore = "Semaphore"
    file_lock = "File Lock"
    na = "N/A"

# --- Base Schema --- #
class ServiceInstanceBase(BaseModel):
    '''Shared properties for a service instance.'''
    svcint_id: str
    svcintname: str
    svcid: str
    ipc_authentication_methods: Optional[IpcAuthnEnum] = None
    ipc_authorization_methods: Optional[IpcAuthzEnum] = None
    sast_status: Optional[ScanStatusEnum] = None
    dast_status: Optional[ScanStatusEnum] = None
    parameterized_queries_status: Optional[ParamQueriesEnum] = None
    input_validation_methods: Optional[str] = None
    output_encoding_contexts: Optional[str] = None
    csrf_protection_mechanism: Optional[CsrfEnum] = None
    race_condition_sync: Optional[RaceCondEnum] = None

# --- Create Schema --- #
class ServiceInstanceCreate(ServiceInstanceBase):
    '''Schema for creating a new service instance.'''
    pass

# --- Update Schema --- #
class ServiceInstanceUpdate(BaseModel):
    '''Schema for updating an existing service instance.'''
    svcintname: Optional[str] = None
    svcid: Optional[str] = None
    ipc_authentication_methods: Optional[IpcAuthnEnum] = None
    ipc_authorization_methods: Optional[IpcAuthzEnum] = None
    sast_status: Optional[ScanStatusEnum] = None
    dast_status: Optional[ScanStatusEnum] = None
    parameterized_queries_status: Optional[ParamQueriesEnum] = None
    input_validation_methods: Optional[str] = None
    output_encoding_contexts: Optional[str] = None
    csrf_protection_mechanism: Optional[CsrfEnum] = None
    race_condition_sync: Optional[RaceCondEnum] = None

# --- Response Schema --- #
class ServiceInstance(ServiceInstanceBase):
    '''Schema for representing a service instance in API responses.'''
    class Config:
        from_attributes = True
