from typing import Any
from pydantic import BaseModel


class CouponBase(BaseModel):
    case_id: str
    coupon_type: str
    payload: Any


class CouponCreate(CouponBase):
    id: str


class Coupon(CouponBase):
    id: str

    class Config:
        orm_mode = True
