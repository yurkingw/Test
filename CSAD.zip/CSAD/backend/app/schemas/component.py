'''
Pydantic schemas for Components.
'''

from pydantic import BaseModel
from typing import Optional, Dict, Any

# --- Base Schema --- #
class ComponentBase(BaseModel):
    '''Shared properties for a component.'''
    cmpid: str
    cmpname: str
    svcint_id: str

# --- Create Schema --- #
class ComponentCreate(BaseModel):
    '''
    Schema for creating a new component.
    In practice, components are materialized by the system. This schema
    defines the minimal input required if manual creation were needed.
    '''
    cmpid: str
    cmpname: str
    svcint_id: str

# --- Update Schema --- #
# Components are materialized and generally not updated directly.
# An update schema can be added here if that logic is required later.
class ComponentUpdate(BaseModel):
    cmpname: Optional[str] = None

# --- Response Schema --- #
class Component(ComponentBase):
    '''Schema for representing a component in API responses.'''
    # This field can be populated by the application logic when returning a component.
    inherited_properties: Optional[Dict[str, Any]] = None
    
    class Config:
        from_attributes = True
