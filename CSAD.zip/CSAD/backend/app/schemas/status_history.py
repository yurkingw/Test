from typing import Optional
from pydantic import BaseModel


class StatusHistoryBase(BaseModel):
    case_id: str
    from_status: Optional[str] = None
    to_status: str
    changed_by: Optional[str] = None


class StatusHistoryCreate(StatusHistoryBase):
    id: str


class StatusHistory(StatusHistoryBase):
    id: str

    class Config:
        orm_mode = True
