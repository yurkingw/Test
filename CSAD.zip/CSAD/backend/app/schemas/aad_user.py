from typing import Optional, List
from pydantic import BaseModel, ConfigDict


class AadUserBase(BaseModel):
    login_id: str
    display_name: Optional[str] = None
    email: Optional[str] = None
    role: Optional[str] = None
    group_ids: Optional[List[str]] = None


class AadUser(AadUserBase):
    model_config = ConfigDict(from_attributes=True)
