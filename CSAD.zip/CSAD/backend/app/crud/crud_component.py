'''
CRUD operations for Components.
'''

from sqlalchemy.orm import Session
from typing import List, Optional, Union, Dict, Any

from app.models.component import Component
from app.schemas.component import ComponentCreate, ComponentUpdate

class CRUDComponent:
    '''CRUD operations for Component model.'''

    def get(self, db: Session, cmpid: str) -> Optional[Component]:
        '''Retrieve a single component by its cmpid.'''
        return db.query(Component).filter(Component.cmpid == cmpid).first()

    def get_multi(
        self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> List[Component]:
        '''Retrieve multiple components.'''
        return db.query(Component).offset(skip).limit(limit).all()

    def create(self, db: Session, *, obj_in: ComponentCreate) -> Component:
        '''Create a new component.'''
        db_obj = Component(**obj_in.dict())
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def update(
        self, db: Session, *, db_obj: Component, obj_in: Union[ComponentUpdate, Dict[str, Any]]
    ) -> Component:
        '''Update an existing component.'''
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.dict(exclude_unset=True)
        
        for field, value in update_data.items():
            if hasattr(db_obj, field):
                setattr(db_obj, field, value)
        
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

# Create a single, reusable instance of the CRUD class.
component = CRUDComponent()
