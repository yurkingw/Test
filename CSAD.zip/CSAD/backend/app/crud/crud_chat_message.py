from typing import Optional, List
from sqlalchemy.orm import Session
from app.models.chat_message import ChatMessage
from app.schemas.chat_message import ChatMessageCreate


class CRUDChatMessage:
    def get(self, db: Session, id: str) -> Optional[ChatMessage]:
        return db.query(ChatMessage).filter(ChatMessage.id == id).first()

    def get_by_case(self, db: Session, case_id: str) -> List[ChatMessage]:
        return db.query(ChatMessage).filter(ChatMessage.case_id == case_id).order_by(ChatMessage.created_at.asc()).all()

    def create(self, db: Session, obj_in: ChatMessageCreate) -> ChatMessage:
        db_obj = ChatMessage(**obj_in.dict())
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj


chat_message = CRUDChatMessage()
