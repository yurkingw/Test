'''
CRUD operations for ArchitectureModels.
'''

from sqlalchemy.orm import Session
from typing import List, Optional, Union, Dict, Any

from app.models.architecture_model import ArchitectureModel
from app.schemas.architecture_model import ArchitectureModelCreate, ArchitectureModelUpdate

class CRUDArchitectureModel:
    '''CRUD operations for ArchitectureModel model.'''

    def get(self, db: Session, architecture_model_id: str) -> Optional[ArchitectureModel]:
        '''Retrieve a single architecture model by its id.'''
        return db.query(ArchitectureModel).filter(ArchitectureModel.architecture_model_id == architecture_model_id).first()

    def get_multi(
        self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> List[ArchitectureModel]:
        '''Retrieve multiple architecture models.'''
        return db.query(ArchitectureModel).offset(skip).limit(limit).all()

    def create(self, db: Session, *, obj_in: ArchitectureModelCreate) -> ArchitectureModel:
        '''Create a new architecture model.'''
        db_obj = ArchitectureModel(**obj_in.dict())
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def update(
        self, db: Session, *, db_obj: ArchitectureModel, obj_in: Union[ArchitectureModelUpdate, Dict[str, Any]]
    ) -> ArchitectureModel:
        '''Update an existing architecture model.'''
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.dict(exclude_unset=True)
        
        for field, value in update_data.items():
            if hasattr(db_obj, field):
                setattr(db_obj, field, value)
        
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

# Create a single, reusable instance of the CRUD class.
architecture_model = CRUDArchitectureModel()
