'''
CRUD operations for ConnectionTypes.
'''

from sqlalchemy.orm import Session
from typing import List, Optional, Union, Dict, Any

from app.models.connection_type import ConnectionType
from app.schemas.connection_type import ConnectionTypeCreate, ConnectionTypeUpdate

class CRUDConnectionType:
    '''CRUD operations for ConnectionType model.'''

    def get(self, db: Session, connection_type_id: str) -> Optional[ConnectionType]:
        '''Retrieve a single connection type by its id.'''
        return db.query(ConnectionType).filter(ConnectionType.connection_type_id == connection_type_id).first()

    def get_multi(
        self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> List[ConnectionType]:
        '''Retrieve multiple connection types.'''
        return db.query(ConnectionType).offset(skip).limit(limit).all()

    def create(self, db: Session, *, obj_in: ConnectionTypeCreate) -> ConnectionType:
        '''Create a new connection type.'''
        db_obj = ConnectionType(**obj_in.dict())
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def update(
        self, db: Session, *, db_obj: ConnectionType, obj_in: Union[ConnectionTypeUpdate, Dict[str, Any]]
    ) -> ConnectionType:
        '''Update an existing connection type.'''
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.dict(exclude_unset=True)
        
        for field, value in update_data.items():
            if hasattr(db_obj, field):
                setattr(db_obj, field, value)
        
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

# Create a single, reusable instance of the CRUD class.
connection_type = CRUDConnectionType()
