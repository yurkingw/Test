'''
CRUD operations for DeploymentModels.
'''

from sqlalchemy.orm import Session
from typing import List, Optional, Union, Dict, Any

from app.models.deployment_model import DeploymentModel
from app.schemas.deployment_model import DeploymentModelCreate, DeploymentModelUpdate

class CRUDDeploymentModel:
    '''CRUD operations for DeploymentModel model.'''

    def get(self, db: Session, deployment_model_id: str) -> Optional[DeploymentModel]:
        '''Retrieve a single deployment model by its id.'''
        return db.query(DeploymentModel).filter(DeploymentModel.deployment_model_id == deployment_model_id).first()

    def get_multi(
        self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> List[DeploymentModel]:
        '''Retrieve multiple deployment models.'''
        return db.query(DeploymentModel).offset(skip).limit(limit).all()

    def create(self, db: Session, *, obj_in: DeploymentModelCreate) -> DeploymentModel:
        '''Create a new deployment model.'''
        db_obj = DeploymentModel(**obj_in.dict())
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def update(
        self, db: Session, *, db_obj: DeploymentModel, obj_in: Union[DeploymentModelUpdate, Dict[str, Any]]
    ) -> DeploymentModel:
        '''Update an existing deployment model.'''
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.dict(exclude_unset=True)
        
        for field, value in update_data.items():
            if hasattr(db_obj, field):
                setattr(db_obj, field, value)
        
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

# Create a single, reusable instance of the CRUD class.
deployment_model = CRUDDeploymentModel()
