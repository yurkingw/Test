'''
CRUD operations for ServiceInstances.
'''

from sqlalchemy.orm import Session
from typing import List, Optional, Union, Dict, Any

from app.models.service_instance import ServiceInstance
from app.schemas.service_instance import ServiceInstanceCreate, ServiceInstanceUpdate

class CRUDServiceInstance:
    '''CRUD operations for ServiceInstance model.'''

    def get(self, db: Session, svcint_id: str) -> Optional[ServiceInstance]:
        '''Retrieve a single service instance by its svcint_id.'''
        return db.query(ServiceInstance).filter(ServiceInstance.svcint_id == svcint_id).first()

    def get_multi(
        self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> List[ServiceInstance]:
        '''Retrieve multiple service instances.'''
        return db.query(ServiceInstance).offset(skip).limit(limit).all()

    def get_multi_by_service(
        self, db: Session, *, svcid: str, skip: int = 0, limit: int = 100
    ) -> List[ServiceInstance]:
        '''Retrieve multiple service instances belonging to a specific service.'''
        return (
            db.query(ServiceInstance)
            .filter(ServiceInstance.svcid == svcid)
            .offset(skip)
            .limit(limit)
            .all()
        )

    def create(self, db: Session, *, obj_in: ServiceInstanceCreate) -> ServiceInstance:
        '''Create a new service instance.'''
        db_obj = ServiceInstance(**obj_in.dict())
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def update(
        self, db: Session, *, db_obj: ServiceInstance, obj_in: Union[ServiceInstanceUpdate, Dict[str, Any]]
    ) -> ServiceInstance:
        '''Update an existing service instance.'''
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.dict(exclude_unset=True)
        
        for field, value in update_data.items():
            if hasattr(db_obj, field):
                setattr(db_obj, field, value)
        
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

# Create a single, reusable instance of the CRUD class.
service_instance = CRUDServiceInstance()
