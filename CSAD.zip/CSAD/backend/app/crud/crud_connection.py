'''
CRUD operations for Connections.
'''

from sqlalchemy.orm import Session
from typing import List, Optional, Union, Dict, Any

from app.models.connection import Connection
from app.schemas.connection import ConnectionCreate, ConnectionUpdate

class CRUDConnection:
    '''CRUD operations for Connection model.'''

    def get(self, db: Session, conid: str) -> Optional[Connection]:
        '''Retrieve a single connection by its conid.'''
        return db.query(Connection).filter(Connection.conid == conid).first()

    def get_multi(
        self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> List[Connection]:
        '''Retrieve multiple connections.'''
        return db.query(Connection).offset(skip).limit(limit).all()

    def create(self, db: Session, *, obj_in: ConnectionCreate) -> Connection:
        '''Create a new connection.'''
        db_obj = Connection(**obj_in.dict())
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def update(
        self, db: Session, *, db_obj: Connection, obj_in: Union[ConnectionUpdate, Dict[str, Any]]
    ) -> Connection:
        '''Update an existing connection.'''
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.dict(exclude_unset=True)
        
        for field, value in update_data.items():
            if hasattr(db_obj, field):
                setattr(db_obj, field, value)
        
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

# Create a single, reusable instance of the CRUD class.
connection = CRUDConnection()
