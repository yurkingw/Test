"""
CRUD (Create, Read, Update, Delete) operations for Security Blueprints.

This module provides a class-based approach to handling all database interactions
related to the SecurityBlueprint model.
"""

from sqlalchemy.orm import Session
from typing import List, Optional

from app.models.security_blueprint import SecurityBlueprint
from app.schemas.security_blueprint import SecurityBlueprintCreate, SecurityBlueprintUpdate

class CRUDSecurityBlueprint:
    """CRUD operations for SecurityBlueprint model."""

    def get(self, db: Session, id: int) -> Optional[SecurityBlueprint]:
        """
        Retrieve a single security blueprint by its ID.

        Args:
            db (Session): The database session.
            id (int): The ID of the blueprint to retrieve.

        Returns:
            Optional[SecurityBlueprint]: The blueprint object if found, else None.
        """
        return db.query(SecurityBlueprint).filter(SecurityBlueprint.id == id).first()

    def get_multi(
        self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> List[SecurityBlueprint]:
        """
        Retrieve multiple security blueprints with pagination.

        Args:
            db (Session): The database session.
            skip (int): Number of records to skip.
            limit (int): Maximum number of records to return.

        Returns:
            List[SecurityBlueprint]: A list of blueprint objects.
        """
        return db.query(SecurityBlueprint).offset(skip).limit(limit).all()

    def create(self, db: Session, *, obj_in: SecurityBlueprintCreate) -> SecurityBlueprint:
        """
        Create a new security blueprint.

        Args:
            db (Session): The database session.
            obj_in (SecurityBlueprintCreate): The data for the new blueprint.

        Returns:
            SecurityBlueprint: The newly created blueprint object.
        """
        # Create a new SQLAlchemy model instance from the Pydantic schema data.
        db_obj = SecurityBlueprint(
            component_type=obj_in.component_type,
            details=obj_in.details
        )
        db.add(db_obj)  # Add the new object to the session.
        db.commit()  # Commit the transaction to the database.
        db.refresh(db_obj)  # Refresh the object to get the new ID and other defaults.
        return db_obj

# Create a single, reusable instance of the CRUD class.
security_blueprint = CRUDSecurityBlueprint()