from typing import Optional, List
from sqlalchemy.orm import Session
from app.models.evidence import Evidence
from app.schemas.evidence import EvidenceCreate, EvidenceUpdate


class CRUDEvidence:
    def get(self, db: Session, id: str) -> Optional[Evidence]:
        return db.query(Evidence).filter(Evidence.id == id).first()

    def get_by_case(self, db: Session, case_id: str) -> List[Evidence]:
        return db.query(Evidence).filter(Evidence.case_id == case_id).all()

    def create(self, db: Session, obj_in: EvidenceCreate) -> Evidence:
        db_obj = Evidence(**obj_in.dict())
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def update(self, db: Session, db_obj: Evidence, obj_in: EvidenceUpdate) -> Evidence:
        update_data = obj_in.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_obj, field, value)
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj


evidence = CRUDEvidence()
