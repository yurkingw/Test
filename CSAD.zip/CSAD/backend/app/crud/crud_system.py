'''
CRUD (Create, Read, Update, Delete) operations for Systems.
'''

from sqlalchemy.orm import Session
from typing import List, Optional, Union, Dict, Any

from app.models.system import System
from app.schemas.system import SystemCreate, SystemUpdate

class CRUDSystem:
    '''CRUD operations for System model.'''

    def get(self, db: Session, cmdb_sysid: str) -> Optional[System]:
        '''Retrieve a single system by its cmdb_sysid.'''
        return db.query(System).filter(System.cmdb_sysid == cmdb_sysid).first()

    def get_multi(
        self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> List[System]:
        '''Retrieve multiple systems.'''
        return db.query(System).offset(skip).limit(limit).all()

    def create(self, db: Session, *, obj_in: SystemCreate) -> System:
        '''Create a new system.'''
        db_obj = System(
            cmdb_sysid=obj_in.cmdb_sysid,
            sysname=obj_in.sysname,
            description=obj_in.description,
            information_sensetivity_classification=obj_in.information_sensetivity_classification,
            asset_risk_ranking=obj_in.asset_risk_ranking,
        )
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def update(
        self, db: Session, *, db_obj: System, obj_in: Union[SystemUpdate, Dict[str, Any]]
    ) -> System:
        '''Update an existing system.'''
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.dict(exclude_unset=True)
        
        for field in update_data:
            if hasattr(db_obj, field):
                setattr(db_obj, field, update_data[field])
        
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

# Create a single, reusable instance of the CRUD class.
system = CRUDSystem()
