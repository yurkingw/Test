'''
CRUD operations for Applications.
'''

from sqlalchemy.orm import Session
from typing import List, Optional, Union, Dict, Any

from app.models.application import Application
from app.schemas.application import ApplicationCreate, ApplicationUpdate

class CRUDApplication:
    '''CRUD operations for Application model.'''

    def get(self, db: Session, appid: str) -> Optional[Application]:
        '''Retrieve a single application by its appid.'''
        return db.query(Application).filter(Application.appid == appid).first()

    def get_multi(
        self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> List[Application]:
        '''Retrieve multiple applications.'''
        return db.query(Application).offset(skip).limit(limit).all()

    def get_multi_by_system(
        self, db: Session, *, cmdb_sysid: str, skip: int = 0, limit: int = 100
    ) -> List[Application]:
        '''Retrieve multiple applications belonging to a specific system.'''
        return (
            db.query(Application)
            .filter(Application.cmdb_sysid == cmdb_sysid)
            .offset(skip)
            .limit(limit)
            .all()
        )

    def create(self, db: Session, *, obj_in: ApplicationCreate) -> Application:
        '''Create a new application.'''
        db_obj = Application(**obj_in.dict())
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def update(
        self, db: Session, *, db_obj: Application, obj_in: Union[ApplicationUpdate, Dict[str, Any]]
    ) -> Application:
        '''Update an existing application.'''
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.dict(exclude_unset=True)
        
        for field in update_data:
            if hasattr(db_obj, field):
                setattr(db_obj, field, update_data[field])
        
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

# Create a single, reusable instance of the CRUD class.
application = CRUDApplication()
