from typing import List
from sqlalchemy.orm import Session
from app.models.status_history import StatusHistory
from app.schemas.status_history import StatusHistoryCreate


class CRUDStatusHistory:
    def create(self, db: Session, obj_in: StatusHistoryCreate) -> StatusHistory:
        db_obj = StatusHistory(**obj_in.dict())
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def list_by_case(self, db: Session, case_id: str) -> List[StatusHistory]:
        return db.query(StatusHistory).filter(StatusHistory.case_id == case_id).order_by(StatusHistory.changed_at.asc()).all()


status_history = CRUDStatusHistory()
