'''
CRUD operations for Services.
'''

from sqlalchemy.orm import Session
from typing import List, Optional, Union, Dict, Any

from app.models.service import Service
from app.models.application import Application
from app.schemas.service import ServiceCreate, ServiceUpdate

class CRUDService:
    '''CRUD operations for Service model.'''

    def get(self, db: Session, svcid: str) -> Optional[Service]:
        '''Retrieve a single service by its svcid.'''
        return db.query(Service).filter(Service.svcid == svcid).first()

    def get_multi(
        self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> List[Service]:
        '''Retrieve multiple services.'''
        return db.query(Service).offset(skip).limit(limit).all()

    def create(self, db: Session, *, obj_in: ServiceCreate) -> Service:
        '''Create a new service.'''
        # Create a dictionary of the service data without the application_ids
        obj_in_data = obj_in.dict(exclude={'application_ids'})
        db_obj = Service(**obj_in_data)

        # Handle the many-to-many relationship
        if obj_in.application_ids:
            applications = db.query(Application).filter(Application.appid.in_(obj_in.application_ids)).all()
            db_obj.applications = applications

        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def update(
        self, db: Session, *, db_obj: Service, obj_in: Union[ServiceUpdate, Dict[str, Any]]
    ) -> Service:
        '''Update an existing service.'''
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.dict(exclude_unset=True)

        # Handle the many-to-many relationship
        if 'application_ids' in update_data:
            application_ids = update_data.pop('application_ids')
            if application_ids is not None:
                applications = db.query(Application).filter(Application.appid.in_(application_ids)).all()
                db_obj.applications = applications
            else: # Allow clearing the relationship
                db_obj.applications = []

        # Update the other fields
        for field, value in update_data.items():
            if hasattr(db_obj, field):
                setattr(db_obj, field, value)

        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

# Create a single, reusable instance of the CRUD class.
service = CRUDService()
