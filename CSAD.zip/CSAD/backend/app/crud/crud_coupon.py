from typing import Optional, List
from sqlalchemy.orm import Session
from app.models.coupon import Coupon
from app.schemas.coupon import CouponCreate


class CRUDCoupon:
    def get(self, db: Session, id: str) -> Optional[Coupon]:
        return db.query(Coupon).filter(Coupon.id == id).first()

    def get_by_case(self, db: Session, case_id: str) -> List[Coupon]:
        return db.query(Coupon).filter(Coupon.case_id == case_id).all()

    def create(self, db: Session, obj_in: CouponCreate) -> Coupon:
        db_obj = Coupon(**obj_in.dict())
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj


coupon = CRUDCoupon()
