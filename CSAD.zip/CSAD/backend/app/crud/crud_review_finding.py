"""
CRUD (Create, Read, Update, Delete) operations for Review Findings.

This module provides a class-based approach to handling all database interactions
related to the ReviewFinding model, including custom query methods.
"""

from sqlalchemy.orm import Session
from typing import List, Optional

from app.models.review_finding import ReviewFinding
from app.schemas.review_finding import ReviewFindingCreate, ReviewFindingUpdate


class CRUDReviewFinding:
    """CRUD operations for ReviewFinding model."""

    def get(self, db: Session, id: str) -> Optional[ReviewFinding]:
        return db.query(ReviewFinding).filter(ReviewFinding.id == id).first()

    def get_multi_by_blueprint(
        self, db: Session, *, blueprint_id: int, skip: int = 0, limit: int = 100
    ) -> List[ReviewFinding]:
        return (
            db.query(ReviewFinding)
            .filter(ReviewFinding.blueprint_id == blueprint_id)
            .offset(skip)
            .limit(limit)
            .all()
        )

    def create(self, db: Session, *, obj_in: ReviewFindingCreate) -> ReviewFinding:
        db_obj = ReviewFinding(**obj_in.dict())
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def update(self, db: Session, *, db_obj: ReviewFinding, obj_in: ReviewFindingUpdate) -> ReviewFinding:
        update_data = obj_in.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_obj, field, value)
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj


review_finding = CRUDReviewFinding()
