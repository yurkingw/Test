from typing import Any, Dict, Optional, Union, List
from sqlalchemy.orm import Session, joinedload

from app.models.case_review import CaseReview
from app.models.review_finding import ReviewFinding
from app.schemas.case_review import CaseReviewCreate, CaseReviewUpdate


class CRUDCaseReview:
    model = CaseReview
    def get(self, db: Session, id: str) -> Optional[CaseReview]:
        return db.query(CaseReview).filter(CaseReview.id == id).first()

    def get_full_details(self, db: Session, *, id: str) -> Optional[CaseReview]:
        return (
            db.query(CaseReview)
            .options(joinedload(CaseReview.findings))
            .filter(CaseReview.id == id)
            .first()
        )

    def get_multi(
        self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> List[CaseReview]:
        return db.query(CaseReview).offset(skip).limit(limit).all()

    def create(self, db: Session, *, obj_in: CaseReviewCreate) -> CaseReview:
        data = obj_in.dict(exclude_unset=True)
        # Strip/initialize relationship fields to avoid None on relationship attributes
        relationship_keys = {"findings", "evidence_items", "chat_messages", "coupons", "status_history", "system", "system_id"}
        for key in list(data.keys()):
            if key in relationship_keys:
                data.pop(key, None)
        db_obj = CaseReview(**data)
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def update(
        self, db: Session, *, db_obj: CaseReview, obj_in: Union[CaseReviewUpdate, Dict[str, Any]]
    ) -> CaseReview:
        update_data = obj_in if isinstance(obj_in, dict) else obj_in.dict(exclude_unset=True)
        # Handle findings separately to persist relational records
        findings_data = update_data.pop("findings", None)
        reviewer_extra = update_data.pop("reviewer_extra_findings", None)

        for field, value in update_data.items():
            setattr(db_obj, field, value)

        if findings_data is not None:
            # Replace existing findings with the provided set
            db_obj.findings.clear()
            for item in findings_data:
                if not isinstance(item, dict):
                    continue
                # Always generate a unique ID per save to avoid collisions
                fid = f"{db_obj.id}-FIN-{len(db_obj.findings) + 1}"
                details = item.get("details") or {}
                summary = item.get("summary") or details.get("violation_summary")
                risk_level = item.get("risk_level") or details.get("risk")
                classification = item.get("classification")
                requirement = item.get("requirement")
                source_ref = item.get("source_ref")
                kind = item.get("kind")
                rf = ReviewFinding(
                    id=str(fid) if fid else None,
                    summary=summary,
                    risk_level=risk_level,
                    classification=classification,
                    requirement=requirement,
                    source_ref=source_ref,
                    kind=kind,
                    details=details,
                    case_review_id=db_obj.id,
                )
                db_obj.findings.append(rf)

        if reviewer_extra is not None:
            # Save reviewer added findings into details for persistence
            db_obj.reviewer_extra_findings = reviewer_extra

        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def remove(self, db: Session, *, id: str) -> Optional[CaseReview]:
        obj = db.query(CaseReview).filter(CaseReview.id == id).first()
        if not obj:
            return None
        db.delete(obj)
        db.commit()
        return obj


case_review = CRUDCaseReview()
