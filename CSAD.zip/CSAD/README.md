This is a project about CALM based Security Architecture Desinger system.
