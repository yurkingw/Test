"""Add reviewer feedback columns to case_reviews.

Revision ID: 20250320_08
Revises: 20250320_07
Create Date: 2025-03-20 00:00:08
"""

from alembic import op


# revision identifiers, used by Alembic.
revision = "20250320_08"
down_revision = "20250320_07"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute(
        """
        ALTER TABLE case_reviews
            ADD COLUMN IF NOT EXISTS reviewer_comment VARCHAR,
            ADD COLUMN IF NOT EXISTS reviewer_comment_files JSONB,
            ADD COLUMN IF NOT EXISTS reviewer_extra_findings JSONB,
            ADD COLUMN IF NOT EXISTS evidence JSONB
        """
    )


def downgrade() -> None:
    op.execute(
        """
        ALTER TABLE case_reviews
            DROP COLUMN IF EXISTS evidence,
            DROP COLUMN IF EXISTS reviewer_extra_findings,
            DROP COLUMN IF EXISTS reviewer_comment_files,
            DROP COLUMN IF EXISTS reviewer_comment
        """
    )
