#!/usr/bin/env python3
"""
Cleanup case-related records and attachments while preserving option tables.
"""
from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from app.db.session import SessionLocal
from app.models import (
    CaseReview,
    ReviewFinding,
    Evidence,
    ChatMessage,
    Coupon,
    StatusHistory,
)


CASE_TABLES = (
    Evidence,
    ChatMessage,
    ReviewFinding,
    Coupon,
    StatusHistory,
    CaseReview,
)


def remove_attachments() -> int:
    root = Path(os.environ.get("ATTACHMENTS_DIR", "/data/attachments")).resolve()
    uploads_dir = root / "uploads"
    if not uploads_dir.exists():
        return 0
    deleted = 0
    for path in uploads_dir.rglob("*"):
        if path.is_file():
            path.unlink()
            deleted += 1
    # remove empty dirs
    for path in sorted(uploads_dir.rglob("*"), reverse=True):
        if path.is_dir():
            try:
                path.rmdir()
            except OSError:
                pass
    return deleted


def main() -> None:
    db = SessionLocal()
    try:
        totals = {}
        for model in CASE_TABLES:
            totals[model.__tablename__] = db.query(model).delete(synchronize_session=False)
        db.commit()
    finally:
        db.close()

    files_deleted = remove_attachments()
    print("Case tables cleared:", totals)
    print(f"Attachments removed: {files_deleted}")


if __name__ == "__main__":
    main()
