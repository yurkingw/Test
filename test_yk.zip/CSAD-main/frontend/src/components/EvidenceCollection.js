import React, { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { useUser } from '../context/UserContext';
import { saveCaseApi, getCaseApi, confirmAndCancelCase } from '../api/cases';
import { ensureFileMetaArray } from '../utils/fileUtils';
import { uploadFiles, getAttachmentUrl } from '../utils/attachments';
import { resolveCaseId, appendCaseIdParam } from '../utils/caseId';

// --- Styles (collapsed for brevity) --- //
const containerStyle = { margin: '20px auto', padding: '20px', maxWidth: '800px', backgroundColor: '#f9f9f9', borderRadius: '8px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)', textAlign: 'left' };
const findingCardStyle = { backgroundColor: '#fff', border: '1px solid #ddd', padding: '15px', borderRadius: '8px', marginBottom: '20px' };
const formGroupStyle = { marginBottom: '15px' };
const labelStyle = { display: 'block', marginBottom: '5px', color: '#333', fontWeight: 'bold' };
const inputStyle = { width: '100%', padding: '10px', border: '1px solid #ccc', borderRadius: '4px', boxSizing: 'border-box' };
const buttonStyle = { backgroundColor: '#1976D2', color: '#FFFFFF', border: 'none', padding: '12px 20px', borderRadius: '5px', cursor: 'pointer', fontSize: '16px', width: '100%', marginTop: '20px' };

const EvidenceCollection = () => {
    const location = useLocation();
    const [searchParams] = useSearchParams();
    const navigate = useNavigate();
    const { user } = useUser();
    const resolvedCaseId = resolveCaseId(location.state?.caseId, searchParams, null);
    const [caseData, setCaseData] = useState(null);

    useEffect(() => {
        let mounted = true;
        (async () => {
            if (!resolvedCaseId) return;
            try {
                const data = await getCaseApi(resolvedCaseId);
                if (mounted) setCaseData(data);
            } catch (e) {
                console.error('Failed to load case', e);
            }
        })();
        return () => { mounted = false; };
    }, [resolvedCaseId]);

    const caseId = resolvedCaseId || caseData?.id;
    const findings = useMemo(() => {
        const baseFindings = location.state?.findings && location.state.findings.length ? location.state.findings : caseData?.findings || [];
        const sanitizedBase = (baseFindings || []).filter((f) => (f.details?.violation_summary || '').trim().length > 0);
        const extra = (caseData?.reviewerExtraFindings || [])
          .filter((f) => (f.riskDescription || '').trim().length > 0)
          .map((f, idx) => ({
            id: f.id || `EX-${idx}`,
            kind: 'manual',
            details: {
                violation_summary: f.riskDescription || 'Reviewer added finding',
                risk: f.riskLevel || 'N/A',
                requirement: f.requirement ? [{ description: f.requirement }] : [],
            },
        })) || [];
        return [...sanitizedBase, ...extra];
    }, [location.state?.findings, caseData]);
    const payload = location.state?.payload || caseData?.designPayload;

    const findingKey = (finding, idx) => finding.id || `finding-${idx}`;
    const isSuppressed = (finding) => Boolean(finding?.suppressed || finding?.details?.suppressed);
    const findEvidenceEntry = (finding, idx) => {
        const key = findingKey(finding, idx);
        const evidenceMap = caseData?.evidence || {};
        if (evidenceMap[key]) return evidenceMap[key];
        const entries = Object.values(evidenceMap || {});
        const matchById = entries.find((ev) => ev?.finding_id === key);
        if (matchById) return matchById;
        const summary = finding.details?.violation_summary || finding.riskDescription || '';
        if (summary) {
            const matchBySummary = entries.find((ev) => (ev?.violation_summary || '').trim() === summary.trim());
            if (matchBySummary) return matchBySummary;
        }
        if (evidenceMap[idx]) return evidenceMap[idx];
        return null;
    };
    const getFindingTypeLabel = (finding) => {
        if (finding?.kind === 'manual') return 'Manual Review';
        if (finding?.kind === 'ai' || (finding?.id || '').startsWith('AI-')) return 'AI Pre-Review';
        return 'Rule-Based Pre-Review';
    };

    // Create a state to hold evidence for each finding
    const [evidence, setEvidence] = useState({});

    useEffect(() => {
        const initialEvidence = {};
        findings.forEach((finding, idx) => {
            const key = findingKey(finding, idx);
            const existing = findEvidenceEntry(finding, idx);
            initialEvidence[key] = {
                description: existing?.description || '',
                files: ensureFileMetaArray(existing?.files),
                decision: existing?.decision || 'accept',
            };
        });
        setEvidence(initialEvidence);
    }, [findings, caseData]);

    const handleCancel = async () => {
        if (!caseId) {
            navigate('/my-cases');
            return;
        }
        try {
            await confirmAndCancelCase(caseId);
            alert('Case cancelled.');
            navigate('/my-cases');
        } catch (e) {
            console.error('Cancel failed', e);
            alert('Cancel failed, see console.');
        }
    };

    const handleTextChange = (findingId, description) => {
        setEvidence(prev => ({
            ...prev,
            [findingId]: { ...prev[findingId], description },
        }));
    };

    const handleFileChange = async (findingId, files) => {
        const list = Array.from(files || []);
        if (!list.length) return;
        try {
            const uploaded = await uploadFiles(list);
            setEvidence(prev => ({
                ...prev,
                [findingId]: { ...prev[findingId], files: [...(prev[findingId]?.files || []), ...uploaded] },
            }));
        } catch (error) {
            console.error('Failed to upload evidence files', error);
            alert('Failed to upload evidence files.');
        }
    };

    const handleRemoveFile = (findingId, index) => {
        setEvidence((prev) => ({
            ...prev,
            [findingId]: { ...prev[findingId], files: (prev[findingId]?.files || []).filter((_, idx) => idx !== index) },
        }));
    };

    const handleDecisionChange = (findingId, decision) => {
        setEvidence((prev) => ({
            ...prev,
            [findingId]: { ...prev[findingId], decision },
        }));
    };
    const renderFiles = (files = [], onRemove) => {
        const list = ensureFileMetaArray(files);
        if (!list.length) return null;
        return (
            <div style={{ marginTop: '6px' }}>
                <strong>Existing Evidence:</strong>
                <ul>
                    {list.map((file, idx) => {
                        const href = file.path ? getAttachmentUrl(file.path) : (file.dataUrl || '');
                        const isImage = (file.type || '').startsWith('image') && !!href;
                        return (
                            <li key={`${file.name || 'file'}-${idx}`} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                <span>
                                    {href ? (
                                        <a href={href} target="_blank" rel="noreferrer">{file.name || 'attachment'}</a>
                                    ) : (
                                        file.name || 'attachment'
                                    )}
                                </span>
                                {onRemove ? (
                                    <button
                                        type="button"
                                        onClick={() => onRemove(idx)}
                                        style={{ border: 'none', background: 'transparent', color: '#d32f2f', cursor: 'pointer', fontSize: '1rem', lineHeight: 1 }}
                                    >
                                        ×
                                    </button>
                                ) : null}
                                {isImage ? (
                                    <div style={{ marginTop: '6px' }}>
                                        <img src={href} alt={file.name || 'attachment'} style={{ maxWidth: '240px', border: '1px solid #e0e0e0', borderRadius: '6px' }} />
                                    </div>
                                ) : null}
                            </li>
                        );
                    })}
                </ul>
            </div>
        );
    };

    const buildEvidencePayload = async () => {
        const evidenceWithData = {};
        for (const [key, value] of Object.entries(evidence)) {
            const findingMatch = findings.find((f, idx) => findingKey(f, idx) === key) || {};
            let filesMeta = [];
            if (value.files?.length) {
                const first = value.files[0];
                if (first instanceof File) {
                    filesMeta = await uploadFiles(value.files);
                } else {
                    filesMeta = value.files;
                }
            }
            evidenceWithData[key] = {
                finding_id: key,
                violation_summary: findingMatch.details?.violation_summary || findingMatch.riskDescription || '',
                description: value.description,
                files: filesMeta,
                decision: value.decision || 'accept',
            };
        }
        return evidenceWithData;
    };

    const validateEvidence = () => {
        for (let idx = 0; idx < findings.length; idx += 1) {
            const finding = findings[idx];
            const key = findingKey(finding, idx);
            const ev = evidence[key];
            if (!ev) return `Missing evidence for finding ${finding.details?.violation_summary || key}`;
            if (isSuppressed(finding)) {
                continue;
            }
            const descOk = ev.description && ev.description.trim().length > 0;
            const filesOk = ev.files && ev.files.length > 0;
            if (!descOk || !filesOk) {
                return `Finding "${finding.details?.violation_summary || key}": description and at least one attachment are required.`;
            }
        }
        return '';
    };

    const handleSubmit = async () => {
        const validationMsg = validateEvidence();
        if (validationMsg) {
            const proceed = window.confirm(`${validationMsg}\n\nProceed to submit anyway?`);
            if (!proceed) return;
        }
        if (!caseId) {
            alert('Missing case id, please reopen this case from My Cases.');
            return;
        }
        // 校验（若有）已提示，此处负责落盘状态与数据
        const evidenceWithData = await buildEvidencePayload();
        await saveCaseApi(caseId, {
            status: 'resubmitted',
            evidence: evidenceWithData,
            lastEvidenceSubmittedAt: new Date().toISOString(),
        });
        alert("Evidence submitted for SecDesign Review! (Check console for data)");
        if (user.role === 'Requestor') {
            navigate('/requestor-finish', { state: { caseId: caseId || 'Pending' }, search: `?caseId=${caseId}` });
        } else {
            navigate(appendCaseIdParam('/secdesign-review', caseId), { state: { findings, evidence: evidenceWithData, payload, stage: 'reviewer', caseId } });
        }
    };

    const handleSubmitNoFindings = async () => {
        if (!caseId) {
            alert('Missing case id, please reopen this case from My Cases.');
            return;
        }
        await saveCaseApi(caseId, {
            status: 'resubmitted',
            lastEvidenceSubmittedAt: new Date().toISOString(),
        });
        alert('Submitted to SecDesign Review.');
        if (user.role === 'Requestor') {
            navigate('/requestor-finish', { state: { caseId: caseId || 'Pending' }, search: `?caseId=${caseId}` });
        } else {
            navigate(appendCaseIdParam('/secdesign-review', caseId), { state: { findings: [], evidence: {}, payload, stage: 'reviewer', caseId } });
        }
    };

    if (findings.length === 0) {
        return (
          <div style={containerStyle}>
            <h2>Evidence Collection</h2>
            <p>No findings to address. You can still resubmit to SecDesign Review.</p>
            <button style={{ ...buttonStyle, marginRight: '10px', width: 'auto' }} onClick={handleSubmitNoFindings}>Submit for Review</button>
            <button
              type="button"
              style={{ ...buttonStyle, backgroundColor: '#f44336', width: 'auto' }}
              onClick={handleCancel}
            >
              Cancel Case
            </button>
          </div>
        );
    }

    return (
        <div style={containerStyle}>
            <h2>Evidence Collection</h2>
            <p>For each finding, please provide a description of the implemented control and upload supporting evidence.</p>
            
            {findings.map((finding, idx) => {
                const key = findingKey(finding, idx);
                const suppressed = isSuppressed(finding);
                const findingType = getFindingTypeLabel(finding);
                return (
                <div key={key} style={findingCardStyle}>
                    <h4>Finding: {finding.details?.violation_summary || key}</h4>
                    <p><strong>Finding Type:</strong> {findingType}</p>
                    {suppressed ? (
                      <p style={{ color: '#8e24aa', marginTop: '4px' }}>
                        Suppressed by reviewer — evidence not required.
                      </p>
                    ) : null}
                    <p><strong>Risk:</strong> {finding.details?.risk || 'N/A'}</p>
                    <p><strong>Classification:</strong> {finding.details?.classification || finding.classification || '—'}</p>
                    <div>
                        <strong>Requirements:</strong>
                        <ul>
                            {finding.details?.requirement?.length
                              ? finding.details.requirement.map((req, i) => <li key={i}>{req.description || req}</li>)
                              : <li>No requirements listed.</li>}
                        </ul>
                    </div>
                    
                    {!suppressed ? (
                      <>
                        <div style={formGroupStyle}>
                            <label style={labelStyle}>Implemented Control Description:</label>
                            <textarea 
                                style={{...inputStyle, height: '80px'}} 
                                value={evidence[key]?.description || ''}
                                onChange={(e) => handleTextChange(key, e.target.value)}
                            />
                        </div>

                        <div style={formGroupStyle}>
                            <label style={labelStyle}>Upload Evidence (Image, Doc, etc.):</label>
                            <input
                                type="file"
                                multiple
                                style={inputStyle}
                                onChange={(e) => {
                                    handleFileChange(key, Array.from(e.target.files || []));
                                    e.target.value = '';
                                }}
                            />
                            {renderFiles(evidence[key]?.files, (index) => handleRemoveFile(key, index))}
                        </div>
                        <div style={formGroupStyle}>
                            <label style={labelStyle}>Decision:</label>
                            <label style={{ marginRight: '10px' }}>
                                <input
                                    type="radio"
                                    name={`decision-${key}`}
                                    value="accept"
                                    checked={(evidence[key]?.decision || 'accept') === 'accept'}
                                    onChange={() => handleDecisionChange(key, 'accept')}
                                /> Accept
                            </label>
                            <label>
                                <input
                                    type="radio"
                                    name={`decision-${key}`}
                                    value="reject"
                                    checked={evidence[key]?.decision === 'reject'}
                                    onChange={() => handleDecisionChange(key, 'reject')}
                                /> Reject
                            </label>
                        </div>
                      </>
                    ) : null}
                </div>
            )})}

            <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                <button style={{ ...buttonStyle, width: 'auto', backgroundColor: '#4CAF50' }} onClick={async () => { const payload = await buildEvidencePayload(); if (caseId) await saveCaseApi(caseId, { evidence: payload }); alert('Saved.'); }}>
                    Save
                </button>
                <button style={{ ...buttonStyle, width: 'auto' }} onClick={handleSubmit}>Submit to SecDesign Review</button>
                <button
                    type="button"
                    style={{ ...buttonStyle, backgroundColor: '#f44336', width: 'auto' }}
                    onClick={handleCancel}
                >
                    Cancel Case
                </button>
            </div>
        </div>
    );
};

export default EvidenceCollection;
