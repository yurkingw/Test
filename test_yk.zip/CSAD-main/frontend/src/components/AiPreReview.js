import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import apiClient from '../api';
import { uploadFiles } from '../utils/attachments';
import { REVIEW_TYPES, DEFAULT_REVIEW_TYPE } from '../constants/reviewTypes';
import { useReviewCache } from '../context/ReviewCacheContext';

const containerStyle = { margin: '20px auto', maxWidth: '900px', padding: '20px', backgroundColor: '#f9f9f9', borderRadius: '8px', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' };
const chatHistoryStyle = { maxHeight: '400px', overflowY: 'auto', padding: '10px', backgroundColor: '#fff', borderRadius: '6px', border: '1px solid #ddd', marginBottom: '15px' };
const messageItemStyle = { marginBottom: '12px', textAlign: 'left', lineHeight: 1.5 };
const formRowStyle = { display: 'flex', gap: '10px', marginBottom: '10px' };
const inputStyle = { flex: 1, padding: '10px', borderRadius: '4px', border: '1px solid #ccc' };
const buttonStyle = { padding: '10px 16px', borderRadius: '4px', border: 'none', cursor: 'pointer', backgroundColor: '#1976D2', color: '#FFFFFF' };
const helperTextStyle = { fontSize: '0.9rem', color: '#555', marginBottom: '10px' };

const AiPreReview = () => {
    const [searchParams] = useSearchParams();
    const reviewType = searchParams.get('type') || DEFAULT_REVIEW_TYPE;
    const reviewMeta = useMemo(
        () => REVIEW_TYPES[reviewType] ?? REVIEW_TYPES[DEFAULT_REVIEW_TYPE],
        [reviewType]
    );

    const [messages, setMessages] = useState([]);
    const [userInput, setUserInput] = useState('');
    const [primaryFiles, setPrimaryFiles] = useState([]);
    const [securityTemplates, setSecurityTemplates] = useState([]);
    const [fileInputKey, setFileInputKey] = useState(0);
    const [templateInputKey, setTemplateInputKey] = useState(0);
    const [analysisMarkdown, setAnalysisMarkdown] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [uploadedArtifacts, setUploadedArtifacts] = useState([]);
    const navigate = useNavigate();
    const cacheKey = `ai_${reviewType}`;
    const { cachedValue, saveCache, clearCacheForKey } = useReviewCache(cacheKey);
    const hydrated = useRef(false);
    const lastSavedRef = useRef(null);

    const shallowEqual = (a, b) => {
        if (a === b) return true;
        if (!a || !b) return false;
        const keysA = Object.keys(a);
        const keysB = Object.keys(b);
        if (keysA.length !== keysB.length) return false;
        for (const key of keysA) {
            if (a[key] !== b[key]) return false;
        }
        return true;
    };

    useEffect(() => {
        if (hydrated.current) return;
        if (cachedValue) {
            setMessages(cachedValue.messages || []);
            setUserInput(cachedValue.userInput || '');
            setPrimaryFiles(cachedValue.primaryFiles || []);
            setSecurityTemplates(cachedValue.securityTemplates || []);
            setFileInputKey(cachedValue.fileInputKey || 0);
            setTemplateInputKey(cachedValue.templateInputKey || 0);
            setAnalysisMarkdown(cachedValue.analysisMarkdown || '');
            setUploadedArtifacts(cachedValue.uploadedArtifacts || []);
        }
        hydrated.current = true;
    }, [cachedValue]);

    useEffect(() => {
        const snapshot = {
            messages,
            userInput,
            primaryFiles,
            securityTemplates,
            fileInputKey,
            templateInputKey,
            analysisMarkdown,
            uploadedArtifacts,
        };
        if (shallowEqual(lastSavedRef.current, snapshot)) return;
        lastSavedRef.current = snapshot;
        saveCache(snapshot);
    }, [messages, userInput, primaryFiles, securityTemplates, fileInputKey, templateInputKey, analysisMarkdown, uploadedArtifacts, saveCache]);

    const resetInputs = () => {
        setUserInput('');
        setFileInputKey((prev) => prev + 1);
        setTemplateInputKey((prev) => prev + 1);
        setPrimaryFiles([]);
        setSecurityTemplates([]);
    };

    const handleFileChange = (setter) => (event) => {
        const files = Array.from(event.target.files || []);
        setter(files);
        event.target.value = '';
    };

    const handleSendMessage = async (event) => {
        event.preventDefault();
        if (!userInput.trim() && primaryFiles.length === 0 && securityTemplates.length === 0) {
            setErrorMessage('Please enter a message or attach a file before sending.');
            return;
        }
        setErrorMessage('');
        const userMessage = {
            sender: 'user',
            text: userInput.trim() || '(User uploaded attachments without additional notes.)',
        };

        const conversationWithUser = [...messages, userMessage];
        setMessages(conversationWithUser);
        setIsLoading(true);

        try {
            const formData = new FormData();
            formData.append('conversation', JSON.stringify(conversationWithUser));
            formData.append('message', userMessage.text);
            formData.append('review_type', reviewType);
            primaryFiles.forEach((file) => formData.append('files', file));
            securityTemplates.forEach((file) => formData.append('security_designs', file));

            const response = await apiClient.post('/ai/chat', formData, {
                headers: { 'Content-Type': 'multipart/form-data' },
            });
            const { reply, analysis_markdown: analysisMarkdownFromAI } = response.data;
            const assistantMessage = {
                sender: 'ai',
                text: reply || 'AI did not return any content.',
            };
            setMessages((prev) => [...prev, assistantMessage]);
            if (analysisMarkdownFromAI) {
                setAnalysisMarkdown(analysisMarkdownFromAI);
            }
            const newArtifacts = [];
            if (primaryFiles.length) {
                const uploaded = await uploadFiles(primaryFiles);
                uploaded.forEach((attachment) => newArtifacts.push({ label: 'Supporting File', attachment }));
            }
            if (securityTemplates.length) {
                const uploaded = await uploadFiles(securityTemplates);
                uploaded.forEach((attachment) => newArtifacts.push({ label: 'Security Design Template', attachment }));
            }
            if (newArtifacts.length) setUploadedArtifacts((prev) => [...prev, ...newArtifacts]);
            resetInputs();
        } catch (error) {
            console.error('Error communicating with AI:', error);
            setErrorMessage('Failed to contact the AI assistant. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleDownloadMarkdown = () => {
        if (!analysisMarkdown) return;
        const blob = new Blob([analysisMarkdown], { type: 'text/markdown;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'ai-pre-review-report.md';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    const handleCompleteReview = async () => {
        if (messages.length === 0) {
            alert('Please provide at least one message before completing the review.');
            return;
        }
        setIsLoading(true);
        try {
            const response = await apiClient.post('/ai/complete-review', {
                review_type: reviewType,
                messages,
            });
            navigate('/pre-review-summary', {
                state: {
                    mode: 'ai',
                    reviewType,
                    findings: response.data,
                    payload: {
                        messages,
                        analysisMarkdown,
                        attachments: uploadedArtifacts,
                    },
                },
            });
        } catch (error) {
            console.error('Error completing review:', error);
            alert('Failed to complete the review. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleCancelReview = () => {
        if (window.confirm('Are you sure you want to cancel this review?')) {
            clearCacheForKey();
            navigate('/');
        }
    };

    const renderSelectedFiles = (files, onRemove) => {
        if (!files?.length) return null;
        return (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', marginTop: '6px' }}>
                {files.map((file, idx) => (
                    <span
                        key={`${file.name}-${idx}`}
                        style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '4px 8px', borderRadius: '12px', background: '#e3f2fd' }}
                    >
                        {file.name}
                        <button
                            type="button"
                            onClick={() => onRemove(idx)}
                            disabled={isLoading}
                            style={{ border: 'none', background: 'transparent', color: '#d32f2f', cursor: 'pointer', fontSize: '1rem', lineHeight: 1 }}
                        >
                            ×
                        </button>
                    </span>
                ))}
            </div>
        );
    };

    return (
        <div style={containerStyle}>
            <h2>AI Pre-Review — {reviewMeta.label}</h2>
            <p style={helperTextStyle}>{reviewMeta.aiHelperText}</p>

            <div style={chatHistoryStyle}>
                {messages.length === 0 ? (
                    <p style={{ color: '#666' }}>No messages yet. Start by sending details about your design.</p>
                ) : (
                    messages.map((message, index) => (
                        <div key={index} style={messageItemStyle}>
                            <strong>{message.sender === 'user' ? 'You' : 'CALM-Bot'}:</strong> {message.text}
                        </div>
                    ))
                )}
            </div>

            {analysisMarkdown && (
                <div style={{ marginBottom: '15px', textAlign: 'left' }}>
                    <h4>Latest Analysis Snapshot</h4>
                    <div
                        style={{
                            backgroundColor: '#fff',
                            border: '1px solid #ddd',
                            borderRadius: '6px',
                            padding: '10px',
                            maxHeight: '220px',
                            overflowY: 'auto',
                            overflowX: 'auto',
                            whiteSpace: 'pre-wrap',
                            wordBreak: 'break-word',
                            fontFamily: 'monospace',
                            lineHeight: 1.4,
                        }}
                    >
                        {analysisMarkdown}
                    </div>
                    <button style={{ ...buttonStyle, backgroundColor: '#4CAF50', marginTop: '10px' }} onClick={handleDownloadMarkdown}>
                        Download Markdown Report
                    </button>
                    <p style={{ fontSize: '0.85rem', color: '#666', marginTop: '6px' }}>{reviewMeta.aiMarkdownHint}</p>
                </div>
            )}

            {errorMessage && (
                <div style={{ color: '#D32F2F', marginBottom: '10px' }}>
                    {errorMessage}
                </div>
            )}

            <form onSubmit={handleSendMessage}>
                <div style={formRowStyle}>
                    <input
                        type="text"
                        value={userInput}
                        onChange={(event) => setUserInput(event.target.value)}
                        placeholder="Describe your design or ask a question..."
                        style={inputStyle}
                        disabled={isLoading}
                    />
                    <button type="submit" style={buttonStyle} disabled={isLoading}>
                        {isLoading ? 'Sending...' : 'Send'}
                    </button>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '15px' }}>
                    <label>
                        <strong>Attach supporting file(s) (documents, images):</strong>
                        <input key={fileInputKey} type="file" multiple onChange={handleFileChange(setPrimaryFiles)} disabled={isLoading} />
                        {renderSelectedFiles(primaryFiles, (idx) => setPrimaryFiles((prev) => prev.filter((_, i) => i !== idx)))}
                    </label>
                    <label>
                        <strong>Attach Security Design template(s):</strong>
                        <input key={templateInputKey} type="file" multiple onChange={handleFileChange(setSecurityTemplates)} disabled={isLoading} />
                        {renderSelectedFiles(securityTemplates, (idx) => setSecurityTemplates((prev) => prev.filter((_, i) => i !== idx)))}
                    </label>
                </div>
            </form>

            <div style={{padding: '10px', borderTop: '1px solid #ccc', textAlign: 'center', display: 'flex', justifyContent: 'space-between'}}>
                <button onClick={handleCancelReview} disabled={isLoading} style={{ ...buttonStyle, backgroundColor: '#757575' }}>
                    Cancel Review
                </button>
                <button onClick={handleCompleteReview} disabled={isLoading} style={buttonStyle}>
                    {isLoading ? 'Finalizing...' : 'Complete AI-Pre-Review'}
                </button>
            </div>
        </div>
    );
};

export default AiPreReview;
