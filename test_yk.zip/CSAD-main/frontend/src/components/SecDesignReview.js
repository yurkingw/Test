import React, { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { useUser } from '../context/UserContext';
import apiClient from '../api';
import { getCaseApi, saveCaseApi } from '../api/cases';
import { ensureFileMetaArray } from '../utils/fileUtils';
import { uploadFiles, getAttachmentUrl } from '../utils/attachments';
import FormReadonly from './FormReadonly';
import { appendCaseIdParam, resolveCaseId } from '../utils/caseId';
import { buildCalmReport, stripAttachmentData } from '../utils/calmUtils';
import { useBlueprintTemplates } from '../hooks/useBlueprintTemplates';

const containerStyle = { margin: '20px auto', maxWidth: '900px', padding: '20px', backgroundColor: '#f5f7ff', borderRadius: '10px', boxShadow: '0 4px 14px rgba(0,0,0,0.08)', textAlign: 'left' };
const sectionStyle = { backgroundColor: '#fff', border: '1px solid #dde3f7', padding: '18px', borderRadius: '10px', marginBottom: '20px' };
const buttonRowStyle = { display: 'flex', gap: '12px', flexWrap: 'wrap' };
const buttonStyle = { backgroundColor: '#1976D2', color: '#FFFFFF', border: 'none', padding: '10px 18px', borderRadius: '5px', cursor: 'pointer', fontSize: '15px' };
const dangerButtonStyle = { ...buttonStyle, backgroundColor: '#f44336' };
const successButtonStyle = { ...buttonStyle, backgroundColor: '#4CAF50' };
const inputStyle = { width: '100%', padding: '10px', border: '1px solid #cfd8dc', borderRadius: '4px', boxSizing: 'border-box', backgroundColor: '#fafafa' };

const SecDesignReview = () => {
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const rawCaseId = useMemo(() => resolveCaseId(location.state?.caseId, searchParams, null), [location.state?.caseId, searchParams]);
  const [storedCase, setStoredCase] = useState(null);
  const caseId = rawCaseId || storedCase?.id || null;
  useEffect(() => {
    let mounted = true;
    (async () => {
      if (!rawCaseId) return;
      try {
        const data = await getCaseApi(rawCaseId);
        if (mounted) setStoredCase(data);
      } catch (e) {
        console.error('Failed to load case', e);
      }
    })();
    return () => { mounted = false; };
  }, [rawCaseId]);

  const normalizeSuppressed = (items = []) => (items || []).map((item) => {
    const suppressed = Boolean(item?.suppressed || item?.details?.suppressed);
    return {
      ...item,
      suppressed,
      details: { ...(item?.details || {}), suppressed },
    };
  });
  const sanitizeFindings = (items = []) =>
    normalizeSuppressed(items || []).filter((f) => (f?.details?.violation_summary || '').trim().length > 0);
  const { templates } = useBlueprintTemplates();
  const findings = sanitizeFindings(location.state?.findings || storedCase?.findings || []);
  const payload = location.state?.payload || storedCase?.designPayload;
  const evidence = location.state?.evidence || storedCase?.evidence || {};
  const calmSummary = useMemo(
    () => buildCalmReport({
      payload: payload || {},
      findings,
      manualFindings: storedCase?.reviewerExtraFindings || [],
      templates,
    }),
    [payload, findings, storedCase?.reviewerExtraFindings, templates]
  );
  const { user } = useUser();
  const isReviewer = user.role === 'Reviewer';
  const [generatedFindings, setGeneratedFindings] = useState(findings.length ? findings : []);
  const [isRunning, setIsRunning] = useState(false);

  const [comment, setComment] = useState('');
  const [commentFiles, setCommentFiles] = useState([]);
  const [extraFindings, setExtraFindings] = useState([]);
  const [draftFinding, setDraftFinding] = useState({
    id: '',
    issueContext: '',
    riskDescription: '',
    classification: 'Requirement',
    riskLevel: 'Moderate',
    requirement: '',
    files: [],
  });
  const [showDesign, setShowDesign] = useState(false);
  const [showFindings, setShowFindings] = useState(false);
  const [showDesignForm, setShowDesignForm] = useState(false);
  const handleCommentFiles = async (fileList) => {
    const files = Array.from(fileList || []);
    if (!files.length) return;
    try {
      const uploaded = await uploadFiles(files);
      setCommentFiles((prev) => [...prev, ...uploaded]);
    } catch (error) {
      console.error('Failed to upload comment files', error);
      alert('Failed to upload comment files.');
    }
  };
  const removeCommentFile = (index) => {
    setCommentFiles((prev) => prev.filter((_, idx) => idx !== index));
  };
  const removeDraftFindingFile = (index) => {
    setDraftFinding((prev) => ({ ...prev, files: (prev.files || []).filter((_, idx) => idx !== index) }));
  };
  const removeExtraFindingFile = (id, index) => {
    setExtraFindings((prev) =>
      prev.map((finding) =>
        finding.id === id
          ? { ...finding, files: (finding.files || []).filter((_, idx) => idx !== index) }
          : finding
      )
    );
  };

  useEffect(() => {
    if (!storedCase) return;
    setComment(storedCase.reviewerComment || '');
    setCommentFiles(ensureFileMetaArray(storedCase.reviewerCommentFiles));
    const extras = storedCase.reviewerExtraFindings?.length
      ? storedCase.reviewerExtraFindings.map((f, idx) => ({
          id: f.id || `EX-${idx}`,
          issueContext: f.issueContext || '',
          riskDescription: f.riskDescription || '',
          classification: f.classification || 'Requirement',
          riskLevel: f.riskLevel || 'Moderate',
          requirement: f.requirement || '',
          files: ensureFileMetaArray(f.attachments),
        }))
      : [];
    setExtraFindings(extras);
    if (!generatedFindings.length && (storedCase.findings || []).length) {
      setGeneratedFindings(sanitizeFindings(storedCase.findings));
    }
  }, [storedCase]);

  const filesToMeta = async (files) => {
    if (!files || !files.length) return [];
    const first = files[0];
    if (first instanceof File) {
      return uploadFiles(files);
    }
    return files;
  };

  const saveFindingsDraft = async () => {
    await persistReviewerDraft();
    alert('Findings saved.');
  };

  const handleAddFinding = () => {
    const trimmedRisk = (draftFinding.riskDescription || '').trim();
    if (!trimmedRisk) {
      alert('Please provide Risk Description before adding the finding.');
      return;
    }
    const id = `EX-${Date.now()}`;
    setExtraFindings((prev) => [...prev, { ...draftFinding, id }]);
    setDraftFinding({
      id: '',
      issueContext: '',
      riskDescription: '',
      classification: 'Requirement',
      riskLevel: 'Moderate',
      requirement: '',
      files: [],
    });
  };

  const updateExtraFinding = (id, patch) => {
    setExtraFindings((prev) => prev.map((item) => (item.id === id ? { ...item, ...patch } : item)));
  };

  const updateDraftFinding = (patch) => {
    setDraftFinding((prev) => ({ ...prev, ...patch }));
  };

  const handleFindingFiles = async (id, fileList) => {
    const files = Array.from(fileList || []);
    if (!files.length) return;
    try {
      const uploaded = await uploadFiles(files);
      setExtraFindings((prev) =>
        prev.map((item) => (item.id === id ? { ...item, files: [...(item.files || []), ...uploaded] } : item))
      );
    } catch (error) {
      console.error('Failed to upload finding files', error);
      alert('Failed to upload finding files.');
    }
  };

  const handleDraftFindingFiles = async (fileList) => {
    const files = Array.from(fileList || []);
    if (!files.length) return;
    try {
      const uploaded = await uploadFiles(files);
      setDraftFinding((prev) => ({ ...prev, files: [...(prev.files || []), ...uploaded] }));
    } catch (error) {
      console.error('Failed to upload finding files', error);
      alert('Failed to upload finding files.');
    }
  };

  const nonEmptyExtras = extraFindings.filter((f) => (f.riskDescription || '').trim().length > 0);

  const resolveEvidenceForFinding = (finding, idx) => {
    if (!evidence) return null;
    const fid = finding.id || `finding-${idx}`;
    if (evidence[fid]) return evidence[fid];
    const entries = Object.values(evidence || {});
    const byMeta = entries.find((ev) => ev?.finding_id === fid);
    if (byMeta) return byMeta;
    const summary = finding.details?.violation_summary || finding.riskDescription || '';
    if (summary) {
      const bySummary = entries.find((ev) => (ev?.violation_summary || '').trim() === summary.trim());
      if (bySummary) return bySummary;
    }
    if (evidence[idx]) return evidence[idx];
    return null;
  };

  const evidenceComplete = () => {
    const activeFindings = generatedFindings.filter((finding) => !finding?.suppressed);
    const baseOk = activeFindings.length === 0 || activeFindings.every((finding, idx) => {
      const ev = resolveEvidenceForFinding(finding, idx);
      if (!ev) return false;
      const hasDesc = ev.description && ev.description.trim().length > 0;
      const hasFiles = ev.files && ev.files.length > 0;
      return hasDesc && hasFiles;
    });
    const extraOk = nonEmptyExtras.every((f, idx) => {
      if (f.classification !== 'Requirement') return true;
      const ev = resolveEvidenceForFinding(f, idx);
      if (!ev) return false;
      const hasDesc = ev.description && ev.description.trim().length > 0;
      const hasFiles = ev.files && ev.files.length > 0;
      return hasDesc && hasFiles;
    });
    return baseOk && extraOk;
  };

  const formatRequirementText = (value) => {
    if (!value) return '—';
    if (Array.isArray(value)) {
      const items = value.map((item) => (typeof item === 'string' ? item : item?.description)).filter(Boolean);
      return items.length ? items.join('; ') : '—';
    }
    return value;
  };

  const formatValue = (value) => {
    if (value === null || value === undefined || value === '') return '—';
    if (Array.isArray(value)) return value.map((item) => formatValue(item)).join(', ');
    if (typeof value === 'object') {
      try {
        return JSON.stringify(value);
      } catch {
        return String(value);
      }
    }
    return String(value);
  };

  const humanizePath = (path) => {
    if (!path) return 'input';
    const known = {
      'raw.metadata.checklist.data_perimeter.pii': 'PII',
      'raw.metadata.checklist.data_perimeter.mnpi': 'MNPI',
      'raw.metadata.checklist.data_perimeter.arr20': 'ARR 2.0',
      'raw.metadata.checklist.data_perimeter.isc': 'ISC',
      'raw.metadata.checklist.data_perimeter.external_transfer': 'External Transfer',
      'raw.metadata.checklist.data_perimeter.prod_data': 'PROD Data',
      'raw.metadata.checklist.data_perimeter.prod_mdex': 'PROD COD MDEX',
      'raw.metadata.checklist.data_perimeter.prod_mssip': 'PROD COD MSSIP',
      'raw.metadata.checklist.scenario_options.privileged_access': 'Scenario: Privileged Access',
      'connection.properties.implemented_controls.encryption.value': 'Implemented Control: Encryption',
      'connection.properties.implemented_controls.authn_authz.value': 'Implemented Control: AuthN & AuthZ',
      'connection.properties.implemented_controls.privileged_access.value': 'Implemented Control: Privileged Access',
      'architecture_description': 'Architecture Description',
      'architecture_files': 'Architecture Files',
      'exception_expiry': 'Exception Expiry',
      'raw.metadata.checklist.exception_expiry': 'Exception Expiry',
    };
    if (known[path]) return known[path];
    let cleaned = path
      .replace(/^raw\.metadata\.checklist\./, '')
      .replace(/^connection\.properties\./, '')
      .replace(/^connection\./, '')
      .replace(/^calm\./, '');
    cleaned = cleaned.replace(/\./g, ' > ').replace(/_/g, ' ');
    return cleaned;
  };

  const opPhrase = (op, expected) => {
    const exp = formatValue(expected);
    switch (op) {
      case 'equals':
        return `equal ${exp}`;
      case 'not_equals':
        return `not equal ${exp}`;
      case 'in':
        return `be in ${exp}`;
      case 'not_in':
        return `not be in ${exp}`;
      case 'contains':
        return `contain ${exp}`;
      case 'contains_any':
        return `contain any of ${exp}`;
      case 'contains_all':
        return `contain all of ${exp}`;
      case 'regex':
        return `match pattern ${exp}`;
      case 'min_length':
        return `have length >= ${exp}`;
      case 'max_length':
        return `have length <= ${exp}`;
      case 'min_items':
        return `have at least ${exp} item(s)`;
      case 'max_items':
        return `have at most ${exp} item(s)`;
      case 'gt':
        return `be greater than ${exp}`;
      case 'gte':
        return `be greater than or equal to ${exp}`;
      case 'lt':
        return `be less than ${exp}`;
      case 'lte':
        return `be less than or equal to ${exp}`;
      case 'between':
        return `be between ${exp}`;
      case 'max_days_from_now':
        return `be within ${exp} day(s)`;
      case 'min_days_from_now':
        return `be at least ${exp} day(s) from now`;
      case 'any_true':
        return 'have at least one selected option';
      case 'exists':
        return 'exist';
      case 'not_exists':
        return 'not exist';
      case 'is_true':
        return 'be true';
      case 'is_false':
        return 'be false';
      default:
        return `satisfy condition ${formatValue(op)} ${exp}`;
    }
  };

  const describeCondition = (item, isMatched) => {
    const label = humanizePath(item?.path);
    const actual = formatValue(item?.actual);
    const phrase = opPhrase(item?.op || 'equals', item?.expected);
    if (isMatched) {
      return `User input ${label} was ${actual}, matching ${phrase}.`;
    }
    return `User input ${label} was ${actual}; expected to ${phrase}.`;
  };

  const resolveFindingType = (source, finding) => {
    if (source === 'manual') return 'Manual Review';
    if (source === 'ai' || finding?.kind === 'ai' || (finding?.id || '').startsWith('AI-')) {
      return 'AI Pre-Review';
    }
    return 'Rule-Based Pre-Review';
  };

  const formatIssueContext = (finding) => {
    const snapshot = finding?.details?.violating_condition_snapshot || {};
    const failed = snapshot.failed_fragments || [];
    const matched = snapshot.matched_conditions || [];
    if (failed.length) {
      return failed.map((item) => describeCondition(item, false)).join(' ');
    }
    if (matched.length) {
      return matched.map((item) => describeCondition(item, true)).join(' ');
    }
    if (finding?.details?.issue_context) {
      return finding.details.issue_context;
    }
    return '—';
  };

  const handleSaveAll = async () => {
    if (!caseId) {
      alert('Missing case id. Please reopen this case from Review List.');
      return;
    }
    await persistReviewerDraft();
    alert('Draft saved.');
  };

  const persistReviewerDraft = async (statusPatch = {}) => {
    if (!caseId) return;
    const commentMeta = await filesToMeta(commentFiles);
    const extraFindingMeta = await Promise.all(
      extraFindings.map(async (f) => ({
        id: f.id,
        issueContext: f.issueContext,
        riskDescription: f.riskDescription,
        classification: f.classification,
        riskLevel: f.riskLevel,
        requirement: f.requirement,
        attachments: await filesToMeta(f.files),
      }))
    );
    await saveCaseApi(caseId, {
      reviewerComment: comment,
      reviewerCommentFiles: commentMeta,
      reviewerExtraFindings: extraFindingMeta,
      findings: normalizeSuppressed(generatedFindings),
      ...statusPatch,
    });
  };

  const handleDecision = (type) => {
    const added = nonEmptyExtras;

    if (!caseId) {
      alert('Missing case id. Please reopen this case from Review List.');
      return;
    }

    if (type === 'denied') {
      const confirmed = window.confirm('You are about to deny this case; evidence is no longer required. Confirm you want to finalize this case with DENY?');
      if (!confirmed) return;
    } else {
      const evidenceMsg = evidenceComplete() ? '' : 'Some findings are missing evidence. Please return to Requestor for evidence before closing.';
      if (evidenceMsg) {
        alert(evidenceMsg);
        return;
      }
      if (Object.keys(evidence || {}).length) {
        const confirmed = window.confirm('Evidence is present. Confirm you want to finalize this case?');
        if (!confirmed) return;
      }
    }

      const finalize = async () => {
      alert(`SecDesign review has been ${type === 'approved' ? 'approved' : 'denied'}.`);
      const latestCase = caseId ? await getCaseApi(caseId) : null;
      const latestEvidence = latestCase?.evidence || evidence || {};
      const finalSnapshot = {
        decision: type,
        reviewerName: user?.name || '',
        comment,
        addedFindings: added,
        payload,
        findings: [...normalizeSuppressed(generatedFindings), ...nonEmptyExtras],
        evidence: latestEvidence,
        reviewerComment: comment,
      };
      if (!caseId) {
        alert('Missing case id. Please reopen this case from Review List.');
        return;
      }
      const commentMeta = await filesToMeta(commentFiles);
      const extraFindingMeta = await Promise.all(
        nonEmptyExtras.map(async (f) => ({
          issueContext: f.issueContext,
          riskDescription: f.riskDescription,
          classification: f.classification,
          riskLevel: f.riskLevel,
          requirement: f.requirement,
          attachments: await filesToMeta(f.files),
        }))
      );
      await saveCaseApi(caseId, {
        findings: [...normalizeSuppressed(generatedFindings), ...nonEmptyExtras],
        status: type === 'approved' ? 'closed_approve' : 'closed_deny',
        reviewerComment: comment,
        reviewerCommentFiles: commentMeta,
        reviewerExtraFindings: extraFindingMeta,
        finalSnapshot,
      });
      navigate(appendCaseIdParam('/secdesign-final', caseId), {
        state: {
          caseId,
          ...finalSnapshot,
        },
      });
    };

    finalize();
  };

  const handleReturnToRequestor = async () => {
    alert('Case returned to Requestor.');
    if (!caseId) {
      alert('Missing case id. Please reopen this case from Review List.');
      return;
    }
    const commentMeta = await filesToMeta(commentFiles);
    const extraFindingMeta = await Promise.all(
      nonEmptyExtras.map(async (f) => ({
        issueContext: f.issueContext,
        riskDescription: f.riskDescription,
        classification: f.classification,
        riskLevel: f.riskLevel,
        requirement: f.requirement,
        attachments: await filesToMeta(f.files),
      }))
    );
    await saveCaseApi(caseId, {
      status: 'returned',
      findings: [...normalizeSuppressed(generatedFindings), ...nonEmptyExtras],
      reviewerComment: comment,
      reviewerCommentFiles: commentMeta,
      reviewerExtraFindings: extraFindingMeta,
    });
    navigate('/requestor-finish', { state: { caseId: caseId || 'Pending', returned: true }, search: `?caseId=${caseId}` });
  };

  const canEdit = isReviewer;

  if (!payload) {
    let stored = null;
    try {
      const raw = localStorage.getItem('csad_latest_case');
      if (raw) stored = JSON.parse(raw);
    } catch {
      stored = null;
    }
    if (stored) {
      location.state = { ...location.state, payload: stored };
    } else {
      return (
        <div style={containerStyle}>
          <h2>SecDesign Review</h2>
          <p>Missing case payload. Please restart the review from the beginning.</p>
        </div>
      );
    }
  }

  if (!isReviewer) {
    return (
      <div style={containerStyle}>
        <h2>SecDesign Review</h2>
        <p>Access denied. Reviewer only.</p>
      </div>
    );
  }

  const renderJSON = (data) => (
    <pre style={{ whiteSpace: 'pre-wrap', background: '#f1f4ff', padding: '10px', borderRadius: '6px', border: '1px solid #dce3f7' }}>
      {JSON.stringify(data, null, 2)}
    </pre>
  );
  const getEvidenceForFinding = (finding, idx) => {
    if (!evidence) return null;
    const fid = finding.id || `finding-${idx}`;
    if (evidence[fid]) return evidence[fid];
    const fallbackKey = `finding-${idx}`;
    if (evidence[fallbackKey]) return evidence[fallbackKey];
    const entries = Object.values(evidence);
    // match by stored finding_id metadata
    const byMeta = entries.find((ev) => ev?.finding_id === fid);
    if (byMeta) return byMeta;
    // match by violation summary text
    const summary = finding.details?.violation_summary || finding.riskDescription || '';
    if (summary) {
      const bySummary = entries.find((ev) => (ev.violation_summary || '').trim() === summary.trim());
      if (bySummary) return bySummary;
    }
    // scan by index numeric key
    if (evidence[idx]) return evidence[idx];
    return null;
  };
  const renderFiles = (files = [], onRemove) => {
    const list = ensureFileMetaArray(files);
    return list.map((file, idx) => {
      const href = file.path ? getAttachmentUrl(file.path) : (file.dataUrl || '');
      const isImage = (file.type || '').startsWith('image') && !!href;
      return (
        <div key={`${file.name || 'file'}-${idx}`} style={{ marginTop: '4px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span>
            <a
              href={href || '#'}
              download={file.name || 'download'}
              onClick={(e) => { if (!href) e.preventDefault(); }}
            >
              {file.name || 'attachment'}
            </a>
          </span>
          {onRemove ? (
            <button
              type="button"
              onClick={() => onRemove(idx)}
              style={{ border: 'none', background: 'transparent', color: '#d32f2f', cursor: 'pointer', fontSize: '1rem', lineHeight: 1 }}
            >
              ×
            </button>
          ) : null}
          {isImage ? (
            <div style={{ marginTop: '4px' }}>
              <img src={href} alt={file.name} style={{ maxWidth: '260px', border: '1px solid #e0e0e0', borderRadius: '6px' }} />
            </div>
          ) : null}
        </div>
      );
    });
  };

  const checklist = payload?.metadata?.checklist || {};
  const renderDesignForm = () => <FormReadonly checklist={checklist} />;

  return (
    <div style={containerStyle}>
      <h2>SecDesign Review</h2>
      <p>Review the submitted findings and evidence, add supplemental notes, and decide whether to approve or deny.</p>

      <div style={{ ...sectionStyle, border: '1px dashed #b0bec5' }}>
        <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
          <button type="button" style={buttonStyle} onClick={() => setShowDesignForm((v) => !v)}>
            {showDesignForm ? 'Hide' : 'Show'} Design (Form)
          </button>
          <button type="button" style={buttonStyle} onClick={() => setShowDesign((v) => !v)}>
            {showDesign ? 'Hide' : 'Show'} Design (CALM)
          </button>
          <button type="button" style={buttonStyle} onClick={() => setShowFindings((v) => !v)}>
            {showFindings ? 'Hide' : 'Show'} Findings (CALM)
          </button>
        </div>
        {showDesign && (
          <div style={{ marginTop: '12px' }}>
            <h4>Design CALM Summary</h4>
            {renderJSON(stripAttachmentData(calmSummary))}
          </div>
        )}
        {showFindings && (
          <div style={{ marginTop: '12px' }}>
            <h4>Review Findings (CALM)</h4>
            {generatedFindings?.length
              ? renderJSON({ ReviewFinding: generatedFindings })
              : <p>No findings.</p>}
          </div>
        )}
        {showDesignForm && (
          <div style={{ marginTop: '12px' }}>
            <h4>Design (Form)</h4>
            {payload?.metadata?.checklist ? <FormReadonly checklist={payload.metadata.checklist} /> : <p>No form data.</p>}
          </div>
        )}
      </div>

      {canEdit && (
        <div style={{ ...sectionStyle, border: '1px dashed #90caf9' }}>
          <h3>Generate Findings</h3>
          <p style={{ marginTop: 0 }}>Select how to pre-review the submitted design.</p>
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            <button
              type="button"
              style={successButtonStyle}
              onClick={async () => {
                setIsRunning(true);
                try {
                  if (!payload?.metadata) {
                    alert('No design payload to review. Please reload the case or ensure design was submitted.');
                    setIsRunning(false);
                    return;
                  }
                  const resp = await apiClient.post('/audits/', {
                    review_type: payload?.review_type || 'control_exception',
                    user_design: { metadata: payload?.metadata },
                  });
                  const sanitized = sanitizeFindings(resp.data || []);
                  const ranked = sanitized.sort((a, b) => {
                    const rank = (item) => {
                      if (item?.kind === 'ai') return 1;
                      if ((item?.id || '').startsWith('AI-')) return 1;
                      return 0;
                    };
                    return rank(a) - rank(b);
                  });
                  setGeneratedFindings(ranked);
                  if (caseId) await saveCaseApi(caseId, { findings: sanitized });
                  alert('Rule-based Pre Review completed.');
                } catch (err) {
                  console.error(err);
                  alert(`Failed to run rule-based review: ${err?.response?.data?.detail || err.message}`);
                } finally {
                  setIsRunning(false);
                }
              }}
              disabled={isRunning}
            >
              {isRunning ? 'Running...' : 'Rule-based Pre Review'}
            </button>
            <button
              type="button"
              style={buttonStyle}
              onClick={async () => {
                setIsRunning(true);
                try {
                  if (!payload?.metadata) {
                    alert('No design payload to review. Please reload the case or ensure design was submitted.');
                    setIsRunning(false);
                    return;
                  }
                  const resp = await apiClient.post('/audits/ai', {
                    review_type: payload?.review_type || 'control_exception',
                    user_design: { metadata: payload?.metadata, mode: 'ai' },
                  });
                  const sanitized = sanitizeFindings(resp.data || []);
                  const ranked = sanitized.sort((a, b) => {
                    const rank = (item) => {
                      if (item?.kind === 'ai') return 1;
                      if ((item?.id || '').startsWith('AI-')) return 1;
                      return 0;
                    };
                    return rank(a) - rank(b);
                  });
                  setGeneratedFindings(ranked);
                  if (caseId) await saveCaseApi(caseId, { findings: sanitized });
                  alert('AI Pre Review completed.');
                } catch (err) {
                  console.error(err);
                  alert(`Failed to run AI pre review: ${err?.response?.data?.detail || err.message}`);
                } finally {
                  setIsRunning(false);
                }
              }}
              disabled={isRunning}
            >
              {isRunning ? 'Running...' : 'AI Pre Review'}
            </button>
          </div>
        </div>
      )}

      <div style={sectionStyle}>
        <h3>Existing Findings</h3>
        {generatedFindings.length === 0 && extraFindings.length === 0 ? (
          <p>No existing findings were submitted.</p>
        ) : (
          <ul>
            {[
              ...generatedFindings.map((finding, idx) => ({
                source: finding?.kind === 'ai' || (finding?.id || '').startsWith('AI-') ? 'ai' : 'rule',
                index: idx,
                finding,
              })),
              ...extraFindings.filter((f) => (f.riskDescription || '').trim().length > 0).map((finding, idx) => ({ source: 'manual', index: idx, finding })),
            ].map(({ source, index, finding }) => {
              const fid = finding.id || `finding-${source}-${index}`;
              const ev = getEvidenceForFinding(finding, index);
              const decision = ev?.decision || 'accept';
              const issueContext = source === 'manual' ? (finding.issueContext || '—') : formatIssueContext(finding);
              const riskDescription = source === 'manual'
                ? (finding.riskDescription || '—')
                : (finding.details?.violation_summary || '—');
              const requirement = source === 'manual'
                ? (finding.requirement || '—')
                : formatRequirementText(finding.details?.requirement);
              const riskValue = source === 'manual'
                ? (finding.riskLevel || 'N/A')
                : (finding.details?.risk || 'N/A');
              const classificationValue = source === 'manual'
                ? (finding.classification || '—')
                : (finding.details?.classification || finding.classification || '—');
              const findingType = resolveFindingType(source, finding);
              return (
                <li key={fid} style={{ marginBottom: '10px' }}>
                  <div><strong>Issue Context:</strong> {issueContext}</div>
                  <div><strong>Finding Type:</strong> {findingType}</div>
                  <div><strong>Risk Description:</strong> {riskDescription}</div>
                  <div><strong>Requirement:</strong> {requirement}</div>
                  <div><strong>Risk:</strong> {riskValue}</div>
                  <div><strong>Classification:</strong> {classificationValue}</div>
                  <div><strong>Decision:</strong> {decision === 'reject' ? 'Reject' : 'Accept'}</div>
                  {source !== 'manual' && (
                    <button
                      type="button"
                      onClick={() =>
                        setGeneratedFindings((prev) =>
                          prev.map((item, idx) => {
                            if (idx !== index) return item;
                            const nextSuppressed = !item?.suppressed;
                            return { ...item, suppressed: nextSuppressed, details: { ...(item?.details || {}), suppressed: nextSuppressed } };
                          })
                        )
                      }
                      style={{
                        marginTop: '6px',
                        padding: '4px 10px',
                        borderRadius: '6px',
                        border: '1px solid #8e24aa',
                        background: finding?.suppressed ? '#f3e5f5' : '#fff',
                        color: '#6a1b9a',
                        cursor: 'pointer',
                      }}
                    >
                      {finding?.suppressed ? 'Unsuppress' : 'Suppress'}
                    </button>
                  )}
                  {source !== 'manual' && finding?.suppressed ? (
                    <div style={{ marginTop: '4px', fontSize: '0.85rem', color: '#8e24aa' }}>
                      Suppressed by reviewer — evidence not required.
                    </div>
                  ) : null}
                  {ev ? (
                    <div style={{ marginTop: '6px', fontSize: '0.9rem' }}>
                      <div><strong>Evidence Description:</strong> {ev.description || '—'}</div>
                      <div><strong>Evidence Files:</strong></div>
                      {ev.files?.length ? (
                        <div>{renderFiles(ev.files)}</div>
                      ) : (
                        <div style={{ color: '#78909c', fontSize: '0.85rem' }}>No attachments provided.</div>
                      )}
                    </div>
                  ) : (
                    <div style={{ marginTop: '6px', fontSize: '0.9rem', color: '#c62828' }}>No evidence submitted.</div>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <div style={sectionStyle}>
        <h3>Additional Finding</h3>
        <div style={{ marginBottom: '14px', border: '1px solid #e0e0e0', padding: '10px', borderRadius: '8px' }}>
          <label style={{ fontWeight: 'bold' }}>Issue Context</label>
          <textarea
            style={{ ...inputStyle, minHeight: '60px' }}
            placeholder="Describe the issue context..."
            value={draftFinding.issueContext}
            onChange={(e) => updateDraftFinding({ issueContext: e.target.value })}
            disabled={!canEdit}
          />
          <label style={{ fontWeight: 'bold' }}>Risk Description</label>
          <textarea
            style={{ ...inputStyle, minHeight: '60px' }}
            placeholder="Describe the risk..."
            value={draftFinding.riskDescription}
            onChange={(e) => updateDraftFinding({ riskDescription: e.target.value })}
            disabled={!canEdit}
          />
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginTop: '8px' }}>
            <div>
              <label style={{ fontWeight: 'bold' }}>Control Classification</label><br />
              <select
                value={draftFinding.classification}
                onChange={(e) => updateDraftFinding({ classification: e.target.value })}
                disabled={!canEdit}
                style={inputStyle}
              >
                <option value="Requirement">Requirement</option>
                <option value="Recommendation">Recommendation</option>
              </select>
            </div>
            <div>
              <label style={{ fontWeight: 'bold' }}>Risk Level</label><br />
              <select
                value={draftFinding.riskLevel}
                onChange={(e) => updateDraftFinding({ riskLevel: e.target.value })}
                disabled={!canEdit}
                style={inputStyle}
              >
                <option value="Critical">Critical</option>
                <option value="High">High</option>
                <option value="Moderate">Moderate</option>
                <option value="Low">Low</option>
              </select>
            </div>
          </div>
          <label style={{ fontWeight: 'bold', marginTop: '8px' }}>Requirement</label>
          <textarea
            style={{ ...inputStyle, minHeight: '60px' }}
            placeholder="Control requirement..."
            value={draftFinding.requirement}
            onChange={(e) => updateDraftFinding({ requirement: e.target.value })}
            disabled={!canEdit}
          />
          <label style={{ fontWeight: 'bold', marginTop: '8px' }}>Attach Evidence (optional)</label>
          <input
            type="file"
            multiple
            onChange={(e) => {
              handleDraftFindingFiles(e.target.files);
              e.target.value = '';
            }}
            disabled={!canEdit}
          />
          {draftFinding.files?.length ? (
            <div style={{ marginTop: '6px' }}>
              {renderFiles(draftFinding.files, removeDraftFindingFile)}
            </div>
          ) : null}
          <div style={{ marginTop: '10px' }}>
            <button type="button" style={buttonStyle} onClick={handleAddFinding} disabled={!canEdit}>
              Add Finding
            </button>
          </div>
        </div>

        {extraFindings.length === 0 ? <p>No additional findings added.</p> : null}
        {extraFindings.map((item) => (
          <div key={item.id} style={{ marginBottom: '14px', border: '1px solid #e0e0e0', padding: '10px', borderRadius: '8px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <strong>Saved Finding</strong>
              <button
                type="button"
                onClick={() => setExtraFindings((prev) => prev.filter((f) => f.id !== item.id))}
                disabled={!canEdit}
                style={{ ...dangerButtonStyle, padding: '6px 10px' }}
              >
                Delete
              </button>
            </div>
            <label style={{ fontWeight: 'bold' }}>Issue Context</label>
            <textarea
              style={{ ...inputStyle, minHeight: '60px' }}
              placeholder="Describe the issue context..."
              value={item.issueContext}
              onChange={(e) => updateExtraFinding(item.id, { issueContext: e.target.value })}
              disabled={!canEdit}
            />
            <label style={{ fontWeight: 'bold' }}>Risk Description</label>
            <textarea
              style={{ ...inputStyle, minHeight: '60px' }}
              placeholder="Describe the risk..."
              value={item.riskDescription}
              onChange={(e) => updateExtraFinding(item.id, { riskDescription: e.target.value })}
              disabled={!canEdit}
            />
            <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginTop: '8px' }}>
              <div>
                <label style={{ fontWeight: 'bold' }}>Control Classification</label><br />
                <select
                  value={item.classification}
                  onChange={(e) => updateExtraFinding(item.id, { classification: e.target.value })}
                  disabled={!canEdit}
                  style={inputStyle}
                >
                  <option value="Requirement">Requirement</option>
                  <option value="Recommendation">Recommendation</option>
                </select>
              </div>
              <div>
                <label style={{ fontWeight: 'bold' }}>Risk Level</label><br />
                <select
                  value={item.riskLevel}
                  onChange={(e) => updateExtraFinding(item.id, { riskLevel: e.target.value })}
                  disabled={!canEdit}
                  style={inputStyle}
                >
                  <option value="Critical">Critical</option>
                  <option value="High">High</option>
                  <option value="Moderate">Moderate</option>
                  <option value="Low">Low</option>
                </select>
              </div>
            </div>
            <label style={{ fontWeight: 'bold', marginTop: '8px' }}>Requirement</label>
            <textarea
              style={{ ...inputStyle, minHeight: '60px' }}
              placeholder="Control requirement..."
              value={item.requirement}
              onChange={(e) => updateExtraFinding(item.id, { requirement: e.target.value })}
              disabled={!canEdit}
            />
            <label style={{ fontWeight: 'bold', marginTop: '8px' }}>Attach Evidence (optional)</label>
            <input
              type="file"
              multiple
              onChange={(e) => {
                handleFindingFiles(item.id, e.target.files);
                e.target.value = '';
              }}
              disabled={!canEdit}
            />
            {item.files?.length ? (
              <div style={{ marginTop: '6px' }}>
                {renderFiles(item.files, (index) => removeExtraFindingFile(item.id, index))}
              </div>
            ) : null}
          </div>
        ))}
      </div>

      <div style={sectionStyle}>
        <h3>Reviewer Comment</h3>
        <textarea
          style={{ ...inputStyle, minHeight: '100px' }}
          placeholder="Provide SecDesign reviewer comments..."
          value={comment}
          onChange={(event) => setComment(event.target.value)}
          disabled={!canEdit}
        />
        <div style={{ marginTop: '8px' }}>
          <input
            type="file"
            multiple
            onChange={(e) => {
              handleCommentFiles(e.target.files);
              e.target.value = '';
            }}
            disabled={!canEdit}
          />
          {commentFiles.length ? (
            <div style={{ marginTop: '6px' }}>
              {renderFiles(commentFiles, removeCommentFile)}
            </div>
          ) : null}
        </div>
        <div style={{ ...buttonRowStyle, marginTop: '16px' }}>
          {canEdit && (
            <>
              <button type="button" style={buttonStyle} onClick={handleSaveAll}>Save</button>
              <button type="button" style={successButtonStyle} onClick={() => handleDecision('approved')}>Approve</button>
              <button type="button" style={dangerButtonStyle} onClick={() => handleDecision('denied')}>Deny</button>
              <button type="button" style={buttonStyle} onClick={handleReturnToRequestor}>Return to Requestor</button>
            </>
          )}
          {!canEdit && <p style={{ margin: 0, color: '#546e7a' }}>This page is read-only for your current role.</p>}
        </div>
      </div>
    </div>
  );
};

export default SecDesignReview;
